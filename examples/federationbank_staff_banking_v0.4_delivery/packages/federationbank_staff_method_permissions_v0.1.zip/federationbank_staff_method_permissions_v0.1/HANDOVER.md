# Handover — FederationBank Staff Method Permissions v0.1

## Accepted candidate point

v0.1 is the first executable FederationBank adapter from the generic ooRexx Access Permissions/Security Manager layer into the staff-banking architecture.

The important rule is architectural, not cosmetic:

- **Method Permission** decides whether an exact technical principal may invoke an exact method on an exact Alchemy object under Security Effect.
- **Staff Authority** independently decides whether a bank employee may perform the represented banking action.
- **Access Control** independently decides whether the principal may enter/cross the protected domain.
- **Authentication** supplies attribution/integrity evidence only.
- **Core Banking** remains final execution authority for core monetary commands.

Do not collapse these layers in a later version.

## Qualified behaviour

The v0.1 tests prove:

- the allowed exact object/method executes once;
- another object of the same class is denied;
- an explicit staff/principal binding is required;
- method admission and Staff Authority remain different types/authorities;
- valid business authority cannot bypass a technical method DENY;
- admission evidence survives persistent state round-trip with the same semantic identity;
- runtime metadata advertises the separation and enforcement capabilities.

## Continuation candidates

The next safe extensions are endpoint-specific policy provisioning and integration at actual Staff Channel ingress boundaries. Do not instrument arbitrary downstream domain methods merely because the mechanism exists; preserve narrow choke points and default-DENY policy.

Teller Cash is not rolled into this package. The supplied 20260828-191958 roll-up contains teller cash packages and `federationbank_teller_till_v0.2`, but the teller cash dependency declaration references `federationbank_teller_till_service_v0.1`, which is not present in that roll-up. Treat that as an external closure issue until the exact required service package or an intentional migration is supplied.
