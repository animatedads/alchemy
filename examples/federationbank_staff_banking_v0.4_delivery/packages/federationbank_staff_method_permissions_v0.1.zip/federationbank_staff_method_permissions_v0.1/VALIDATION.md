# Validation — FederationBank Staff Method Permissions v0.1

Qualification date: 2026-08-28

Runtime: ooRexx 5.3.0 r13196 Internal Test Version.

Dependency source: `oorexxapis(20260828-191958).zip`, SHA-256 `5885f1906dc5ae7307e6fc7d557b88d1770b0c401f5a62063b999834222d5d66`.

## Compile validation

The following package classes were compiled successfully with `rexxc`:

- `src/FederationBankStaffMethodPermissions.cls`
- `runtime/FederationBankStaffMethodPermissionsRuntimeModule.cls`
- `tests/TestSupport.cls`

## Executable suite

Result: **7/7 PASS**

1. `test_exact_object_method_permission.rex`
2. `test_same_class_other_object_denied.rex`
3. `test_staff_principal_binding_required.rex`
4. `test_business_and_method_authority_separate.rex`
5. `test_business_authority_cannot_bypass_method_permission.rex`
6. `test_durable_admission_evidence.rex`
7. `test_runtime_module.rex`

The exact-object test runs the protected agent under the actual `AlchemySecurityManager`, checks that the ingress body executes exactly once, and verifies the Access Permissions proof with the trusted key ring.

See `VALIDATION_TRANSCRIPT.txt` for the captured live run.
