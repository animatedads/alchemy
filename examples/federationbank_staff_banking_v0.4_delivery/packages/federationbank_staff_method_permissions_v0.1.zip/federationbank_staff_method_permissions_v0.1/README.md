# FederationBank Staff Method Permissions v0.1

This package places a low-level, object-and-method permission boundary alongside FederationBank Staff Authority without merging the two authorities.

It answers one narrow question:

> May this exact technical principal invoke this exact method on this exact Alchemy object under the resolved Security Effect?

It deliberately does **not** answer whether the employee is authorised to perform the banking action represented by the payload. That remains the job of FederationBank Staff Authority and, for monetary execution, the Core Banking authority that follows it.

## Authority layers

The package preserves four distinct concepts:

1. **Authentication / attribution** — evidence identifying a technical principal. It grants no authority.
2. **Access Control** — coarse permission to enter a protected domain or service boundary ("enter the building"). It is not supplied by this package.
3. **Method Permission** — exact principal × Alchemy object × class × method permission, evaluated with Security Effect and enforced by the real ooRexx Security Manager.
4. **Staff Authority** — business authority for a specific staff banking action. A method admission cannot substitute for a `FederationBankStaffAuthorityEnvelope`.

## What v0.1 implements

- Effective-dated staff-id ↔ technical-principal attribution binding.
- A concrete `FederationBankStaffMethodPermissionIngress` Alchemy object.
- Exact permission for method `ADMIT` on one specific ingress object identity.
- Security Effect resolution bound to staff/session/branch/desk/workstation/authentication-reference context.
- Default-DENY permission policy creation.
- Real `AlchemySecurityManager` enforcement using `AlchemyPermissionPolicyAdapter`.
- Cryptographically verifiable Access Permissions decision evidence using the supplied Crypto key ring/signer abstraction.
- Durable, non-bearer `FederationBankStaffMethodPermissionAdmission` evidence.
- Explicit type separation between method admission and `FederationBankStaffAuthorityEnvelope`.

## Non-goals

This package does not authenticate staff, grant building/domain Access Control, decide customer or institutional Staff Authority, grant Core Banking authority, or turn permission proofs into bearer credentials.

## Run tests

Set the dependency source directories documented by `run_tests.sh`, then run:

```sh
./run_tests.sh
```

The qualified v0.1 suite contains seven executable tests. See `VALIDATION.md` and `VALIDATION_TRANSCRIPT.txt`.
