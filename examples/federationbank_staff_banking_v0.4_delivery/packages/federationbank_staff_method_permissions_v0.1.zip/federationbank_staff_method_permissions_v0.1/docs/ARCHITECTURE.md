# Architecture — Staff Method Permissions v0.1

## Boundary model

The intended request path is:

```text
authentication evidence
        |
        v
staff-id <-> technical-principal attribution binding
        |
        +--------------------------+
        |                          |
        v                          v
Access Control                 Staff Method Permission
(domain entry)                 exact object + method
                                   |
                                   | real ooRexx Security Manager
                                   | + Security Effect
                                   v
                         non-bearer method admission
                                   |
                                   v
                         Staff Authority decision
                         (separate business authority)
                                   |
                                   v
                         Core Banking authority
                         (where monetary execution applies)
```

No arrow above means that the upstream artifact grants the downstream authority. Each boundary makes its own decision.

## Main types

### `FederationBankStaffPermissionPrincipalBinding`
An effective-dated attribution record connecting a FederationBank staff id to an Access Permissions principal id. It is evidence of correspondence only.

### `FederationBankStaffMethodPermissionIngress`
An `AlchemyObject` representing the concrete technical front door. Its protected operation is `ADMIT`. The object has a stable Alchemy object identity; permission is not class-wide.

### `FederationBankStaffMethodSecurityEffectResolver`
Builds Security Effect context for the exact invocation. It binds the principal, exact object/method and staff-session facts including branch, desk, workstation and authentication reference.

### `FederationBankStaffMethodPermissionPolicyFactory`
Produces sealed default-DENY `PermissionPolicy` instances. An allow rule can target one exact principal, one exact object identity, the ingress class, method `ADMIT`, and the exact Security Effect policy identity.

### `FederationBankStaffMethodPermissionBoundary`
Creates the Access Permissions adapter and `AlchemySecurityManager`, executes the protected agent routine under that manager, and then requires one fresh allowed decision whose principal/object/method identities match the invocation and whose proof verifies against the trusted key ring.

### `FederationBankStaffMethodPermissionAdmission`
Durable evidence that the technical invocation was admitted. It records the payload semantic identity, staff/session/principal, object and method, permission decision and policy identities, Security Effect policy/trace identities and proof metadata.

The admission explicitly states that it implies no Staff Authority, Access Control or authentication authority. It is non-bearer evidence.

### `FederationBankStaffMethodPermissionSeparation`
A small type-boundary helper used by consumers/tests to make accidental substitution of method admission for Staff Authority visible.

## Exact-object property

An allow rule for object A does not allow the same method on object B, even where A and B share the same class. This is tested with two `FederationBankStaffMethodPermissionIngress` instances.

## Business-authority property

A valid `FederationBankStaffAuthorityEnvelope` cannot bypass a DENY method-permission policy. Conversely, a valid method admission is not a Staff Authority envelope and cannot be passed as one.

## Security Effect

Security Effect is part of the permission decision context. The permission boundary does not treat a method name alone as authority. The resolved Security Effect policy/trace identities are retained in the admission evidence.

## Cryptographic evidence

Access Permissions signs/proves the permission decision through its Crypto-backed proof abstraction. The boundary verifies that proof before producing an admission. Verification proves integrity/attribution of the permission decision; it does not confer business authority.
