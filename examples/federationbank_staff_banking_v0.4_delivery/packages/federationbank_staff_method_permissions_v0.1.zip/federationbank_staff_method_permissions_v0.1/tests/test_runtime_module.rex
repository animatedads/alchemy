caps=.FederationBankStaffMethodPermissionsRuntimeModule~capabilities
.FBStaffMethodPermissionTestSupport~assertEq("0.1",.FederationBankStaffMethodPermissionsRuntimeModule~version,"runtime version")
.FBStaffMethodPermissionTestSupport~assertTrue(caps~hasItem("EXACT_METHOD_OBJECT_PERMISSION"),"exact permission capability")
.FBStaffMethodPermissionTestSupport~assertTrue(caps~hasItem("BUSINESS_AUTHORITY_SEPARATION"),"business separation capability")
say "PASS test_runtime_module"
exit 0
::requires "TestSupport.cls"
::requires "FederationBankStaffMethodPermissionsRuntimeModule.cls"
