agent=arg(1)
f=.FBStaffMethodPermissionTestSupport~fixture
business=.FBStaffMethodPermissionTestSupport~businessAuthorityEnvelope
r=f["boundary"]~admit(f["ingress"],business["action"]~semanticIdentity,agent)
.FBStaffMethodPermissionTestSupport~assertTrue(r~ok,"technical method admitted")
admission=r~value
.FBStaffMethodPermissionTestSupport~assertTrue(.FederationBankStaffMethodPermissionSeparation~isMethodAdmission(admission),"typed as method admission")
.FBStaffMethodPermissionTestSupport~assertFalse(.FederationBankStaffMethodPermissionSeparation~isBusinessAuthority(admission),"method admission not Staff Authority")
.FBStaffMethodPermissionTestSupport~assertTrue(.FederationBankStaffMethodPermissionSeparation~isBusinessAuthority(business["envelope"]),"Staff Authority envelope remains separate")
.FBStaffMethodPermissionTestSupport~assertFalse(business["envelope"]~isA(.FederationBankStaffMethodPermissionAdmission),"Staff Authority cannot masquerade as method admission")
say "PASS test_business_and_method_authority_separate"
exit 0
::requires "TestSupport.cls"
