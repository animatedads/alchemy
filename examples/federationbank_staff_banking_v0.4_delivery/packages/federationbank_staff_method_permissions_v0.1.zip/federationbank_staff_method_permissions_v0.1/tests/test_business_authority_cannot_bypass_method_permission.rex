agent=arg(1)
f=.FBStaffMethodPermissionTestSupport~fixture
business=.FBStaffMethodPermissionTestSupport~businessAuthorityEnvelope
denyPolicy=.FederationBankStaffMethodPermissionPolicyFactory~denyAllPolicy("FB-STAFF-METHOD-DENY","1")
resolver=.FederationBankStaffMethodSecurityEffectResolver~new(f["binding"],f["session"],f["snapshot"],f["framework"])
boundary=.FederationBankStaffMethodPermissionBoundary~new(f["binding"],f["session"],f["principal"],denyPolicy,f["authority"],resolver,f["ring"],.AlchemySecurityRuntimeProfile~observedR13196)
signal on syntax name denied
ignore=boundary~admit(f["ingress"],business["action"]~semanticIdentity,agent)
signal off syntax
raise syntax 88.900 array("valid Staff Authority unexpectedly bypassed method permission")
denied:
  signal off syntax
.FBStaffMethodPermissionTestSupport~assertEq(0,f["ingress"]~admissionCount,"method body blocked despite valid business authority")
.FBStaffMethodPermissionTestSupport~assertTrue(.FederationBankStaffMethodPermissionSeparation~isBusinessAuthority(business["envelope"]),"business authority itself remains valid typed evidence")
say "PASS test_business_authority_cannot_bypass_method_permission"
exit 0
::requires "TestSupport.cls"
