agent=arg(1)
f=.FBStaffMethodPermissionTestSupport~fixture
r=f["boundary"]~admit(f["ingress"],"PAYLOAD:STAFF-REQUEST-001",agent)
.FBStaffMethodPermissionTestSupport~assertTrue(r~ok,"exact ingress method allowed")
a=r~value
.FBStaffMethodPermissionTestSupport~assertEq("PAYLOAD:STAFF-REQUEST-001",a~payloadIdentity,"payload identity bound")
.FBStaffMethodPermissionTestSupport~assertEq(f["ingress"]~alchemyObjectId,a~ingressObjectId,"exact object bound")
.FBStaffMethodPermissionTestSupport~assertEq("ADMIT",a~methodName,"exact method bound")
.FBStaffMethodPermissionTestSupport~assertEq(1,f["ingress"]~admissionCount,"method body ran exactly once")
.FBStaffMethodPermissionTestSupport~assertFalse(a~businessAuthorityImplied,"method admission is not business authority")
.FBStaffMethodPermissionTestSupport~assertTrue(f["boundary"]~adapter~decisionEnvelopes[1]~verifyProof(f["ring"]),"permission proof verifies")
say "PASS test_exact_object_method_permission"
exit 0
::requires "TestSupport.cls"
