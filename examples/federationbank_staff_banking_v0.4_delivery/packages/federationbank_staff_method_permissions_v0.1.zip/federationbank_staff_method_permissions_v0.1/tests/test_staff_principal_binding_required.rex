f=.FBStaffMethodPermissionTestSupport~fixture
now=.DateTime~new
badPrincipal=.AccessPrincipal~new("PRINCIPAL:OTHER","staff-method-proof")~seal
signal on syntax name mismatch
ignore=.FederationBankStaffMethodPermissionBoundary~new(f["binding"],f["session"],badPrincipal,f["policy"],f["authority"],f["resolver"],f["ring"],.AlchemySecurityRuntimeProfile~observedR13196)
signal off syntax
raise syntax 88.900 array("mismatched technical principal unexpectedly accepted")
mismatch:
  signal off syntax
/* Authentication reference is evidence only; it did not override the explicit binding mismatch. */
.FBStaffMethodPermissionTestSupport~assertEq("AUTHN-REF-01",f["session"]~authenticationRef,"authentication evidence retained but not authority")
say "PASS test_staff_principal_binding_required"
exit 0
::requires "TestSupport.cls"
