agent=arg(1)
f=.FBStaffMethodPermissionTestSupport~fixture
other=.FederationBankStaffMethodPermissionIngress~new("STAFF-CHANNEL-OTHER","STAFF_BANKING")
signal on syntax name denied
ignore=f["boundary"]~admit(other,"PAYLOAD:OTHER",agent)
signal off syntax
raise syntax 88.900 array("same-class different object unexpectedly admitted")
denied:
  signal off syntax
.FBStaffMethodPermissionTestSupport~assertEq(0,other~admissionCount,"denied exact object method body did not run")
envs=f["boundary"]~adapter~decisionEnvelopes
.FBStaffMethodPermissionTestSupport~assertEq(1,envs~items,"one permission decision captured")
.FBStaffMethodPermissionTestSupport~assertFalse(envs[1]~decision~allowed,"different object denied")
say "PASS test_same_class_other_object_denied"
exit 0
::requires "TestSupport.cls"
