agent=arg(1)
f=.FBStaffMethodPermissionTestSupport~fixture
r=f["boundary"]~admit(f["ingress"],"PAYLOAD:DURABLE-001",agent)
.FBStaffMethodPermissionTestSupport~assertTrue(r~ok,"admission created")
a=r~value
s=a~queuePersistentState
restored=.FederationBankStaffMethodPermissionAdmission~new("x","x","x","x","x","x","x","x","x","x","x","x","x","x","x","x")
restored~queueRestoreState(s)
.FBStaffMethodPermissionTestSupport~assertEq(a~semanticIdentity,restored~semanticIdentity,"durable admission semantic identity preserved")
.FBStaffMethodPermissionTestSupport~assertFalse(restored~businessAuthorityImplied,"durable evidence remains non-bearer business authority")
say "PASS test_durable_admission_evidence"
exit 0
::requires "TestSupport.cls"
