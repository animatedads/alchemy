use strict arg ingress, payloadIdentity
return ingress~admit(payloadIdentity)
