# Changelog

## 0.1 — 2026-08-28

Initial candidate release.

- Added explicit effective-dated FederationBank staff ↔ Access Permissions principal attribution binding.
- Added exact-object `FederationBankStaffMethodPermissionIngress` Alchemy object with protected `ADMIT` method.
- Added Staff-session-aware Security Effect resolver.
- Added exact-object/method and deny-all policy factories.
- Added real ooRexx Security Manager enforcement boundary through `AlchemyPermissionPolicyAdapter`.
- Added verified cryptographic permission-decision evidence before admission issuance.
- Added durable non-bearer method-admission evidence.
- Added explicit separation from authentication, Access Control, Staff Authority and Core Banking authority.
- Added seven executable regression/architecture tests and runtime metadata.
