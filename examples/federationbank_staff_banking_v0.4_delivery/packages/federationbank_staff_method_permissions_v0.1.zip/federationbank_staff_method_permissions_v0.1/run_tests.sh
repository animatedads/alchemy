#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
: "${REXX_BIN:=rexx}"
: "${ACCESS_PERMISSIONS_SRC:?set ACCESS_PERMISSIONS_SRC}"
: "${ALCHEMY_SRC:?set ALCHEMY_SRC}"
: "${STAFF_AUTHORITY_SRC:?set STAFF_AUTHORITY_SRC}"
: "${FB_SRC:?set FB_SRC}"
: "${POLICY_SRC:?set POLICY_SRC}"
: "${SECURITY_SRC:?set SECURITY_SRC}"
: "${SECURITY_RUNTIME:?set SECURITY_RUNTIME}"
: "${LEGAL_SRC:?set LEGAL_SRC}"
: "${CIVIC_SRC:?set CIVIC_SRC}"
: "${DB_SRC:?set DB_SRC}"
: "${QUEUE_SRC:?set QUEUE_SRC}"
: "${JMS_SRC:?set JMS_SRC}"
: "${CRYPTO_SRC:?set CRYPTO_SRC}"
: "${OOREXX_LIB:?set OOREXX_LIB}"
export REXX_PATH="$HERE/src:$HERE/runtime:$HERE/tests:$ACCESS_PERMISSIONS_SRC:$ALCHEMY_SRC:$STAFF_AUTHORITY_SRC:$FB_SRC:$POLICY_SRC:$SECURITY_SRC:$SECURITY_RUNTIME:$LEGAL_SRC:$CIVIC_SRC:$DB_SRC:$QUEUE_SRC:$JMS_SRC:$CRYPTO_SRC:$OOREXX_LIB${REXX_PATH:+:$REXX_PATH}"
AGENT="$HERE/agents/staff_method_permission_agent.rex"
for t in \
  test_exact_object_method_permission.rex \
  test_same_class_other_object_denied.rex \
  test_staff_principal_binding_required.rex \
  test_business_and_method_authority_separate.rex \
  test_business_authority_cannot_bypass_method_permission.rex \
  test_durable_admission_evidence.rex \
  test_runtime_module.rex; do
  echo "== $t =="
  "$REXX_BIN" "$HERE/tests/$t" "$AGENT"
done
