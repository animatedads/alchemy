# Handover — ooRexx Access Permissions v0.1

Candidate: oorexx_access_permissions_v0.1
API: access.permissions/0.1
Date: 2026-08-28

## Architectural contract

- Security Manager enforces.
- Permissions authorizes exact method/object operations.
- Security Effect supplies deterministic security semantics and is bound into every Permission request.
- Access Control is a separate domain-entry/building gate.
- Authentication is cryptographic attribution/integrity only and grants no authority.
- Crypto proofs are evidence, never bearer authority.

## Implemented

- Separate AccessControlPolicy/Authority and PermissionPolicy/Authority.
- Exact subject × Alchemy object id × class × method permission selectors.
- Required Security Effect object/method/subject binding plus disposition, policy identity, trace and constraints.
- AlchemyPermissionPolicyAdapter plugs into the existing AlchemySecurityManager policy seam without forking Security Manager.
- Crypto v0.4 CryptoMacKeyRing/SipHash-128 attribution and policy/decision proof envelopes.
- Institutional Policy v0.8 catalog compatibility for both policy types.
- Fixed default DENY; highest priority wins; DENY wins equal-priority ties.

## Qualification

Module tests 6/6 PASS on user-supplied ooRexx 5.3.0 r13196 debug build.
Focused upstream: Alchemy Security Manager contract PASS; Security Effect deterministic policy PASS; shared Institutional Policy PASS.

## Supplied roll-up anchors

c79db6a4c58ddd3ffa9c50efc1babe7992d55b71c7e2bb57e0ba5e27a45e001e  oorexxapis(20260828-163623).zip
7683ed56ea99097226ea2f13f73305fb49919ba2ec822df2253ccfff59c6c073  alchemy_objects_v0.8.zip
c272c694d9a6b39862681c66712259947132996c048f7e369e6b1cfc7ffcfd8a  oorexx_crypto_v0.4.zip
cc299764ae7e4d5c9aab7457b46f49ba524320296ed1e85d37b74025b16700bc  institutional_policy_v0.8.zip
37661bc708f29061757d7c2ff8946fd7d63da39bec47a993e257760180bc6465  security_effect_v0.10.zip
