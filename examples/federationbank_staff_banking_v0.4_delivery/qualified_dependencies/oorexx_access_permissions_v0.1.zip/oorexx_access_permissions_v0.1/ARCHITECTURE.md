# Access Permissions v0.1 architecture

## Strict separation of responsibilities

- **Authentication attribution** proves which principal/key produced exact evidence. A valid assertion grants no access and no method permission.
- **Access Control** is coarse admission to a protected domain: permission to enter the building.
- **Permissions** is the lowest-level method authority: exact subject × exact object × method, evaluated against retained Security Effect semantics and a sealed permission policy.
- **Security Effect** supplies deterministic business-security meaning. Permission requests bind the exact Security Effect policy identity, final disposition, trace identity, and applicable constraints.
- **Alchemy Security Manager** remains the enforcement point. `AlchemyPermissionPolicyAdapter` implements its existing policy contract and delegates METHOD decisions to this module.
- **Crypto** makes policy and decision identities independently verifiable. Cryptographic MAC proofs establish provenance/integrity to holders of the trusted key ring; they do not themselves convey authority.

## Execution path

`attributed principal -> Access Control -> object reachability -> protected method attempt -> Alchemy Security Manager -> PermissionAuthority(subject, exact object, method, Security Effect, policy) -> MAC-proved decision -> Security Manager enforcement`

Access Control success never implies a method permission. A Permission ALLOW is an evaluation receipt, not a bearer capability and not a reusable substitute for a fresh current decision.

## Enforcement coverage

Alchemy Security Manager receives a METHOD checkpoint only for interpreter-protected method surfaces. A method that must be governed by this adapter must therefore remain `PROTECTED` (or use an independent method-local permission gate). Making a method public is not a permission rule; it changes the enforcement boundary and cannot be compensated for by a policy object that the interpreter never calls.

## Determinism

Policies are immutable after `seal`. The default is DENY. Matching rules select the highest numeric priority. At equal priority, DENY wins; remaining same-action ties use lexical rule id. Permission rules can bind exact Security Effect policy identity and maximum allowed disposition.

## Exact object identity

The Alchemy adapter uses `alchemyObjectId` when available and otherwise `identityHash`. A class-wide permission is possible only if policy deliberately uses a wildcard object selector. The canonical integration test authorizes one instance and proves a second object of the same class is denied.
