# Changelog

## 0.1

- Initial Access Control / attribution / Permissions module.
- Separates building/domain admission from exact method/object permission.
- Permission requests require Security Effect assessment evidence.
- Exact Security Effect policy and trace identities are retained in decisions.
- Default deny, deterministic priority, deny-wins-tie policy semantics.
- Crypto v0.4 key-ring attribution assertions and generic SipHash-128 MAC policy/decision proofs.
- Alchemy Security Manager policy adapter with retained cryptographically proved decision envelopes.
- Integration test proves one exact Alchemy object is allowed and a second instance of the same class is denied.
