# ooRexx Access Permissions v0.1

A granular, policy-driven, cryptographically provable security-authority module designed to sit alongside Alchemy Security Manager and Security Effect.

This is **not a login system**. Authentication is only cryptographic attribution/integrity. Access Control answers whether a principal may cross a domain boundary. Permissions answers whether that principal may invoke a specific method on a specific object after Security Effect semantics have been evaluated. Alchemy Security Manager enforces the result.

## Main classes

- `AccessPrincipal`, `AuthenticationAssertion`, `AuthenticationVerifier`
- `AccessControlRequest`, `AccessControlRule`, `AccessControlPolicy`, `AccessControlAuthority`
- `PermissionRequest`, `PermissionRule`, `PermissionPolicy`, `PermissionAuthority`
- `AccessPermissionsSigner`, `AccessPermissionsProof`, `AuthorizationDecisionEnvelope`
- `AlchemyPermissionPolicyAdapter`

## Important invariant

A cryptographically valid identity, policy proof, or MAC-proved ALLOW receipt is evidence. It is not itself executable authority. Current policy evaluation and Security Manager enforcement remain required.

Both policy types implement the Institutional Policy v0.8 publication protocol and can be published/resolved through `AccessControlPolicyCatalog` and `PermissionPolicyCatalog`.
