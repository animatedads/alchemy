/* ========================================================================= */
/* Native ooRexx ZIP writer, method 8 fixed-Huffman DEFLATE                  */
/*                                                                           */
/* No ADDRESS, no gzip wrapper, no zlib, no Java.                            */
/* Produces a normal ZIP archive with one file entry.                         */
/*                                                                           */
/* Usage:                                                                    */
/*   rexx native_zip_fixed_method8.rex fixed   input.txt output.zip [name]    */
/*   rexx native_zip_fixed_method8.rex literal input.txt output.zip [name]    */
/*   rexx native_zip_fixed_method8.rex store   input.txt output.zip [name]    */
/*                                                                           */
/* fixed   = raw DEFLATE method 8 with fixed Huffman and simple LZ77 matches  */
/* literal = raw DEFLATE method 8, literals only, useful for bit-writer proof */
/* store   = ZIP method 0, raw file payload, useful as a container baseline   */
/* ========================================================================= */

numeric digits 30
parse arg mode inPath outZip entryName .
mode = translate(mode)

if mode = "" | inPath = "" | outZip = "" then do
  say "Usage: rexx native_zip_fixed_method8.rex fixed|literal|store input output.zip [entry-name]"
  exit 2
end

if entryName = "" then entryName = baseName(inPath)

inputData = readBinaryFile(inPath)
select
  when mode = "STORE" then archive = buildZipSingle(entryName, inputData, 0)
  when mode = "LITERAL" then archive = buildZipSingle(entryName, inputData, 8, 0)
  when mode = "FIXED" then archive = buildZipSingle(entryName, inputData, 8, 1)
  otherwise do
    say "Unknown mode:" mode
    say "Use: fixed, literal, or store"
    exit 2
  end
end

call writeBinaryFile outZip, archive
say "OK native ZIP written:" outZip
say "entry="entryName "input_bytes="length(inputData) "archive_bytes="length(archive) "mode="mode
exit 0

/* ========================================================================= */
/* ZIP container                                                              */
/* ========================================================================= */

buildZipSingle: procedure
  numeric digits 30
  parse arg fileName, fileData, method, useMatches

  if method = 0 then compressedData = fileData
  else compressedData = deflateFixed(fileData, useMatches)

  uncompressedSize = length(fileData)
  compressedSize   = length(compressedData)
  nameLen          = length(fileName)
  crc              = calcCRC32(fileData)

  dosTime = 0
  dosDate = 33                         /* 1980-01-01 in DOS date format */

  localOffset = 0

  lfh = "504B0304"x || ,               /* local file header signature */
        le2(20)     || ,               /* version needed to extract */
        le2(0)      || ,               /* general purpose bit flag */
        le2(method) || ,               /* method 0=store, 8=deflate */
        le2(dosTime)|| ,
        le2(dosDate)|| ,
        le4(crc)    || ,
        le4(compressedSize) || ,
        le4(uncompressedSize) || ,
        le2(nameLen) || ,
        le2(0)      || ,               /* extra field length */
        fileName

  cdfh = "504B0102"x || ,              /* central directory signature */
         le2(20)     || ,              /* version made by */
         le2(20)     || ,              /* version needed */
         le2(0)      || ,              /* general purpose bit flag */
         le2(method) || ,
         le2(dosTime)|| ,
         le2(dosDate)|| ,
         le4(crc)    || ,
         le4(compressedSize) || ,
         le4(uncompressedSize) || ,
         le2(nameLen) || ,
         le2(0)      || ,              /* extra length */
         le2(0)      || ,              /* comment length */
         le2(0)      || ,              /* disk start */
         le2(0)      || ,              /* internal attributes */
         le4(0)      || ,              /* external attributes */
         le4(localOffset) || ,
         fileName

  centralOffset = length(lfh) + compressedSize
  centralSize   = length(cdfh)

  eocd = "504B0506"x || ,              /* end of central directory */
         le2(0) || le2(0) || ,
         le2(1) || le2(1) || ,
         le4(centralSize) || ,
         le4(centralOffset) || ,
         le2(0)

  return lfh || compressedData || cdfh || eocd

/* ========================================================================= */
/* Raw DEFLATE fixed-Huffman encoder                                          */
/* ========================================================================= */

deflateFixed: procedure
  numeric digits 30
  parse arg rawData, useMatches

  outBytes = ""
  currentByte = 0
  bitCount = 0

  call writeBits 3, 3                  /* BFINAL=1, BTYPE=01, emitted 1,1,0 */

  cursor = 1
  dataLen = length(rawData)
  windowSize = 32768

  do while cursor <= dataLen
    matchLen = 0
    matchDist = 0

    if useMatches \= 0 then do
      remaining = dataLen - cursor + 1
      if cursor > 1 & remaining >= 3 then do
        winStart = max(1, cursor - windowSize)
        winLen = cursor - winStart
        history = substr(rawData, winStart, winLen)
        maxLen = min(258, remaining)

        do tryLen = maxLen to 3 by -1
          probe = substr(rawData, cursor, tryLen)
          pos = lastpos(probe, history)
          if pos \= 0 then do
            matchLen = tryLen
            matchDist = (winLen - pos) + 1
            leave
          end
        end
      end
    end

    if matchLen >= 3 then do
      parse value lengthCode(matchLen) with lenSym lenExtra lenExtraBits
      call emitFixedSymbol lenSym
      if lenExtraBits > 0 then call writeBits lenExtra, lenExtraBits

      parse value distanceCode(matchDist) with distSym distExtra distExtraBits
      call writeBits bitReverse(distSym, 5), 5
      if distExtraBits > 0 then call writeBits distExtra, distExtraBits

      cursor = cursor + matchLen
    end
    else do
      ch = c2d(substr(rawData, cursor, 1))
      call emitFixedSymbol ch
      cursor = cursor + 1
    end
  end

  call emitFixedSymbol 256             /* end-of-block */
  if bitCount > 0 then outBytes = outBytes || d2c(currentByte)
  return outBytes

emitFixedSymbol: procedure expose outBytes currentByte bitCount
  numeric digits 30
  parse arg sym
  if sym <= 143 then do; code = sym + 48;  bits = 8; end
  else if sym <= 255 then do; code = sym + 256; bits = 9; end
  else if sym <= 279 then do; code = sym - 256; bits = 7; end
  else do; code = sym - 88; bits = 8; end
  rev = bitReverse(code, bits)
  call writeBits rev, bits
  return

writeBits: procedure expose outBytes currentByte bitCount
  numeric digits 30
  parse arg value, count
  v = value
  do k = 1 to count
    if (v // 2) = 1 then currentByte = currentByte + (2 ** bitCount)
    v = v % 2
    bitCount = bitCount + 1
    if bitCount = 8 then do
      outBytes = outBytes || d2c(currentByte)
      currentByte = 0
      bitCount = 0
    end
  end
  return

bitReverse: procedure
  numeric digits 30
  parse arg value, count
  v = value
  out = 0
  do k = 1 to count
    out = out * 2 + (v // 2)
    v = v % 2
  end
  return out

lengthCode: procedure
  numeric digits 30
  parse arg len
  if len = 258 then return "285 0 0"

  base.257 = 3;   extra.257 = 0
  base.258 = 4;   extra.258 = 0
  base.259 = 5;   extra.259 = 0
  base.260 = 6;   extra.260 = 0
  base.261 = 7;   extra.261 = 0
  base.262 = 8;   extra.262 = 0
  base.263 = 9;   extra.263 = 0
  base.264 = 10;  extra.264 = 0
  base.265 = 11;  extra.265 = 1
  base.266 = 13;  extra.266 = 1
  base.267 = 15;  extra.267 = 1
  base.268 = 17;  extra.268 = 1
  base.269 = 19;  extra.269 = 2
  base.270 = 23;  extra.270 = 2
  base.271 = 27;  extra.271 = 2
  base.272 = 31;  extra.272 = 2
  base.273 = 35;  extra.273 = 3
  base.274 = 43;  extra.274 = 3
  base.275 = 51;  extra.275 = 3
  base.276 = 59;  extra.276 = 3
  base.277 = 67;  extra.277 = 4
  base.278 = 83;  extra.278 = 4
  base.279 = 99;  extra.279 = 4
  base.280 = 115; extra.280 = 4
  base.281 = 131; extra.281 = 5
  base.282 = 163; extra.282 = 5
  base.283 = 195; extra.283 = 5
  base.284 = 227; extra.284 = 5

  do code = 257 to 284
    b = base.code
    e = extra.code
    span = 2 ** e
    if len >= b & len < b + span then do
      return code (len - b) e
    end
  end
  return "285 0 0"

distanceCode: procedure
  numeric digits 30
  parse arg dist
  base.0 = 1;      extra.0 = 0
  base.1 = 2;      extra.1 = 0
  base.2 = 3;      extra.2 = 0
  base.3 = 4;      extra.3 = 0
  base.4 = 5;      extra.4 = 1
  base.5 = 7;      extra.5 = 1
  base.6 = 9;      extra.6 = 2
  base.7 = 13;     extra.7 = 2
  base.8 = 17;     extra.8 = 3
  base.9 = 25;     extra.9 = 3
  base.10 = 33;    extra.10 = 4
  base.11 = 49;    extra.11 = 4
  base.12 = 65;    extra.12 = 5
  base.13 = 97;    extra.13 = 5
  base.14 = 129;   extra.14 = 6
  base.15 = 193;   extra.15 = 6
  base.16 = 257;   extra.16 = 7
  base.17 = 385;   extra.17 = 7
  base.18 = 513;   extra.18 = 8
  base.19 = 769;   extra.19 = 8
  base.20 = 1025;  extra.20 = 9
  base.21 = 1537;  extra.21 = 9
  base.22 = 2049;  extra.22 = 10
  base.23 = 3073;  extra.23 = 10
  base.24 = 4097;  extra.24 = 11
  base.25 = 6145;  extra.25 = 11
  base.26 = 8193;  extra.26 = 12
  base.27 = 12289; extra.27 = 12
  base.28 = 16385; extra.28 = 13
  base.29 = 24577; extra.29 = 13

  do code = 0 to 29
    b = base.code
    e = extra.code
    span = 2 ** e
    if dist >= b & dist < b + span then do
      return code (dist - b) e
    end
  end
  return "29" (dist - 24577) "13"

/* ========================================================================= */
/* CRC32 and basic binary helpers                                             */
/* ========================================================================= */

calcCRC32: procedure
  numeric digits 30
  parse arg data
  table. = 0
  poly = 3988292384                    /* 0xEDB88320 */

  do i = 0 to 255
    c = i
    do j = 1 to 8
      if (c // 2) = 1 then c = xor32(c % 2, poly)
      else c = c % 2
    end
    table.i = c
  end

  crc = 4294967295
  do p = 1 to length(data)
    b = c2d(substr(data, p, 1))
    idx = xor32(crc // 256, b)
    crc = xor32(crc % 256, table.idx)
  end

  return xor32(crc, 4294967295)

xor32: procedure
  numeric digits 30
  parse arg a, b
  return c2d(bitxor(d2c(a, 4), d2c(b, 4)))

le2: procedure
  numeric digits 30
  parse arg n
  return reverse(d2c(n, 2))

le4: procedure
  numeric digits 30
  parse arg n
  return reverse(d2c(n, 4))

max: procedure
  parse arg a, b
  if a > b then return a
  return b

min: procedure
  parse arg a, b
  if a < b then return a
  return b

baseName: procedure
  parse arg path
  p = path
  do while pos("/", p) > 0
    p = substr(p, pos("/", p) + 1)
  end
  do while pos("\\", p) > 0
    p = substr(p, pos("\\", p) + 1)
  end
  if p = "" then p = "file.bin"
  return p

readBinaryFile: procedure
  parse arg path
  call stream path, 'c', 'open read'
  data = ''
  do while chars(path) > 0
    n = chars(path)
    if n > 1048576 then n = 1048576
    data = data || charin(path, , n)
  end
  call stream path, 'c', 'close'
  return data

writeBinaryFile: procedure
  parse arg path, data
  call stream path, 'c', 'open write replace'
  call charout path, data
  call stream path, 'c', 'close'
  return
