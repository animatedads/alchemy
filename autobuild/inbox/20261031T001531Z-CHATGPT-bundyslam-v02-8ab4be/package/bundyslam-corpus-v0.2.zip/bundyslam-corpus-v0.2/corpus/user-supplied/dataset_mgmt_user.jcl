//UTILJOB  JOB (SYS),'DATASET UTILS',CLASS=A,MSGCLASS=A,NOTIFY=HERC01
//* ------------------------------------------------------------------
//* ALLOCATE NEW PDS DATASET
//* ------------------------------------------------------------------
//ALLOCPDS EXEC PGM=IEFBR14
//NEWPDS   DD  DSN=HERC01.TEST.PDS,
//             DISP=(NEW,CATLG,DELETE),
//             UNIT=SYSDA,
//             VOL=SER=PUB001,
//             SPACE=(CYL,(2,1,10)),
//             DCB=(RECFM=FB,LRECL=80,BLKSIZE=3120)
//* ------------------------------------------------------------------
//* UNCATALOG AND DELETE DATASET USING IEHPROGM
//* ------------------------------------------------------------------
//DELPDS   EXEC PGM=IEHPROGM,COND=(0,NE)
//SYSPRINT DD  SYSOUT=A
//DD1      DD  UNIT=SYSDA,VOL=SER=PUB001,DISP=OLD
//SYSIN    DD  *
  UNCATLG DSNAME=HERC01.TEST.PDS
  SCRATCH DSNAME=HERC01.TEST.PDS,VOL=SYSDA=PUB001,PURGE
/*
//
