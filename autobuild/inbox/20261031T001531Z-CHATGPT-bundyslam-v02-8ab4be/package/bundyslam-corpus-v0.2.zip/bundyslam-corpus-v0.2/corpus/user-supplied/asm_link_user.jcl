//ASMJOB   JOB (SYS),'ASSEMBLE & LINK',CLASS=A,MSGCLASS=A,
//             MSGLEVEL=(1,1),NOTIFY=HERC01
//* ------------------------------------------------------------------
//* STEP 1: ASSEMBLE SOURCE CODE
//* ------------------------------------------------------------------
//ASM      EXEC PGM=IFOX00,PARM='LOAD,NODECK,OBJECT'
//SYSLIB   DD  DSN=SYS1.MACLIB,DISP=SHR
//         DD  DSN=SYS1.AMODGEN,DISP=SHR
//SYSUT1   DD  UNIT=SYSDA,SPACE=(CYL,(2,1))
//SYSUT2   DD  UNIT=SYSDA,SPACE=(CYL,(2,1))
//SYSUT3   DD  UNIT=SYSDA,SPACE=(CYL,(2,1))
//SYSPRINT DD  SYSOUT=A
//SYSGO    DD  DSN=&&OBJMOD,UNIT=SYSDA,SPACE=(TRK,(5,5)),
//             DISP=(NEW,PASS)
//SYSIN    DD  *
HELLO    CSECT
         SAVE  (14,12)
         BALR  12,0
         USING *,12
         WTO   'HELLO WORLD FROM MVS 3.8J HERCULES!'
         RETURN (14,12)
         END   HELLO
/*
//* ------------------------------------------------------------------
//* STEP 2: LINK-EDIT OBJECT TO LOAD LIBRARY
//* ------------------------------------------------------------------
//LKED     EXEC PGM=IEWL,PARM='XREF,LIST,LET',COND=(4,LT,ASM)
//SYSLIN   DD  DSN=&&OBJMOD,DISP=(OLD,DELETE)
//SYSLMOD  DD  DSN=HERC01.LOADLIB(HELLO),DISP=SHR
//SYSUT1   DD  UNIT=SYSDA,SPACE=(CYL,(1,1))
//SYSPRINT DD  SYSOUT=A
//
