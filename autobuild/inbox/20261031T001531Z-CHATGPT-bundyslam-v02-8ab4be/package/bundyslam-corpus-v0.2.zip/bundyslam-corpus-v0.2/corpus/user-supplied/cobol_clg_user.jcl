//COBJOB   JOB (SYS),'COBOL COMPILE',CLASS=A,MSGCLASS=A,
//             MSGLEVEL=(1,1),NOTIFY=HERC01
//* ------------------------------------------------------------------
//* STEP 1: COMPILE COBOL SOURCE
//* ------------------------------------------------------------------
//COB      EXEC PGM=IKFCBL00,PARM='LOAD,SUPMAP,SIZE=2048K'
//SYSPRINT DD  SYSOUT=A
//SYSUT1   DD  UNIT=SYSDA,SPACE=(CYL,(2,1))
//SYSUT2   DD  UNIT=SYSDA,SPACE=(CYL,(2,1))
//SYSUT3   DD  UNIT=SYSDA,SPACE=(CYL,(2,1))
//SYSUT4   DD  UNIT=SYSDA,SPACE=(CYL,(2,1))
//SYSLIN   DD  DSN=&&LOADSET,DISP=(MOD,PASS),UNIT=SYSDA,
//             SPACE=(TRK,(3,3))
//SYSIN    DD  *
       IDENTIFICATION DIVISION.
       PROGRAM-ID. HELLOC.
       PROCEDURE DIVISION.
       MAIN-LINE.
           DISPLAY 'HELLO FROM MVS COBOL'.
           STOP RUN.
/*
//* ------------------------------------------------------------------
//* STEP 2: LINK EDIT
//* ------------------------------------------------------------------
//LKED     EXEC PGM=IEWL,PARM='LIST,XREF,LET',COND=(4,LT,COB)
//SYSLIB   DD  DSN=SYS1.COBLIB,DISP=SHR
//SYSLIN   DD  DSN=&&LOADSET,DISP=(OLD,DELETE)
//SYSLMOD  DD  DSN=&&GOSET(GO),DISP=(NEW,PASS),UNIT=SYSDA,
//             SPACE=(CYL,(1,1,1))
//SYSUT1   DD  UNIT=SYSDA,SPACE=(CYL,(1,1))
//SYSPRINT DD  SYSOUT=A
//* ------------------------------------------------------------------
//* STEP 3: RUN THE PROGRAM
//* ------------------------------------------------------------------
//GO       EXEC PGM=*.LKED.SYSLMOD,COND=((4,LT,COB),(4,LT,LKED))
//SYSPRINT DD  SYSOUT=A
//
