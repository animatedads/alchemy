/* Test against the documented current SlamStore interface with a spy.
 * This is an interface test, not a test of an actual SQLite database. */
d = .BundySlam~new('MVS-3.8J', 'fixture')
d~feedCard('//J JOB CLASS=A,')
d~feedCard('//             MSGCLASS=A')
d~feedCard('//S EXEC PGM=IEFBR14')
d~finish
store = .SpyStore~new
hash = copies('A',64)
uid = .BundySlamBridge~new~ingest(d,store,hash)
call ok 'unit inserted', uid == 1
call ok 'all card and statement instances', store~instances~items == 5
call ok '3 card instances before 2 statement instances', store~instances[4]['LINE'] == 1
call ok 'card and statement edges', store~edges~items == 7
call ok 'continuation recognised as shape', store~shapeNames~hasIndex('BUNDY.CARD.CONTINUATION')
call ok 'statement JOB retained as shape', store~shapeNames~hasIndex('BUNDY.STATEMENT.JOB')
call ok 'no claim of TESTED', store~lessons == 0
call ok 'hash included in immutable signature', pos(hash, store~signature) > 0
call ok 'repeat signature recognised', .BundySlamBridge~new~ingest(d,store,hash) == 0
say 'BUNDY-SLAM BRIDGE: 9 / 9 PASS'
exit 0
ok: procedure
  parse arg what, yes
  if \yes then do
    say 'FAIL:' what
    exit 1
  end
  return
::class SpyStore public
::attribute instances get
::attribute edges get
::attribute shapeNames get
::attribute signature get
::attribute lessons get
::method init
  expose instances edges shapeNames signature lessons
  instances = .array~new
  edges = .array~new
  shapeNames = .directory~new
  signature = ''
  lessons = 0
::method unitInsert
  expose signature
  use arg path, kind, owner, selector, line, sig
  if sig == signature then return 0
  signature = sig
  return 1
::method markerId
  use arg context, side
  return context || '/' || side
::method shapeId
  expose shapeNames
  use arg kind, family, canonical
  shapeNames[canonical] = .true
  return canonical
::method instanceInsert
  expose instances
  use arg uid, parent, sequence, node, line, repeat, binding, consts
  e = .directory~new
  e['LINE'] = line
  e['NODE'] = node
  e['BINDING'] = binding
  instances~append(e)
  return instances~items
::method edgeAdd
  expose edges
  use arg prev, next, n = 1
  edges~append(prev || ' -> ' || next)
::requires '../src/BundySlam.cls'
::requires '../src/BundySlamBridge.cls'
