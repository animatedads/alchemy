/* BundySlam regression: run with ooRexx 5.3.0 r13196. */
n = 0
fail = 0
sources = .array~of('asm_link_user.jcl','cobol_clg_user.jcl','dataset_mgmt_user.jcl')
do f over sources
  p = '../corpus/user-supplied/' || f
  d = .BundySlam~new('MVS-3.8J', p)
  d~loadFile(p)
  d~finish
  call test 'raw round-trip 'f, d~roundTrip == d~bytes
  call test 'physical cards seen 'f, d~cards~items > 10
  call test 'logical statements seen 'f, d~statements~items > 5
  call test 'has JOB 'f, d~statements[1]['OP'] == 'JOB'
  call test 'deck ends, not in data 'f, \d~memory['INSTREAM']
  do c over d~cards
    call test 'physical index 'f' 'c['INDEX'], c['INDEX'] > 0
  end
  if f == 'asm_link_user.jcl' then do
    call test 'assembly 2 steps', countOp(d, 'EXEC') == 2
    call test 'assembler in-stream data', countKind(d, 'DATA') >= 7
    call test 'assembly continuation cards', countKind(d, 'CONTINUATION') >= 2
    call test 'nested language not parsed as JCL', \hasStatement(d,'HELLO')
  end
  if f == 'cobol_clg_user.jcl' then do
    call test 'cobol 3 steps', countOp(d, 'EXEC') == 3
    call test 'COBOL in-stream data', countKind(d, 'DATA') >= 5
    call test 'nested PARM quote leaves correct structure', countOp(d, 'DD') >= 8
  end
  if f == 'dataset_mgmt_user.jcl' then do
    call test 'dataset management 2 steps', countOp(d, 'EXEC') == 2
    call test 'SYSIN utility control cards are data', countKind(d, 'DATA') == 2
    call test 'SCRATCH is not a JCL op', \hasStatement(d, 'SCRATCH')
  end
end

/* Position and line-endings are not to be normalized. */
d = .BundySlam~new
d~feedBytes('//JOB1 JOB 1' || '0d0a'x || '//S1 EXEC PGM=X' || '0a'x || '//')
d~finish
call test 'mixed CRLF/LF/no EOL round-trip', d~roundTrip == d~bytes
call test 'EOL CRLF', d~cards[1]['EOL'] == '0d0a'x
call test 'EOL LF', d~cards[2]['EOL'] == '0a'x
call test 'EOL absent', d~cards[3]['EOL'] == ''

/* Memory carried between physical cards, not inferred after scan. */
d = .BundySlam~new
d~feedCard('//T1 JOB ,CLASS=A,')
call test 'pending continuation', d~memory['PENDING']
call test 'job scope in pending statement', d~memory['JOB'] == 'T1'
d~feedCard('//             MSGCLASS=A')
call test 'continuation completed', \d~memory['PENDING']
call test 'one logical JOB', d~statements~items == 1
call test 'JOB 2 physical cards', d~statements[1]['CARDS']~items == 2
call test 'operands combined', pos('CLASS=A,MSGCLASS=A',d~statements[1]['OPERANDS']) > 0
call test 'case insensitive physical statement recognition', d~statements[1]['OP'] == 'JOB'

/* DD concatenation is a new unnamed DD statement, not a continuation. */
d~feedCard('//S1 EXEC PGM=IFOX00')
d~feedCard('//SYSLIB DD DSN=SYS1.MACLIB,DISP=SHR')
d~feedCard('//         DD DSN=SYS1.AMODGEN,DISP=SHR')
call test 'two DD statements', countOp(d,'DD') == 2
call test 'unnamed DD has SYSLIB context', d~statements[4]['DD'] == 'SYSLIB'
call test 'unnamed DD has blank name', d~statements[4]['NAME'] == ''
call test 'current step preserved', d~memory['STEP'] == 'S1'

/* Missing continuation must produce a diagnostic; never silently accept. */
b = .BundySlam~new
b~feedCard('//X JOB ,CLASS=A,')
b~feedCard('//S1 EXEC PGM=IEFBR14')
b~finish
call test 'interrupted continuation reported', diagnostic(b,'CONTINUATION_INTERRUPTED')
call test 'new EXEC still represented', countOp(b,'EXEC') == 1

b = .BundySlam~new
b~feedCard('//X JOB ,CLASS=A,')
b~finish
call test 'unfinished continuation at EOF reported', diagnostic(b,'CONTINUATION_AT_EOF')

b = .BundySlam~new
b~feedCard('//X JOB ,CLASS=A,')
b~feedCard('// XXXNOTBLANK,CLASS=A')
b~finish
call test 'bad continuation position reported', diagnostic(b,'CONTINUATION_POSITION')

/* In-stream records MUST NOT become JOB/EXEC/DD statements. */
b = .BundySlam~new
b~feedCard('//X JOB CLASS=A')
b~feedCard('//S EXEC PGM=IKFCBL00')
b~feedCard('//SYSIN DD *')
b~feedCard('//NOTREAL EXEC PGM=FALSE')
b~finish
call test 'JCL // boundary closes default DD *', \b~memory['INSTREAM']
call test 'JCL after // resumes statement', countOp(b,'EXEC') == 2

b = .BundySlam~new
b~feedCard('//X JOB CLASS=A')
b~feedCard('//S EXEC PGM=IKFCBL00')
b~feedCard('//SYSIN DD *')
b~feedCard('        DD EXEC JOB COND=FALSE')
b~feedCard('/*')
b~finish
call test 'data contains misleading keywords', countOp(b,'EXEC') == 1
call test 'data card preserved', countKind(b,'DATA') == 1
call test 'data delim is separate card', countKind(b,'DATA_END') == 1

/* Only prior observed RCs are admissible, no inferred success. */
b = .BundySlam~new
rc = .directory~new
call test 'missing RC is unknown', b~evaluateCond('COND=(4,LT,ASM)', rc) == 'UNKNOWN'
rc['ASM'] = 0
call test 'COND 4 LT 0 false: execute', b~evaluateCond('COND=(4,LT,ASM)', rc) == 'EXECUTE'
rc['ASM'] = 8
call test 'COND 4 LT 8 true: skip', b~evaluateCond('COND=(4,LT,ASM)', rc) == 'SKIP'
rc['ASM'] = 4
call test 'COND 4 LT 4 false', b~evaluateCond('COND=(4,LT,ASM)', rc) == 'EXECUTE'
rc['COB'] = 0
rc['LKED'] = 8
call test 'COND double any true skip', b~evaluateCond('COND=((4,LT,COB),(4,LT,LKED))',rc) == 'SKIP'
rc['LKED'] = 0
call test 'COND double both false execute', b~evaluateCond('COND=((4,LT,COB),(4,LT,LKED))',rc) == 'EXECUTE'
rc2 = .directory~new
rc2['COB'] = 0
call test 'COND unknown secondary stays unknown', b~evaluateCond('COND=((4,LT,COB),(4,LT,LKED))',rc2) == 'UNKNOWN'
call test 'COND bad operator refused', b~evaluateCond('COND=(4,WRONG,ASM)',rc) == 'UNKNOWN'
rc['ASM'] = 0
call test 'COND 0 NE all zero execute', b~evaluateCond('COND=(0,NE)',rc) == 'EXECUTE'
rc['ASM'] = 8
call test 'COND 0 NE any nonzero skip', b~evaluateCond('COND=(0,NE)',rc) == 'SKIP'

/* The delimiter belongs to the DD stream and is not a JCL statement. */
b = .BundySlam~new
b~feedCard('//X JOB CLASS=A')
b~feedCard('//S EXEC PGM=IEHPROGM')
b~feedCard('//SYSIN DD DATA')
b~feedCard('//FAKE EXEC PGM=FALSE')
b~feedCard('SCRATCH DSNAME=TEST.FILE')
b~feedCard('/*')
b~finish
call test 'DD DATA keeps slash slash as data', countKind(b, 'DATA') == 2
call test 'DD DATA does not make fake EXEC', countOp(b, 'EXEC') == 1
call test 'IEHPROGM SCRATCH flagged in data', eventPresent(b, 'effect.utility.control.candidate')
call test 'IEHPROGM program review', eventPresent(b, 'effect.program.candidate')

b = .BundySlam~new
b~feedCard('//X JOB CLASS=A')
b~feedCard('//S EXEC PGM=PGM')
b~feedCard('//SYSIN DD *,DLM=AA')
b~feedCard('/*')
b~feedCard('HELLO')
b~feedCard('AA')
b~finish
call test 'custom DLM preserves slash star as data', countKind(b, 'DATA') == 2
call test 'custom DLM ends AA stream', countKind(b, 'DATA_END') == 1
call test 'custom DLM does not leak stream at EOF', \b~memory['INSTREAM']

b = .BundySlam~new('MVS-3.8J','<memory>','JES3')
b~feedCard('//X JOB CLASS=A')
b~feedCard('//S EXEC PGM=PGM')
b~feedCard('//SYSIN DD *')
b~feedCard('//FAKE EXEC PGM=FALSE')
b~feedCard('/*')
b~finish
call test 'JES3 DD star // stays data until delimiter', countKind(b,'DATA') == 1
call test 'JES3 DD star no extra EXEC', countOp(b,'EXEC') == 1

b = .BundySlam~new
b~feedCard('//X JOB CLASS=A')
b~feedCard('//S EXEC PGM=PGM')
b~feedCard('//SYSIN DD DATA,DLM=AA')
b~feedCard('//FAKE EXEC PGM=FALSE')
b~feedCard('/*')
b~feedCard('AA')
b~finish
call test 'custom DATA DLM keeps JCL-like source as data', countKind(b,'DATA') == 2
call test 'custom DATA DLM closes', countKind(b,'DATA_END') == 1
call test 'custom DATA DLM has only one exec', countOp(b,'EXEC') == 1

b = .BundySlam~new
b~feedCard('//X JOB CLASS=A')
b~feedCard('//S EXEC PGM=PGM')
b~feedCard('//SYSIN DD *,DLM=LONG')
b~feedCard('/*')
b~finish
call test 'unsupported longer DLM identified', diagnostic(b,'DLM_UNRESOLVED')
call test 'unsupported longer DLM not silently closed', diagnostic(b,'INSTREAM_AT_EOF')

b = .BundySlam~new
b~feedCard('//X JOB CLASS=A')
b~feedCard('//SYM SET A=B')
b~finish
call test 'modern-only syntax marked unqualified on MVS', diagnostic(b, 'RELEASE_NOT_QUALIFIED')

b = .BundySlam~new('zOS-modern')
b~feedCard('//X JOB CLASS=A')
b~feedCard('//SYM SET A=B')
b~finish
call test 'modern syntax is not flagged by MVS rule', \diagnostic(b, 'RELEASE_NOT_QUALIFIED')

say 'BUNDYSLAM:' n-fail '/' n 'PASS; failures='fail
if fail > 0 then exit 1
exit 0

test: procedure expose n fail
  parse arg what, yes
  n += 1
  if yes then return
  fail += 1
  say 'FAIL:' what
  return

countOp: procedure
  use arg deck, op
  x = 0
  do st over deck~statements
    if st['OP'] == op then x += 1
  end
  return x
countKind: procedure
  use arg deck, kind
  x = 0
  do c over deck~cards
    if c['KIND'] == kind then x += 1
  end
  return x
hasStatement: procedure
  use arg deck, name
  do st over deck~statements
    if st['NAME'] == name then return .true
  end
  return .false
eventPresent: procedure
  use arg deck, kind
  do e over deck~events
    if e['KIND'] == kind then return .true
  end
  return .false
diagnostic: procedure
  use arg deck, code
  do o over deck~diagnostics
    if o['CODE'] == code then return .true
  end
  return .false
::requires '../src/BundySlam.cls'
