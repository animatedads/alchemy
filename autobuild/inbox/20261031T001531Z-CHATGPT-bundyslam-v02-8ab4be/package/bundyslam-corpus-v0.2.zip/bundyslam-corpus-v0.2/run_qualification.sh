#!/usr/bin/env sh
set -eu
here=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
REXX=${REXX:-rexx}
(cd "$here/tests" && "$REXX" test_bundyslam.rex && "$REXX" test_bridge.rex)
(cd "$here" && python3 -m unittest discover -s tools/tests -v)
(cd "$here/bin" && "$REXX" bundyslam.rex audit ../corpus/user-supplied/asm_link_user.jcl)
