#!/usr/bin/env python3
"""Seed raw-card evidence audit; deliberately NOT a validator or substitute for SLAM.

Any status returned is observation-only. This script cannot certify JCL syntax or
operational compatibility. Do not submit any job based on this report alone.
"""
import argparse
from pathlib import Path
import json
import re

DANGEROUS = re.compile(r'\b(SCRATCH|UNCATLG|DELETE|FORMAT|PURGE|RESTORE|INITIALIZE|ERASE|ICKDSF|IEHPROGM)\b', re.I)


def audit_bytes(raw, name='<bytes>'):
    cards = []
    pending = False
    in_data = False
    current_step = None
    current_dd = None
    current_job = None
    observations = []
    for line_no, line in enumerate(raw.splitlines(keepends=True), 1):
        card = line.rstrip(b'\r\n')
        text = card.decode('latin-1')
        kind = 'UNCLASSIFIED'
        if len(card) > 80:
            observations.append({'line': line_no, 'kind': 'PHYSICAL_CARD_OVER_80', 'columns': len(card)})
        if in_data:
            if text.startswith('/*'):
                kind = 'INSTREAM_DELIMITER'
                in_data = False
            elif text.startswith('//') and not text.startswith('//*'):
                kind = 'INSTREAM_POSSIBLE_JCL_BOUNDARY'
                observations.append({'line': line_no, 'kind': 'INSTREAM_SLASH_BOUNDARY_REQUIRES_DLM_POLICY'})
                in_data = False
            else:
                kind = 'INSTREAM_DATA'
        if kind == 'UNCLASSIFIED':
            if text.startswith('//*'):
                kind = 'JCL_COMMENT'
            elif text.startswith('/*'):
                kind = 'JES_CONTROL_OR_DELIMITER'
            elif text == '//' or (text.startswith('//') and not text[2:].strip()):
                kind = 'JCL_NULL'
                if pending:
                    observations.append({'line': line_no, 'kind': 'EXPECTED_CONTINUATION_NOT_RECEIVED'})
                    pending = False
            elif text.startswith('//'):
                # Parsing only job/step/dd token boundaries here, not full JCL expressions.
                kind = 'JCL_CARD'
                card_area = text[2:71]  # col 3..71; 72 is a separate indicator
                m = re.match(r'\s*(\S+)\s+(JOB|EXEC|DD)\b(.*)', card_area, re.I)
                if m:
                    label, op, operand = m.groups()
                    op = op.upper()
                    if pending:
                        observations.append({'line': line_no, 'kind': 'EXPECTED_CONTINUATION_NOT_RECEIVED'})
                    if op == 'JOB':
                        current_job, current_step, current_dd = label, None, None
                    elif op == 'EXEC':
                        current_step, current_dd = label, None
                    elif op == 'DD':
                        current_dd = label
                        if re.match(r'\s+\*\s*(?:$|,)', operand):
                            in_data = True
                            kind = 'INSTREAM_OPEN'
                    pending = False
                elif pending:
                    kind = 'JCL_CONTINUATION'
                    pending = False
                else:
                    kind = 'JCL_UNRESOLVED_CARD'
                if not in_data:
                    # Only a conservative signal; comments, apostrophes, and
                    # symbolic substitution need target-specific full parsing.
                    meaningful = card_area.rstrip()
                    if meaningful.endswith(',') or (len(card) >= 72 and text[71] not in ' '):
                        pending = True
            else:
                kind = 'NON_JCL_CARD'
        if DANGEROUS.search(text) and kind not in ('JCL_COMMENT',):
            observations.append({'line': line_no, 'kind': 'DANGEROUS_TOKEN_REVIEW',
                                 'token': DANGEROUS.search(text).group(0).upper()})
        cards.append({'line': line_no, 'length': len(card), 'kind': kind,
                      'columns_1_2': text[:2], 'column_72': text[71:72],
                      'columns_73_80': text[72:80], 'job': current_job,
                      'step': current_step, 'dd': current_dd,
                      'pending_continuation': pending, 'in_stream_data': in_data})
    if pending:
        observations.append({'line': len(cards), 'kind': 'UNTERMINATED_CONTINUATION'})
    if in_data:
        observations.append({'line': len(cards), 'kind': 'UNTERMINATED_INSTREAM_DATA'})
    return {'schema': 'bundyslam.seed.card-audit/0.1', 'file': name, 'card_count': len(cards),
            'cards': cards, 'observations': observations,
            'qualification': 'NOT_A_JCL_VALIDATOR'}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('path', type=Path)
    p.add_argument('--json', action='store_true')
    a = p.parse_args()
    paths = sorted(a.path.glob('*.jcl')) if a.path.is_dir() else [a.path]
    reports = [audit_bytes(path.read_bytes(), str(path)) for path in paths]
    if a.json:
        print(json.dumps(reports, indent=2))
    else:
        for report in reports:
            print(f"{report['file']} {report['card_count']} cards; "
                  f"{len(report['observations'])} observations; {report['qualification']}")
            for v in report['observations']:
                print(f"  {v['line']}: {v['kind']}")
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
