import sys
import unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from audit_seed import audit_bytes
from acquire import candidates


class SeedAuditTests(unittest.TestCase):
    def test_user_fixtures_have_instream_delimiters(self):
        root = Path(__file__).resolve().parents[2] / 'corpus/user-supplied'
        for filename in ('asm_link_user.jcl', 'cobol_clg_user.jcl', 'dataset_mgmt_user.jcl'):
            with self.subTest(filename=filename):
                r = audit_bytes((root / filename).read_bytes())
                self.assertGreater(r['card_count'], 10)
                self.assertEqual(r['qualification'], 'NOT_A_JCL_VALIDATOR')
                self.assertTrue(any(x['kind'] == 'INSTREAM_DELIMITER' for x in r['cards']))

    def test_continuation_scope(self):
        raw = b'//A JOB (X),CLASS=A,\n//       MSGCLASS=A\n//S EXEC PGM=IEFBR14\n//D DD DUMMY\n//\n'
        r = audit_bytes(raw)
        self.assertEqual([x['kind'] for x in r['cards'][:2]], ['JCL_CARD', 'JCL_CONTINUATION'])
        self.assertEqual(r['cards'][3]['step'], 'S')
        self.assertEqual(r['cards'][3]['dd'], 'D')
        self.assertFalse(any(o['kind'] == 'EXPECTED_CONTINUATION_NOT_RECEIVED' for o in r['observations']))

    def test_invalid_continuation_is_observed_not_repaired(self):
        r = audit_bytes(b'//A JOB (X),CLASS=A,\n//S EXEC PGM=IEFBR14\n')
        self.assertTrue(any(o['kind'] == 'EXPECTED_CONTINUATION_NOT_RECEIVED' for o in r['observations']))

    def test_fixed_card_columns_are_preserved(self):
        raw = ('//A JOB (X)'+ ' ' * 60 + 'X' + '12345678').encode('ascii') + b'\n'
        r = audit_bytes(raw)
        self.assertEqual(r['cards'][0]['column_72'], 'X')
        self.assertEqual(r['cards'][0]['columns_73_80'], '12345678')

    def test_template_not_executable_jcl(self):
        self.assertEqual(candidates(Path('job_asm_clg.JESI'), b'//JOB JOB ...\n'), 'template')
        self.assertEqual(candidates(Path('run.jcl.j2'), b'//JOB JOB ...\n'), 'template')

    def test_pds_txt_classified_on_first_card(self):
        self.assertEqual(candidates(Path('MYJOB.txt'), b'//MYJOB JOB (X)\n//S EXEC PGM=IEFBR14\n'), 'jcl_by_content')

    def test_destructive_input_not_for_submission(self):
        r = audit_bytes(b'//J JOB (X)\n//S EXEC PGM=IEHPROGM\n//SYSIN DD *\n SCRATCH DSNAME=X\n/*\n')
        self.assertTrue(any(x['kind'] == 'DANGEROUS_TOKEN_REVIEW' for x in r['observations']))


if __name__ == '__main__':
    unittest.main()
