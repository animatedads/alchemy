#!/usr/bin/env python3
"""Pin, fetch and inventory candidate JCL source repositories. NOT a JCL parser.

No network operations except in the explicit `fetch` subcommand. Source files are
kept at their original bytes in per-source Git checkouts; index is metadata only.
"""
import argparse
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
SOURCES = ROOT / 'sources.json'
JCL_NAME = re.compile(r'\.(?:jcl|job|proc|prc)$', re.I)
TEMPLATE_NAME = re.compile(r'\.(?:jesi|j2|jinja2|template|tmpl)$', re.I)
TEXT_NAME = re.compile(r'\.(?:txt|cntl|ctl)$', re.I)


def candidates(source, data):
    """Conservative discovery, not any assertion of executable correctness."""
    if b'\x00' in data[:4096]:
        return None
    name = source.name
    if TEMPLATE_NAME.search(name) or re.search(r'\.jcl\.(?:j2|template|tmpl)$', name, re.I):
        return 'template'
    if JCL_NAME.search(name):
        return 'jcl_named'
    if not TEXT_NAME.search(name) and source.suffix:
        return None
    # Many mainframe source control dumps contain PDS cards in .txt members.
    # Ignore leading blank lines and recognizable non-JCL comments.
    for line in data.splitlines()[:25]:
        line = line.lstrip(b'\xef\xbb\xbf')
        if not line.strip():
            continue
        if line.startswith((b'//*', b'//', b'/*JOBPARM')):
            return 'jcl_by_content'
        if not line.startswith((b'#', b';', b'*')):
            break
    return None


def sh(*args, cwd=None):
    subprocess.run(args, cwd=cwd, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)


def acquire(s, dest):
    repo = s['repo']
    pin = s['commit']
    target = dest / repo.replace('/', '__')
    if not target.exists():
        target.mkdir(parents=True)
        sh('git', 'init', '-q', str(target))
        sh('git', 'remote', 'add', 'origin', f'https://github.com/{repo}.git', cwd=target)
    if not (target / '.git').exists():
        raise RuntimeError(f'Existing non-Git directory: {target}')
    try:
        head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=target, stderr=subprocess.DEVNULL).decode().strip()
    except subprocess.CalledProcessError:
        head = None
    if head != pin:
        sh('git', 'fetch', '--depth=1', 'origin', pin, cwd=target)
        sh('git', 'checkout', '--detach', '--force', pin, cwd=target)
    head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=target).decode().strip()
    if head != pin:
        raise RuntimeError(f'Pin mismatch: {repo} requested={pin} got={head}')
    return target


def index(sources, dest, out):
    out.parent.mkdir(parents=True, exist_ok=True)
    n = 0
    with out.open('w', encoding='utf-8', newline='\n') as target:
        for s in sources:
            repo = s['repo']
            checkout = dest / repo.replace('/', '__')
            if not checkout.is_dir():
                print(f'SKIP not fetched: {repo}', file=sys.stderr)
                continue
            head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=checkout).decode().strip()
            if head != s['commit']:
                raise RuntimeError(f'Not pinned: {repo} HEAD={head}')
            for path in sorted(checkout.rglob('*')):
                if not path.is_file() or '.git' in path.relative_to(checkout).parts or path.is_symlink():
                    continue
                raw = path.read_bytes()
                classification = candidates(path, raw)
                if classification is None:
                    continue
                record = {
                    'source_repo': repo, 'source_commit': head,
                    'relative_path': path.relative_to(checkout).as_posix(),
                    'sha256': hashlib.sha256(raw).hexdigest(),
                    'bytes': len(raw), 'candidate_kind': classification,
                    'license': s['license'], 'acquisition_tier': s['tier'],
                    'dialect_claim': s['dialect'], 'execution_status': 'UNQUALIFIED',
                    'template_needs_expansion': classification == 'template',
                    'redistribution_review_required': s['tier'] == 'reference-only',
                }
                target.write(json.dumps(record, ensure_ascii=True, sort_keys=True) + '\n')
                n += 1
    return n


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('action', choices=['list', 'fetch', 'index'])
    p.add_argument('--dest', type=Path, default=ROOT / 'corpus/upstream')
    p.add_argument('--out', type=Path, default=ROOT / 'results/catalog.jsonl')
    p.add_argument('--optional', action='store_true', help='include GPL-licensed optional material')
    p.add_argument('--reference-only', action='store_true', help='fetch sources for review; not a reuse licence')
    a = p.parse_args()
    manifest = json.loads(SOURCES.read_text(encoding='utf-8'))
    sources = [s for s in manifest['sources'] if s['tier'] == 'import' or
               (s['tier'] == 'optional' and a.optional) or
               (s['tier'] == 'reference-only' and a.reference_only)]
    if a.action == 'list':
        for s in sources:
            print(f"{s['repo']:58} {s['tier']:14} {s['dialect']:13} {s['commit']}")
    elif a.action == 'fetch':
        for s in sources:
            try:
                path = acquire(s, a.dest)
                print(f'PINNED {s["repo"]} => {path}')
            except Exception as exc:
                print(f'ERROR {s["repo"]}: {exc}', file=sys.stderr)
                return 1
    else:
        print(f'INDEXED {index(sources, a.dest, a.out)} candidates => {a.out}')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
