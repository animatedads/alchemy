# BundySlam candidate JCL corpus and ooRexx card engine v0.2

**Status: source discovery, reproducible acquisition, 3 unqualified user-supplied fixtures, and a tested ooRexx card-memory engine. This is not a proven or fully downloaded execution corpus.** BundySlam is intended to be an ooRexx/SLAM specialist, not a wrapper around a general LLM. The Python utilities perform acquisition/indexing **only**; `src/BundySlam.cls` implements the first physical-card memory and statement assembler in ooRexx, with `src/BundySlamBridge.cls` exporting candidate evidence into the known SLAM store interface. See `docs/DEV2.md` for exact qualification limits.

## Use

```
python3 tools/acquire.py list
python3 tools/acquire.py fetch --dest corpus/upstream
python3 tools/acquire.py index --dest corpus/upstream --out results/catalog.jsonl
python3 tools/audit_seed.py corpus/user-supplied --json
python3 -m unittest discover -s tools/tests -v
(cd tests && rexx test_bundyslam.rex)
(cd tests && rexx test_bridge.rex)
(cd bin && rexx bundyslam.rex audit ../corpus/user-supplied/asm_link_user.jcl)
```

`fetch` requires Git and network access; commits are pinned by full Git SHA. The included package does **not** pre-fetch GitHub contents. The normal import tier excludes GPL-licensed, unlicensed and otherwise reference-only repos. `--optional` includes the GPL fixture for locally reviewed use; `--reference-only` requires an explicit choice and **does not grant redistribution permission**. Every indexed candidate records original bytes SHA-256, source repo, pinned revision, path, classification, licence, and dialect, without rewriting columns/line endings. Treat `jcl.j2`, `.JESI` and `*.jcl.template` as **templates**, not executable JCL. Do not silently convert them to passing JCL.

## Core rule

Three target profiles: `MVS-3.8J`, `zOS-modern`, `unqualified`. NEVER transfer `// IF/THEN`, `SET`, `JCLLIB` or other modern constructs into an MVS/3.8J job merely because they appeared in an IBM z/OS manual. `CLASS`, `MSGCLASS`, `NOTIFY`, available compilers, catalogues, unit names, and datasets are installation/site settings, not global JCL defaults. `IFOX00` is Assembler XF on MVS 3.8J, even when a fixture's title says "Assembler F".

## Acceptance ladder

1. **Raw corpus**: exact bytes, pinned source commit, rights, version/site tags, and independent per-file SHA-256.
2. **Card/grammar**: full source positions and columns, continued operands, comments, instream data, `/*` delimiter, symbolic expressions and replacement, JOB/EXEC/DD/PROC/PEND as available in target release.
3. **Semantic constraints**: per-release grammar, procedure and DD overrides, in-stream records, DSN/VOL/UNIT/DCB/SPACE/DISP interactions, temporary datasets and step references, JES conventions, program/utility availability and COND bypass semantics.
4. **Safety**: classify SCRATCH/DELETE/UNCATLG/FORMAT/RESTORE/PROD targets; require an execution policy and explicit permission. Never send automatically through socket reader; no defaults to live volumes. Strip credential-bearing or environment-sensitive material from training/export.
5. **Execution**: submit only to an approved isolated Hercules MVS 3.8J instance; collect JES messages, return codes, allocation outcomes, spool, state side effects, and job ID. Record a durable result, not just "JCL accepted".
6. **Mutation bench**: create controlled invalid variants; error localisation, minimal repair, no destructive command introduction, byte-preserving round-trip, and rerun. Hold entire application/job families out of training for independent qualification.

## Initial donated fixtures

- `asm_link_user.jcl` — IFOX00 assemble/link candidate. *Unverified*: assembler/options, SYSGO output and runtime macro library must be checked against **this** installation. It is **not** automatically valid because JCL looks plausible.
- `cobol_clg_user.jcl` — IKFCBL00 compile/link/go candidate. *Unverified*: compiler availability, COBLIB/load library, link/edit setup, executable back-reference.
- `dataset_mgmt_user.jcl` — IEFBR14 allocation then IEHPROGM UNCATLG/SCRATCH **in the same job**. Classified `DESTRUCTIVE_TEST_ONLY`. **Do not submit to a non-disposable volume.**

`COND=(4,LT,ASM)` bypasses when ASM's return code is **greater than 4**; `COND=(0,NE)` without a step name bypasses if **any** preceding executed normal step had a return code other than zero. A true COND predicate means **do not execute** the step. MVS/3.8J-specific execution evidence remains required.

## Source links

**First-party operational seed:** `animatedads/alchemy` itself, including RecordSet MVS/3.8J `QUALIFY.JCL` decks and JES diagnostic/rerun notes. This is potentially richer than tutorial examples because it preserves failing and revised versions; see `docs/KNOWN_REGRESSION.md`.


See `sources.json`, with complete commit pins, licence and tier per source. Especially relevant: [MainframeJCL](https://github.com/billrain/MainframeJCL), [MVS/3.8J LangTest](https://github.com/wfjm/mvs38j-langtest), [MVS CE sysgen](https://github.com/MVS-sysgen/sysgen), [IBM Z Open Editor examples](https://github.com/IBM/zopeneditor-sample), [CardDemo](https://github.com/aws-samples/aws-mainframe-modernization-carddemo), and [rewrite-mainframe benchmark](https://github.com/moderneinc/rewrite-mainframe).

## Not yet achieved

No Hercules job has been executed from this package. No corpus downloaded in the preparation environment (public GitHub DNS unavailable). The first pure ooRexx physical-card reader passes local regression tests; a complete execution-grade JCL parser is NOT yet qualified. No claim of 100% source acceptance. The separate `rewrite-mainframe` benchmark's 518/555 figure is **not** a BundySlam score.

## Limitations of seed auditor

`tools/audit_seed.py` is a lightweight acquisition check only, intentionally distinct from ooRexx SLAM. It emits physical-card positions and conservative danger-token observations. It is **not a syntax or safety oracle**; for example, `DISP=(OLD,DELETE)` and an intentional scratch of a disposable dataset are not identical to erasing a production dataset. It does not decide true safety from tokens. Card column 72 is meaningful only under the current nested language (JCL, assembler, DFSORT, etc.).
