# BundySlam development increment v0.2 — 30 October 2026

## Delivered code

- `src/BundySlam.cls` — ooRexx 5.3.0 pure ooRexx card/statement/state reader. It never invokes a JES socket or edits a JCL deck.
- `src/BundySlamBridge.cls` — optional non-SQL adapter to existing `SlamStore` interface. Takes a verified source SHA-256, ingests CARD and STATEMENT shape instances and prior edges; does NOT label them TESTED or PROVED.
- `tests/test_bundyslam.rex` — 166 assertions covering physical layout, byte-for-byte round trips, multi-card statements, DD concatenations, data streams, delimiter differences, state, error cases and conservative COND handling.
- `tests/test_bridge.rex` — 9 interface checks using a spy implementation of `SlamStore`. **Not** an integration test against real SQLite.
- `bin/bundyslam.rex` — read-only audit command.

## Why this is different from generating text

Source bytes remain the authority. The reader derives an ordered card event stream and scoped statement list; every card retains its exact physical content, line-ending, location, job/step/DD context, and observed column 72. `card.precedes`, `statement.started`, `statement.continues`, and `statement.completed` are explicit events. An incomplete statement remains pending across records, and new statements cannot silently overwrite it without a diagnostic.

The store bridge derives stable shape nodes such as `BUNDY.CARD.CONTINUATION` and `BUNDY.STATEMENT.DD`, preserving source positions as instance bindings. Adjacent nodes add counts as `PRIOR` evidence only, consistent with SLAM's existing scoring distinction. The original JCL byte content is not duplicated into the node store.

## Commands and measured results

```sh
cd bundyslam-corpus-v0.2
(cd tests && rexx test_bundyslam.rex)    # 166/166 PASS
(cd tests && rexx test_bridge.rex)       # 9/9 PASS (spy interface only)
python3 -m unittest discover -s tools/tests -v  # 7/7 PASS
(cd bin && rexx bundyslam.rex audit ../corpus/user-supplied/asm_link_user.jcl)
```

Tests were executed with the user-supplied debug ooRexx build reporting `Open Object Rexx Version 5.3.0 r13196 - Internal Test Version` (build date 2026-08-03). The 7 Python checks cover the acquisition auditor, not the ooRexx semantic engine.

## What is deliberately not claimed

- **No real MVS/JES/Hercules submission or observed job RCs.** A parsed deck is not a passing job.
- Neither full syntax checking nor a complete release-qualified grammar.
- No evaluation of symbolic substitutions, DD override resolution, conditional processing across ABENDs, procedure PEND resolution, GDG catalog effects, or real utility installation.
- `DLM` handling currently admits only simple two-character delimiters, with JES mode explicit. Complex delimiters and invalid DLM forms remain unresolved, not accepted.
- `COND` accepts only a strict subset of numeric RC comparisons. Missing RC evidence yields `UNKNOWN`. It is not JES completion/ABEND semantics.
- Source family corpus acquisition still requires external Git/network connectivity. No raw upstream corpus is included and source licences remain recorded individually.
- The bridge conforms to known `SlamStore` method signatures but has not executed the actual SQLite backend in this environment.

## Next gates

1. Test `BundySlamBridge` with actual `SlamStore` against a disposable SQLite database; verify unit dedup and prior edges.
2. Expand fixed-column lexical rules, quoted strings, symbolic substitution and trailing comments; hold unsupported cases at `UNQUALIFIED`.
3. Import pinned, rights-reviewed MVS/3.8J corpus and classify platform-specific JCL templates separately from runnable decks.
4. Qualify on an explicitly approved isolated ED209Z/ED209ZZ Hercules instance, using `JES job ID + spool + step RC/ABEND + installation identity` as observed results. Retain failing deck and correction lineage without rewriting the original.
5. Run mutation cases, including column 72 source-language confusion and `COND` inversion; require evidence-based repair before awarding `TESTED`.

## References for behavior distinctions

- IBM: [DD * parameter](https://www.ibm.com/docs/en/zos/3.1.0?topic=statement-parameter)
- IBM: [DD DATA parameter](https://www.ibm.com/docs/en/zos/3.1.0?topic=statement-data-parameter)
- IBM: [DLM parameter](https://www.ibm.com/docs/en/zos/3.1.0?topic=statement-dlm-parameter)

These documents describe modern z/OS behavior; historical MVS 3.8J compatibility is a separate qualification obligation. The `JES2` default in this initial reader is an explicit profile assumption, not a discovery that every installation runs JES2.
