# BundySlam: JCL semantics in SLAM-English (candidate v0.1)

## Design principle

Do not generate cards by imitating strings. Interpret an ordered evidence stream;
resolve it into a typed graph; check a versioned target profile; emit a proposed
deck; predict its effects; obtain **real JES evidence** before calling it correct.

1. **A card exists.** A card is a physical source record with immutable
   `origin`, `content_bytes`, `record_index`, `columns[1..80]`, line ending,
   encoding claim, and SHA-256. Preserve the source bytes.
2. **Cards have an order.** `precedes(cardA,cardB)` is an observed fact, not a
   guess. Do not reorder while parsing, repairing, formatting, or submitting.
3. **A statement might not be finished.** `continues(cardA,cardB)` is a
   proposition backed by target-version continuation rules and physical
   evidence (comma, column 72, quoted parameter, syntax context). A later card
   cannot retrospectively repair missing evidence without a proposed edit.
4. **The parser has memory.** At every card, carry:
   `phase`, `job`, `step`, `dd`, `proc_stack`, `pending_statement`,
   `quoted_operand_state`, `symbol_scope`, `instream_dd`, `instream_delimiter`,
   `dataset_bindings`, `step_return_codes`, and `target_profile`.
5. **Physical and logical are different.** Multiple cards can make one statement;
   one DD can own many data cards. A literal inside `SYSIN DD *` is not a JCL
   keyword merely because it spells `JOB`, `DD`, `EXEC`, or `COND`.
6. **Scope matters.** `DD` belongs to its EXEC step; a DD override in a PROC
   must resolve against the step within the invoked PROC, not the caller's
   currently visible step. `&&` temporary dataset ownership and lifetime
   are not simply string equality.
7. **An interpretation has a target.** Facts about z/OS 3.2 do not by
   themselves license the same construct on MVS 3.8J. Facts about ED209Z do
   not prove software, procedure or datasets present on ED209ZZ. Distinguish
   syntax, release support, and site installation facts.
8. **Execution is not syntax.** A successful parse or JCL conversion is not
   proof of executable success. The JES job ID, step RCs/ABENDs, allocation
   effects, messages and spool are separate evidence with provenance.
9. **Error means hypothesis + evidence.** Diagnose with the smallest card set
   and rule, propose a minimal patch, preserve the original, and qualify the
   corrected version by running it. Never rewrite silently.
10. **Danger is a first-class predicate.** SCRATCH, UNCATLG, DELETE, FORMAT,
    RESTORE, overwrite/catlg of non-disposable datasets and privileged JES
    requests require a distinct approval path; no auto-submit on recognition.

## Candidate events (not necessarily implemented in core SLAM)

- `card.observed`: `card_id`, `deck_id`, `index`, `sha256`, `content_bytes`,
  `column_span`, `source`, `encoding`
- `statement.started`: `id`, `card_id`, `operation`, `name`, `scope`
- `statement.continuation.expected`: `statement_id`, `cause`, `card_id`
- `statement.continuation.received`: `statement_id`, `card_id`, `start_col`
- `statement.completed`: `id`, `cards[]`, `parameter_tree`
- `dd.instream.opened` / `dd.instream.closed`: `dd_id`, `delimiter`, `cards[]`
- `procedure.invoked` / `procedure.override.bound`: `proc`, `step`, `dd`
- `dataset.binding.declared` / `dataset.disposition.proposed`: target and effects
- `step.condition.evaluated`: declared condition, prior RC evidence, skip decision
- `diagnostic.observed`: message ID, job ID, step, evidence source, exact text
- `repair.proposed`: unchanged original hash, edit, impacted cards, rule basis

## State transition examples

`EXPECT_JOB -> IN_JOB -> IN_STEP -> IN_DD -> INSTREAM_DATA -> IN_STEP -> END_JOB`

On a card with a comma indicating continuation, emit `statement.continuation.expected`
and keep `PENDING_STATEMENT`. On a valid continuation, append an ordered physical
record; do not create a second DD. If a new `EXEC` appears instead, emit a
missing-continuation diagnostic, not an automatically patched step.

On `//SYSIN DD *`, enter `INSTREAM_DATA` according to that DD's delimiter
policy. Interpret subsequent cards as input data, not JCL, until a valid
terminator according to the target's rules. In-stream `//` handling must be
release- and DLM-specific; do not implement a blanket rule without evidence.

On `//LKED EXEC ...,COND=(4,LT,ASM)`, read the condition as **bypass LKED if 4
is less than the actual ASM RC** (for normal completed prior step). Do not
invert it to "run when ASM is good" without checking the evaluator's skip
semantics. RC, ABEND, prior-step scope and ordering must be evidence-based.

## Corpus partitions

- `reference`: manuals, diagnostic catalogs; links and metadata, not
  unlicensed reproduction of copyrighted manuals.
- `positive`: correctly interpreted candidate decks; only *verified* positives
  have a real job outcome or independent trusted qualification.
- `negative`: intentionally mutated card layout, missing continuation, bad
  DD scope, invalid step/proc references, wrong installation assumptions.
- `operational`: isolated Hercules job IDs, JES conversion, RCs, spool,
  catalog/dataset side effects, actual system build metadata.

Withhold complete source families from development; a good parser must transfer
from utility members to previously unseen application decks. Track the
false-positive (bad JCL accepted) rate independently from recovery accuracy.

## Sources for rules

- IBM z/OS JCL statement fields:
  https://www.ibm.com/docs/en/zos/2.5.0?topic=statements-jcl-statement-fields
- IBM JCL continuation diagnostic IEFC621I:
  https://www.ibm.com/docs/en/zos/3.2.0?topic=messages-iefc621i
- IBM symbol/continuation interaction:
  https://www.ibm.com/docs/en/zos/3.1.0?topic=jcl-continuing-statements-that-contain-symbols
- Distinguish assembler/DFSORT *control-card* continuation rules from
  JCL continuation rules. They are different languages inside a job deck.

**Not an implemented SLAM rule engine; initial semantic brief and test vocabulary only.**

## What the v0.2 card reader now gives SLAM

I read one card. I keep its place and each byte. I do not change it.
I read the next card. I keep which card came first.
If the first card says there is more, I wait for the next card.
If the next card is not part of the first card, I say what went wrong.
I keep which job, step and data name I have read.
I know the difference between JCL that says what to do, and data that a program reads.
I can write out the same cards, in the same order, without changing a byte.
I can make the kinds of cards and statements nodes, and their order edges.
An edge that is seen in code is a prior. It is not a tested result.
If I do not know what an MVS or JES rule permits, I say unknown.
I do not run a job. A job that I read is not a job that passed.
