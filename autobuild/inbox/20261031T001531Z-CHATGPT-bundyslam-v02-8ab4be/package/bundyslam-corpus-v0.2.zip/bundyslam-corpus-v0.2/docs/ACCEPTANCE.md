# First acceptance test plan

This plan is not evidence of passing JCL or of submission to MVS.

| Gate | Evidence required | Success criterion |
|---|---|---|
| Provenance | pinned source path + commit + licence + SHA-256 | reproducible import, original bytes unchanged |
| Physical | original 80-column records + line ending + offsets | exact source reconstruction; no column bleed |
| Continuation | positive/negative continuation and quoted cases | no silent join, missing-line diagnostic at exact card |
| In-stream | DD * / DATA / DLM boundaries | never promote program data to JCL without boundary evidence |
| Structural | JOB/EXEC/DD/PROC scope | correct step ownership, PROC overrides resolved with evidence |
| Semantics | DISP, DCB, SPACE, GDG, temp datasets, RC/COND | correct release-specific constraints and bypass decisions |
| Safety | scratch/uncatalog/format/overwrite | destructive fixture blocked before any MVS submission |
| Real MVS | approved isolated ED209Z or ED209ZZ (separately) | JES/job ID/step RCs/side effects recorded |
| Repair | single-edit and composed faults | no new hazardous operations; verified minimal repair |
| Generalisation | held-out repository + dialect profile | score independently from dev/training fixtures |

## Immediate MVS/3.8J checks

- Verify `CLASS`, `MSGCLASS`, `NOTIFY`, `SYSDA`, volume labels and actual compiler
  programs in the target JES/procedure libraries. Do not assume site defaults.
- Check `IFOX00` as Assembler XF and associated macro-library sequence.
- Check assembler object deck (`SYSGO`), linker inputs, output PDS and
  `COND=(4,LT,ASM)` before marking the assembly fixture ready.
- Check compiler `IKFCBL00`, compiler `SYSLIN`, link library and load
  module back-reference before marking the COBOL fixture ready.
- Do not run destructive dataset management fixture on a populated
  volume; use a disposable volume and dataset identifier selected by the
  operator, then inspect catalog/allocation effects.
- First submit an isolated benign allocation/IEFBR14 job after approval;
  never auto-submit examples simply because the parser accepts them.

## Score separately

Report `recognized / candidates`, `parsed / recognized`, `semantic_pass /
parsed`, `JES_convert_pass / submitted`, `step_success / started`,
`diagnostic_localisation / invalid_cases`, and `minimal_repair / confirmed_faults`.
Unsubmitted/unverified is `UNKNOWN`, not `PASS`. Record dialect/version and
source dataset split on every score.
