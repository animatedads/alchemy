# High-value existing Alchemy JCL evidence

The user's own `animatedads/alchemy` GitHub repository already contains
`packages/oorexx_recordset/tests/dev6/mvs/QUALIFY.JCL` (and preceding dev
versions), plus real Hercules/JES qualification logs and correction notes.

Source, pinned repo revision: `f84e806eabc2192acf65ab9b6f3f16a9753aa698`.

- `packages/oorexx_recordset/DEV5_NOTES.md`: one earlier incident had
  a trailing assembler-source `*` in column 72. That changed the meaning
  of the next physical assembler record into a continuation and yielded
  a failure. Note: this is **an assembler control-card continuation** issue,
  not proof that the JCL grammar uses exactly the same rule.
- `packages/oorexx_recordset/DEV4_NOTES.md`: MVS 3.8J `IFOX00`/`IEWL`
  job case and program relocation fixes.
- `packages/oorexx_recordset/tests/dev6/mvs/QUALIFY.JCL`: candidate for
  physical-card and job-step trace extraction.
- `packages/oorexx_recordset/CODEX_ED209Z_DEV6_RERUN.md`: job rerun
  instructions and evidence collection. Do not assume a successful run from
  mere presence of a JCL deck.

Bundle these with the actual job's JES log, exact job ID and run target
for a strong test triple `(bad deck, diagnostic, corrected deck)`.

References:
- https://github.com/animatedads/alchemy/blob/main/packages/oorexx_recordset/DEV5_NOTES.md
- https://github.com/animatedads/alchemy/blob/main/packages/oorexx_recordset/tests/dev6/mvs/QUALIFY.JCL
- https://github.com/animatedads/alchemy/blob/main/packages/oorexx_recordset/CODEX_ED209Z_DEV6_RERUN.md

**Target-specific**: ED209Z and ED209ZZ are separate MVS guest environments;
never infer installed programmes, libraries or operational results between them.
