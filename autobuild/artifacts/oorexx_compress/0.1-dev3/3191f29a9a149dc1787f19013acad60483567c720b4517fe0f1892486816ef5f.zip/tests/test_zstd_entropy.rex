/* Standards vectors for native Zstandard entropy infrastructure. */
numeric digits 80
failures = 0

/* Meta Zstandard format 0.4.5 Appendix A: complete predefined LL table. */
distribution = .array~of(4,3,2,2,2,2,2,2,2,2,2,2,2,1,1,1,2,2,2,2,2,2,2,2,2,3,2,1,1,1,1,1,-1,-1,-1,-1)
table = .ZstdFSETable~new(distribution,6)
expected = .array~of( -
 '0 0 4 0','1 0 4 16','2 1 5 32','3 3 5 0','4 4 5 0','5 6 5 0','6 7 5 0','7 9 5 0', -
 '8 10 5 0','9 12 5 0','10 14 6 0','11 16 5 0','12 18 5 0','13 19 5 0','14 21 5 0','15 22 5 0', -
 '16 24 5 0','17 25 5 32','18 26 5 0','19 27 6 0','20 29 6 0','21 31 6 0','22 0 4 32','23 1 4 0', -
 '24 2 5 0','25 4 5 32','26 5 5 0','27 7 5 32','28 8 5 0','29 10 5 32','30 11 5 0','31 13 6 0', -
 '32 16 5 32','33 17 5 0','34 19 5 32','35 20 5 0','36 22 5 32','37 23 5 0','38 25 4 0','39 25 4 16', -
 '40 26 5 32','41 28 6 0','42 30 6 0','43 0 4 48','44 1 4 16','45 2 5 32','46 3 5 32','47 5 5 32', -
 '48 6 5 32','49 8 5 32','50 9 5 32','51 11 5 32','52 12 5 32','53 15 6 0','54 17 5 32','55 18 5 32', -
 '56 20 5 32','57 21 5 32','58 23 5 32','59 24 5 32','60 35 6 0','61 34 6 0','62 33 6 0','63 32 6 0')

do item over expected
  parse var item state symbol bits base
  if table~symbolAt(state) \== symbol then call fail 'Appendix A LL symbol mismatch at state ' || state
  if table~numBitsAt(state) \== bits then call fail 'Appendix A LL bit-count mismatch at state ' || state
  if table~baselineAt(state) \== base then call fail 'Appendix A LL baseline mismatch at state ' || state
end

/* Format-spec Huffman example: listed weights 4,3,2,0,1 infer final weight 1. */
h = .ZstdHuffmanTable~new(.array~of(4,3,2,0,1))
w = h~allWeights
if h~maximumBits \== 4 then call fail 'Huffman example maximum depth is not 4'
if w~items \== 6 then call fail 'Huffman example did not infer the sixth weight'
expectedWeights = .array~of(4,3,2,0,1,1)
do i = 1 to expectedWeights~items
  if w[i] \== expectedWeights[i] then call fail 'Huffman example weight mismatch at index ' || i
end

/* Direct tree description: header 132 => five listed weights, high nibble first. */
info = .ZstdHuffmanTable~fromDescription(x2c('84432010'))
w = info[1]~allWeights
if info[2] \== 4 then call fail 'Direct Huffman tree description consumed wrong byte count'
do i = 1 to expectedWeights~items
  if w[i] \== expectedWeights[i] then call fail 'Direct Huffman tree weight mismatch at index ' || i
end

if failures = 0 then do
  say 'PASS Zstandard entropy standards vectors'
  exit 0
end
say 'FAIL count=' failures
exit 1

fail: procedure expose failures
  parse arg message
  failures += 1
  say 'FAIL:' message
  return

::requires '../src/ZstdFSETable.cls'
::requires '../src/ZstdHuffmanTable.cls'
