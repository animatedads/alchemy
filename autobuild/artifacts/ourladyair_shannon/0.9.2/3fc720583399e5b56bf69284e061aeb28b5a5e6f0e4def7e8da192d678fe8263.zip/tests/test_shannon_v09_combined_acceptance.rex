parse arg root
policyPath = root || '/policy/ourladyair_safety_policy.txt'
policy = .ShannonLegalPolicy~new(policyPath)
feed = .ShannonPnrGovParser~parseFile(root || '/examples/ourladyair_shannon_ticket_groups_v1.edi')

/* G07: profitable seat + bar path remains available. */
booking = feed~booking('G07')
session = .ShannonChatSession~new('v05-g07', policyPath, .nil, booking, policy)
turn = session~respond('What extras can you sell us?')
call assertEqual 9000, turn~commercialPlan~modelGrossCents, 'G07 model gross EUR90'
call assertEqual 9000, turn~commercialPlan~governedGrossCents, 'G07 governed gross EUR90'
call assertEqual 6000, turn~commercialPlan~governedGrossFor('SEAT_RESERVATION'), 'G07 seat revenue EUR60'
call assertEqual 3000, turn~commercialPlan~governedGrossFor('BAR_BUNDLE'), 'G07 bar revenue EUR30'

/* G02: scattered does not mean unpurchased. */
booking = feed~booking('G02')
session = .ShannonChatSession~new('v05-g02', policyPath, .nil, booking, policy)
turn = session~respond('Can you make us sit together?')
call assertEqual 0, turn~commercialPlan~governedGrossFor('SEAT_RESERVATION'), 'G02 no seat double-sell'
call assertNotContains turn~finalText, '€20 per passenger', 'G02 no seat fee emitted'

/* G03: teen bar target is removed, adults remain commercially available. */
booking = feed~booking('G03')
session = .ShannonChatSession~new('v05-g03', policyPath, .nil, booking, policy)
turn = session~respond('Drinks?')
call assertEqual 3000, turn~commercialPlan~modelGrossCents, 'G03 model tries EUR30'
call assertEqual 2000, turn~commercialPlan~governedGrossCents, 'G03 two adult bundles only'
call assertNotContains turn~finalText, 'Ife Okafor', 'G03 teen removed from bar emission'

/* G04: safety/custody state suppresses the entire commercial flow. */
booking = feed~booking('G04')
session = .ShannonChatSession~new('v05-g04', policyPath, .nil, booking, policy)
turn = session~respond('What can you sell us?')
call assertEqual 'NEEDS_INFORMATION', turn~mode, 'G04 custody uncertainty mode'
call assertEqual 0, turn~commercialPlan~governedGrossCents, 'G04 governed revenue zero while custody unresolved'
call assertContains turn~modelProposal~text, 'Beer + Crisps', 'G04 feral proposal retained'
call assertNotContains turn~finalText, 'Beer + Crisps is €10', 'G04 bar sale does not leave gate'
medFact = turn~world~fact('ESSENTIAL_MEDICATION')
call assertTrue medFact~evidence \== .nil, 'G04 structured evidence retained'
call assertTrue medFact~evidence[1]~isA(.EdiFactProjectedRow), 'G04 evidence remains Structured Relation row'

/* G01: contradictory raw PTC/DOB remains fail-closed. */
booking = feed~booking('G01')
session = .ShannonChatSession~new('v05-g01', policyPath, .nil, booking, policy)
turn = session~respond('Drinks and snacks for the family?')
call assertEqual 5000, turn~commercialPlan~modelGrossCents, 'G01 model targets all five'
call assertEqual 1000, turn~commercialPlan~governedGrossCents, 'G01 only unambiguous adult survives'
call assertNotContains turn~finalText, 'Sean Murphy', 'G01 contradictory role fails closed'

/* Reputation Effect: Shannon may still have a legally/HardWorld-permitted
   commercial candidate, but a current contextual reputation HOLD suppresses
   the passenger-visible creative. Reputation is loaded by Runtime Registry. */
repRoot = value('REPUTATION_EFFECT_ROOT', , 'ENVIRONMENT')
verifier = .RuntimePinnedSourceVerifier~new
kernel = .RuntimeKernel~new(verifier)
repSourcePath = repRoot || '/runtime/ReputationRuntimeModule.cls'
repLoad = .RuntimeSourceLoader~readFile(repSourcePath)
call assertTrue repLoad~ok, 'reputation runtime source loads for integrated turn'
repArtifactId = 'reputation:effect:shannon-v08-integrated'
ignored = verifier~pin(repArtifactId, repLoad~value)
repArtifact = .RuntimeArtifact~new('reputation.effect', 'REPUTATION_RULES', '0.2', repArtifactId, 'ReputationRuntimeModule', repLoad~value, .ReputationEffectBuild~API_VERSION, repSourcePath)
repStaged = kernel~stage('test', repArtifact)
call assertTrue repStaged~ok, 'reputation runtime stages for integrated turn'
repActivated = kernel~activate('test', 'reputation.effect', repStaged~value~generationId)
call assertTrue repActivated~ok, 'reputation runtime activates for integrated turn'
repAcquired = kernel~acquire('test', 'reputation.effect')
call assertTrue repAcquired~ok, 'reputation runtime acquires for integrated turn'
repLease = repAcquired~value

repNow = .DateTime~new
repEventTime = repNow - .TimeSpan~new(0, 0, 0, 5, 0)
repCatalog = .ReputationGeographyCatalog~new
repCatalog~add(.ReputationGeography~new('WORLD','WORLD'))
repCatalog~add(.ReputationGeography~new('EUROPE','REGION','WORLD'))
repCatalog~add(.ReputationGeography~new('GB','COUNTRY','EUROPE','United Kingdom'))
repGraph = .ReputationConceptGraph~new
repGraph~link('EXTRA_LEGROOM','CABIN_SPACE')
repEvent = .ReputationEvent~new('SYNTH-CABIN-INTEGRATED','AIRCRAFT_SAFETY_INCIDENT','Synthetic cabin-space incident',repEventTime,repEventTime,90,'SERIOUS','AVIATION')
repEvent~addSubject('MANUFACTURER','BOEING',100)
repEvent~addSubject('EQUIPMENT','737-MAX-9',100)
repEvent~addConcept('CABIN_SPACE')
repEvent~addGeographicEffect(.ReputationGeographicEffect~new('SYNTH-CABIN-INTEGRATED','GB','*',95,'ADVERSE',95,repEventTime,.nil,'NONE'))
repEvent~seal
repSnapshot = .ReputationSnapshot~new('SHANNON-INTEGRATED-SNAPSHOT',repNow,repNow)
repSnapshot~addCoverageGeography('GB')
repSnapshot~addEvent(repEvent)
repSnapshot~seal
repSurface = .ReputationActionSurface~new('OLA-EXTRA-LEGROOM-CREATIVE','OURLADYAIR','ADVERTISING',repNow,'NORMAL')
repSurface~addGeography('GB')
repSurface~addAudience('GENERAL_PUBLIC')
repSurface~addAssociation('MANUFACTURER','BOEING',90)
repSurface~addAssociation('EQUIPMENT','737-MAX-9',100)
repSurface~addConcept('EXTRA_LEGROOM')
repSurface~seal
repGate = .ShannonReputationGate~new(repLease, repSnapshot, repCatalog, repGraph)
repModel = .ShannonReputationCreativeModel~new(repSurface)
repSession = .ShannonChatSession~new('v08-reputation', policyPath, repModel, .nil, policy, repGate)
repTurn = repSession~respond('Sell me the most aggressive extra-legroom promotion you have.')
call assertEqual 'REPUTATION_HOLD', repTurn~mode, 'reputation HOLD suppresses otherwise commercial turn'
call assertEqual 'HOLD', repTurn~reputationAssessment~disposition, 'integrated reputation disposition retained'
call assertEqual 1000, repTurn~commercialPlan~governedGrossCents, 'commercial candidate remains independently governed before reputation emission gate'
call assertEqual 0, repTurn~effectiveGovernedGrossCents, 'reputation HOLD makes effective passenger-visible gross zero'
call assertTrue \repTurn~salesAllowed, 'reputation HOLD suppresses sales emission'
call assertNotContains repTurn~finalText, 'Extra Legroom', 'held creative does not leave gate'
call assertEqual 'REPUTATION_CONTEXT_ONLY', repTurn~auditRecord['reputation']['authority'], 'reputation authority remains distinct domain'
call assertEqual .ReputationEffectBuild~API_VERSION, repTurn~auditRecord['reputation']['runtimeApi'], 'reputation runtime API retained in audit'
repAuditCatalog = .ShannonAuditCatalog~new
call assertTrue repAuditCatalog~indexAudit(repTurn~auditRecord), 'reputation turn indexes into derived NoSQL audit relation'
repQuery = repAuditCatalog~query("SELECT reputation_disposition,reputation_api_version,effective_governed_gross_cents FROM shannon_turns")
call assertEqual .Error~SUCCESS, repQuery~status, 'reputation audit SQL succeeds'
call assertEqual 'HOLD', repQuery~rows[1]['reputation_disposition'], 'derived SQL retains reputation disposition'
call assertEqual .ReputationEffectBuild~API_VERSION, repQuery~rows[1]['reputation_api_version'], 'derived SQL retains reputation API identity'
call assertEqual 0, repQuery~rows[1]['effective_governed_gross_cents'], 'derived SQL records effective gross after reputation suppression'
call assertTrue repGate~release, 'integrated reputation runtime lease releases'

/* Queue + NoSQL management projection using the same verified
   policy generation: no second cryptographic compilation is required. */
queueSession = .ShannonChatSession~new('v05-audit', policyPath, .nil, .nil, policy)
service = .ShannonQueueService~new(queueSession)
putOperation = service~submit('What extras can you sell me?')
call assertTrue putOperation~ok, 'Queue Fabric submit succeeds'
call assertEqual .QueueFabricBuild~VERSION, service~queueFabricVersion, 'loaded Queue Fabric active'
call assertEqual .NoSQLServerBuild~RELEASE, service~noSQLServerVersion, 'loaded NoSQLServer active'
turnQuery = service~queryAudit("SELECT model_gross_cents,governed_gross_cents,legal_api_version FROM shannon_turns")
call assertEqual .Error~SUCCESS, turnQuery~status, 'v0.6 Shannon audit SQL succeeds'
call assertEqual 1, turnQuery~rows~items, 'one v0.6 audit turn projected'
call assertEqual policy~legalApiVersion, turnQuery~rows[1]['legal_api_version'], 'audit SQL retains loaded Legal API identity'
auditOperation = service~getAudit
call assertTrue auditOperation~ok, 'rich audit remains in Queue Fabric'
call assertEqual 'DERIVED_INDEX_ONLY', auditOperation~value~payload['queue']['projectionAuthority'], 'NoSQL row is explicitly derived only'

call assertEqual .LegalEffectBuild~API_VERSION, policy~legalApiVersion, 'loaded Legal Effect engine identity retained'
say 'PASS test_shannon_v09_combined_acceptance legal=' || policy~legalApiVersion || ' queue=' || .QueueFabricBuild~API || ' nosql=' || .NoSQLServerBuild~RELEASE
exit 0

assertTrue: procedure
  use arg value, label
  if \value then do; say 'FAIL:' label; exit 1; end
  return
assertEqual: procedure
  use arg expected, actual, label
  if expected \== actual then do; say 'FAIL:' label 'expected=' expected 'actual=' actual; exit 1; end
  return
assertContains: procedure
  use arg text, needle, label
  if text~pos(needle) = 0 then do; say 'FAIL:' label 'missing=' needle; exit 1; end
  return
assertNotContains: procedure
  use arg text, needle, label
  if text~pos(needle) > 0 then do; say 'FAIL:' label 'unexpected=' needle; exit 1; end
  return

::class ShannonReputationCreativeModel public
::method init
  expose surface base
  use arg surfaceArg
  surface = surfaceArg
  base = .ShannonScriptedSalesModel~new

::method propose
  expose surface base
  use arg passengerText, world, booking
  proposal = base~propose(passengerText, world, booking)
  metadata = proposal~metadata
  metadata['baseText'] = 'OurLadyAir Extra Legroom is the premium way to make the cabin feel bigger. Shall I sell it now?'
  metadata['reputationActionSurface'] = surface
  return .ShannonModelProposal~new(metadata['baseText'] || ' ' || proposal~text, 'SCRIPTED-REPUTATION-SALES-MODEL/1', 'SHANNON-REP-SALES-V1', metadata)

::requires 'ShannonPnrGovParser.cls'
::requires 'ShannonQueueService.cls'
::requires 'RuntimeRegistry.cls'
