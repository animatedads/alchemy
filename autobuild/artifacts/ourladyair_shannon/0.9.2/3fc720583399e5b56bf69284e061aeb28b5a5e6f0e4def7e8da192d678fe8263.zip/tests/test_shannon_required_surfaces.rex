/* Fail early and intelligibly when a configured dependency root lacks a
 * surface Shannon v0.9.1 actually uses.  This is capability checking, not a
 * release-number gate: newer/older releases are welcome if the required
 * classes/surfaces exist.
 */
parse arg root

repRoot = value('REPUTATION_EFFECT_ROOT', , 'ENVIRONMENT')
feedRoot = value('REPUTATION_FEED_ROOT', , 'ENVIRONMENT')

say 'STACK reputation_effect=' || .ReputationEffectBuild~API_VERSION || ' root=' || repRoot
say 'STACK reputation_feed=' || .ReputationFeedBuild~API_VERSION || ' root=' || feedRoot

missing = 0
call requireClass .ReputationCommunicationFailure, 'ReputationCommunicationFailure', 'Reputation Effect communication-failure surface', repRoot
call requireClass .ReputationCommunicationAct, 'ReputationCommunicationAct', 'Reputation Effect communication-act surface', repRoot
call requireClass .ReputationCommunicationSurface, 'ReputationCommunicationSurface', 'Reputation Effect communication-surface', repRoot
call requireClass .ReputationPublicationSurface, 'ReputationPublicationSurface', 'Reputation Feed publication surface', feedRoot
call requireClass .ReputationFeedArticle, 'ReputationFeedArticle', 'Reputation Feed article surface', feedRoot
call requireClass .ReputationLineageEngine, 'ReputationLineageEngine', 'Reputation Feed lineage engine', feedRoot

if missing then do
  say 'FAIL test_shannon_required_surfaces'
  say 'NOTE: this is not a hard version check.  The configured dependency root simply lacks a surface Shannon uses.'
  exit 1
end

say 'PASS test_shannon_required_surfaces reputation=' || .ReputationEffectBuild~API_VERSION || ' feed=' || .ReputationFeedBuild~API_VERSION
exit 0

requireClass: procedure expose missing
  use arg classObject, className, surfaceName, configuredRoot
  if classObject~isA(.Class) then return
  say 'MISSING:' surfaceName || ' class=' || className
  say '         configured_root=' || configuredRoot
  missing = 1
  return

::requires 'ReputationEffect.cls'
::requires 'ReputationFeed.cls'
