parse arg root
feedRoot = value('REPUTATION_FEED_ROOT', , 'ENVIRONMENT')
if feedRoot == '' then do; say 'FAIL: REPUTATION_FEED_ROOT missing'; exit 1; end

verifier = .RuntimePinnedSourceVerifier~new
kernel = .RuntimeKernel~new(verifier)
sourcePath = feedRoot || '/runtime/ReputationFeedRuntimeModule.cls'
loadOp = .RuntimeSourceLoader~readFile(sourcePath)
call assertTrue loadOp~ok, 'reputation feed runtime source loads'
artifactId = 'reputation:feed:shannon-v09-test'
ignored = verifier~pin(artifactId, loadOp~value)
artifact = .RuntimeArtifact~new('reputation.feed', 'REPUTATION_ACQUISITION', '0.1', artifactId, 'ReputationFeedRuntimeModule', loadOp~value, .ReputationFeedBuild~API_VERSION, sourcePath)
staged = kernel~stage('test', artifact)
call assertTrue staged~ok, 'reputation feed stages'
activated = kernel~activate('test', 'reputation.feed', staged~value~generationId)
call assertTrue activated~ok, 'reputation feed activates'
acquired = kernel~acquire('test', 'reputation.feed')
call assertTrue acquired~ok, 'reputation feed acquires'
feedGate = .ShannonReputationFeedGate~new(acquired~value)

now = .DateTime~new
expiry = now + .TimeSpan~new(1)

a = .ReputationFeedArticle~new('A', 'SOURCE-A', 'GROUP-ONE', 'Cabin incident report', now)
sa = .ReputationPublicationSurface~new('SURF-A', 'Glasgow title', 'GROUP-ONE', 'SCOTLAND', now)
sa~setReachEvidence(.ReputationReachEvidence~new(120000, 'PERSONS', 'AUDIT-A', now, 90, expiry))
ra = .ReputationRangeEvidence~new('RANGE-A', 90, now); ra~addGeography('SCOTLAND'); sa~setRangeEvidence(ra)
a~addSurface(sa); a~seal

b = .ReputationFeedArticle~new('B', 'SOURCE-B', 'GROUP-ONE', 'AI rewritten cabin incident report', now)
sb = .ReputationPublicationSurface~new('SURF-B', 'Manchester title', 'GROUP-ONE', 'ENGLAND', now)
sb~setReachEvidence(.ReputationReachEvidence~new(180000, 'PERSONS', 'AUDIT-B', now, 90, expiry))
rb = .ReputationRangeEvidence~new('RANGE-B', 90, now); rb~addGeography('ENGLAND'); sb~setRangeEvidence(rb)
b~addSurface(sb); b~seal

c = .ReputationFeedArticle~new('C', 'SOURCE-C', 'GROUP-TWO', 'Independent witness report', now)
sc = .ReputationPublicationSurface~new('SURF-C', 'Athens title', 'GROUP-TWO', 'GR', now)
/* Missing reach is deliberate: range can be known while reach remains incomplete. */
rc = .ReputationRangeEvidence~new('RANGE-C', 85, now); rc~addGeography('GR'); sc~setRangeEvidence(rc)
c~addSurface(sc); c~seal

ab = .ReputationArticleComparison~new('AB', 'A', 'B', 'OLA-NEWS-CORPUS', 95, 95, 'SOURCE-A')
ab~addParagraphComparison(.ReputationParagraphComparison~new(1,1,'OLA-NEWS-CORPUS',25,97,96,95,100,95,95,100))
ab~addParagraphComparison(.ReputationParagraphComparison~new(2,2,'OLA-NEWS-CORPUS',30,96,95,96,100,95,95,100))
ab~seal

assessment = feedGate~analyze(.array~of(a,b,c), .array~of(ab), now)
call assertTrue assessment~analyzed, 'feed analysis completes'
call assertEqual 'REPUTATION_ACQUISITION_ONLY', assessment~authority, 'feed authority remains acquisition only'
call assertEqual .ReputationFeedBuild~API_VERSION, assessment~runtimeApi, 'loaded feed API retained as evidence'
summary = assessment~summary
call assertEqual 3, summary~publicationSurfaceCount, 'three publication surfaces retained'
call assertEqual 2, summary~lineageFamilyCount, 'AI rewrite and source collapse to two lineage families'
call assertEqual 2, summary~validatedReachSurfaceCount, 'only two surfaces have valid reach evidence'
call assertEqual 300000, summary~grossValidatedReach, 'gross reach is retained separately from lineage count'
call assertTrue \summary~reachComplete, 'missing reach fails completeness rather than becoming zero-known'
call assertTrue summary~rangeComplete, 'all surfaces have explicit range evidence'
call assertEqual 3, summary~rangeGeographies~items, 'range union remains separate from lineage count'

/* Bridge creates an observation carrying lineage metadata; it does not manufacture
   an authoritative event or geographic effect. */
observation = feedGate~observationFromArticle(assessment, 'OBS-A', 'REPORTED-CABIN-INCIDENT', a, 'SCOTLAND', 'GB', now, 80, 'UNVERIFIED', 'Publication evidence awaiting corroboration')
call assertEqual 'REPORTED-CABIN-INCIDENT', observation~reportedEventId, 'reported event id remains a report association only'
call assertEqual 'SCOTLAND', observation~observedGeographyId, 'observed geography preserved'
call assertEqual 'GB', observation~affectedGeographyId, 'affected geography separately preserved'
meta = observation~sourceAnchor~metadata
call assertTrue meta~hasIndex('lineage_family'), 'lineage family metadata retained on observation anchor'
call assertEqual 2, meta['family_article_count'], 'A/B lineage family contains two articles'
call assertEqual 2, meta['family_surface_count'], 'A/B lineage family retains two publication surfaces'
call assertEqual 'PUBLICATION', observation~sourceAnchor~sourceKind, 'bridge remains publication evidence'

call assertTrue feedGate~release, 'reputation feed runtime lease releases'
say 'PASS test_shannon_reputation_feed api=' || .ReputationFeedBuild~API_VERSION
exit 0

assertTrue: procedure
  use arg value, label
  if \value then do; say 'FAIL:' label; exit 1; end
  return
assertEqual: procedure
  use arg expected, actual, label
  if expected \== actual then do; say 'FAIL:' label 'expected='expected 'actual='actual; exit 1; end
  return

::requires 'ShannonReputationFeed.cls'
::requires 'RuntimeRegistry.cls'
