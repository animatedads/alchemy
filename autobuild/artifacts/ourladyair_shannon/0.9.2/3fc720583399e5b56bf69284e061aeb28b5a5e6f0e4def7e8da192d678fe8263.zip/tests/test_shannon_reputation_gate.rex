parse arg root
repRoot = value('REPUTATION_EFFECT_ROOT', , 'ENVIRONMENT')
if repRoot == '' then do; say 'FAIL: REPUTATION_EFFECT_ROOT missing'; exit 1; end

/* Load Reputation Effect through Runtime Registry. Shannon receives a lease;
   it does not instantiate the runtime module by classname. */
verifier = .RuntimePinnedSourceVerifier~new
kernel = .RuntimeKernel~new(verifier)
sourcePath = repRoot || '/runtime/ReputationRuntimeModule.cls'
load = .RuntimeSourceLoader~readFile(sourcePath)
call assertTrue load~ok, 'reputation runtime source loads'
artifactId = 'reputation:effect:shannon-v09-test'
ignored = verifier~pin(artifactId, load~value)
artifact = .RuntimeArtifact~new('reputation.effect', 'REPUTATION_RULES', '0.2', artifactId, 'ReputationRuntimeModule', load~value, .ReputationEffectBuild~API_VERSION, sourcePath)
staged = kernel~stage('test', artifact)
call assertTrue staged~ok, 'reputation runtime stages'
activated = kernel~activate('test', 'reputation.effect', staged~value~generationId)
call assertTrue activated~ok, 'reputation runtime activates'
acquired = kernel~acquire('test', 'reputation.effect')
call assertTrue acquired~ok, 'reputation runtime acquires'
lease = acquired~value

now = .DateTime~new
eventTime = now - .TimeSpan~new(0, 0, 0, 5, 0)

catalog = .ReputationGeographyCatalog~new
catalog~add(.ReputationGeography~new('WORLD','WORLD'))
catalog~add(.ReputationGeography~new('EUROPE','REGION','WORLD'))
catalog~add(.ReputationGeography~new('GB','COUNTRY','EUROPE','United Kingdom'))

graph = .ReputationConceptGraph~new
graph~link('EXTRA_LEGROOM','CABIN_SPACE')

event = .ReputationEvent~new('SYNTH-CABIN','AIRCRAFT_SAFETY_INCIDENT','Synthetic cabin-space incident',eventTime,eventTime,90,'SERIOUS','AVIATION')
event~addSubject('MANUFACTURER','BOEING',100)
event~addSubject('EQUIPMENT','737-MAX-9',100)
event~addConcept('CABIN_SPACE')
event~addGeographicEffect(.ReputationGeographicEffect~new('SYNTH-CABIN','GB','*',95,'ADVERSE',95,eventTime,.nil,'NONE'))
event~seal

snapshot = .ReputationSnapshot~new('SHANNON-REP-SNAPSHOT',now,now)
snapshot~addCoverageGeography('GB')
snapshot~addEvent(event)
snapshot~seal

gate = .ShannonReputationGate~new(lease, snapshot, catalog, graph)
call assertEqual .ReputationEffectBuild~API_VERSION, gate~runtimeApi, 'loaded reputation API retained as evidence'

action = .ReputationActionSurface~new('OLA-EXTRA-LEGROOM','OURLADYAIR','ADVERTISING',now,'NORMAL')
action~addGeography('GB')
action~addAudience('GENERAL_PUBLIC')
action~addAssociation('MANUFACTURER','BOEING',90)
action~addAssociation('EQUIPMENT','737-MAX-9',100)
action~addConcept('EXTRA_LEGROOM')
action~seal
assessment = gate~assess(action)
call assertTrue assessment~evaluated, 'reputation action evaluated'
call assertEqual 'HOLD', assessment~disposition, 'direct synthetic incident holds creative'
call assertTrue \assessment~emissionAllowed, 'held creative cannot emit'

ordinary = .ReputationActionSurface~new('OLA-BAR','OURLADYAIR','TRANSACTIONAL_OFFER',now,'NORMAL')
ordinary~addGeography('GB')
ordinary~addAudience('GENERAL_PUBLIC')
ordinary~addConcept('BAR_BUNDLE')
ordinary~seal
ordinaryAssessment = gate~assess(ordinary)
call assertEqual 'CLEAR', ordinaryAssessment~disposition, 'unrelated ordinary offer remains clear'
call assertTrue ordinaryAssessment~emissionAllowed, 'clear ordinary offer remains commercially available'

staleRefresh = now - .TimeSpan~new(0, 0, 30, 0, 0)
staleSnapshot = .ReputationSnapshot~new('SHANNON-REP-STALE',now,staleRefresh)
staleSnapshot~addCoverageGeography('GB')
staleSnapshot~seal
staleGate = .ShannonReputationGate~new(lease, staleSnapshot, catalog, graph)
staleAction = .ReputationActionSurface~new('OLA-LIVE','OURLADYAIR','ADVERTISING',now,'LIVE_MAJOR_EVENT')
staleAction~addGeography('GB')
staleAction~addAudience('GENERAL_PUBLIC')
staleAction~seal
stale = staleGate~assess(staleAction)
call assertEqual 'HOLD_REFRESH_REQUIRED', stale~disposition, 'stale reputation world fails closed'
call assertTrue \stale~emissionAllowed, 'stale reputation world suppresses action requiring evaluation'

call assertTrue gate~release, 'runtime lease releases'
say 'PASS test_shannon_reputation_gate api=' || .ReputationEffectBuild~API_VERSION
exit 0

assertTrue: procedure
  use arg value, label
  if \value then do; say 'FAIL:' label; exit 1; end
  return
assertEqual: procedure
  use arg expected, actual, label
  if expected \== actual then do; say 'FAIL:' label 'expected='expected 'actual='actual; exit 1; end
  return

::requires 'ShannonReputationGate.cls'
::requires 'RuntimeRegistry.cls'
