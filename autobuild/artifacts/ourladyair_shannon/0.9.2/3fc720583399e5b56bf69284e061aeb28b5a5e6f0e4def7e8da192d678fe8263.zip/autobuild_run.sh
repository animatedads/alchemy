#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
DEPS="$ROOT/.autobuild-deps"
MODE="${1:-quick}"

command -v rexx >/dev/null 2>&1 || { echo 'FAIL: ooRexx executable rexx not found in PATH' >&2; exit 127; }
command -v unzip >/dev/null 2>&1 || { echo 'FAIL: unzip not found in PATH' >&2; exit 127; }

( cd "$ROOT/deps" && sha256sum -c LOCK.sha256 )
rm -rf "$DEPS"
mkdir -p "$DEPS"

unpack() {
  local zip="$1" dir="$2"
  mkdir -p "$DEPS/$dir"
  unzip -q "$ROOT/deps/$zip" -d "$DEPS/$dir"
}

unpack virtual_ryta_hardworld_v0.19.zip hardworld
unpack legal_effect_v0.10.zip legal
unpack runtime_registry_v0.11.zip registry
unpack oorexx_queue_fabric_v0.8.1.zip queue
unpack structured_relation_plugin_v0.9.zip structured
unpack nosqlserver_v0.75.zip nosql
unpack oorexx_work_load_units_v0.2.zip wlu
unpack reputation_effect_v0.2.zip reputation_effect
unpack reputation_feed_v0.1.zip reputation_feed

export HARDWORLD_ROOT="$DEPS/hardworld/virtual_ryta_hardworld_v0.19"
export LEGAL_EFFECT_ROOT="$DEPS/legal/legal_effect_v0.10"
export RUNTIME_REGISTRY_ROOT="$DEPS/registry/runtime_registry_v0.11"
export QUEUE_FABRIC_ROOT="$DEPS/queue/oorexx_queue_fabric_v0.8.1"
export STRUCTURED_RELATION_ROOT="$DEPS/structured/structured_relation_plugin_v0.9"
export NOSQLSERVER_ROOT="$DEPS/nosql/nosqlserver_v0.75"
export WLU_ROOT="$DEPS/wlu/oorexx_work_load_units_v0.2"
export REPUTATION_EFFECT_ROOT="$DEPS/reputation_effect/reputation_effect_v0.2"
export REPUTATION_FEED_ROOT="$DEPS/reputation_feed/reputation_feed_v0.1"

for v in HARDWORLD_ROOT LEGAL_EFFECT_ROOT RUNTIME_REGISTRY_ROOT QUEUE_FABRIC_ROOT STRUCTURED_RELATION_ROOT NOSQLSERVER_ROOT WLU_ROOT REPUTATION_EFFECT_ROOT REPUTATION_FEED_ROOT; do
  p="${!v}"
  [[ -d "$p" ]] || { echo "FAIL: resolved dependency root missing: $v=$p" >&2; exit 2; }
done

echo "AUTOBUILD closure=LOCKED sha256=$(sha256sum "$ROOT/deps/LOCK.sha256" | awk '{print $1}')"
echo "AUTOBUILD rexx=$(command -v rexx)"
exec "$ROOT/run_tests.sh" "$MODE"
