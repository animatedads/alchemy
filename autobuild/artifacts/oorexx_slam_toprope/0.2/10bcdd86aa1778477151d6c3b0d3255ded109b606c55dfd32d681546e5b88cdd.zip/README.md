# oorexx_slam_toprope v0.2 — SLAM draws, sees, reads and maps, and says who can see what

Architecture: Tom Dyer. Code: Claude (Opus 5.5). This README: Claude (Opus 5.5).

Part of the SLAM family (BodySlam, Piledriver, Moonsault, Boston Crab, ...). Simple controlled words plus
deterministic ooRexx tools, in place of a large language model guessing at pictures.

Tools used: ooRexx 5.3.0 with rxmath; ImageMagick (reads pictures to PPM, draws check pictures
where SLAM says); rsvg-convert (SVG to PNG; renders training glyphs); GDAL 3.8.4 (cut and converted the Balaklava
grid from Copernicus GeoTIFF, and drew its relief picture). No Python in the package.

New in v0.2: the sight line (`src/height_grid.cls`, `src/sight_line.cls`, `src/sight_line.rex`).
Boston Crab's order checker and SLAM 450 ask it who can see what.

## The parts

| Part | Program | What it does | State |
|---|---|---|---|
| SLAM Draw | `src/slam_draw.rex`, `src/pictures.words` | draws from simple words (box, band, star, circle, shape, write) to SVG | working |
| SLAM Space | `src/slam_space.rex`, `src/space_words.md` | reads a described room ("4 metre hallway ...") into a plan | working |
| Top Rope Slam | `src/top_rope.rex`, `src/master.cls` | looks at a picture and says how to draw it in SLAM Draw words (stars, circles, boxes, bands, writing); checks itself with Tom's V5V codec (low resolution, then detail) | working |
| Reader (OCR) | `src/glyphs.cls`, `src/glyphs.txt`, `src/word_hint.rex` | 6 fonts, 76 characters; a word hint that tips close glyph choices, never forces | working |
| Chart reader | `src/top_rope_chart.rex` | flow chart to logic steps | in progress: one step box not yet found; the last change (paper found by colour) is untested |
| Map reader | `src/top_rope_map.rex` | two Google map screenshots: water shapes, fitted (zoom, place), merged, put on the earth | working |
| Stitch tools | `src/stitch.cls`, `src/stitch.rex`, `docs/stitch_words.md` | SLAM stitches pictures of one place by itself: island shape prints, kappa checks, lessons | working (10 of 12 satellite pictures joined) |
| Read map | `src/read_map.rex` | layers: at a place, the layer with the most detail that saw it answers | written; not yet run end to end |
| Height map | `src/height_map.rex`, `src/mga.cls` | ELVIS / NSW DEM to a height layer, "how high is this place", rough 3D model in SLAM Draw words | working |
| Height grid | `src/height_grid.cls` | one height layer read once, asked many times: an ESRI ASCII grid in degrees (Copernicus, SRTM) or Top Rope height words (MGA) | working; tested |
| Sight line | `src/sight_line.cls`, `src/sight_line.rex` | can A see B over the ground: curve of the earth with refraction, eye height above ground or above datum, where the line is blocked; "within" for places known only roughly | working; tested (`tests/test_sight_line.rex`, 18 checks) |

## Run

Draw a flag from words:

```
rexx src/slam_draw.rex examples/flags/za_flag.words za.svg
```

See a picture and say it in words:

```
rexx src/top_rope.rex examples/flags/boxes.png boxes_seen.words
```

Stitch pictures (Google screenshots carry 16 rows of small print at the foot):

```
rexx src/stitch.rex sky.words bottom 16 s01.png s02.png s03.png
```

Height layer and 3D model from an ELVIS grid (north lat, west lon, south lat, east lon, step m):

```
rexx src/height_map.rex make Sydney-DEM-AHD_56_5m.asc heights.words harbour_3d.words -33.795 151.170 -33.885 151.290 50
rexx src/slam_draw.rex harbour_3d.words harbour_3d.svg
```

How high is a place:

```
rexx src/height_map.rex at examples/harbour/harbour_heights.words -33.8597 151.2045
```

`TOPROPE_DEBUG` (time, read, chart, map, stitch, height) shows the working.

## Teaching

SLAM is taught in its own small words, so a small model can follow: `docs/stitch_words.md`,
`src/space_words.md`. What SLAM learned is kept beside the programs: `src/stitch_lessons.txt`
(zooms that were right), `src/top_rope_lessons.txt` (turns that read writing best).

## Examples

- `examples/flags` — words and drawings (Australia, US, South Africa, boxes)
- `examples/hallway` — a described hallway and the plan SLAM Space made
- `examples/harbour/harbour_heights.words` — Sydney Harbour heights, 50 m grid, with fixed places.
  Source: NSW Spatial Services 5 m DEM via ELVIS (AHD71, GDA94 MGA zone 56, +/-0.9 m at 95%), CC BY 4.0.
- `examples/harbour/satellite_stitch.words` — where SLAM put 13 satellite pictures (names and places only)

Not in the repo, on purpose: Google map and satellite screenshots and anything traced from them
(their terms do not allow it in a public repo), the user's own photos, and the 790 MB DEM.
The commands above remake the outputs locally.

## Known limits

- Rexx symbols ignore case: `w`/`W`, `r`/`R`, `n`/`N`, `e`/`E` have each broken a routine here once.
- The DEM alone can not say where water is (round Fort Denison it holds water at 2.5 to 3.3 m);
  the 3D model takes water from a map layer where one saw it, else under 1 m.
- Stitch: the Middle Harbour pair is not joined (best kappa 0.52; its confirm 0.446 is under 0.5).

## Sight line (v0.2)

Who can see what, from a height layer. Ask it in a program:

```rexx
g  = .HeightGrid~new('examples/balaklava/north_valley.asc', 'Copernicus GLO-30 surface model')
sl = .SightLine~new(g)
a = .directory~new; a['LAT'] = 44.5400; a['LON'] = 33.6070; a['EYE'] = 2.5
b = .directory~new; b['LAT'] = 44.5295; b['LON'] = 33.6250; b['EYE'] = 1.5
d = sl~look(a, b)      /* d['SEES'] is 1, 0 or "UNKNOWN"; d['CLEAR'] metres; d['BLOCK_FROM'] metres */
r = sl~spread(a, 300, b, 150)  /* r['VERDICT'] SEES / CANNOT / SOMETIMES; r['SEEN'] of r['TRIED'] */
::requires 'sight_line.cls'
```

Give a place `ASL` (metres above the datum) in place of `EYE` for something in the air, such as a SLAM 450 aircraft. Read the grid once and ask it many times: a look over 2 km on a 30 m grid takes about 11 ms here, and a spread (225 looks) about 2.5 seconds. Loading the Balaklava grid takes under a second.

Or from the command line, from a places file (see `examples/balaklava/places.words`):

```
rexx src/sight_line.rex examples/balaklava/north_valley.asc examples/balaklava/places.words
```

Add `words` at the end for one line per look (`sight <from> <to> SEES|CANNOT|SOMETIMES|UNKNOWN <seen> <tried>`). That is what Boston Crab reads.

Rules it keeps:
- The line is walked in steps of half a grid cell.
- The earth's curve is allowed for, with refraction k = 0.13. The test pins it: two 2 m eyes over flat sea see each other at 10 km and not at 12 km.
- Any part of the line off the grid, or with no data, gives UNKNOWN. It is never guessed.
- Every answer carries the grid's source string. Say in it whether the grid is bare earth (ELVIS DEM) or a surface model with today's trees and buildings (Copernicus).

### For SLAM 450 testers

Run these from the package folder. Each command goes on one line.

1. Set the class path:
```
export REXX_PATH=$PWD/src
```
2. Run the tests. All 18 must pass:
```
rexx tests/test_sight_line.rex
```
3. Run the Balaklava example. Compare with `examples/balaklava/sight_results.txt`:
```
rexx src/sight_line.rex examples/balaklava/north_valley.asc examples/balaklava/places.words
```
4. For the harbour, use `.HeightGrid~new('examples/harbour/harbour_heights.words', 'ELVIS DEM, bare earth, 50 m grid')`. Give the aircraft `ASL` and the watcher `EYE`. The heights are AHD on a bare-earth grid, so buildings do not block. That is said with every answer.

### Balaklava example

`examples/balaklava/north_valley.asc` is cut from the Copernicus GLO-30 tile N44 E033, supplied by Tom Dyer, with GDAL. It covers 33.565–33.665 E, 44.518–44.552 N. The places are Claude (Opus 5.5)'s reading of the relief against the written accounts (see `places.words`), so every look is made "within" a distance. On this grid, from every position tried within 300 m of the Light Brigade's start line, the reverse slope of the Causeway Heights is hidden: 0 of 225 for both the middle and the east of the ridge. That matches the accounts of the captured guns being out of sight behind the ridge. Lucan's and Raglan's views depend on where exactly they stood: "sometimes", with counts.

Produced using Copernicus WorldDEM-30 © DLR e.V. 2010-2014 and © Airbus Defence and Space GmbH 2014-2018 provided under COPERNICUS by the European Union and ESA; all rights reserved. The organisations in charge of the Copernicus programme by law or by delegation do not incur any liability for any use of the Copernicus WorldDEM-30.
