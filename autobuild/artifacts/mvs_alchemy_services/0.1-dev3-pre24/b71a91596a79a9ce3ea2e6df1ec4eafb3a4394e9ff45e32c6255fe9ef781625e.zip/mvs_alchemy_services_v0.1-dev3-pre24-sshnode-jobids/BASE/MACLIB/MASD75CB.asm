* MASD75CB - public pre9 transport control block, ABI level 1
MD75VER  EQU   1
MD75INIT EQU   1
MD75CONN EQU   2
MD75SEND EQU   3
MD75RECV EQU   4
MD75CLOS EQU   5
MD75TERM EQU   6
MD75CB   DSECT
MD75EYE  DS    CL4             'MD75'
MD75LEN  DS    H               control block length
MD75VERS DS    H               MD75VER
MD75FUNC DS    H               function
MD75FLAG DS    H               reserved, zero
MD75SOCK DS    F               socket descriptor
MD75ERR  DS    F               X75/native error detail
MD75RET  DS    F               X75/native return
MD75ACT  DS    F               bytes actually transferred
MD75HOST DS    XL4             IPv4 network address
MD75PORT DS    H               TCP port, network byte order on S/370
MD75RSV  DS    H               reserved, zero
MD75BUFA DS    A               caller buffer
MD75BUFL DS    F               requested byte count
MD75MAX  DS    F               INITAPI max socket result
MD75SIZE EQU   *-MD75CB
