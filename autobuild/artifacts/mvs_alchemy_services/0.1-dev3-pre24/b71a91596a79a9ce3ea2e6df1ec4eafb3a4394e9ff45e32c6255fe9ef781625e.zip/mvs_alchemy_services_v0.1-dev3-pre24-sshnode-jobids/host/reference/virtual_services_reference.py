#!/usr/bin/env python3
"""Executable host-side virtual service providers for MVS Alchemy Services.

This module models the services presented to MVS.  The providers are deliberately
host-side: MVS sees stable MAS operations while the provider may be in-memory for
qualification or backed by Queue Fabric, NoSQLServer, ooRexx IMAP and the SMTP
Secure Stack in deployment.
"""
from dataclasses import dataclass, field
from typing import Dict, List, Tuple

RC_OK=0; RC_WARN=4; RC_REQUEST=8; RC_UNAVAILABLE=12; RC_POLICY=16; RC_INTERNAL=20

class MasServiceError(Exception):
    def __init__(self, rc, reason):
        super().__init__(reason); self.rc=rc; self.reason=reason

class QueueProvider:
    def put(self, queue, payload): raise NotImplementedError
    def get(self, queue): raise NotImplementedError
    def depth(self, queue): raise NotImplementedError

class MemoryQueueProvider(QueueProvider):
    def __init__(self): self.queues: Dict[str,List[bytes]]={}
    def _q(self,name): return self.queues.setdefault(name,[])
    def put(self,queue,payload):
        if not isinstance(payload,(bytes,bytearray)): raise MasServiceError(RC_REQUEST,"QUEUE_PAYLOAD_MUST_BE_BYTES")
        q=self._q(queue); q.append(bytes(payload)); return len(q)
    def get(self,queue):
        q=self._q(queue); return None if not q else q.pop(0)
    def depth(self,queue): return len(self._q(queue))

class DatabaseProvider:
    def put(self, database, key, value): raise NotImplementedError
    def get(self, database, key): raise NotImplementedError
    def delete(self, database, key): raise NotImplementedError
    def scan(self, database, after_key=b"", limit=50): raise NotImplementedError

class MemoryDatabaseProvider(DatabaseProvider):
    """Opaque key/value DB qualification provider; bytes stay untranslated."""
    def __init__(self): self.databases: Dict[str,Dict[bytes,bytes]]={}
    def _db(self,name): return self.databases.setdefault(name,{})
    @staticmethod
    def _bytes(v,reason):
        if not isinstance(v,(bytes,bytearray)): raise MasServiceError(RC_REQUEST,reason)
        return bytes(v)
    def put(self,database,key,value):
        k=self._bytes(key,"DB_KEY_MUST_BE_BYTES"); v=self._bytes(value,"DB_VALUE_MUST_BE_BYTES")
        self._db(database)[k]=v; return True
    def get(self,database,key):
        k=self._bytes(key,"DB_KEY_MUST_BE_BYTES"); return self._db(database).get(k)
    def delete(self,database,key):
        k=self._bytes(key,"DB_KEY_MUST_BE_BYTES"); return self._db(database).pop(k,None) is not None
    def scan(self,database,after_key=b"",limit=50):
        a=self._bytes(after_key,"DB_KEY_MUST_BE_BYTES")
        if limit<1 or limit>256: raise MasServiceError(RC_REQUEST,"BAD_PAGE_LIMIT")
        items=sorted(self._db(database).items(), key=lambda kv:kv[0])
        return tuple((k,v) for k,v in items if k>a)[:limit]

@dataclass(frozen=True)
class MailMessage:
    uidvalidity:int; uid:int; mailbox:str; sender:str; subject:str; headers:bytes; body:bytes; parts:tuple=()

@dataclass
class OutboundDraft:
    sender:str=""; recipients:List[str]=field(default_factory=list); body:bytes=b""
    signature_present:bool=False; signature_verified:bool=False
    signature_identity_matches:bool=False; email_send_authorized:bool=False
    egress_permitted:bool=False; state:str="DRAFT"

class ImapProvider:
    def list_mailboxes(self): raise NotImplementedError
    def page(self,mailbox,after_uid=0,limit=50): raise NotImplementedError
    def get(self,mailbox,uidvalidity,uid): raise NotImplementedError
    def set_seen(self,mailbox,uidvalidity,uid,seen=True): raise NotImplementedError

class MemoryImapProvider(ImapProvider):
    def __init__(self):
        self.mailboxes={
          "INBOX":[MailMessage(71,1001,"INBOX","alice@example.test","signed one",b"From: alice@example.test\r\nSubject: signed one\r\n",b"hello\r\n",(b"attachment\x00\xff",)),
                   MailMessage(71,1002,"INBOX","bob@example.test","signed two",b"From: bob@example.test\r\nSubject: signed two\r\n",b"second\r\n",())],
          "INBOX-UNSIGNED":[MailMessage(72,2001,"INBOX-UNSIGNED","unknown@example.test","unverified",b"From: unknown@example.test\r\nSubject: unverified\r\n",b"unsigned\r\n",())]}
        self.seen=set()
    def list_mailboxes(self): return tuple(sorted(self.mailboxes))
    def page(self,mailbox,after_uid=0,limit=50):
        if mailbox not in self.mailboxes: raise MasServiceError(RC_REQUEST,"MAILBOX_NOT_FOUND")
        if limit<1 or limit>256: raise MasServiceError(RC_REQUEST,"BAD_PAGE_LIMIT")
        return tuple(m for m in self.mailboxes[mailbox] if m.uid>after_uid)[:limit]
    def get(self,mailbox,uidvalidity,uid):
        for m in self.mailboxes.get(mailbox,()):
            if m.uid==uid:
                if m.uidvalidity!=uidvalidity: raise MasServiceError(RC_WARN,"UIDVALIDITY_CHANGED")
                return m
        raise MasServiceError(RC_REQUEST,"MESSAGE_NOT_FOUND")
    def set_seen(self,mailbox,uidvalidity,uid,seen=True):
        self.get(mailbox,uidvalidity,uid); token=(mailbox,uidvalidity,uid)
        if seen:self.seen.add(token)
        else:self.seen.discard(token)
        return seen

class SmtpProvider:
    def submit(self,draft): raise NotImplementedError

class MemorySmtpProvider(SmtpProvider):
    def __init__(self): self.relayed=[]
    def submit(self,d):
        if not d.sender or not d.recipients: raise MasServiceError(RC_REQUEST,"ENVELOPE_INCOMPLETE")
        if not d.signature_present: raise MasServiceError(RC_POLICY,"MESSAGE_SIGNATURE_REQUIRED")
        if not d.signature_verified: raise MasServiceError(RC_POLICY,"MESSAGE_SIGNATURE_INVALID")
        if not d.signature_identity_matches: raise MasServiceError(RC_POLICY,"SIGNATURE_IDENTITY_MISMATCH")
        if not d.email_send_authorized: raise MasServiceError(RC_POLICY,"EMAIL_SEND_NOT_AUTHORIZED")
        if not d.egress_permitted: raise MasServiceError(RC_POLICY,"EGRESS_POLICY_DENIED")
        d.state="RELAY_ELIGIBLE"; self.relayed.append(d); return "RELAY_ELIGIBLE"

class MasVirtualServices:
    """Stable MVS-facing host facade over replaceable providers."""
    def __init__(self,queue=None,database=None,imap=None,smtp=None):
        self.queue=queue or MemoryQueueProvider()
        self.database=database or MemoryDatabaseProvider()
        self.imap=imap or MemoryImapProvider()
        self.smtp=smtp or MemorySmtpProvider()

    def inventory(self):
        return {"QUEUE":"AVAILABLE","DATABASE":"AVAILABLE","IMAP":"AVAILABLE","SMTP":"AVAILABLE"}
