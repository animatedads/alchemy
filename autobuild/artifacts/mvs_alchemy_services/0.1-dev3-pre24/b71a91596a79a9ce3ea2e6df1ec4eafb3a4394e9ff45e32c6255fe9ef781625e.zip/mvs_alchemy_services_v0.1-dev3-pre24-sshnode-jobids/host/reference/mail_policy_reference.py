"""MAS/MAIL non-bypassable relay eligibility reference."""

class MailPolicyError(ValueError):
    pass

def relay_eligible(*, signature_present, signature_verified,
                   signature_identity_matches, email_send_authorized,
                   egress_permitted):
    # Deliberately no compatibility/bypass parameter.
    if not signature_present:
        return False, "MESSAGE_SIGNATURE_REQUIRED"
    if not signature_verified:
        return False, "MESSAGE_SIGNATURE_INVALID"
    if not signature_identity_matches:
        return False, "SIGNATURE_IDENTITY_MISMATCH"
    if not email_send_authorized:
        return False, "EMAIL_SEND_NOT_AUTHORIZED"
    if not egress_permitted:
        return False, "EGRESS_POLICY_DENIED"
    return True, "RELAY_ELIGIBLE"
