#!/usr/bin/env python3
"""MVS-facing queue/database session semantics for MAS dev3-pre6."""
from virtual_services_reference import MasVirtualServices, MasServiceError, RC_REQUEST

OP_QOPEN=0x1000; OP_QPUT=0x1001; OP_QGET=0x1002; OP_QDEPTH=0x1003; OP_QCLOSE=0x1004
OP_DBOPEN=0x1100; OP_DBGET=0x1101; OP_DBPUT=0x1102; OP_DBDELETE=0x1103; OP_DBSCAN=0x1104; OP_DBCLOSE=0x1105

class DataSession:
    def __init__(self, services=None):
        self.services=services or MasVirtualServices(); self.next_handle=1; self.handles={}
    def _put(self,kind,name):
        h=self.next_handle; self.next_handle+=1; self.handles[h]=(kind,name); return h
    def _get(self,h,kind):
        if h not in self.handles: raise MasServiceError(RC_REQUEST,"BAD_HANDLE")
        k,v=self.handles[h]
        if k!=kind: raise MasServiceError(RC_REQUEST,"HANDLE_TYPE_MISMATCH")
        return v
    def queue_open(self,name): return self._put("queue",name)
    def queue_put(self,h,payload): return self.services.queue.put(self._get(h,"queue"),payload)
    def queue_get(self,h): return self.services.queue.get(self._get(h,"queue"))
    def queue_depth(self,h): return self.services.queue.depth(self._get(h,"queue"))
    def db_open(self,name): return self._put("database",name)
    def db_get(self,h,key): return self.services.database.get(self._get(h,"database"),key)
    def db_put(self,h,key,value): return self.services.database.put(self._get(h,"database"),key,value)
    def db_delete(self,h,key): return self.services.database.delete(self._get(h,"database"),key)
    def db_scan(self,h,after_key=b"",limit=50): return self.services.database.scan(self._get(h,"database"),after_key,limit)
    def close(self,h):
        if h not in self.handles: raise MasServiceError(RC_REQUEST,"BAD_HANDLE")
        del self.handles[h]
