#!/usr/bin/env python3
from mas_wire_reference import *
from session_reference import *

def fail(fn,*args):
    try: fn(*args)
    except ValueError: return
    raise AssertionError('expected rejection')

def main():
    sweep=bytes(range(256))
    vectors=(b'',b'MASIVP1',bytes.fromhex('00FFC100'),sweep)
    for p in vectors:
        f=Frame(session=1,request=2,obj=3,op=OP_PING,payload=p)
        assert decode(encode(f))==f
    fail(decode,b'ALCH')
    x=bytearray(encode(Frame(op=OP_PING))); x[0:4]=b'FAIL'; fail(decode,bytes(x))
    x=bytearray(encode(Frame(op=OP_PING))); x[4]=2; fail(decode,bytes(x))
    fail(encode,Frame(op=OP_PING,payload=b'x'*(MAX_FRAME-HLEN+1)))
    # stream fragmentation/coalescing: deliberately split every few bytes
    raws=[encode(Frame(session=1,request=i,op=OP_PING,payload=bytes([i])*i)) for i in range(1,20)]
    d=StreamDecoder(); got=[]; blob=b''.join(raws)
    for i in range(0,len(blob),7): got.extend(d.feed(blob[i:i+7]))
    assert [encode(x) for x in got]==raws and not d.buf
    # HELLO/PING/replay/conflict/DISCONNECT
    s=Session(); hello=Frame(request=1,op=OP_HELLO,payload=b'TK5A')
    a=s.process(hello); assert a.op==OP_ACCEPT and a.session==s.sid
    ping=Frame(session=s.sid,request=2,op=OP_PING,payload=sweep)
    r=s.process(ping); assert r.op==OP_COMPLETE and r.payload==sweep
    assert encode(s.process(ping))==encode(r)
    conflict=Frame(session=s.sid,request=2,op=OP_PING,payload=b'changed')
    assert s.process(conflict).reason==R_REPLAY_CONFLICT
    bye=Frame(session=s.sid,request=3,op=OP_DISCONNECT)
    assert s.process(bye).op==OP_COMPLETE and s.closed
    print('MAS dev3-pre2 BASE-1 host/session reference: PASS')
if __name__=='__main__': main()
