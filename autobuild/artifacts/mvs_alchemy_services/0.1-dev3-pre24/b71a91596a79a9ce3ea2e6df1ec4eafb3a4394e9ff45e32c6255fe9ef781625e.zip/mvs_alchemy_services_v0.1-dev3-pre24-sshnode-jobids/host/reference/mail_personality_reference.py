#!/usr/bin/env python3
"""Executable bounded MAS/MAIL semantic reference; not an SMTP/IMAP implementation."""
from dataclasses import dataclass, field
from mail_policy_reference import relay_eligible
RC_OK=0; RC_WARN=4; RC_REQUEST=8; RC_UNAVAILABLE=12; RC_POLICY=16; RC_INTERNAL=20
OP_MAILINIT=0x1400; OP_MAILBOX=0x1401; OP_MAILLIST=0x1402; OP_MAILOPEN=0x1403
OP_MAILENV=0x1404; OP_MAILHEAD=0x1405; OP_MAILBODY=0x1406; OP_MAILPART=0x1407
OP_MAILNEXT=0x1408; OP_MAILSEEN=0x1409; OP_MAILCLOS=0x140A; OP_MAILTERM=0x140B
OP_MAILNEW=0x1420; OP_MAILFROM=0x1421; OP_MAILTO=0x1422; OP_MAILTEXT=0x1423
OP_MAILSIGN=0x1424; OP_MAILSEND=0x1425; OP_MAILSTAT=0x1426

class MailReferenceError(Exception):
    def __init__(self,rc,reason): super().__init__(reason); self.rc=rc; self.reason=reason

@dataclass(frozen=True)
class Message:
    uidvalidity:int; uid:int; mailbox:str; sender:str; subject:str
    headers:bytes; body:bytes; parts:tuple=()

@dataclass
class Draft:
    sender:str=""; recipients:list=field(default_factory=list); body:bytes=b""
    signature_present:bool=False; signature_verified:bool=False
    signature_identity_matches:bool=False; email_send_authorized:bool=False
    egress_permitted:bool=False; state:str="DRAFT"

class MailBackend:
    def __init__(self):
        self.mailboxes={
          "INBOX":[
            Message(71,1001,"INBOX","alice@example.test","signed one",b"From: alice@example.test\r\nSubject: signed one\r\n",b"hello\r\n",(b"attachment\x00\xff",)),
            Message(71,1002,"INBOX","bob@example.test","signed two",b"From: bob@example.test\r\nSubject: signed two\r\n",b"second\r\n",())],
          "INBOX-UNSIGNED":[
            Message(72,2001,"INBOX-UNSIGNED","unknown@example.test","unverified",b"From: unknown@example.test\r\nSubject: unverified\r\n",b"unsigned\r\n",())]}
        self.relayed=[]
    def list_mailboxes(self): return tuple(sorted(self.mailboxes))
    def page(self,mailbox,after_uid=0,limit=50):
        if mailbox not in self.mailboxes: raise MailReferenceError(RC_REQUEST,"MAILBOX_NOT_FOUND")
        if limit<1 or limit>256: raise MailReferenceError(RC_REQUEST,"BAD_PAGE_LIMIT")
        return tuple(m for m in self.mailboxes[mailbox] if m.uid>after_uid)[:limit]
    def get(self,mailbox,uidvalidity,uid):
        for m in self.mailboxes.get(mailbox,()):
            if m.uid==uid:
                if m.uidvalidity!=uidvalidity: raise MailReferenceError(RC_WARN,"UIDVALIDITY_CHANGED")
                return m
        raise MailReferenceError(RC_REQUEST,"MESSAGE_NOT_FOUND")
    def release(self,d):
        ok,reason=relay_eligible(signature_present=d.signature_present,
          signature_verified=d.signature_verified,
          signature_identity_matches=d.signature_identity_matches,
          email_send_authorized=d.email_send_authorized,
          egress_permitted=d.egress_permitted)
        if not ok: raise MailReferenceError(RC_POLICY,reason)
        d.state="RELAY_ELIGIBLE"; self.relayed.append(d); return reason

class MailSession:
    def __init__(self,backend=None):
        self.backend=backend or MailBackend(); self.next_handle=1; self.handles={}; self.closed=False
    def _put(self,kind,value):
        h=self.next_handle; self.next_handle+=1; self.handles[h]=(kind,value); return h
    def _get(self,h,kind):
        if h not in self.handles: raise MailReferenceError(RC_REQUEST,"BAD_HANDLE")
        k,v=self.handles[h]
        if k!=kind: raise MailReferenceError(RC_REQUEST,"HANDLE_TYPE_MISMATCH")
        return v
    def mailbox(self,name):
        if name not in self.backend.list_mailboxes(): raise MailReferenceError(RC_REQUEST,"MAILBOX_NOT_FOUND")
        return self._put("mailbox",name)
    def list(self,h,after_uid=0,limit=50):
        name=self._get(h,"mailbox")
        return tuple((m.uidvalidity,m.uid,m.sender,m.subject) for m in self.backend.page(name,after_uid,limit))
    def open(self,h,uidvalidity,uid): return self._put("message",self.backend.get(self._get(h,"mailbox"),uidvalidity,uid))
    def envelope(self,h):
        m=self._get(h,"message")
        return {"mailbox":m.mailbox,"uidvalidity":m.uidvalidity,"uid":m.uid,"from":m.sender,"subject":m.subject}
    def headers(self,h): return self._get(h,"message").headers
    def _window(self,b,offset,maximum):
        if offset<0 or maximum<1 or maximum>32768: raise MailReferenceError(RC_REQUEST,"BAD_TRANSFER_WINDOW")
        end=min(len(b),offset+maximum); return b[offset:end],end<len(b)
    def body(self,h,offset=0,maximum=4096): return self._window(self._get(h,"message").body,offset,maximum)
    def part(self,h,index,offset=0,maximum=4096):
        m=self._get(h,"message")
        if index<1 or index>len(m.parts): raise MailReferenceError(RC_REQUEST,"PART_NOT_FOUND")
        return self._window(m.parts[index-1],offset,maximum)
    def close(self,h):
        if h not in self.handles: raise MailReferenceError(RC_REQUEST,"BAD_HANDLE")
        del self.handles[h]
    def new(self): return self._put("draft",Draft())
    def set_from(self,h,sender): self._get(h,"draft").sender=sender
    def add_to(self,h,recipient): self._get(h,"draft").recipients.append(recipient)
    def set_text(self,h,body):
        if not isinstance(body,(bytes,bytearray)): raise MailReferenceError(RC_REQUEST,"BODY_MUST_BE_BYTES")
        self._get(h,"draft").body=bytes(body)
    def apply_host_signature_evidence(self,h,*,present,verified,identity_matches):
        d=self._get(h,"draft"); d.signature_present=bool(present); d.signature_verified=bool(verified); d.signature_identity_matches=bool(identity_matches)
    def apply_host_authority(self,h,*,email_send,egress):
        d=self._get(h,"draft"); d.email_send_authorized=bool(email_send); d.egress_permitted=bool(egress)
    def send(self,h):
        d=self._get(h,"draft")
        if not d.sender or not d.recipients: raise MailReferenceError(RC_REQUEST,"ENVELOPE_INCOMPLETE")
        return self.backend.release(d)
    def status(self,h): return self._get(h,"draft").state
    def term(self): self.handles.clear(); self.closed=True
