from pathlib import Path
import json, os
class Store:
    def __init__(self, root):
        self.root=Path(root); self.obj=self.root/'objects'; self.obj.mkdir(parents=True,exist_ok=True)
        self.j=self.root/'objects.journal'; self.seq=0; self.bind={}; self.objects={}; self._reload()
    def _reload(self):
        if not self.j.exists(): return
        for line in self.j.read_text().splitlines():
            if not line: continue
            rec=json.loads(line); self.seq=max(self.seq,rec['seq']); self.bind[rec['path']]=rec['id']; self.objects[rec['id']]=rec
    def publish(self,path,data,media='application/octet-stream'):
        self.seq+=1; oid=f'mvs-sf:{self.seq:012d}'; final=self.obj/(oid.replace(':','_')+'.bin'); stage=final.with_suffix('.stage')
        stage.write_bytes(data); os.replace(stage,final)
        rec={'seq':self.seq,'id':oid,'path':path,'media':media,'size':len(data),'file':str(final)}
        with self.j.open('a') as f: f.write(json.dumps(rec,sort_keys=True)+'\n'); f.flush(); os.fsync(f.fileno())
        self.objects[oid]=rec; self.bind[path]=oid; return oid
    def read_path(self,path): return Path(self.objects[self.bind[path]]['file']).read_bytes()
