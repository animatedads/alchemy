#!/usr/bin/env python3
import tempfile
from dsfs_durable_reference import Store
with tempfile.TemporaryDirectory() as td:
    s=Store(td); a=s.publish('/u/USER/sample.txt',b'HELLO WORLD\n','text/plain'); b=s.publish('/u/USER/sample.txt',b'HELLO WORLD\nSECOND\n','text/plain')
    assert a!=b and len(s.objects)==2 and s.bind['/u/USER/sample.txt']==b
    s2=Store(td)
    assert len(s2.objects)==2 and s2.bind['/u/USER/sample.txt']==b and s2.read_path('/u/USER/sample.txt')==b'HELLO WORLD\nSECOND\n'
    print('PASS DSFS_DURABLE_REFERENCE')
    print('REF1='+a); print('REF2='+b); print('OBJECTS='+str(len(s2.objects)))
