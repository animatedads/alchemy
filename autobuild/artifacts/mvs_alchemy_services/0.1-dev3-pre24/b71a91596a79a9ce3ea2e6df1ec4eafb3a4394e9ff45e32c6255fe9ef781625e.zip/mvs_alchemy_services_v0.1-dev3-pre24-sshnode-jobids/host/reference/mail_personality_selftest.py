#!/usr/bin/env python3
from mail_personality_reference import *
def expect(reason,fn,*a,**kw):
    try: fn(*a,**kw)
    except MailReferenceError as e:
        assert e.reason==reason,(e.reason,reason); return e.rc
    raise AssertionError("expected "+reason)
b=MailBackend(); s=MailSession(b)
assert b.list_mailboxes()==("INBOX","INBOX-UNSIGNED")
ibox=s.mailbox("INBOX")
assert s.list(ibox,limit=1)[0][1]==1001
assert s.list(ibox,after_uid=1001,limit=1)[0][1]==1002
assert expect("BAD_PAGE_LIMIT",s.list,ibox,limit=257)==RC_REQUEST
assert expect("UIDVALIDITY_CHANGED",s.open,ibox,999,1001)==RC_WARN
mh=s.open(ibox,71,1001); e=s.envelope(mh)
assert (e["mailbox"],e["uidvalidity"],e["uid"])==("INBOX",71,1001)
assert s.headers(mh).startswith(b"From:")
x,more=s.body(mh,0,3); assert x==b"hel" and more
x,more=s.body(mh,3,32768); assert x==b"lo\r\n" and not more
x,more=s.part(mh,1,0,32768); assert x==b"attachment\x00\xff" and not more
assert expect("HANDLE_TYPE_MISMATCH",s.envelope,ibox)==RC_REQUEST
s.close(mh); assert expect("BAD_HANDLE",s.envelope,mh)==RC_REQUEST
d=s.new(); s.set_from(d,"mvs@example.test"); s.add_to(d,"dest@example.test"); s.set_text(d,b"opaque\x00body\xff")
s.apply_host_authority(d,email_send=True,egress=True)
assert expect("MESSAGE_SIGNATURE_REQUIRED",s.send,d)==RC_POLICY
s.apply_host_signature_evidence(d,present=True,verified=False,identity_matches=False)
assert expect("MESSAGE_SIGNATURE_INVALID",s.send,d)==RC_POLICY
s.apply_host_signature_evidence(d,present=True,verified=True,identity_matches=False)
assert expect("SIGNATURE_IDENTITY_MISMATCH",s.send,d)==RC_POLICY
s.apply_host_signature_evidence(d,present=True,verified=True,identity_matches=True)
s.apply_host_authority(d,email_send=False,egress=True)
assert expect("EMAIL_SEND_NOT_AUTHORIZED",s.send,d)==RC_POLICY
s.apply_host_authority(d,email_send=True,egress=False)
assert expect("EGRESS_POLICY_DENIED",s.send,d)==RC_POLICY
s.apply_host_authority(d,email_send=True,egress=True)
assert s.send(d)=="RELAY_ELIGIBLE" and s.status(d)=="RELAY_ELIGIBLE" and len(b.relayed)==1
s.term(); assert s.closed and not s.handles
print("MAS dev3-pre5 MAIL personality/handles/paging/security reference: PASS")
