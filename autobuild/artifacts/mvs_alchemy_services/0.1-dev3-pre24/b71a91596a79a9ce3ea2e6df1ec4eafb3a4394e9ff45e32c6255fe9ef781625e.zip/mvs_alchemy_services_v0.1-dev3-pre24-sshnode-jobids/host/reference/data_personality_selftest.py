#!/usr/bin/env python3
from data_personality_reference import *

def expect(reason,fn,*a):
    try: fn(*a)
    except MasServiceError as e:
        assert e.reason==reason; return
    raise AssertionError('expected '+reason)

s=DataSession()
q=s.queue_open('MVS.APP.Q')
assert s.queue_put(q,b'abc\x00\xff')==1
assert s.queue_depth(q)==1
assert s.queue_get(q)==b'abc\x00\xff'
d=s.db_open('MVS.APP.DB')
assert s.db_put(d,b'k\x00',b'v\xff')
assert s.db_get(d,b'k\x00')==b'v\xff'
assert s.db_scan(d)==((b'k\x00',b'v\xff'),)
expect('HANDLE_TYPE_MISMATCH',s.queue_depth,d)
s.close(q); expect('BAD_HANDLE',s.queue_depth,q)
print('MAS dev3-pre6 QUEUE/DB MVS handle personality reference: PASS')
