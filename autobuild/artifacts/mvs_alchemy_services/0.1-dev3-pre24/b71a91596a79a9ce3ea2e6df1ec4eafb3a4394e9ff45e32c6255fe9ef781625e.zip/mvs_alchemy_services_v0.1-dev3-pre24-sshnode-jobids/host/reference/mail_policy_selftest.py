from mail_policy_reference import relay_eligible

cases = [
    ((False,False,False,False,False), (False,"MESSAGE_SIGNATURE_REQUIRED")),
    ((True,False,False,True,True), (False,"MESSAGE_SIGNATURE_INVALID")),
    ((True,True,False,True,True), (False,"SIGNATURE_IDENTITY_MISMATCH")),
    ((True,True,True,False,True), (False,"EMAIL_SEND_NOT_AUTHORIZED")),
    ((True,True,True,True,False), (False,"EGRESS_POLICY_DENIED")),
    ((True,True,True,True,True), (True,"RELAY_ELIGIBLE")),
]
for args, expected in cases:
    got=relay_eligible(signature_present=args[0], signature_verified=args[1],
        signature_identity_matches=args[2], email_send_authorized=args[3],
        egress_permitted=args[4])
    assert got == expected, (args, got, expected)

# Prove the API has no hidden compatibility override argument.
try:
    relay_eligible(signature_present=False, signature_verified=False,
        signature_identity_matches=False, email_send_authorized=True,
        egress_permitted=True, allow_unsigned_relay=True)
except TypeError:
    pass
else:
    raise AssertionError("unsigned-relay compatibility argument unexpectedly accepted")

print("MAS dev3-pre4 MAIL hard-relay-policy reference: PASS")
