#!/usr/bin/env python3
"""Executable BASE-1 host/session reference. No socket or DYN75 assumptions."""
from dataclasses import dataclass
from mas_wire_reference import Frame, encode, decode, HLEN, MAX_FRAME
OP_HELLO=0x0001; OP_ACCEPT=0x0002; OP_PING=0x0003; OP_DISCONNECT=0x0004
OP_COMPLETE=0x8001; OP_ERROR=0x8002
R_OK=0; R_PROTOCOL=1; R_REPLAY_CONFLICT=2; R_BAD_SESSION=3

class StreamDecoder:
    def __init__(self): self.buf=bytearray()
    def feed(self,data):
        self.buf.extend(data); out=[]
        while True:
            if len(self.buf)<HLEN: break
            if self.buf[:4] != b'ALCH': raise ValueError('bad eye')
            total=int.from_bytes(self.buf[8:12],'big')
            if total < HLEN or total > MAX_FRAME: raise ValueError('bad total')
            if len(self.buf)<total: break
            raw=bytes(self.buf[:total]); del self.buf[:total]
            out.append(decode(raw))
        return out

@dataclass
class LedgerEntry:
    fingerprint: bytes
    response: bytes

class Session:
    def __init__(self, sid=0x4d41530000000001):
        self.sid=sid; self.accepted=False; self.closed=False; self.ledger={}
    @staticmethod
    def _fp(f):
        import hashlib,struct
        h=hashlib.sha256(); h.update(struct.pack('>HI',f.op,f.obj)); h.update(f.payload); return h.digest()
    def _reply(self,req,op,status=0,reason=0,payload=b''):
        return Frame(session=self.sid,request=req.request,obj=req.obj,op=op,status=status,reason=reason,payload=payload)
    def process(self,req):
        fp=self._fp(req); key=req.request
        if key in self.ledger:
            e=self.ledger[key]
            if e.fingerprint != fp:
                return self._reply(req,OP_ERROR,12,R_REPLAY_CONFLICT)
            return decode(e.response)
        if not self.accepted:
            if req.session != 0 or req.op != OP_HELLO:
                rsp=self._reply(req,OP_ERROR,12,R_PROTOCOL)
            else:
                self.accepted=True
                rsp=self._reply(req,OP_ACCEPT,payload=b'mvs.alchemy/1')
        elif req.session != self.sid:
            rsp=self._reply(req,OP_ERROR,12,R_BAD_SESSION)
        elif req.op == OP_PING:
            rsp=self._reply(req,OP_COMPLETE,payload=req.payload)
        elif req.op == OP_DISCONNECT:
            self.closed=True; rsp=self._reply(req,OP_COMPLETE)
        else:
            rsp=self._reply(req,OP_ERROR,12,R_PROTOCOL)
        self.ledger[key]=LedgerEntry(fp,encode(rsp))
        return rsp
