#!/usr/bin/env python3
from virtual_services_reference import *

def expect(reason, fn, *a, **kw):
    try: fn(*a,**kw)
    except MasServiceError as e:
        assert e.reason==reason,(e.reason,reason); return e.rc
    raise AssertionError("expected "+reason)

s=MasVirtualServices()
assert s.inventory()=={"QUEUE":"AVAILABLE","DATABASE":"AVAILABLE","IMAP":"AVAILABLE","SMTP":"AVAILABLE"}
# queue
assert s.queue.depth("MAS.TEST.QUEUE")==0
assert s.queue.put("MAS.TEST.QUEUE",b"one\x00\xff")==1
assert s.queue.put("MAS.TEST.QUEUE",b"two")==2
assert s.queue.get("MAS.TEST.QUEUE")==b"one\x00\xff"
assert s.queue.get("MAS.TEST.QUEUE")==b"two"
assert s.queue.get("MAS.TEST.QUEUE") is None
assert expect("QUEUE_PAYLOAD_MUST_BE_BYTES",s.queue.put,"Q","text")==RC_REQUEST
# database
assert s.database.put("MAS.TEST.DB",b"A",b"alpha\x00")
assert s.database.put("MAS.TEST.DB",b"B",b"beta\xff")
assert s.database.get("MAS.TEST.DB",b"A")==b"alpha\x00"
assert s.database.scan("MAS.TEST.DB",b"",1)==((b"A",b"alpha\x00"),)
assert s.database.scan("MAS.TEST.DB",b"A",50)==((b"B",b"beta\xff"),)
assert s.database.delete("MAS.TEST.DB",b"A")
assert s.database.get("MAS.TEST.DB",b"A") is None
assert expect("BAD_PAGE_LIMIT",s.database.scan,"MAS.TEST.DB",b"",257)==RC_REQUEST
# IMAP projection
assert s.imap.list_mailboxes()==("INBOX","INBOX-UNSIGNED")
page=s.imap.page("INBOX",0,1); assert page[0].uid==1001
m=s.imap.get("INBOX",71,1001); assert m.body==b"hello\r\n"
assert s.imap.set_seen("INBOX",71,1001,True)
assert ("INBOX",71,1001) in s.imap.seen
assert expect("UIDVALIDITY_CHANGED",s.imap.get,"INBOX",999,1001)==RC_WARN
# SMTP security gate
for reason,vals in [
 ("MESSAGE_SIGNATURE_REQUIRED",{}),
 ("MESSAGE_SIGNATURE_INVALID",{"signature_present":True}),
 ("SIGNATURE_IDENTITY_MISMATCH",{"signature_present":True,"signature_verified":True}),
 ("EMAIL_SEND_NOT_AUTHORIZED",{"signature_present":True,"signature_verified":True,"signature_identity_matches":True}),
 ("EGRESS_POLICY_DENIED",{"signature_present":True,"signature_verified":True,"signature_identity_matches":True,"email_send_authorized":True})]:
    d=OutboundDraft(sender="mvs@example.test",recipients=["dest@example.test"],body=b"body")
    for k,v in vals.items(): setattr(d,k,v)
    assert expect(reason,s.smtp.submit,d)==RC_POLICY

d=OutboundDraft(sender="mvs@example.test",recipients=["dest@example.test"],body=b"opaque\x00\xff",
    signature_present=True,signature_verified=True,signature_identity_matches=True,
    email_send_authorized=True,egress_permitted=True)
assert s.smtp.submit(d)=="RELAY_ELIGIBLE"
assert len(s.smtp.relayed)==1
print("MAS dev3-pre6 virtual QUEUE/DB/IMAP/SMTP services reference: PASS")
