# Development checkpoints

- dev1 / BASE-0: frame and application ABI foundation.
- dev2 / BASE-0.5: typed values and replay representation qualification.
- dev3 / BASE-1: real TK5 + Hercules DYN75 + HELLO/ACCEPT/PING and binary-integrity qualification.
- dev4 / BASE-2: Alchemy handles, replay/recovery and MemoryQueue.
- dev5 / BASE-3: resident MAS STC and local callers.
- dev6 / BASE-4: IBM-style installation, media and service.
- Personality qualification follows: MQ, DB2, LDAP, CICS.

`dev3-pre1` is preparation for BASE-1 and is not BASE-1 qualification.

## dev3-pre3 dependency discovery

The current reviewed Library line is `oorexx_ldap_identity_v0.1-dev14` (the original MAS binding was established against dev10). MAS/LDAP is therefore no longer specified against hypothetical LDAP class names: its host-side semantic seam is grounded in `LdapConversationService` and the published `identity.directory/0.1`, `ldap.personality/0.1`, `ldap.conversation/0.1`, `ldap.dn/0.1`, `ldap.filter/0.1`, `ldap.matching/0.1`, `ldap.schema/0.1`, and `ldap.paging/0.1` development contracts.

- MAS/MAIL personality reserved at `1400-14FF`; semantic binding added in dev3-pre4; executable bounded host reference added in dev3-pre5.
