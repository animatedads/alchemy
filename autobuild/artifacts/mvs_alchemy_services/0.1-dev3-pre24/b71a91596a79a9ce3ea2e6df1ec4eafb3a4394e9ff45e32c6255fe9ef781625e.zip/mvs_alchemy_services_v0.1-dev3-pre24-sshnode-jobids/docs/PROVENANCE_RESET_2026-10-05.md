# MVS Alchemy Services — Provenance Reset

Date: 2026-10-05

## Purpose

This document resets the implementation ledger after prior assistant claims represented guest-side MVS Alchemy components as written/delivered when the surviving artifacts do not support those claims.

## Invalidated historical claim

`mvs_alchemy_services_v0.1-dev2.zip` was previously described as attached, including a filename, size and SHA-256. No actual archive bytes or source from that MAS dev2 delivery are present in the surviving artifact set. The claim must not be used as implementation evidence.

## Verified surviving archives

- `mvs_alchemy_services_v0.1-dev3-pre5(2).zip` — `3a0544355f7e8b1968b5876bf7741a811eab7ce3d2e337546cdedf60852e5cbe`
- `mvs_alchemy_services_v0.1-dev3-pre6.zip` — `54e46f1623fd211b0ea0221303fc6bdbf3099c78e5a371987b00755144602dec`
- `mvs_alchemy_services_v0.1-dev3-pre7-dsfs.zip` — `b92f442a8662b977b515ad5929876d212f3b8314e03b311a31801a10a8ccd71e`
- `mvs_alchemy_services_v0.1-dev3-pre8-dsfs-durable.zip` — `8db99d0a584fa00fa49b8e349ec677a35eb2c8d48f72b8674b7953eb090e1b16`

## Verified implementation chronology

### dev3-pre5

Real artifacts include:
- BASE ABI/wire macros and BASE-0 material.
- MVS `MASCB.asm` ABI header.
- MVS `MASIVP1.asm` safety stub.
- Host `MasBase.cls`.
- Mail personality/reference material.

Guest transport status: **NOT IMPLEMENTED / NOT QUALIFIED**.

### dev3-pre6

Adds real host-side executable virtual-service providers:
- `MasMemoryQueueProvider`
- `MasMemoryDatabaseProvider`
- `MasMemoryImapProvider`
- `MasMemorySmtpProvider`
- `MasVirtualServices`

These are host-side qualification providers, not a live ED209Z service path.

Guest transport status: **NOT IMPLEMENTED / NOT QUALIFIED**.

### dev3-pre7-dsfs

Adds real host-side Storage Fabric / DSFS code:
- `MasMemoryStorageFabricStore`
- `MasStorageFabricDsfsService`
- TEXT/BINARY/RECORD views
- directory-to-AWS tape projection

Guest transport status: **NOT IMPLEMENTED / NOT QUALIFIED**.

### dev3-pre8-dsfs-durable

Adds:
- durable host-backed Storage Fabric object store
- restart reconstruction
- `MasPathSessionDispatcher`
- AWS inspector and Hercules tape planner

The dispatcher is explicitly transport-neutral. It does not implement the MVS guest carrier.

Guest transport status: **NOT IMPLEMENTED / NOT QUALIFIED**.

## Direct guest-side evidence

`mvs/asm/MASIVP1.asm` in the surviving line is a deliberate RC=8 safety stub. It states BASE-1 may only return success after the real TK5 DYN75 calling convention and live HELLO/ACCEPT/PING/binary-integrity tests are implemented.

`qualification/BASE1/dyn75_interface.txt` states:
- `STATUS=NOT_QUALIFIED`
- MASD75 is intended as the R1 transport binding.
- The MVS calling convention was intentionally not fabricated.
- Required surface: INITIALIZE, CONNECT, SEND, RECEIVE, CLOSE, TERMINATE.

## GitHub history check

The `animatedads/alchemy` repository contains the earlier MAS transport specification defining `MASD75` as an outbound Hercules DYN75 host-socket binding and listing INITIALIZE/CONNECT/SEND/RECEIVE/CLOSE/TERMINATE. Current code search found the specification but no `MASD75` implementation source.

Therefore the guest transport must be treated as **never delivered**, not lost.

## Current truthful capability ledger

| Facility | Host semantics | Durable host state | Guest ED209Z transport | Live ED209Z qualification |
|---|---|---|---|---|
| Queue | YES (pre6 memory provider) | NO in surviving MAS package | NO | NOT_RUN |
| Generic DB | YES (pre6 memory provider) | NO in surviving MAS package | NO | NOT_RUN |
| DB2P | No surviving MAS implementation; belongs at NoSQLServer personality boundary | external | NO | NOT_RUN |
| SMTP | YES (pre6 bounded provider) | provider-dependent | NO | NOT_RUN |
| IMAP | YES (pre6 bounded provider) | provider-dependent | NO | NOT_RUN |
| PATH / Storage Fabric | YES | YES (pre8 host store) | NO | NOT_RUN |
| AWS tape projection | YES | file artifact | via Hercules device only, not MAS request transport | host fixture PASS; MVS read-back NOT_RUN |
| Hercules control | YES, separately in Hercules Services | N/A | resident Hercules Rexx | LIVE PASS on ED209C/ED209Z |

## Standing evidence rule

From this reset onward:

1. `IMPLEMENTED` requires an actual source file in a delivered artifact.
2. `DELIVERED` requires actual archive bytes and a computed hash.
3. `COMPILES` requires compiler/interpreter execution in a named environment.
4. `LIVE PASS` requires the full environment path to execute and produce correlated evidence.
5. Fixture/fake/in-memory qualification cannot be promoted to live qualification.
6. Any environment-dependent delivery must include a full environment qualification script.
7. Logging v0.7 is mandatory for multi-process/multi-machine acceptance evidence.

## Next implementation boundary

The next MAS delivery must be labelled as the **first real guest transport implementation**, not as a recovered dev2 feature. It must include actual MVS-side source, host endpoint, installation/build JCL or scripts, Logging v0.7 host evidence, and a full ED209C/ED209Z environment qualification script.
