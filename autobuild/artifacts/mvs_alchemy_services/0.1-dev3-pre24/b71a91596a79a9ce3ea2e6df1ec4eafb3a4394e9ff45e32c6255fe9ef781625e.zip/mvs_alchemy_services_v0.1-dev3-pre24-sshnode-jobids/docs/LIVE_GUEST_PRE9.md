# pre9: first real MVS guest transport implementation

This cut replaces the old `MASIVP1` RC=8 transport stub with actual source for
an ED209Z -> ED209C service crossing.

## MVS side

`mvs/asm/MASD75.asm` is a byte transport over the EZASMI API shipped for
MVS 3.8/TK5. EZASMI uses Hercules' X'75' host-socket facility. MASD75 implements
INITIALIZE, CONNECT, SEND, RECEIVE, CLOSE and TERMINATE and deliberately does
not parse the MAS protocol. SEND/RECEIVE loop until the requested byte count is
complete.

`mvs/asm/MASLIVE.asm` is the live integration IVP. It constructs the existing
48-byte `mvs.alchemy/1` frame and typed values and tests:

- HELLO/ACCEPT;
- binary PING containing `00 FF`;
- Queue OPEN/PUT/DEPTH/GET;
- database OPEN/PUT/GET with opaque binary bytes;
- IMAP session/list/open/body;
- SMTP draft/from/to/text/sign/send policy path;
- PATH create/write/close/reopen/read;
- DISCONNECT.

The program issues `WTO 'MASLIVE PASS ...'` after each facility and
`MASLIVE PASS ALL` only after the complete crossing succeeds.

## Host side

`HOST/src/MasLiveGateway.cls` is an ooRexx socket endpoint. It uses:

- `MasWire.cls` for the `mvs.alchemy/1` frame and typed-value codec;
- the existing pre6 `MasVirtualServices` provider semantics for Queue, DB,
  IMAP and SMTP;
- a small durable PATH provider behind the existing PATH semantic contract;
- ooRexx Logging v0.7 for every request and completion/error event.

For this cut Queue/DB/IMAP/SMTP still use their explicit qualification
providers. This proves the **real MVS guest transport and MAS dispatch**, not
production Queue Fabric/NoSQLServer/IMAP/SMTP provider bindings.

## Full environment qualification

Run from the controller:

```sh
SSHNODE=./sshnode.sh \
MAS_PACKAGE_ZIP=/path/to/mvs_alchemy_services_v0.1-dev3-pre9-live-guest.zip \
./scripts/qualify_ed209c_ed209z_services.sh
```

The script stages ED209C, compiles the ooRexx gateway under the installed
runtime, starts the live gateway on host loopback, creates a complete MVS
assembler/link/run job from the exact packaged source, submits it to the
Hercules 3505 reader, and requires both the ED209Z WTO markers and correlated
host gateway log operations.

Fixture tests cannot produce the environment PASS.
