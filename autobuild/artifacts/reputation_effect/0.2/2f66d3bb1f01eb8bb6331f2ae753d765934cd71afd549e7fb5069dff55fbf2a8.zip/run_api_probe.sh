#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
export PATH="$ROOT/src:$ROOT/runtime:$ROOT/tests:${PATH}"
export REXX_PATH="$ROOT/src:$ROOT/runtime:$ROOT/tests${REXX_PATH:+:$REXX_PATH}"
exec "${REXX:-rexx}" "$ROOT/tests/test_api_communication_constructor.rex"
