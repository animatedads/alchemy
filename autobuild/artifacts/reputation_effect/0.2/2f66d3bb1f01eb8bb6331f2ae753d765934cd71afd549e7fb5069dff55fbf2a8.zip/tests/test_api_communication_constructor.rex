say 'api=' .ReputationEffectBuild~API_VERSION
if .ReputationEffectBuild~API_VERSION \== 'reputation.effect/0.2' then do
  say 'FAIL REPUTATION_API_TOO_OLD actual=' .ReputationEffectBuild~API_VERSION 'required=reputation.effect/0.2'
  exit 1
end
failure = .ReputationCommunicationFailure~new('F-SERVICE', 'SERVICE_RESPONSE_FAILURE', 'SUPPORT', 'OPEN', 70, 'Technical response consumed allowance but was not delivered')
if failure~failureId \== 'F-SERVICE' then do
  say 'FAIL constructor failureId=' failure~failureId
  exit 1
end
say 'PASS test_api_communication_constructor class=ReputationCommunicationFailure id=' failure~failureId
exit 0
::requires 'ReputationEffect.cls'
