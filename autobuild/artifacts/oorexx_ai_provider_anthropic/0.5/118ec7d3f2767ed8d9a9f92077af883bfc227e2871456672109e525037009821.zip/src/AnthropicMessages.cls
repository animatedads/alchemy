/* ooRexx AI Provider - Anthropic v0.3 : multi-block Messages client.
 * Architecture: Tom Dyer. Implementation: Claude (Opus 5.5), 2026-11-03.
 *
 * Adds what v0.2's narrow AIProviderRequest (one text prompt) cannot carry:
 *   - a system prompt, optionally marked cache_control:ephemeral so a long
 *     static briefing is billed at the cache-read rate after the first call;
 *   - an ordered list of content blocks: text and image (PNG, base64);
 *   - full usage accounting: input, output, cache-write, cache-read tokens,
 *     wall-clock latency, and a rate-card cost estimate.
 * Credential discipline is unchanged from v0.2: the secret is acquired from
 * the Secret Broker by reference, handed to curl on stdin (v0.4: never a file),
 * the lease is retired as soon as curl returns, temp files are removed.
 */
::class AnthropicMessageRequest public
::attribute model
::attribute system
::attribute cacheSystem
::attribute blocks
::attribute maxTokens
::attribute temperature
::attribute thinking
::attribute effort
::method init
  expose model system cacheSystem blocks maxTokens temperature thinking effort
  use strict arg model, system = "", cacheSystem = .false, maxTokens = 512, temperature = .nil
  blocks = .array~new
  thinking = "DEFAULT"; effort = .nil
  if \datatype(maxTokens, "W") | maxTokens < 1 then raise syntax 88.900 array("positive maxTokens")
::method addText
  expose blocks
  use strict arg text
  b = .directory~new; b["type"] = "text"; b["text"] = text
  blocks~append(b)
  return self
::method addPngBase64
  expose blocks
  use strict arg base64
  if base64~length = 0 then raise syntax 88.900 array("non-empty base64 PNG")
  src = .directory~new
  src["type"] = "base64"; src["media_type"] = "image/png"; src["data"] = base64
  b = .directory~new; b["type"] = "image"; b["source"] = src
  blocks~append(b)
  return self
::method thinkingOff
  /* Answer directly: thinking:{type:disabled} (Haiku 5.5 thinks by default);
     on Sonnet/Opus 5.5 serialised as {type:between_tools} (v0.4). */
  expose thinking effort
  thinking = "DISABLED"; effort = .nil
  return self
::method thinkingAdaptive
  /* thinking:{type:adaptive} + output_config.effort (LOW|MEDIUM|HIGH). */
  expose thinking effort
  use strict arg level = "LOW"
  if level~upper \= "LOW" & level~upper \= "MEDIUM" & level~upper \= "HIGH" then raise syntax 88.900 array("effort LOW, MEDIUM or HIGH")
  thinking = "ADAPTIVE"; effort = level~lower
  return self
::method toBody
  expose model system cacheSystem blocks maxTokens temperature thinking effort
  body = .directory~new
  body["model"] = model
  body["max_tokens"] = maxTokens
  if temperature \== .nil then body["temperature"] = temperature
  if thinking = "DISABLED" then do
    /* v0.4: the 5.5 frontier models (Sonnet 5.5, Opus 5.5) reject
       {type:disabled}; the API says to send {type:between_tools}, under
       which "the model does not think before responding" (observed
       2026-11-03). Haiku 5.5 and older models keep {type:disabled}. */
    t = .directory~new; t["type"] = "disabled"
    m = model~string~lower
    if m~left(17) = "claude-sonnet-5-5" | m~left(15) = "claude-opus-5-5" then t["type"] = "between_tools"
    body["thinking"] = t
  end
  if thinking = "ADAPTIVE" then do
    t = .directory~new; t["type"] = "adaptive"; body["thinking"] = t
    oc = .directory~new; oc["effort"] = effort; body["output_config"] = oc
  end
  if system \== "" then do
    sb = .directory~new; sb["type"] = "text"; sb["text"] = system
    if cacheSystem then do
      cc = .directory~new; cc["type"] = "ephemeral"; sb["cache_control"] = cc
    end
    body["system"] = .array~of(sb)
  end
  msg = .directory~new; msg["role"] = "user"; msg["content"] = blocks
  body["messages"] = .array~of(msg)
  return body

::class AnthropicMessageReply public
::attribute ok get
::attribute code get
::attribute message get
::attribute text get
::attribute model get
::attribute stopReason get
::attribute inputTokens get
::attribute outputTokens get
::attribute cacheWriteTokens get
::attribute cacheReadTokens get
::attribute latencyMs get
::method init
  expose ok code message text model stopReason inputTokens outputTokens cacheWriteTokens cacheReadTokens latencyMs
  use strict arg ok, code, message, text, model, stopReason, inputTokens, outputTokens, cacheWriteTokens, cacheReadTokens, latencyMs
::method costUsd
  /* Rate card from the catalog entry (micro-dollars per Mtok).
     Cache write = 1.25x input (5-minute TTL); cache read = the entry's
     cacheReadMultiplier x input (v0.4: 0.1 default, 0.05 on Sonnet 5.5). */
  expose model inputTokens outputTokens cacheWriteTokens cacheReadTokens
  use strict arg catalog
  numeric digits 16
  e = catalog~entry(model)
  if e == .nil then return ""
  inRate = e~inputMicroUsdPerMtok / 1000000; outRate = e~outputMicroUsdPerMtok / 1000000
  return (inputTokens * inRate + cacheWriteTokens * inRate * 1.25 + cacheReadTokens * inRate * e~cacheReadMultiplier + outputTokens * outRate) / 1000000

::class AnthropicMessageClient public
::method init
  expose config
  use strict arg config
::method send
  expose config
  use strict arg request
  t0 = .dateTime~new
  secretOutcome = config~secretBroker~acquire(config~credentialReference)
  if \secretOutcome~ok then return self~failure("AI_ANTHROPIC_CREDENTIAL_MISSING", "credential could not be acquired", request, t0)
  lease = secretOutcome~value
  secretValue = lease~secretForTrustedConsumer
  if \secretValue~ok then do
    ignore = lease~retire
    return self~failure("AI_ANTHROPIC_CREDENTIAL_MISSING", "credential lease is unavailable", request, t0)
  end
  credential = secretValue~value
  workDir = "/tmp/anthropic_msg_" || self~identityHash || "_" || .dateTime~new~microseconds
  call sysMkDir workDir
  bodyFile = workDir || "/body.json"; cfgFile = workDir || "/curl.cfg"
  outFile = workDir || "/out.json"; errFile = workDir || "/err.txt"
  call charout bodyFile, .JSON~toJSON(request~toBody)
  call stream bodyFile, "c", "close"
  cfg = 'header = "x-api-key: ' || credential || '"' || "0a"x || -
        'header = "anthropic-version: ' || .AnthropicProviderBuild~ANTHROPIC_API_VERSION_HEADER || '"' || "0a"x || -
        'header = "content-type: application/json"' || "0a"x || -
        'data-binary = @' || bodyFile || "0a"x || 'silent' || "0a"x || 'show-error' || "0a"x || -
        'max-time = ' || config~timeoutSeconds || "0a"x || -
        'url = "https://' || config~channel~baseHost || .AnthropicProviderBuild~PATH_MESSAGES || '"' || "0a"x
  /* v0.4: config with the key on stdin only, never a file on disk. */
  curlRc = curlWithStdinConfig(config~curlPath || ' --config - > "' || outFile || '" 2> "' || errFile || '"', cfg)
  cfg = ""
  ignore = lease~retire
  credential = ""
  outText = self~slurp(outFile)
  call SysFileDelete cfgFile; call SysFileDelete bodyFile; call SysFileDelete outFile; call SysFileDelete errFile
  call SysRmDir workDir
  if curlRc \= 0 then return self~failure("AI_ANTHROPIC_TRANSPORT", "transport failed, exit" curlRc, request, t0)
  return self~replyFromBody(outText, request, t0)

/* v0.5: the reply read from the response body, shared by the curl client and
   the fetch client (AnthropicFetchMessageClient).  Unchanged from v0.4's send. */
::method replyFromBody
  use strict arg outText, request, t0
  signal on syntax name badJson
  parsed = .JSON~fromJSON(outText)
  signal off syntax
  if parsed == .nil | \parsed~isa(.Directory) then return self~failure("AI_ANTHROPIC_BAD_REPLY", "unparseable response body", request, t0)
  err = parsed~at("error")
  if err \== .nil then do
    etype = "AI_ANTHROPIC_API_ERROR"; emsg = "provider returned an error"
    if err~isa(.Directory) then do
      if err~at("type") \== .nil then etype = "AI_ANTHROPIC_" || err~at("type")~string~upper
      if err~at("message") \== .nil then emsg = self~sanitise(err~at("message")~string)
    end
    return self~failure(etype, emsg, request, t0)
  end
  text = ""
  content = parsed~at("content")
  if content \== .nil, content~isa(.Array) then do
    do blk over content
      if blk~isa(.Directory) then if blk~at("type") = "text" then text = text || blk~at("text")
    end
  end
  u = parsed~at("usage"); inT = 0; outT = 0; cw = 0; cr = 0
  if u \== .nil, u~isa(.Directory) then do
    if u~at("input_tokens") \== .nil then inT = u~at("input_tokens")
    if u~at("output_tokens") \== .nil then outT = u~at("output_tokens")
    if u~at("cache_creation_input_tokens") \== .nil then cw = u~at("cache_creation_input_tokens")
    if u~at("cache_read_input_tokens") \== .nil then cr = u~at("cache_read_input_tokens")
  end
  model = parsed~at("model"); if model == .nil then model = request~model
  stop = parsed~at("stop_reason"); if stop == .nil then stop = "unknown"
  return .AnthropicMessageReply~new(.true, "OK", "", text, model, stop, inT, outT, cw, cr, self~elapsed(t0))
badJson:
  signal off syntax
  return self~failure("AI_ANTHROPIC_BAD_REPLY", "response body did not parse as JSON", request, t0)
::method failure
  use strict arg code, message, request, t0
  return .AnthropicMessageReply~new(.false, code, message, "", request~model, "error", 0, 0, 0, 0, self~elapsed(t0))
::method elapsed
  use strict arg t0
  return trunc((.dateTime~new - t0)~microseconds / 1000)
::method sanitise
  use strict arg text
  /* Never echo anything shaped like a credential back to a caller. */
  p = text~pos("sk-ant-")
  do while p > 0
    e = verify(text, "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_", "N", p)
    if e = 0 then e = text~length + 1
    text = text~left(p - 1) || "<redacted>" || text~substr(e)
    p = text~pos("sk-ant-")
  end
  return text~left(min(300, text~length))
::method slurp private
  use strict arg path
  if \SysFileExists(path) then return ""
  s = charin(path, 1, chars(path))
  call stream path, "c", "close"
  return s

/* v0.5: the same Messages client over fetch (ooRexx/WASM's ADDRESS FETCH), for
   a browser page: the ooDialog Designer's and Object Editor's code assistance.
   Architecture: Tom Dyer.  Implementation: Claude (Opus 5.5), 2026-11-15.
   Credential discipline as the curl client's: the key is acquired from the
   Secret Broker by reference, set as the x-api-key header from a variable
   (HEADER x-api-key FROM credential: never in the command's text), and the
   header is dropped again as soon as the request returns, so no later
   request carries it; the lease is retired at once.  In a browser the
   request is the page's: CORS applies, and Anthropic asks for the
   anthropic-dangerous-direct-browser-access header, which is sent.  The key
   is then in the page's memory for the request: the editor's settings say so.
   baseUrl (optional) replaces https://<channel host>: a test's local server. */
::class AnthropicFetchMessageClient public subclass AnthropicMessageClient
::method init
  expose config baseUrl
  use strict arg config, baseUrl = ""
  self~init:super(config)
::method send
  expose config baseUrl
  use strict arg request
  t0 = .dateTime~new
  if \fetchAvailable() then return self~failure("AI_ANTHROPIC_TRANSPORT", "no ADDRESS FETCH here (ooRexx/WASM only)", request, t0)
  secretOutcome = config~secretBroker~acquire(config~credentialReference)
  if \secretOutcome~ok then return self~failure("AI_ANTHROPIC_CREDENTIAL_MISSING", "credential could not be acquired", request, t0)
  lease = secretOutcome~value
  secretValue = lease~secretForTrustedConsumer
  if \secretValue~ok then do
    ignore = lease~retire
    return self~failure("AI_ANTHROPIC_CREDENTIAL_MISSING", "credential lease is unavailable", request, t0)
  end
  credential = secretValue~value
  url = baseUrl
  if url == "" then url = "https://" || config~channel~baseHost
  url = url || .AnthropicProviderBuild~PATH_MESSAGES
  body = .JSON~toJSON(request~toBody)
  version = .AnthropicProviderBuild~ANTHROPIC_API_VERSION_HEADER
  outText = ""
  address fetch
  "TIMEOUT" config~timeoutSeconds
  "HEADER x-api-key FROM credential"
  "HEADER anthropic-version FROM version"
  "HEADER anthropic-dangerous-direct-browser-access true"
  "HEADER content-type application/json"
  "POST" url "FROM body INTO outText"
  httpRc = rc
  "HEADER x-api-key"
  "HEADER anthropic-version"
  "HEADER anthropic-dangerous-direct-browser-access"
  "HEADER content-type"
  address
  credential = ""
  ignore = lease~retire
  if httpRc < 0 then return self~failure("AI_ANTHROPIC_TRANSPORT", "transport failed, fetch" httpRc, request, t0)
  return self~replyFromBody(outText, request, t0)
::method module_version class
  return "0.5"
::method module_lastChanged class
  return "2026-11-15"
::method module_version
  return "0.5"
::method module_lastChanged
  return "2026-11-15"

-- ADDRESS FETCH is ooRexx/WASM's (fetch.cls); natively it is not there, and
-- this package still loads
::routine fetchAvailable
  if .local~hasIndex("ANTHROPIC.FETCH.LOADED") then return .true
  signal on syntax name noFetch
  .context~package~loadPackage("fetch.cls")
  .local["ANTHROPIC.FETCH.LOADED"] = .true
  return .true
noFetch:
  return .false

::requires "AnthropicTransport.cls"
