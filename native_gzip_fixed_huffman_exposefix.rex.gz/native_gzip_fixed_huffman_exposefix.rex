#!/usr/bin/env rexx
/* Native Rexx gzip/gunzip with DEFLATE stored blocks and fixed-Huffman blocks.

   No ADDRESS SYSTEM, no gzip, no zlib, no Java, no Python helper.

   Compression modes:
     gzip        -> fixed-Huffman DEFLATE with a small native LZ77 matcher
     gzip-fixed  -> same as gzip
     gzip-stored -> standards-compatible stored-block gzip baseline

   Decompression mode:
     gunzip      -> reads gzip files whose DEFLATE stream uses stored blocks
                   and/or fixed-Huffman blocks. Dynamic Huffman blocks are
                   intentionally not implemented yet.

   This is meant as an auditable native Rexx compressor baseline. It is not
   trying to compete with zlib. It is trying to make Alchemy able to emit real
   Content-Encoding: gzip without shelling out.
*/

numeric digits 50

parse arg mode inPath outPath opt extra
mode = translate(mode)
opt = translate(opt)

if mode = '' | mode = '-H' | mode = '--HELP' | mode = 'HELP' then do
  call usage
  exit 0
end

if extra <> '' then do
  call usage
  exit 2
end

select
  when mode = 'GZIP' | mode = 'ZIP' | mode = 'C' | mode = 'COMPRESS' | mode = 'GZIP-FIXED' | mode = 'FIXED' then do
    if inPath = '' | outPath = '' then do
      call usage
      exit 2
    end
    if opt = '--STORED' then call gzipFileStored inPath, outPath
                       else call gzipFileFixed inPath, outPath
  end
  when mode = 'GZIP-STORED' | mode = 'STORED' then do
    if inPath = '' | outPath = '' then do
      call usage
      exit 2
    end
    call gzipFileStored inPath, outPath
  end
  when mode = 'GUNZIP' | mode = 'UNZIP' | mode = 'D' | mode = 'DECOMPRESS' then do
    if inPath = '' | outPath = '' then do
      call usage
      exit 2
    end
    call gunzipFile inPath, outPath
  end
  otherwise do
    say 'Unknown mode:' mode
    call usage
    exit 2
  end
end

exit 0

usage:
  say 'native_gzip_fixed_huffman.rex - native Rexx gzip fixed-Huffman codec'
  say ''
  say 'Usage:'
  say '  rexx native_gzip_fixed_huffman.rex gzip        input.file output.gz'
  say '  rexx native_gzip_fixed_huffman.rex gzip-fixed  input.file output.gz'
  say '  rexx native_gzip_fixed_huffman.rex gzip-stored input.file output.gz'
  say '  rexx native_gzip_fixed_huffman.rex gunzip      input.gz   output.file'
  say ''
  say 'Notes:'
  say '  - gzip/gzip-fixed writes fixed-Huffman DEFLATE with simple LZ77 matches.'
  say '  - gzip-stored keeps the earlier stored-block baseline.'
  say '  - gunzip supports stored and fixed-Huffman DEFLATE blocks.'
  say '  - Dynamic Huffman DEFLATE is not implemented yet.'
  say '  - This script does not ADDRESS SYSTEM or call external compressors.'
  return

/* ---------------------------------------------------------------------- */
/* File-level gzip entry points. */

gzipFileFixed: procedure
  numeric digits 50
  parse arg inPath, outPath
  data = readFile(inPath)
  gz = gzipBytesFixed(data)
  call writeFile outPath, gz
  say 'OK gzip fixed-Huffman file written:' outPath
  return

gzipFileStored: procedure
  numeric digits 50
  parse arg inPath, outPath
  data = readFile(inPath)
  gz = gzipBytesStored(data)
  call writeFile outPath, gz
  say 'OK gzip stored-block file written:' outPath
  return

gunzipFile: procedure
  numeric digits 50
  parse arg inPath, outPath
  data = readFile(inPath)
  out = gunzipBytes(data)
  call writeFile outPath, out
  say 'OK gzip decoded:' outPath
  return

/* ---------------------------------------------------------------------- */
/* Byte-string API suitable for an HTTP gzip filter. */

gzipBytesFixed: procedure
  numeric digits 50
  parse arg data
  crcTrailer = crcFinish(crcUpdate(crcInit(), data))
  sizeTrailer = le32(length(data))
  return gzipHeader() || deflateFixed(data) || crcTrailer || sizeTrailer

gzipBytesStored: procedure
  numeric digits 50
  parse arg data
  crcTrailer = crcFinish(crcUpdate(crcInit(), data))
  sizeTrailer = le32(length(data))
  return gzipHeader() || deflateStored(data) || crcTrailer || sizeTrailer

gunzipBytes: procedure
  numeric digits 50
  parse arg data
  if length(data) < 18 then call die 'Input is too small to be gzip data', 3

  if substr(data, 1, 2) <> x2c('1F8B') then call die 'Not a gzip file: bad magic', 3
  if byteAt(data, 3) <> 8 then call die 'Unsupported gzip method: expected DEFLATE method 8', 3

  flg = byteAt(data, 4)
  if flagSet(flg, 32) | flagSet(flg, 64) | flagSet(flg, 128) then do
    call die 'Unsupported gzip reserved flag bit is set', 3
  end

  pos = 11

  if flagSet(flg, 4) then do
    if pos + 1 > length(data) then call die 'Truncated gzip extra field length', 3
    xlen = le16At(data, pos)
    pos = pos + 2 + xlen
  end

  if flagSet(flg, 8) then pos = skipZero(data, pos)
  if flagSet(flg, 16) then pos = skipZero(data, pos)
  if flagSet(flg, 2) then pos = pos + 2

  compressed = substr(data, pos)
  out = inflateStoredOrFixed(compressed)
  trailerPos = BR_POS

  if trailerPos + 7 > length(compressed) then call die 'Missing gzip trailer', 3

  expectedCrc = substr(compressed, trailerPos, 4)
  expectedSize = le32At(compressed, trailerPos + 4)
  actualCrc = crcFinish(crcUpdate(crcInit(), out))
  actualSize = length(out) // 4294967296

  if expectedCrc <> actualCrc then do
    call die 'CRC32 mismatch: expected' hexBytes(expectedCrc) 'got' hexBytes(actualCrc), 4
  end
  if expectedSize <> actualSize then do
    call die 'ISIZE mismatch: expected' expectedSize 'got' actualSize, 4
  end

  return out

gzipHeader: procedure
  numeric digits 50
  /* ID1 ID2 CM FLG MTIME XFL OS. XFL=4 says fastest compressor. OS=255 unknown. */
  return x2c('1F8B0800') || le32(0) || x2c('04FF')

/* ---------------------------------------------------------------------- */
/* DEFLATE writer: fixed Huffman + small LZ77 matcher. */

deflateFixed: procedure expose BW_OUT BW_BUF BW_BITS
  numeric digits 50
  parse arg data

  call bwInit
  call bwWriteBits 1, 1       /* BFINAL */
  call bwWriteBits 1, 2       /* BTYPE=01 fixed Huffman */

  pos = 1
  n = length(data)

  do while pos <= n
    spec = findMatch(data, pos)
    parse var spec mlen mdist

    if mlen >= 3 then do
      call emitLengthDistance mlen, mdist
      pos = pos + mlen
    end
    else do
      call emitFixedSymbol byteAt(data, pos)
      pos = pos + 1
    end
  end

  call emitFixedSymbol 256    /* End-of-block */
  return bwFinish()

findMatch: procedure
  numeric digits 50
  parse arg data, pos
  n = length(data)
  if pos + 2 > n then return '0 0'

  prefix = substr(data, pos, 3)
  windowStart = pos - 32768
  if windowStart < 1 then windowStart = 1
  windowLen = pos - windowStart
  if windowLen < 3 then return '0 0'

  window = substr(data, windowStart, windowLen)
  searchEnd = length(window)
  bestLen = 0
  bestDist = 0
  tries = 0
  maxTry = 48

  do while searchEnd > 0 & tries < maxTry
    hit = lastpos(prefix, window, searchEnd)
    if hit = 0 then leave
    candPos = windowStart + hit - 1
    dist = pos - candPos
    if dist >= 1 & dist <= 32768 then do
      maxLen = n - pos + 1
      if maxLen > 258 then maxLen = 258
      ml = 3
      do while ml < maxLen
        if substr(data, pos + ml, 1) <> substr(data, candPos + ml, 1) then leave
        ml = ml + 1
      end
      if ml > bestLen then do
        bestLen = ml
        bestDist = dist
        if bestLen = maxLen then leave
      end
    end
    searchEnd = hit - 1
    tries = tries + 1
  end

  if bestLen >= 3 then return bestLen bestDist
  return '0 0'

emitLengthDistance: procedure expose BW_OUT BW_BUF BW_BITS
  numeric digits 50
  parse arg mlen, mdist
  lspec = lengthSpec(mlen)
  parse var lspec lcode lextraBits lextraVal
  call emitFixedSymbol lcode
  if lextraBits > 0 then call bwWriteBits lextraVal, lextraBits

  dspec = distanceSpec(mdist)
  parse var dspec dcode dextraBits dextraVal
  dsend = reverseBits(dcode, 5)
  call bwWriteBits dsend, 5
  if dextraBits > 0 then call bwWriteBits dextraVal, dextraBits
  return

emitFixedSymbol: procedure expose BW_OUT BW_BUF BW_BITS
  numeric digits 50
  parse arg sym

  select
    when sym >= 0 & sym <= 143 then do
      code = 48 + sym
      bits = 8
    end
    when sym >= 144 & sym <= 255 then do
      code = 400 + sym - 144
      bits = 9
    end
    when sym >= 256 & sym <= 279 then do
      code = sym - 256
      bits = 7
    end
    when sym >= 280 & sym <= 287 then do
      code = 192 + sym - 280
      bits = 8
    end
    otherwise call die 'Internal error: invalid fixed Huffman symbol' sym, 9
  end

  call bwWriteBits reverseBits(code, bits), bits
  return

lengthSpec: procedure
  numeric digits 50
  parse arg len
  if len < 3 | len > 258 then call die 'Internal error: invalid match length' len, 9
  if len = 258 then return '285 0 0'

  lenBase.257 = 3;   lenBits.257 = 0
  lenBase.258 = 4;   lenBits.258 = 0
  lenBase.259 = 5;   lenBits.259 = 0
  lenBase.260 = 6;   lenBits.260 = 0
  lenBase.261 = 7;   lenBits.261 = 0
  lenBase.262 = 8;   lenBits.262 = 0
  lenBase.263 = 9;   lenBits.263 = 0
  lenBase.264 = 10;  lenBits.264 = 0
  lenBase.265 = 11;  lenBits.265 = 1
  lenBase.266 = 13;  lenBits.266 = 1
  lenBase.267 = 15;  lenBits.267 = 1
  lenBase.268 = 17;  lenBits.268 = 1
  lenBase.269 = 19;  lenBits.269 = 2
  lenBase.270 = 23;  lenBits.270 = 2
  lenBase.271 = 27;  lenBits.271 = 2
  lenBase.272 = 31;  lenBits.272 = 2
  lenBase.273 = 35;  lenBits.273 = 3
  lenBase.274 = 43;  lenBits.274 = 3
  lenBase.275 = 51;  lenBits.275 = 3
  lenBase.276 = 59;  lenBits.276 = 3
  lenBase.277 = 67;  lenBits.277 = 4
  lenBase.278 = 83;  lenBits.278 = 4
  lenBase.279 = 99;  lenBits.279 = 4
  lenBase.280 = 115; lenBits.280 = 4
  lenBase.281 = 131; lenBits.281 = 5
  lenBase.282 = 163; lenBits.282 = 5
  lenBase.283 = 195; lenBits.283 = 5
  lenBase.284 = 227; lenBits.284 = 5
  lenBase.285 = 258; lenBits.285 = 0

  do c = 257 to 284
    b = lenBase.c
    next = c + 1
    nb = lenBase.next
    if len >= b & len < nb then do
      eb = lenBits.c
      ev = len - b
      return c eb ev
    end
  end

  call die 'Internal error: length code lookup failed for' len, 9

distanceSpec: procedure
  numeric digits 50
  parse arg dist
  if dist < 1 | dist > 32768 then call die 'Internal error: invalid match distance' dist, 9

  distBase.0 = 1;      distBits.0 = 0
  distBase.1 = 2;      distBits.1 = 0
  distBase.2 = 3;      distBits.2 = 0
  distBase.3 = 4;      distBits.3 = 0
  distBase.4 = 5;      distBits.4 = 1
  distBase.5 = 7;      distBits.5 = 1
  distBase.6 = 9;      distBits.6 = 2
  distBase.7 = 13;     distBits.7 = 2
  distBase.8 = 17;     distBits.8 = 3
  distBase.9 = 25;     distBits.9 = 3
  distBase.10 = 33;    distBits.10 = 4
  distBase.11 = 49;    distBits.11 = 4
  distBase.12 = 65;    distBits.12 = 5
  distBase.13 = 97;    distBits.13 = 5
  distBase.14 = 129;   distBits.14 = 6
  distBase.15 = 193;   distBits.15 = 6
  distBase.16 = 257;   distBits.16 = 7
  distBase.17 = 385;   distBits.17 = 7
  distBase.18 = 513;   distBits.18 = 8
  distBase.19 = 769;   distBits.19 = 8
  distBase.20 = 1025;  distBits.20 = 9
  distBase.21 = 1537;  distBits.21 = 9
  distBase.22 = 2049;  distBits.22 = 10
  distBase.23 = 3073;  distBits.23 = 10
  distBase.24 = 4097;  distBits.24 = 11
  distBase.25 = 6145;  distBits.25 = 11
  distBase.26 = 8193;  distBits.26 = 12
  distBase.27 = 12289; distBits.27 = 12
  distBase.28 = 16385; distBits.28 = 13
  distBase.29 = 24577; distBits.29 = 13
  distBase.30 = 32769

  do c = 0 to 29
    b = distBase.c
    next = c + 1
    nb = distBase.next
    if dist >= b & dist < nb then do
      eb = distBits.c
      ev = dist - b
      return c eb ev
    end
  end

  call die 'Internal error: distance code lookup failed for' dist, 9

reverseBits: procedure
  numeric digits 50
  parse arg value, bits
  out = 0
  do i = 1 to bits
    out = out * 2 + (value // 2)
    value = value % 2
  end
  return out

/* Bit writer. Values passed to bwWriteBits are emitted low bit first. */

bwInit: procedure expose BW_OUT BW_BUF BW_BITS
  BW_OUT = ''
  BW_BUF = 0
  BW_BITS = 0
  return

bwWriteBits: procedure expose BW_OUT BW_BUF BW_BITS
  numeric digits 50
  parse arg value, count
  do while count > 0
    bit = value // 2
    value = value % 2
    if bit <> 0 then BW_BUF = BW_BUF + (2 ** BW_BITS)
    BW_BITS = BW_BITS + 1
    if BW_BITS >= 8 then do
      BW_OUT = BW_OUT || d2c(BW_BUF // 256, 1)
      BW_BUF = BW_BUF % 256
      BW_BITS = BW_BITS - 8
    end
    count = count - 1
  end
  return

bwFinish: procedure expose BW_OUT BW_BUF BW_BITS
  if BW_BITS > 0 then do
    BW_OUT = BW_OUT || d2c(BW_BUF // 256, 1)
    BW_BUF = 0
    BW_BITS = 0
  end
  return BW_OUT

/* ---------------------------------------------------------------------- */
/* Stored-block writer retained as baseline. */

deflateStored: procedure
  numeric digits 50
  parse arg data
  out = ''
  pos = 1
  n = length(data)

  if n = 0 then return d2c(1, 1) || le16(0) || le16(65535)

  do while pos <= n
    remain = n - pos + 1
    if remain > 65535 then chunkLen = 65535
                      else chunkLen = remain
    chunk = substr(data, pos, chunkLen)
    if pos + chunkLen > n then final = 1
                          else final = 0
    out = out || d2c(final, 1) || le16(chunkLen) || le16(65535 - chunkLen) || chunk
    pos = pos + chunkLen
  end

  return out

/* ---------------------------------------------------------------------- */
/* DEFLATE reader: stored and fixed-Huffman blocks. */

inflateStoredOrFixed: procedure expose BR_DATA BR_POS BR_BUF BR_BITS
  numeric digits 50
  parse arg data
  call brInit data
  out = ''
  final = 0

  do while final = 0
    final = brReadBits(1)
    btype = brReadBits(2)

    select
      when btype = 0 then out = out || inflateStoredBlock()
      when btype = 1 then out = inflateFixedBlock(out)
      when btype = 2 then call die 'Dynamic Huffman DEFLATE is not implemented in this native Rexx build', 3
      otherwise call die 'Invalid DEFLATE block type 3', 3
    end
  end

  return out

inflateStoredBlock: procedure expose BR_DATA BR_POS BR_BUF BR_BITS
  numeric digits 50
  /* Stored blocks start on the next byte boundary. */
  BR_BUF = 0
  BR_BITS = 0

  if BR_POS + 3 > length(BR_DATA) then call die 'Truncated stored block header', 3
  len = le16At(BR_DATA, BR_POS)
  BR_POS = BR_POS + 2
  nlen = le16At(BR_DATA, BR_POS)
  BR_POS = BR_POS + 2

  if nlen <> 65535 - len then call die 'Stored block LEN/NLEN check failed', 3
  if BR_POS + len - 1 > length(BR_DATA) then call die 'Truncated stored block payload', 3

  chunk = substr(BR_DATA, BR_POS, len)
  BR_POS = BR_POS + len
  return chunk

inflateFixedBlock: procedure expose BR_DATA BR_POS BR_BUF BR_BITS
  numeric digits 50
  parse arg out

  do forever
    sym = fixedDecodeSymbol()
    if sym < 256 then do
      out = out || d2c(sym, 1)
      iterate
    end
    if sym = 256 then leave
    if sym < 257 | sym > 285 then call die 'Invalid fixed-Huffman length symbol' sym, 3

    lspec = decodeLengthSpec(sym)
    parse var lspec base eb
    extra = 0
    if eb > 0 then extra = brReadBits(eb)
    mlen = base + extra

    dcode = fixedDecodeDistanceCode()
    dspec = decodeDistanceSpec(dcode)
    parse var dspec dbase deb
    dextra = 0
    if deb > 0 then dextra = brReadBits(deb)
    dist = dbase + dextra

    if dist < 1 | dist > length(out) then call die 'Invalid match distance' dist, 3
    out = copyMatch(mlen, dist, out)
  end

  return out

copyMatch: procedure
  numeric digits 50
  parse arg mlen, dist, out
  do i = 1 to mlen
    ch = substr(out, length(out) - dist + 1, 1)
    out = out || ch
  end
  return out

fixedDecodeSymbol: procedure expose BR_DATA BR_POS BR_BUF BR_BITS
  numeric digits 50
  code = 0
  do bits = 1 to 9
    bit = brReadBits(1)
    code = code * 2 + bit

    if bits = 7 then do
      if code >= 0 & code <= 23 then return 256 + code
    end
    else if bits = 8 then do
      if code >= 48 & code <= 191 then return code - 48
      if code >= 192 & code <= 199 then return 280 + code - 192
    end
    else if bits = 9 then do
      if code >= 400 & code <= 511 then return 144 + code - 400
    end
  end
  call die 'Invalid fixed-Huffman symbol', 3

fixedDecodeDistanceCode: procedure expose BR_DATA BR_POS BR_BUF BR_BITS
  numeric digits 50
  code = 0
  do bits = 1 to 5
    bit = brReadBits(1)
    code = code * 2 + bit
  end
  if code < 0 | code > 31 then call die 'Invalid distance code', 3
  return code

decodeLengthSpec: procedure
  parse arg code
  select
    when code = 257 then return '3 0'
    when code = 258 then return '4 0'
    when code = 259 then return '5 0'
    when code = 260 then return '6 0'
    when code = 261 then return '7 0'
    when code = 262 then return '8 0'
    when code = 263 then return '9 0'
    when code = 264 then return '10 0'
    when code = 265 then return '11 1'
    when code = 266 then return '13 1'
    when code = 267 then return '15 1'
    when code = 268 then return '17 1'
    when code = 269 then return '19 2'
    when code = 270 then return '23 2'
    when code = 271 then return '27 2'
    when code = 272 then return '31 2'
    when code = 273 then return '35 3'
    when code = 274 then return '43 3'
    when code = 275 then return '51 3'
    when code = 276 then return '59 3'
    when code = 277 then return '67 4'
    when code = 278 then return '83 4'
    when code = 279 then return '99 4'
    when code = 280 then return '115 4'
    when code = 281 then return '131 5'
    when code = 282 then return '163 5'
    when code = 283 then return '195 5'
    when code = 284 then return '227 5'
    when code = 285 then return '258 0'
    otherwise call die 'Invalid length code' code, 3
  end

decodeDistanceSpec: procedure
  parse arg code
  select
    when code = 0 then return '1 0'
    when code = 1 then return '2 0'
    when code = 2 then return '3 0'
    when code = 3 then return '4 0'
    when code = 4 then return '5 1'
    when code = 5 then return '7 1'
    when code = 6 then return '9 2'
    when code = 7 then return '13 2'
    when code = 8 then return '17 3'
    when code = 9 then return '25 3'
    when code = 10 then return '33 4'
    when code = 11 then return '49 4'
    when code = 12 then return '65 5'
    when code = 13 then return '97 5'
    when code = 14 then return '129 6'
    when code = 15 then return '193 6'
    when code = 16 then return '257 7'
    when code = 17 then return '385 7'
    when code = 18 then return '513 8'
    when code = 19 then return '769 8'
    when code = 20 then return '1025 9'
    when code = 21 then return '1537 9'
    when code = 22 then return '2049 10'
    when code = 23 then return '3073 10'
    when code = 24 then return '4097 11'
    when code = 25 then return '6145 11'
    when code = 26 then return '8193 12'
    when code = 27 then return '12289 12'
    when code = 28 then return '16385 13'
    when code = 29 then return '24577 13'
    otherwise call die 'Invalid distance code' code, 3
  end

brInit: procedure expose BR_DATA BR_POS BR_BUF BR_BITS
  parse arg data
  BR_DATA = data
  BR_POS = 1
  BR_BUF = 0
  BR_BITS = 0
  return

brReadBits: procedure expose BR_DATA BR_POS BR_BUF BR_BITS
  numeric digits 50
  parse arg count
  value = 0
  mult = 1
  do while count > 0
    if BR_BITS = 0 then do
      if BR_POS > length(BR_DATA) then call die 'Unexpected end of compressed bit stream', 3
      BR_BUF = byteAt(BR_DATA, BR_POS)
      BR_POS = BR_POS + 1
      BR_BITS = 8
    end
    bit = BR_BUF // 2
    BR_BUF = BR_BUF % 2
    BR_BITS = BR_BITS - 1
    if bit <> 0 then value = value + mult
    mult = mult * 2
    count = count - 1
  end
  return value

/* ---------------------------------------------------------------------- */
/* File and binary helpers. */

readFile: procedure
  numeric digits 50
  parse arg path
  call stream path, 'c', 'open read'
  data = ''
  do while chars(path) > 0
    n = chars(path)
    if n > 1048576 then n = 1048576
    data = data || charin(path, , n)
  end
  call stream path, 'c', 'close'
  return data

writeFile: procedure
  parse arg path, data
  call stream path, 'c', 'open write replace'
  call charout path, data
  call stream path, 'c', 'close'
  return

/* ---------------------------------------------------------------------- */
/* CRC32, reflected polynomial, little-endian 4-byte register. */

crcInit: procedure
  return x2c('FFFFFFFF')

crcFinish: procedure
  parse arg crc
  return bitxor(crc, x2c('FFFFFFFF'))

crcUpdate: procedure
  numeric digits 50
  parse arg crc, bytes
  poly = x2c('2083B8ED')              /* 0xEDB88320 in little-endian bytes */
  do p = 1 to length(bytes)
    crc = bitxor(substr(crc, 1, 1), substr(bytes, p, 1)) || substr(crc, 2, 3)
    do 8
      low = byteAt(crc, 1) // 2
      crc = shr1le32(crc)
      if low <> 0 then crc = bitxor(crc, poly)
    end
  end
  return crc

shr1le32: procedure
  numeric digits 50
  parse arg s
  b0 = byteAt(s, 1)
  b1 = byteAt(s, 2)
  b2 = byteAt(s, 3)
  b3 = byteAt(s, 4)

  n0 = (b0 % 2) + ((b1 // 2) * 128)
  n1 = (b1 % 2) + ((b2 // 2) * 128)
  n2 = (b2 % 2) + ((b3 // 2) * 128)
  n3 = (b3 % 2)

  return d2c(n0, 1) || d2c(n1, 1) || d2c(n2, 1) || d2c(n3, 1)

/* ---------------------------------------------------------------------- */
/* Small integer helpers. */

band8: procedure
  parse arg a, b
  return c2d(bitand(d2c(a // 256, 1), d2c(b // 256, 1)))

le16: procedure
  numeric digits 50
  parse arg n
  b0 = n // 256
  b1 = (n % 256) // 256
  return d2c(b0, 1) || d2c(b1, 1)

le32: procedure
  numeric digits 50
  parse arg n
  n = mod32(n)
  b0 = n // 256
  n = n % 256
  b1 = n // 256
  n = n % 256
  b2 = n // 256
  n = n % 256
  b3 = n // 256
  return d2c(b0, 1) || d2c(b1, 1) || d2c(b2, 1) || d2c(b3, 1)

le16At: procedure
  numeric digits 50
  parse arg s, p
  return byteAt(s, p) + byteAt(s, p + 1) * 256

le32At: procedure
  numeric digits 50
  parse arg s, p
  return byteAt(s, p) + byteAt(s, p + 1) * 256 + byteAt(s, p + 2) * 65536 + byteAt(s, p + 3) * 16777216

byteAt: procedure
  parse arg s, p
  if p < 1 | p > length(s) then return 0
  return c2d(substr(s, p, 1))

flagSet: procedure
  parse arg value, mask
  return band8(value, mask) <> 0

skipZero: procedure
  parse arg s, p
  do while p <= length(s)
    if substr(s, p, 1) = d2c(0, 1) then return p + 1
    p = p + 1
  end
  call die 'Truncated zero-terminated gzip field', 3

mod32: procedure
  numeric digits 50
  parse arg n
  n = n // 4294967296
  if n < 0 then n = n + 4294967296
  return n

hexBytes: procedure
  parse arg s
  out = ''
  do i = 1 to length(s)
    h = d2x(c2d(substr(s, i, 1)), 2)
    out = out || h
  end
  return out

die: procedure
  parse arg msg, rc
  if rc = '' then rc = 1
  say 'ERROR:' msg
  exit rc
