say .JobNodeRequirement
j=.JobNodeRequirement~new
say j
::requires '../../job_node_allocator_v0.6/job_node_allocator_v0.6/src/JobNodeAllocator.cls'
