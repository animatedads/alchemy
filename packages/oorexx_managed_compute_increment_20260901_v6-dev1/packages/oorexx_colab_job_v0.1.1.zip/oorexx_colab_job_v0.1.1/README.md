# ooRexx Colab Job v0.1.1

Generic managed-job wrapper around `google-colab-cli`. Colab is treated as an ephemeral execution target, not as an AI-provider abstraction and not as workload-specific logic.

Lifecycle: validate locally -> allocate least-required resource -> stage files -> install declared dependencies -> execute a generated driver -> retrieve declared outputs and Colab history -> clean remote workspace -> stop/release session.

Resource citizenship is fail-closed: CPU/GPU/TPU is a hard requirement. A CPU job emits no accelerator request. GPU/TPU jobs must explicitly name the required accelerator; ranking happens only after eligibility. Local input validation happens before any VM allocation. The default is teardown; retaining a session requires an explicit `retainSession=.true` job spec.

Main classes: `ColabJobRequirement`, `ColabInputFile`, `ColabOutputFile`, `ColabJobSpec`, `ColabCliAdapter`, `ColabJobRunner`, `ColabJobEvidence`, `ColabJobResult`, `ColabAllocatorAdapter`.

The allocator adapter targets the existing `JobNodeRequirement` seam: `COLAB_EXECUTION`, `GPU`/`TPU` and exact accelerator tags are hard eligibility dimensions. It deliberately does not score or choose accelerators.

v0.1.1 acceptance uses a fake `colab` executable so qualification never allocates real Colab resources. The fixture represents the proposed 100-step Gemma recovery job shape (T4, 16 GiB memory, 30 GiB disk, egress, checkpointable) while remaining workload-agnostic.

## Colab CLI assumptions

This version targets the September 2026 CLI surface observed in the supplied command transcript and current `googlecolab/google-colab-cli`: `new`, `upload`, `download`, `install`, `exec`, `log`, `rm`, `status`, and `stop`. It does not manipulate OAuth tokens or browser cookies; authentication remains owned by the Colab CLI/account session. The wrapper never calls `pay`, never changes subscription state, and never probes accelerators merely to see what is available.

## Allocator compatibility

The allocator adapter has been re-qualified against Job-to-Node Allocator v0.6. v0.6 preserves the `JobNodeRequirement` seam while adding durable ownership/recovery and evidence-integrity hardening; the Colab adapter remains a pure hard-requirement mapper. `ColabJob.cls` itself has no allocator dependency; `ColabJobAllocatorAdapter.cls` is optional and maps resource need into hard allocator abilities/tags before placement scoring.
