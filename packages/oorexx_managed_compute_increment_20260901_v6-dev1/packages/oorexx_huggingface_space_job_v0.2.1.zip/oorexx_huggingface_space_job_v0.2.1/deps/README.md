Bundled exact sibling/dependency snapshots used for qualification:
- oorexx_api_client_v0.3.zip
- job_node_allocator_v0.6.zip
- oorexx_crypto_v0.8.3.zip
Foreign Runtime v0.22.5 is intentionally not duplicated here; use the qualified roll-up/runtime dependency.
