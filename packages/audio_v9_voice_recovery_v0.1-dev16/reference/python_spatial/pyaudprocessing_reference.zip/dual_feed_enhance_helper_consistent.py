#!/usr/bin/env python3
"""
dual_feed_enhance_helper_consistent.py
=====================================
Helper-consistent compatibility edition of dual_feed_enhance.py.

Purpose:
- Keep the original radar/sonar/radio-astronomy DSP chain intact:
  CAF/GCC-PHAT alignment, MVDR, CLEAN, phase-coherence Wiener, and persistence gate.
- Replace hard-coded filename globs and explicit timestamp maps with forensic_helper.py
  YAML stream discovery, camera classification, durations, and block loading.
"""

import os
import argparse
import yaml
import numpy as np
import soundfile as sf
import librosa
from datetime import datetime, timedelta
from scipy.signal import correlate, get_window
from scipy.ndimage import uniform_filter1d

from forensic_helper import ForensicHelper as fh

# ---------------------------------------------------------------------------
# CONFIGURATION
# ---------------------------------------------------------------------------
SR            = 22050          # Unified sample rate
BLOCK_SEC     = 8              # Processing window (seconds) — overlap-add friendly
HOP_FRAC      = 0.5            # 50% overlap between blocks
N_FFT         = 2048
HOP_LENGTH    = N_FFT // 4
PERSIST_WINS  = 3              # Temporal persistence gate: # consecutive windows
CLEAN_ITERS   = 6              # CLEAN algorithm iterations
CLEAN_GAIN    = 0.15           # CLEAN loop gain (conservative)
MAX_DELAY_SEC = 0.05           # Max expected inter-mic delay for CAF search (50 ms)
OUTPUT_SR     = 22050


# ---------------------------------------------------------------------------
# HELPER-CONSISTENT PLUMBING
# ---------------------------------------------------------------------------

def safe(y):
    return np.nan_to_num(y, nan=0.0, posinf=0.0, neginf=0.0)


def pad_or_trim(y, n):
    y = safe(y)
    if len(y) >= n:
        return y[:n].copy()
    return np.pad(y, (0, n - len(y)))


def parse_time_arg(value, default_dt):
    if not value:
        return default_dt
    value = str(value).strip()
    if "-" in value:
        dt = fh.parse_dt(value)
    else:
        parts = value.split(":")
        if len(parts) == 2:
            value = value + ":00"
        dt = fh.parse_dt(f"{default_dt.strftime('%Y-%m-%d')} {value}")
    if not dt:
        raise ValueError(f"Cannot parse time: {value!r}")
    return dt


def tier_matches(label, path, tier):
    blob = f"{label or ''} {path or ''}".lower()
    tier = (tier or "").lower()
    if tier == "amp32":
        return "+32db" in blob or "amp32" in blob or "raw amp +32" in blob
    if tier == "plus20":
        return "+20db" in blob or "+20" in blob or "plus20" in blob or "ampamp" in blob
    if tier == "enhanced":
        return "enhanced" in blob and "+20" not in blob and "plus20" not in blob
    if tier == "original":
        return "original" in blob
    return tier in blob


def load_project_streams(yaml_path, tier):
    raw_streams = fh.get_active_streams(yaml_path, datetime.min, datetime.max)
    streams = []
    for s in raw_streams:
        label = s.get("filter") or s.get("type") or ""
        path = s.get("path", "")
        if tier_matches(label, path, tier):
            streams.append(s)
    streams.sort(key=lambda s: (s.get("start_dt"), s.get("cam_id"), s.get("path")))
    return streams


def get_stream_for_time(streams, cam_id, t):
    candidates = [s for s in streams if s.get("cam_id") == cam_id and s.get("start_dt") <= t < s.get("end_dt")]
    if not candidates:
        return None
    return max(candidates, key=lambda s: s.get("start_dt"))


def read_block(stream_info, t, duration_sec=BLOCK_SEC):
    target_len = int(duration_sec * SR)
    if not stream_info:
        return None
    y = fh.read_stream_block(stream_info, t, duration_sec, SR)
    if y is None or not np.any(y):
        return None
    return pad_or_trim(y, target_len)


def ensure_output_dir(path):
    d = os.path.dirname(os.path.abspath(path))
    if d:
        os.makedirs(d, exist_ok=True)


def safe_soundfile_format(out_path):
    fmt = "OGG" if out_path.lower().endswith(".ogg") else None
    subtype = "VORBIS" if fmt == "OGG" else None
    return fmt, subtype


def register_output(yaml_path, output_path, start_dt, label):
    with open(yaml_path, "r") as f:
        cfg = yaml.safe_load(f) or {}
    cfg.setdefault("files", [])
    entry = {
        "path": output_path,
        "start": start_dt.strftime("%Y-%m-%d %H:%M:%S"),
        "type": label,
    }
    updated = False
    for existing in cfg["files"]:
        if os.path.normpath(existing.get("path", "")) == os.path.normpath(output_path):
            existing.update(entry)
            updated = True
            break
    if not updated:
        cfg["files"].append(entry)
    cfg["files"].sort(key=lambda x: x.get("start", ""))
    with open(yaml_path, "w") as f:
        yaml.dump(cfg, f, default_flow_style=False, sort_keys=False)

# ---------------------------------------------------------------------------
# TECHNIQUE 1 — CROSS-AMBIGUITY FUNCTION (CAF) ALIGNMENT
# ---------------------------------------------------------------------------
# In radar, the CAF measures correlation across both time-delay and Doppler.
# Here we use the time-delay axis only (no Doppler needed for voice), but we
# compute it in the frequency domain for efficiency — same math as radar TDOA.

def caf_align(y_a: np.ndarray, y_b: np.ndarray, max_delay_samples: int) -> np.ndarray:
    """
    Phase-Transform (PHAT) weighted GCC — the standard radar/sonar TDOA estimator.
    Returns y_b shifted to align with y_a.
    """
    n = len(y_a) + len(y_b) - 1
    nfft = 1 << int(np.ceil(np.log2(n)))          # next power of 2

    Fa = np.fft.rfft(y_a, n=nfft)
    Fb = np.fft.rfft(y_b, n=nfft)

    # GCC-PHAT: cross-spectrum normalised by magnitude (whitening = phase only)
    cross = Fa * np.conj(Fb)
    denom = np.abs(cross) + 1e-10
    gcc_phat = np.fft.irfft(cross / denom, n=nfft)

    # Search window only within ±max_delay_samples
    search = np.concatenate([gcc_phat[-max_delay_samples:], gcc_phat[:max_delay_samples+1]])
    lag = np.argmax(search) - max_delay_samples       # signed lag

    # Apply integer-sample shift to y_b
    if lag > 0:
        y_b_aligned = np.concatenate([np.zeros(lag), y_b[:-lag]]) if lag < len(y_b) else y_b
    elif lag < 0:
        y_b_aligned = np.concatenate([y_b[-lag:], np.zeros(-lag)])
    else:
        y_b_aligned = y_b

    return y_b_aligned[:len(y_a)]


# ---------------------------------------------------------------------------
# TECHNIQUE 2 — ADAPTIVE MVDR BEAMFORMING (2-element array)
# ---------------------------------------------------------------------------
# MVDR (Minimum Variance Distortionless Response) is the core sonar/radar
# beamformer. For a 2-element array it reduces to a frequency-bin-wise
# adaptive filter that minimises output power while keeping the desired signal.
# We treat Cam A as the "look direction" and suppress what differs from Cam B.

def mvdr_beamform(y_a: np.ndarray, y_b: np.ndarray) -> np.ndarray:
    """
    Per-bin MVDR beamformer for a 2-channel array.
    Returns the beamformed (enhanced) signal as mono.
    """
    S_a = librosa.stft(y_a, n_fft=N_FFT, hop_length=HOP_LENGTH)
    S_b = librosa.stft(y_b, n_fft=N_FFT, hop_length=HOP_LENGTH)

    n_freq, n_frames = S_a.shape

    # Steering vector: we assume "desired" arrives equally at both mics (a=[1,1]/√2)
    # Covariance estimation: R = E[x x^H] per frequency bin, diagonal loading for stability
    out = np.zeros_like(S_a)

    # Vectorised over frames; per-frequency covariance
    for k in range(n_freq):
        x = np.vstack([S_a[k, :], S_b[k, :]])          # (2, T)
        R = (x @ x.conj().T) / n_frames                 # 2x2 covariance
        # Diagonal loading (regularisation, prevents rank deficiency)
        R += np.eye(2) * (1e-3 * np.trace(R) / 2)
        # Steering vector (broadside: equal phase for both channels)
        d = np.array([1.0, 1.0], dtype=complex) / np.sqrt(2)
        try:
            R_inv = np.linalg.inv(R)
        except np.linalg.LinAlgError:
            out[k, :] = S_a[k, :]
            continue
        # MVDR weights: w = R⁻¹d / (d^H R⁻¹ d)
        Rinv_d = R_inv @ d
        w = Rinv_d / (d.conj() @ Rinv_d + 1e-10)
        out[k, :] = w.conj() @ x                        # apply beamformer

    return librosa.istft(out, hop_length=HOP_LENGTH, length=len(y_a))


# ---------------------------------------------------------------------------
# TECHNIQUE 3 — CLEAN ALGORITHM (radio-astronomy interference removal)
# ---------------------------------------------------------------------------
# The CLEAN algorithm (Högbom 1974) iteratively finds and removes the dominant
# component from a "dirty" signal, leaving a residual that contains only
# incoherent noise. Here we apply it in the spectral domain to remove
# stationary tonal interference (HVAC hum, engine noise, radio bleed).

def clean_spectral(y: np.ndarray) -> np.ndarray:
    """
    CLEAN deconvolution in the magnitude spectrum.
    Iteratively identifies and subtracts dominant spectral lines (tones/hum).
    Returns cleaned audio.
    """
    stft = librosa.stft(y, n_fft=N_FFT, hop_length=HOP_LENGTH)
    mag, phase = librosa.magphase(stft)

    # Mean magnitude spectrum = the "dirty beam" of persistent tones
    dirty = mag.mean(axis=1)                  # (n_freq,)
    residual = dirty.copy()
    clean_components = np.zeros_like(dirty)

    for _ in range(CLEAN_ITERS):
        peak_idx = np.argmax(residual)
        peak_val = residual[peak_idx]
        # Subtract a Gaussian "clean beam" centred on the peak
        sigma = 3.0  # bins; narrow = remove only the tone, not neighbours
        bins = np.arange(len(residual))
        beam = peak_val * np.exp(-0.5 * ((bins - peak_idx) / sigma) ** 2)
        residual = residual - CLEAN_GAIN * beam
        clean_components += CLEAN_GAIN * beam

    # Build suppression mask: attenuate bins dominated by CLEAN components
    suppression = 1.0 - np.clip(clean_components / (dirty + 1e-10), 0, 0.95)
    suppression = suppression[:, np.newaxis]              # broadcast over time

    mag_cleaned = mag * suppression
    return librosa.istft(mag_cleaned * phase, hop_length=HOP_LENGTH, length=len(y))


# ---------------------------------------------------------------------------
# TECHNIQUE 4 — PHASE-COHERENCE WIENER FILTER
# ---------------------------------------------------------------------------
# Standard coherence (used in existing scripts) uses only magnitude.
# Phase coherence (borrowed from RF signal processing / interferometry) is
# much more discriminating: noise decorrelates in PHASE as well as magnitude.
# We compute the complex coherence and use its magnitude as the Wiener gain.

def phase_coherence_wiener(y_a: np.ndarray, y_b: np.ndarray) -> tuple:
    """
    Complex coherence mask — uses both magnitude AND phase alignment.
    Returns enhanced (y_a_clean, y_b_clean).
    """
    S_a = librosa.stft(y_a, n_fft=N_FFT, hop_length=HOP_LENGTH)
    S_b = librosa.stft(y_b, n_fft=N_FFT, hop_length=HOP_LENGTH)

    # Complex coherence: γ(f,t) = S_ab / sqrt(S_aa * S_bb)
    # Smoothed over a few frames to stabilise the estimate
    cross   = uniform_filter1d((S_a * np.conj(S_b)).real,  size=5, axis=1) \
            + 1j * uniform_filter1d((S_a * np.conj(S_b)).imag, size=5, axis=1)
    power_a = uniform_filter1d(np.abs(S_a)**2, size=5, axis=1)
    power_b = uniform_filter1d(np.abs(S_b)**2, size=5, axis=1)

    coherence = np.abs(cross) / (np.sqrt(power_a * power_b) + 1e-10)
    # Coherence ranges 0..1; voices are coherent (~1), noise is not (~0)
    # Apply a soft-threshold Wiener-style gain: G = γ² / (γ² + (1-γ²)/SNR_prior)
    snr_prior = 10.0   # assume 10:1 SNR in coherent bins
    G = (coherence**2) / (coherence**2 + (1 - coherence**2) / snr_prior)
    G = np.clip(G, 0.05, 1.0)  # 5% noise floor (avoid musical noise)

    y_a_clean = librosa.istft(S_a * G, hop_length=HOP_LENGTH, length=len(y_a))
    y_b_clean = librosa.istft(S_b * G, hop_length=HOP_LENGTH, length=len(y_b))
    return y_a_clean, y_b_clean


# ---------------------------------------------------------------------------
# TECHNIQUE 5 — TEMPORAL ENERGY PERSISTENCE GATE
# ---------------------------------------------------------------------------
# Radar uses "dwell time" — a target must be present across N consecutive pulses
# before being declared. Here: a spectral bin must be energetic in N consecutive
# blocks to be passed. Short impulse noise (clicks, bangs) has zero persistence.
# Voices persist for hundreds of milliseconds — they pass the gate.

class PersistenceGate:
    def __init__(self, n_freq, n_persist=PERSIST_WINS):
        self.n = n_persist
        # Ring buffer of magnitude spectra
        self.buffer = [np.zeros(n_freq) for _ in range(n_persist)]
        self.ptr = 0

    def update_and_gate(self, mag_frame: np.ndarray) -> np.ndarray:
        """Feed one time-averaged magnitude frame; return persistence mask (0..1)."""
        self.buffer[self.ptr] = mag_frame
        self.ptr = (self.ptr + 1) % self.n
        # Minimum across history: bin must be active in ALL n windows to pass
        stacked = np.vstack(self.buffer)          # (n, freq)
        persist_mask = np.min(stacked, axis=0)    # (freq,)
        # Normalise to 0..1 relative to current frame
        mask = persist_mask / (mag_frame + 1e-10)
        return np.clip(mask, 0.0, 1.0)



# ---------------------------------------------------------------------------
# MAIN PROCESSING PIPELINE — helper-consistent wrapper, original DSP retained
# ---------------------------------------------------------------------------

def process(config_path: str, output_path: str, tier: str = "enhanced", start_time=None, end_time=None):
    streams = load_project_streams(config_path, tier)
    if not streams:
        raise SystemExit(f"[!] No streams found for tier {tier!r} in {config_path}")

    t_start = start_time or min(s["start_dt"] for s in streams)
    t_end = end_time or max(s["end_dt"] for s in streams)
    total_sec = max(1, int((t_end - t_start).total_seconds()))

    cams = {"Cam A": 0, "Cam B": 0}
    for s in streams:
        if s.get("cam_id") in cams:
            cams[s.get("cam_id")] += 1

    print(f"\n=== Dual-Feed Forensic Enhancement — Helper Consistent ===")
    print(f"Timeline  : {t_start}  →  {t_end}  ({total_sec//3600}h {(total_sec%3600)//60}m)")
    print(f"Tier      : {tier}")
    print(f"Streams   : Cam A={cams['Cam A']}  Cam B={cams['Cam B']}  total={len(streams)}")
    print(f"Output    : {output_path}\n")

    ensure_output_dir(output_path)
    fmt, subtype = safe_soundfile_format(output_path)

    n_freq_bins = N_FFT // 2 + 1
    gate_a = PersistenceGate(n_freq_bins)
    gate_b = PersistenceGate(n_freq_bins)

    hop_sec = BLOCK_SEC * HOP_FRAC
    max_delay_samples = int(MAX_DELAY_SEC * SR)
    target_len = int(BLOCK_SEC * SR)
    hop_samples = int(hop_sec * SR)

    ola_buf_l = np.zeros(target_len)
    ola_buf_r = np.zeros(target_len)
    win = get_window('hann', target_len)

    blocks_processed = 0
    blocks_voice = 0
    blocks_silence = 0
    blocks_dual = 0
    blocks_mono = 0
    last_a_path = last_b_path = None

    with sf.SoundFile(output_path, mode='w', samplerate=OUTPUT_SR, channels=2, format=fmt, subtype=subtype) as out_f:
        t = t_start
        while t < t_end:
            stream_a = get_stream_for_time(streams, "Cam A", t)
            stream_b = get_stream_for_time(streams, "Cam B", t)
            a_path = stream_a.get("path") if stream_a else None
            b_path = stream_b.get("path") if stream_b else None

            if a_path != last_a_path:
                print(f"\n  [{t:%Y-%m-%d %H:%M:%S}]  Cam A → {os.path.basename(a_path) if a_path else '(no coverage)'}")
                last_a_path = a_path
            if b_path != last_b_path:
                print(f"\n  [{t:%Y-%m-%d %H:%M:%S}]  Cam B → {os.path.basename(b_path) if b_path else '(no coverage)'}")
                last_b_path = b_path

            y_a = read_block(stream_a, t, BLOCK_SEC)
            y_b = read_block(stream_b, t, BLOCK_SEC)

            if y_a is None and y_b is None:
                out_f.write(np.zeros((hop_samples, 2)))
                t += timedelta(seconds=hop_sec)
                blocks_silence += 1
                blocks_processed += 1
                continue

            y_a = pad_or_trim(y_a if y_a is not None else np.zeros(target_len), target_len)
            y_b = pad_or_trim(y_b if y_b is not None else np.zeros(target_len), target_len)

            has_a = stream_a is not None and np.any(y_a)
            has_b = stream_b is not None and np.any(y_b)

            if has_a and has_b:
                blocks_dual += 1
                y_b_aligned = caf_align(y_a, y_b, max_delay_samples)
                y_a_w, y_b_w = phase_coherence_wiener(y_a, y_b_aligned)
                y_beam = mvdr_beamform(y_a_w, y_b_w)
                y_a_clean = clean_spectral(y_a_w)
                y_b_clean = clean_spectral(y_b_w)
            elif has_a:
                blocks_mono += 1
                y_beam = y_a
                y_a_clean = clean_spectral(y_a)
                y_b_clean = y_a_clean.copy()
            else:
                blocks_mono += 1
                y_beam = y_b
                y_b_clean = clean_spectral(y_b)
                y_a_clean = y_b_clean.copy()

            def apply_persistence(y_clean, gate):
                S = librosa.stft(y_clean, n_fft=N_FFT, hop_length=HOP_LENGTH)
                mag, phase = librosa.magphase(S)
                mean_mag = mag.mean(axis=1)
                pmask = gate.update_and_gate(mean_mag)
                pmask_2d = pmask[:, np.newaxis]
                return librosa.istft(mag * pmask_2d * phase, hop_length=HOP_LENGTH, length=len(y_clean))

            y_a_gated = apply_persistence(y_a_clean, gate_a)
            y_b_gated = apply_persistence(y_b_clean, gate_b)

            L = 0.4 * y_beam + 0.6 * y_a_gated
            R = 0.4 * y_beam + 0.6 * y_b_gated

            peak = max(np.max(np.abs(L)), np.max(np.abs(R)), 1e-10)
            if peak > 0.98:
                L = L / peak * 0.98
                R = R / peak * 0.98

            L_win = pad_or_trim(L, target_len) * win
            R_win = pad_or_trim(R, target_len) * win
            ola_buf_l[:target_len] += L_win
            ola_buf_r[:target_len] += R_win

            chunk = np.vstack([ola_buf_l[:hop_samples], ola_buf_r[:hop_samples]]).T
            out_f.write(chunk)

            ola_buf_l = np.roll(ola_buf_l, -hop_samples)
            ola_buf_l[-hop_samples:] = 0
            ola_buf_r = np.roll(ola_buf_r, -hop_samples)
            ola_buf_r[-hop_samples:] = 0

            blocks_processed += 1
            blocks_voice += 1
            t += timedelta(seconds=hop_sec)

            if blocks_processed % 20 == 0:
                elapsed = (t - t_start).total_seconds()
                pct = 100 * elapsed / total_sec
                print(f"  [{pct:5.1f}%]  {t:%H:%M:%S}  blocks={blocks_processed}  dual={blocks_dual} mono={blocks_mono} voice={blocks_voice} silence={blocks_silence}", end='\r')

    print(f"\n\n=== Complete ===")
    print(f"Output file    : {output_path}")
    print(f"Total blocks   : {blocks_processed}")
    print(f"Dual blocks    : {blocks_dual}")
    print(f"Mono blocks    : {blocks_mono}")
    print(f"Voice blocks   : {blocks_voice}")
    print(f"Silence blocks : {blocks_silence}")

    register_output(config_path, output_path, t_start, f"Coverage - Dual Feed Enhance Helper Consistent ({tier})")
    print(f"[*] YAML registered: {output_path}")


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Dual-feed forensic audio enhancement — helper consistent')
    parser.add_argument('--config', '--yaml', dest='config', default='11_12_ag_neyophetou_cyprus.yaml', help='Path to the YAML project file')
    parser.add_argument('--tier', default='enhanced', help='Audio tier: original, amp32, enhanced, plus20')
    parser.add_argument('--out', default='dual_feed_enhanced_master_helper_consistent.ogg', help='Output filename')
    parser.add_argument('--start', default=None, help='YYYY-MM-DD, YYYY-MM-DD HH:MM[:SS], or HH:MM[:SS]')
    parser.add_argument('--end', default=None, help='YYYY-MM-DD, YYYY-MM-DD HH:MM[:SS], or HH:MM[:SS]')
    args = parser.parse_args()

    streams_for_defaults = load_project_streams(args.config, args.tier)
    if not streams_for_defaults:
        raise SystemExit(f"[!] No streams found for tier {args.tier!r}")
    default_start = min(s["start_dt"] for s in streams_for_defaults)
    t0 = parse_time_arg(args.start, default_start) if args.start else None
    t1 = parse_time_arg(args.end, default_start) if args.end else None
    process(args.config, args.out, tier=args.tier, start_time=t0, end_time=t1)
