#!/usr/bin/env python3
"""
fc_dual_feed.py
===============
Forensic Audio Enhancement — Paphos Dual-Feed Pipeline

TWO CAMERAS:
  Camera A (Short): ~32-min clips, tp00013–tp00227 + tp00000–tp00020
                    Runs Oct 04 – Oct 10.
                    YAML type: "Original", "Raw Amp +32dB", "Enhanced",
                               "Enhanced Amp +20dB"  (all "(Ogg Q10)")

  Camera B (Long):  ~70–160 min clips, tp00013–tp00025 + tp00000–tp00005
                    Runs Oct 09 – Oct 10 only.
                    YAML type: "FD Feed (Original)", "FD Feed (Raw Amp +32dB)",
                               "FD Feed (Enhanced)", "FD Feed (Enhanced +20dB)"

DUAL-FEED OVERLAP: 2023-10-09 04:49:33  →  2023-10-10 08:02:45
  (49 short clips run concurrently with 19 long clips)

SINGLE-FEED PERIOD: Oct 04 – Oct 09 04:49  (short feed only, mono processing)

TWO RUN MODES (--mode):
  plus20   Pair "Enhanced Amp +20dB" (A) vs "FD Feed (Enhanced +20dB)" (B)
           Best for voice clarity — both feeds have been denoised + boosted.

  amp32    Pair "Raw Amp +32dB" (A) vs "FD Feed (Raw Amp +32dB)" (B)
           Most forensically conservative — closest to the raw signal.
           GCC-PHAT alignment is especially important here (no prior sync).

DSP CHAIN (radar / sonar / radio-astronomy):
  1. GCC-PHAT alignment          (radar TDOA — corrects clock drift)
  2. Phase-coherence Wiener mask (RF interferometry — phase + magnitude gate)
  3. MVDR beamforming            (sonar adaptive array — null-steers noise)
  4. CLEAN deconvolution         (radio astronomy — removes stationary tones)
  5. Temporal persistence gate   (radar dwell time — kills impulse noise)
  Adaptive per-block spectral floor replaces any fixed-frequency cutoff.

Usage:
    pip install librosa soundfile scipy pyyaml
    python fc_dual_feed.py --yaml fcpaphos_project.yaml --mode plus20
    python fc_dual_feed.py --yaml fcpaphos_project.yaml --mode amp32
    python fc_dual_feed.py --yaml fcpaphos_project.yaml --mode plus20 --start 2023-10-09 --end 2023-10-10
"""

import os
import sys
import argparse
import yaml
import numpy as np
import soundfile as sf
import librosa
from datetime import datetime, timedelta
from scipy.signal import get_window
from scipy.ndimage import uniform_filter1d

# ---------------------------------------------------------------------------
# DSP CONSTANTS
# ---------------------------------------------------------------------------
SR         = 22050
N_FFT      = 2048
HOP_LEN    = N_FFT // 4      # 512 samples
BLOCK_SEC  = 8
HOP_SEC    = BLOCK_SEC * 0.5
BLOCK_SAMP = int(BLOCK_SEC * SR)
HOP_SAMP   = int(HOP_SEC  * SR)
PERSIST_N  = 3
CLEAN_ITER = 5
CLEAN_GAIN = 0.12
MAX_LAG_SEC= 0.20            # 200 ms — generous for long-form clips with drift
NOISE_PCT  = 8

# ---------------------------------------------------------------------------
# FILE-TYPE SELECTORS per mode
# ---------------------------------------------------------------------------
# Maps --mode to the YAML type strings used for each camera
MODE_TYPES = {
    "plus20": {
        "cam_a": "Enhanced Amp +20dB (Ogg Q10)",
        "cam_b": "FD Feed (Enhanced +20dB)",
        "label": "Enhanced+20dB vs FD+20dB",
    },
    "amp32": {
        "cam_a": "Raw Amp +32dB (Ogg Q10)",
        "cam_b": "FD Feed (Raw Amp +32dB)",
        "label": "Raw+32dB vs FD+32dB",
    },
    "enhanced": {
        "cam_a": "Enhanced (Ogg Q10)",
        "cam_b": "FD Feed (Enhanced)",
        "label": "Enhanced vs FD Enhanced",
    },
}

# ---------------------------------------------------------------------------
# YAML LOADER — builds two sorted clip lists from the project file
# ---------------------------------------------------------------------------

def load_project(yaml_path, mode):
    with open(yaml_path) as f:
        data = yaml.safe_load(f)

    type_a = MODE_TYPES[mode]["cam_a"]
    type_b = MODE_TYPES[mode]["cam_b"]

    clips_a = []
    clips_b = []

    for entry in data["files"]:
        t    = entry.get("type", "")
        path = entry["path"]
        start_str = entry["start"]
        try:
            start_dt = datetime.strptime(start_str, "%Y-%m-%d %H:%M:%S")
        except ValueError:
            continue

        if t == type_a:
            clips_a.append({"path": path, "start": start_dt})
        elif t == type_b:
            clips_b.append({"path": path, "start": start_dt})

    clips_a.sort(key=lambda x: x["start"])
    clips_b.sort(key=lambda x: x["start"])

    print(f"  Camera A clips ({type_a}): {len(clips_a)}")
    print(f"  Camera B clips ({type_b}): {len(clips_b)}")

    return clips_a, clips_b


def build_index(clips):
    """Return list of (start_dt, end_dt, path).
    End is estimated from the next clip's start (or +2h for the final clip)."""
    index = []
    for i, clip in enumerate(clips):
        start = clip["start"]
        if i + 1 < len(clips):
            # Use next clip start as end — accurate for both ~32min and ~100min clips
            end = clips[i + 1]["start"]
        else:
            end = start + timedelta(hours=2, minutes=30)  # safe tail for last clip
        index.append((start, end, clip["path"]))
    return index


# ---------------------------------------------------------------------------
# STREAMING BLOCK LOADER
# ---------------------------------------------------------------------------

def load_block(path, file_start, target_dt, duration_sec):
    """Stream-load `duration_sec` from `path` at the position corresponding
    to `target_dt`. Returns None on any failure (missing file, EOF, etc.)."""
    if not path or not os.path.exists(path):
        return None
    offset = max(0.0, (target_dt - file_start).total_seconds())
    try:
        y, _ = librosa.load(path, sr=SR, offset=offset,
                            duration=duration_sec, mono=True)
        return y if len(y) > 64 else None
    except Exception:
        return None


def find_clip(index, t):
    """Return (file_start, path) for the clip whose window contains t."""
    for (start, end, path) in index:
        if start <= t < end:
            return start, path
    return None, None


def pad_or_trim(y, n):
    if len(y) >= n:
        return y[:n].copy()
    return np.pad(y, (0, n - len(y)))


def safe(y):
    return np.nan_to_num(y, nan=0.0, posinf=0.0, neginf=0.0)


# ---------------------------------------------------------------------------
# ADAPTIVE SPECTRAL FLOOR
# ---------------------------------------------------------------------------

def adaptive_denoise(y):
    """Per-block noise floor from lowest-energy STFT frames → gentle
    spectral subtraction.  Tracks actual noise character of each block
    rather than cutting a fixed frequency shelf."""
    y = safe(y)
    S = librosa.stft(y, n_fft=N_FFT, hop_length=HOP_LEN)
    mag, phase = librosa.magphase(S)
    rms = librosa.feature.rms(S=mag)[0]
    thresh = np.percentile(rms, NOISE_PCT)
    idx = np.where(rms <= thresh)[0]
    floor = (mag[:, idx].mean(axis=1, keepdims=True) if len(idx)
             else np.median(mag, axis=1, keepdims=True) * 0.25)
    mag_clean = np.maximum(mag - floor * 1.2, mag * 0.08)
    return safe(librosa.istft(mag_clean * phase, hop_length=HOP_LEN, length=len(y)))


# ---------------------------------------------------------------------------
# TECHNIQUE 1 — GCC-PHAT ALIGNMENT  (radar TDOA)
# ---------------------------------------------------------------------------

def gcc_phat_align(y_a, y_b):
    """GCC-PHAT: frequency-domain phase-transform TDOA.
    Whitens the cross-spectrum so only inter-channel phase drives the lag
    estimate.  Particularly important for amp32 mode where no prior sync
    has been applied and the two cameras may have drifted."""
    max_lag = int(MAX_LAG_SEC * SR)
    n = len(y_a)
    nfft = 1 << int(np.ceil(np.log2(2 * n - 1)))
    Fa = np.fft.rfft(safe(y_a), n=nfft)
    Fb = np.fft.rfft(safe(y_b), n=nfft)
    cross = Fa * np.conj(Fb)
    gcc   = np.fft.irfft(cross / (np.abs(cross) + 1e-10), n=nfft)
    search = np.concatenate([gcc[-max_lag:], gcc[:max_lag + 1]])
    lag    = int(np.argmax(search)) - max_lag
    if lag > 0:
        aligned = np.concatenate([np.zeros(lag), y_b])[:n]
    elif lag < 0:
        aligned = np.concatenate([y_b[-lag:], np.zeros(-lag)])[:n]
    else:
        aligned = y_b[:n]
    return safe(aligned)


# ---------------------------------------------------------------------------
# TECHNIQUE 2 — PHASE-COHERENCE WIENER MASK  (RF interferometry)
# ---------------------------------------------------------------------------

def phase_coherence_wiener(y_a, y_b):
    """Complex inter-channel coherence Wiener mask.
    Requires phase agreement between channels (not just equal magnitude),
    the way RF interferometry gates correlated signals from noise."""
    n  = len(y_a)
    Sa = librosa.stft(safe(y_a), n_fft=N_FFT, hop_length=HOP_LEN)
    Sb = librosa.stft(safe(y_b), n_fft=N_FFT, hop_length=HOP_LEN)

    cross_r = uniform_filter1d((Sa * np.conj(Sb)).real, size=5, axis=1)
    cross_i = uniform_filter1d((Sa * np.conj(Sb)).imag, size=5, axis=1)
    cross   = cross_r + 1j * cross_i
    pow_a   = uniform_filter1d(np.abs(Sa) ** 2, size=5, axis=1)
    pow_b   = uniform_filter1d(np.abs(Sb) ** 2, size=5, axis=1)

    coh = np.abs(cross) / (np.sqrt(np.abs(pow_a * pow_b)) + 1e-10)
    G   = coh ** 2 / (coh ** 2 + (1.0 - coh ** 2) / 8.0)
    G   = np.clip(safe(G), 0.06, 1.0)

    a_out = safe(librosa.istft(Sa * G, hop_length=HOP_LEN, length=n))
    b_out = safe(librosa.istft(Sb * G, hop_length=HOP_LEN, length=n))
    return a_out, b_out


# ---------------------------------------------------------------------------
# TECHNIQUE 3 — MVDR BEAMFORMING  (sonar adaptive array)
# ---------------------------------------------------------------------------

def mvdr_beamform(y_a, y_b):
    """2-element MVDR: per-bin adaptive weights minimise total output power
    while preserving coherent arrivals (voices).  Spatially nulls sources
    that differ between the two feeds."""
    n  = len(y_a)
    Sa = librosa.stft(safe(y_a), n_fft=N_FFT, hop_length=HOP_LEN)
    Sb = librosa.stft(safe(y_b), n_fft=N_FFT, hop_length=HOP_LEN)
    n_freq, n_frames = Sa.shape
    X    = np.stack([Sa, Sb], axis=0)
    R    = np.einsum('ift,jft->fij', X, X.conj()) / n_frames
    d    = np.array([1.0, 1.0], dtype=complex) / np.sqrt(2)
    eye2 = np.eye(2, dtype=complex)
    out  = np.zeros_like(Sa)

    for k in range(n_freq):
        diag = 1e-4 * (np.abs(R[k, 0, 0]) + np.abs(R[k, 1, 1])) / 2
        Rk   = R[k] + eye2 * diag
        try:
            Rinv = np.linalg.inv(Rk)
        except np.linalg.LinAlgError:
            out[k] = Sa[k]
            continue
        Rinv_d = Rinv @ d
        w = Rinv_d / (d.conj() @ Rinv_d + 1e-10)
        out[k] = w.conj() @ X[:, k, :]

    return safe(librosa.istft(out, hop_length=HOP_LEN, length=n))


# ---------------------------------------------------------------------------
# TECHNIQUE 4 — CLEAN DECONVOLUTION  (radio astronomy, Hogbom 1974)
# ---------------------------------------------------------------------------

def clean_deconvolve(y):
    """Iterative removal of dominant spectral lines (HVAC hum, electrical
    buzz, engine drone) without touching the broadband voice signal."""
    y = safe(y)
    S = librosa.stft(y, n_fft=N_FFT, hop_length=HOP_LEN)
    mag, phase = librosa.magphase(S)
    dirty    = mag.mean(axis=1)
    residual = dirty.copy()
    removed  = np.zeros_like(dirty)
    bins     = np.arange(len(dirty))

    for _ in range(CLEAN_ITER):
        peak_idx = int(np.argmax(residual))
        peak_val = residual[peak_idx]
        if peak_val < 1e-8:
            break
        beam      = peak_val * np.exp(-0.5 * ((bins - peak_idx) / 2.5) ** 2)
        residual -= CLEAN_GAIN * beam
        residual  = np.maximum(residual, 0.0)
        removed  += CLEAN_GAIN * beam

    suppression = np.clip(1.0 - removed / (dirty + 1e-10), 0.05, 1.0)
    mag_clean   = mag * suppression[:, np.newaxis]
    return safe(librosa.istft(mag_clean * phase, hop_length=HOP_LEN, length=len(y)))


# ---------------------------------------------------------------------------
# TECHNIQUE 5 — TEMPORAL PERSISTENCE GATE  (radar dwell time)
# ---------------------------------------------------------------------------

class PersistenceGate:
    """Ring buffer of N spectral magnitude frames.  A bin must be energetic
    across ALL N consecutive windows to pass.  Clicks, slams, radio bleed
    have zero persistence; voiced speech persists for hundreds of ms."""

    def __init__(self):
        n_bins = N_FFT // 2 + 1
        self.buf = [np.zeros(n_bins) for _ in range(PERSIST_N)]
        self.ptr = 0

    def gate(self, y):
        S = librosa.stft(safe(y), n_fft=N_FFT, hop_length=HOP_LEN)
        mag, phase = librosa.magphase(S)
        mean_mag = mag.mean(axis=1)
        self.buf[self.ptr] = mean_mag
        self.ptr = (self.ptr + 1) % PERSIST_N
        persist = np.min(np.vstack(self.buf), axis=0)
        mask = np.clip(persist / (mean_mag + 1e-10), 0.0, 1.0)
        return safe(librosa.istft(mag * mask[:, np.newaxis] * phase,
                                  hop_length=HOP_LEN, length=len(y)))


# ---------------------------------------------------------------------------
# MAIN PROCESSING LOOP
# ---------------------------------------------------------------------------

def process(yaml_path, mode, output_path,
            date_start=None, date_end=None):

    print("=" * 64)
    print(f"  FC Paphos Dual-Feed Enhancement")
    print(f"  Mode     : {mode}  ({MODE_TYPES[mode]['label']})")
    print(f"  YAML     : {yaml_path}")
    print(f"  Output   : {output_path}")
    print("=" * 64)

    clips_a, clips_b = load_project(yaml_path, mode)

    index_a = build_index(clips_a)
    index_b = build_index(clips_b)

    # Overall timeline
    t_global_start = index_a[0][0]
    t_global_end   = max(index_a[-1][1], index_b[-1][1]) if index_b \
                     else index_a[-1][1]

    # Dual-feed window (where B exists)
    dual_start = index_b[0][0]  if index_b else t_global_end
    dual_end   = index_b[-1][1] if index_b else t_global_end

    # Apply optional date restriction
    t_start = date_start or t_global_start
    t_end   = date_end   or t_global_end
    total_sec = (t_end - t_start).total_seconds()

    print(f"\n  Full timeline : {t_global_start:%Y-%m-%d %H:%M}  →  {t_global_end:%Y-%m-%d %H:%M}")
    print(f"  Dual window  : {dual_start:%Y-%m-%d %H:%M}  →  {dual_end:%Y-%m-%d %H:%M}")
    print(f"  Processing   : {t_start:%Y-%m-%d %H:%M}  →  {t_end:%Y-%m-%d %H:%M}")
    print(f"  (~{total_sec/3600:.1f} hours)\n")

    # Pre-flight: warn about missing files
    all_paths = [p for (_, _, p) in index_a + index_b]
    missing   = [p for p in all_paths if not os.path.exists(p)]
    if missing:
        print("WARNING — files not found (expected at these paths):")
        for m in sorted(set(missing)):
            print(f"  {m}")
        print("Make sure the 'fcpaphos/' subdirectory is in the current directory.\n")

    # Persistence gates — one per channel, persist across entire run
    gate_a = PersistenceGate()
    gate_b = PersistenceGate()
    win    = get_window("hann", BLOCK_SAMP).astype(np.float32)

    # OLA buffer: 2x block length so windowed block fits in front half
    ola = np.zeros((BLOCK_SAMP * 2, 2), dtype=np.float32)

    t             = t_start
    blocks_done   = 0
    blocks_dual   = 0
    blocks_mono   = 0
    blocks_silent = 0

    # Track which clips are active for progress display
    last_a_path = last_b_path = None

    with sf.SoundFile(output_path, mode="w",
                      samplerate=SR, channels=2) as out_f:

        while t < t_end:

            # ── FIND ACTIVE CLIPS ──────────────────────────────────────────
            a_start, a_path = find_clip(index_a, t)
            b_start, b_path = find_clip(index_b, t)

            # Announce clip transitions
            if a_path != last_a_path:
                if a_path:
                    print(f"\n  [{t:%Y-%m-%d %H:%M:%S}]  Cam A → {os.path.basename(a_path)}")
                last_a_path = a_path
            if b_path != last_b_path:
                if b_path:
                    print(f"\n  [{t:%Y-%m-%d %H:%M:%S}]  Cam B → {os.path.basename(b_path)}")
                elif last_b_path:
                    print(f"\n  [{t:%Y-%m-%d %H:%M:%S}]  Cam B → (no coverage)")
                last_b_path = b_path

            # ── LOAD BLOCKS ────────────────────────────────────────────────
            y_a = load_block(a_path, a_start, t, BLOCK_SEC) if a_start else None
            y_b = load_block(b_path, b_start, t, BLOCK_SEC) if b_start else None

            # ── ADAPTIVE DENOISE ───────────────────────────────────────────
            if y_a is not None:
                y_a = adaptive_denoise(pad_or_trim(safe(y_a), BLOCK_SAMP))
            if y_b is not None:
                y_b = adaptive_denoise(pad_or_trim(safe(y_b), BLOCK_SAMP))

            # ── DSP CHAIN ──────────────────────────────────────────────────
            if y_a is not None and y_b is not None:
                # Full dual-feed coherence path
                blocks_dual += 1
                y_b        = gcc_phat_align(y_a, y_b)
                y_a, y_b   = phase_coherence_wiener(y_a, y_b)
                y_beam     = mvdr_beamform(y_a, y_b)
                y_a        = clean_deconvolve(gate_a.gate(y_a))
                y_b        = clean_deconvolve(gate_b.gate(y_b))
                y_beam     = clean_deconvolve(y_beam)
                # Stereo: L=CamA, R=CamB, both blended with centre beam
                L = np.clip(0.6 * y_a   + 0.4 * y_beam, -1.0, 1.0)
                R = np.clip(0.6 * y_b   + 0.4 * y_beam, -1.0, 1.0)

            elif y_a is not None:
                # Mono fallback — short feed only (Oct 04–09 period)
                blocks_mono += 1
                mono = clean_deconvolve(gate_a.gate(y_a))
                L = R = np.clip(mono, -1.0, 1.0)

            elif y_b is not None:
                # Mono fallback — long feed only (shouldn't happen but safe)
                blocks_mono += 1
                mono = clean_deconvolve(gate_b.gate(y_b))
                L = R = np.clip(mono, -1.0, 1.0)

            else:
                blocks_silent += 1
                L = R = np.zeros(BLOCK_SAMP, dtype=np.float32)

            # ── OVERLAP-ADD ────────────────────────────────────────────────
            ola[:BLOCK_SAMP, 0] += (L * win).astype(np.float32)
            ola[:BLOCK_SAMP, 1] += (R * win).astype(np.float32)

            chunk = ola[:HOP_SAMP, :].copy()
            peak  = np.max(np.abs(chunk))
            if peak > 0.97:
                chunk *= 0.97 / peak
            out_f.write(chunk)

            # Correct shift: move buffer left, zero the vacated tail
            ola[:-HOP_SAMP] = ola[HOP_SAMP:]
            ola[-HOP_SAMP:] = 0.0

            # ── PROGRESS ───────────────────────────────────────────────────
            blocks_done += 1
            t += timedelta(seconds=HOP_SEC)

            if blocks_done % 50 == 0:
                elapsed = (t - t_start).total_seconds()
                pct = min(100.0, 100.0 * elapsed / total_sec)
                mode_str = "DUAL" if (y_a is not None and y_b is not None) \
                           else "mono"
                print(f"  [{pct:5.1f}%]  {t:%Y-%m-%d %H:%M}  "
                      f"dual={blocks_dual}  mono={blocks_mono}  "
                      f"silent={blocks_silent}  [{mode_str}]",
                      end="\r")

    print(f"\n\n{'='*64}")
    print(f"  Complete  —  {output_path}")
    print(f"  Mode        : {mode}")
    print(f"  Dual blocks : {blocks_dual}  "
          f"({blocks_dual * HOP_SEC / 3600:.1f}h dual-feed processed)")
    print(f"  Mono blocks : {blocks_mono}  "
          f"({blocks_mono * HOP_SEC / 3600:.1f}h single-feed)")
    print(f"  Silent      : {blocks_silent}")
    print(f"  Total       : {blocks_done}  "
          f"({blocks_done * HOP_SEC / 3600:.1f}h output)")
    print(f"{'='*64}\n")

    # ── REGISTER OUTPUT IN YAML ────────────────────────────────────────────
    try:
        with open(yaml_path, "r") as f:
            project = yaml.safe_load(f)

        new_entry = {
            "path":  output_path,
            "start": t_start.strftime("%Y-%m-%d %H:%M:%S"),
            "end":   t_end.strftime("%Y-%m-%d %H:%M:%S"),
            "type":  f"Dual-Feed Master ({MODE_TYPES[mode]['label']})",
        }

        if "files" not in project:
            project["files"] = []

        # Update in place if already present, otherwise append
        updated = False
        for entry in project["files"]:
            if entry.get("path") == output_path:
                entry.update(new_entry)
                updated = True
                break
        if not updated:
            project["files"].append(new_entry)

        with open(yaml_path, "w") as f:
            yaml.dump(project, f, default_flow_style=False,
                      sort_keys=False, allow_unicode=True)

        print(f"  YAML updated : {yaml_path}")
        print(f"    type  : {new_entry['type']}")
        print(f"    start : {new_entry['start']}")
        print(f"    end   : {new_entry['end']}\n")

    except Exception as e:
        print(f"  WARNING: could not update YAML: {e}\n")


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def parse_dt(s):
    for fmt in ("%Y-%m-%d %H:%M", "%Y-%m-%d"):
        try:
            return datetime.strptime(s, fmt)
        except ValueError:
            continue
    raise ValueError(f"Cannot parse date: {s!r}")


def resolve_timeline(yaml_path, mode, t0, t1):
    """Read YAML and return (t_start, t_end) for filename generation."""
    with open(yaml_path) as f:
        data = yaml.safe_load(f)
    type_a = MODE_TYPES[mode]["cam_a"]
    type_b = MODE_TYPES[mode]["cam_b"]
    starts = sorted(
        datetime.strptime(e["start"], "%Y-%m-%d %H:%M:%S")
        for e in data["files"]
        if e.get("type") in (type_a, type_b)
    )
    if not starts:
        raise ValueError("No matching files found in YAML for this mode.")
    t_start = t0 or starts[0]
    t_end   = t1 or (starts[-1] + timedelta(hours=2, minutes=30))
    return t_start, t_end


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="FC Paphos dual-feed forensic audio enhancement")
    parser.add_argument("--yaml",  required=True,
                        help="Path to fcpaphos_project.yaml")
    parser.add_argument("--mode",  required=True, choices=["plus20", "amp32", "enhanced"],
                        help="plus20: Enhanced+20dB | amp32: Raw+32dB | enhanced: Enhanced (no +20dB)")
    parser.add_argument("--out",   default=None,
                        help="Output filename (auto-generated with timestamps if omitted)")
    parser.add_argument("--start", default=None,
                        help="Restrict to date YYYY-MM-DD or YYYY-MM-DD HH:MM")
    parser.add_argument("--end",   default=None,
                        help="Restrict to date YYYY-MM-DD or YYYY-MM-DD HH:MM")
    args = parser.parse_args()

    t0 = parse_dt(args.start) if args.start else None
    t1 = parse_dt(args.end)   if args.end   else None

    if args.out:
        out = args.out
    else:
        ts, te  = resolve_timeline(args.yaml, args.mode, t0, t1)
        ts_from = ts.strftime("%Y%m%d_%H%M")
        ts_to   = te.strftime("%Y%m%d_%H%M")
        out     = f"fc_paphos_{args.mode}_{ts_from}_{ts_to}.ogg"

    process(args.yaml, args.mode, out, t0, t1)
