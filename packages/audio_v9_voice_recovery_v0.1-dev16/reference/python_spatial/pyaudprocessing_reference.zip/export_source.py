#!/usr/bin/env python3
"""
export_source.py
================
Interactive source-window exporter for Forensic Shuttle YAML projects.

Given a project YAML and an absolute time window, it lists all media entries that
overlap that window. You select one source, and it exports only the overlapping
section from that physical/source file.

Examples:
    sh export_source.sh --yaml fcpaphos_project.yaml \
      --start "2023-10-10 12:50:00" \
      --end   "2023-10-10 12:55:00" \
      --out exports/

    sh export_source.sh --yaml fcpaphos_project.yaml \
      --start "2023-10-10 12:50:00" \
      --duration 300 \
      --tier amp32 \
      --out exports/

Non-interactive:
    sh export_source.sh --yaml fcpaphos_project.yaml \
      --start "2023-10-10 12:50:00" --duration 120 \
      --select 4 --out exports/source.wav
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import os
import re
import subprocess
import sys
from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional

import yaml


MEDIA_EXTS = {
    ".ogg", ".oga", ".wav", ".wave", ".flac", ".mp3", ".m4a", ".aac",
    ".mp4", ".m4v", ".mov", ".mkv", ".webm", ".avi"
}


@dataclass
class SourceOption:
    display_idx: int
    yaml_idx: int
    path: str
    cam: str
    typ: str
    start: datetime
    end: datetime
    duration: float
    overlap_start: datetime
    overlap_end: datetime
    overlap_duration: float
    offset: float


def parse_dt(s: str) -> datetime:
    s = str(s).strip().strip("'").strip('"')
    if re.fullmatch(r"\d{8}\s+\d{1,2}:\d{2}(:\d{2})?", s):
        date, tm = s.split(None, 1)
        s = f"{date[:4]}-{date[4:6]}-{date[6:8]} {tm}"
    if re.fullmatch(r"\d{8}_\d{6}", s):
        return datetime.strptime(s, "%Y%m%d_%H%M%S")
    if re.fullmatch(r"\d{14}", s):
        return datetime.strptime(s, "%Y%m%d%H%M%S")

    for fmt in (
        "%Y-%m-%d %H:%M:%S.%f",
        "%Y-%m-%d %H:%M:%S",
        "%Y-%m-%d %H:%M",
        "%Y-%m-%d",
        "%Y/%m/%d %H:%M:%S",
        "%Y/%m/%d %H:%M",
    ):
        try:
            return datetime.strptime(s, fmt)
        except ValueError:
            pass
    raise ValueError(f"Could not parse datetime: {s!r}")


def fmt_dt(dt: datetime) -> str:
    return dt.strftime("%Y-%m-%d %H:%M:%S")


def compact_dt(dt: datetime) -> str:
    return dt.strftime("%Y%m%d_%H%M%S")


def slug(s: str, max_len: int = 90) -> str:
    s = re.sub(r"[^A-Za-z0-9._-]+", "_", str(s)).strip("_")
    return (s[:max_len].rstrip("_") if len(s) > max_len else s) or "source"



def duration_from_entry(entry: Dict[str, Any]) -> Optional[float]:
    """Use cached/project duration if the YAML already has one."""
    for key in ("duration", "duration_sec", "length", "length_sec"):
        if key in entry:
            try:
                v = float(entry.get(key))
                if math.isfinite(v) and v > 0:
                    return v
            except Exception:
                pass
    return None


def rough_duration_guess(entry: Dict[str, Any], include_generated: bool) -> float:
    """
    Cheap duration guess used only to decide whether a file could overlap before
    paying for ffprobe. It deliberately overestimates.
    """
    d = duration_from_entry(entry)
    if d:
        return d

    hay = " ".join(str(entry.get(k, "")) for k in ("type", "filter", "label", "path")).lower()
    if include_generated or any(k in hay for k in ("generated", "trial_mix", "dual_feed", "master", "v8", "v9")):
        return 96 * 3600.0
    return 4 * 3600.0

def ffprobe_duration(path: str) -> Optional[float]:
    cmd = [
        "ffprobe", "-v", "error",
        "-show_entries", "format=duration",
        "-of", "default=noprint_wrappers=1:nokey=1",
        path,
    ]
    try:
        res = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=30)
        if res.returncode != 0:
            return None
        out = (res.stdout or "").strip()
        if not out:
            return None
        dur = float(out)
        if not math.isfinite(dur) or dur <= 0:
            return None
        return dur
    except Exception:
        return None


def infer_cam(entry: Dict[str, Any]) -> str:
    raw = " ".join(str(entry.get(k, "")) for k in ("cam_id", "camera", "type", "filter", "path")).lower()
    if "cam b" in raw or "cam_b" in raw or "fd feed" in raw or "feed b" in raw:
        return "Cam B"
    if "cam a" in raw or "cam_a" in raw or "feed a" in raw:
        return "Cam A"
    return str(entry.get("cam_id") or entry.get("camera") or "Unknown")


def entry_type(entry: Dict[str, Any]) -> str:
    return str(entry.get("filter") or entry.get("type") or entry.get("label") or "")


def matches_filter(entry: Dict[str, Any], tier: Optional[str], cam: Optional[str], include_generated: bool) -> bool:
    path = str(entry.get("path", ""))
    hay = " ".join(str(entry.get(k, "")) for k in ("type", "filter", "label", "path", "cam_id")).lower()

    if tier:
        tl = tier.lower()
        if tl == "amp32":
            ok = ("amp32" in hay) or ("+32db" in hay) or ("raw amp" in hay)
        elif tl == "plus20":
            ok = ("plus20" in hay) or ("+20db" in hay) or ("+20" in hay)
        elif tl == "enhanced":
            ok = ("enhanced" in hay) and ("plus20" not in hay) and ("+20" not in hay)
        elif tl == "original":
            ok = "original" in hay
        else:
            ok = tl in hay
        if not ok:
            return False

    if cam and infer_cam(entry).lower() != cam.lower():
        return False

    if not include_generated:
        generated_terms = [
            "generated", "trial_mix", "dual_feed", "master", "scene",
            "v3", "v4", "v5", "v6", "v7", "v8", "v9", "fcdf", "dfe"
        ]
        base = os.path.basename(path).lower()
        if any(term in base or term in hay for term in generated_terms):
            return False

    return True


def load_options(
    yaml_path: str,
    win_start: datetime,
    win_end: datetime,
    tier: Optional[str],
    cam: Optional[str],
    include_generated: bool,
    allow_missing: bool,
) -> List[SourceOption]:
    with open(yaml_path, "r", encoding="utf-8") as f:
        cfg = yaml.safe_load(f) or {}

    options: List[SourceOption] = []

    for yaml_idx, entry in enumerate(cfg.get("files", []) or []):
        if not isinstance(entry, dict):
            continue

        path = str(entry.get("path") or "")
        if not path:
            continue

        ext = os.path.splitext(path)[1].lower()
        if ext and ext not in MEDIA_EXTS:
            continue

        if not matches_filter(entry, tier, cam, include_generated):
            continue

        try:
            start = parse_dt(str(entry.get("start")))
        except Exception:
            continue

        # Cheap prefilter before ffprobe: avoid probing thousands of files that
        # cannot possibly overlap the requested time window.
        rough_end = start + timedelta(seconds=rough_duration_guess(entry, include_generated))
        if rough_end <= win_start or start >= win_end:
            continue

        if not os.path.exists(path):
            if not allow_missing:
                continue
            dur = duration_from_entry(entry) or 0.0
        else:
            dur = duration_from_entry(entry)
            if dur is None:
                dur = ffprobe_duration(path) or 0.0

        if dur <= 0:
            continue

        end = start + timedelta(seconds=dur)
        overlap_start = max(win_start, start)
        overlap_end = min(win_end, end)
        overlap_duration = (overlap_end - overlap_start).total_seconds()
        if overlap_duration <= 0:
            continue

        offset = (overlap_start - start).total_seconds()

        options.append(SourceOption(
            display_idx=0,
            yaml_idx=yaml_idx,
            path=path,
            cam=infer_cam(entry),
            typ=entry_type(entry),
            start=start,
            end=end,
            duration=dur,
            overlap_start=overlap_start,
            overlap_end=overlap_end,
            overlap_duration=overlap_duration,
            offset=offset,
        ))

    options.sort(key=lambda o: (o.cam, o.start, o.typ, o.path))
    for i, opt in enumerate(options, start=1):
        opt.display_idx = i
    return options


def print_options(options: List[SourceOption], win_start: datetime, win_end: datetime) -> None:
    print()
    print("=== Export Source Selector ===")
    print(f"Window: {fmt_dt(win_start)} -> {fmt_dt(win_end)} ({(win_end-win_start).total_seconds():.1f}s)")
    print("-" * 132)
    print(f"{'#':>3} | {'Cam':<6} | {'Overlap':>9} | {'Offset':>9} | {'Source Start':<19} | {'Source End':<19} | {'Type':<28} | File")
    print("-" * 132)
    for o in options:
        print(
            f"{o.display_idx:>3} | "
            f"{o.cam:<6} | "
            f"{o.overlap_duration:>8.1f}s | "
            f"{o.offset:>8.1f}s | "
            f"{fmt_dt(o.start):<19} | "
            f"{fmt_dt(o.end):<19} | "
            f"{o.typ[:28]:<28} | "
            f"{os.path.basename(o.path)}"
        )
    print("-" * 132)


def output_path_for_selection(out_arg: str, opt: SourceOption, win_start: datetime, win_end: datetime, fmt: str) -> str:
    ext = ".wav" if fmt == "wav" else ".ogg" if fmt == "ogg" else ".flac" if fmt == "flac" else ".mp3"
    base = (
        f"export_{compact_dt(win_start)}_to_{compact_dt(win_end)}_"
        f"S{opt.yaml_idx:04d}_{slug(opt.cam)}_{slug(os.path.splitext(os.path.basename(opt.path))[0])}{ext}"
    )

    if not out_arg:
        return os.path.join("exports", base)

    if os.path.isdir(out_arg) or out_arg.endswith(os.sep) or out_arg.endswith("/"):
        return os.path.join(out_arg, base)

    return out_arg


def ffmpeg_export(opt: SourceOption, out_path: str, fmt: str, copy: bool = False, channels: Optional[int] = None, sr: Optional[int] = None) -> bool:
    os.makedirs(os.path.dirname(os.path.abspath(out_path)) or ".", exist_ok=True)

    cmd = ["ffmpeg", "-y", "-hide_banner", "-loglevel", "error", "-ss", f"{opt.offset:.6f}", "-t", f"{opt.overlap_duration:.6f}", "-i", opt.path, "-vn"]

    if copy:
        cmd += ["-c:a", "copy"]
    else:
        if channels:
            cmd += ["-ac", str(channels)]
        if sr:
            cmd += ["-ar", str(sr)]

        if fmt == "wav":
            cmd += ["-c:a", "pcm_s16le"]
        elif fmt == "flac":
            cmd += ["-c:a", "flac"]
        elif fmt == "mp3":
            cmd += ["-c:a", "libmp3lame", "-b:a", "192k"]
        elif fmt == "ogg":
            cmd += ["-c:a", "libvorbis", "-q:a", "6"]
        else:
            raise ValueError(f"Unsupported format: {fmt}")

    cmd += [out_path]

    print()
    print("[export] " + " ".join(cmd))
    res = subprocess.run(cmd)
    if res.returncode != 0:
        print(f"[!] ffmpeg failed with code {res.returncode}", file=sys.stderr)
        return False

    return True


def write_sidecar(out_path: str, opt: SourceOption, args: argparse.Namespace, win_start: datetime, win_end: datetime) -> None:
    sidecar = out_path + ".json"
    data = {
        "yaml": args.yaml,
        "yaml_index": opt.yaml_idx,
        "source_path": opt.path,
        "camera": opt.cam,
        "type": opt.typ,
        "source_start": fmt_dt(opt.start),
        "source_end": fmt_dt(opt.end),
        "requested_start": fmt_dt(win_start),
        "requested_end": fmt_dt(win_end),
        "export_start": fmt_dt(opt.overlap_start),
        "export_end": fmt_dt(opt.overlap_end),
        "source_offset_sec": opt.offset,
        "duration_sec": opt.overlap_duration,
        "output": out_path,
    }
    with open(sidecar, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, sort_keys=True)
    print(f"[export] sidecar: {sidecar}")


def parse_selection(sel: str, max_idx: int) -> List[int]:
    sel = str(sel).strip().lower()
    if sel in {"q", "quit", "exit"}:
        return []
    if sel in {"all", "*"}:
        return list(range(1, max_idx + 1))

    chosen = []
    for part in re.split(r"[,\s]+", sel):
        if not part:
            continue
        if "-" in part:
            a, b = part.split("-", 1)
            a, b = int(a), int(b)
            chosen.extend(range(min(a, b), max(a, b) + 1))
        else:
            chosen.append(int(part))

    return sorted(set(i for i in chosen if 1 <= i <= max_idx))


def main() -> None:
    p = argparse.ArgumentParser(description="Interactively export a selected project source over a time window.")
    p.add_argument("--yaml", required=True, help="Project YAML")
    p.add_argument("--start", required=True, help="Window start, e.g. '2023-10-10 12:50:00'")
    p.add_argument("--end", help="Window end")
    p.add_argument("--duration", type=float, help="Window duration in seconds, used if --end is omitted")
    p.add_argument("--out", default="exports", help="Output file or output directory")
    p.add_argument("--tier", help="Filter tier, e.g. amp32, original, enhanced, plus20")
    p.add_argument("--cam", help="Restrict to camera, e.g. 'Cam A' or 'Cam B'")
    p.add_argument("--include-generated", action="store_true", help="Show generated/derived tracks too")
    p.add_argument("--allow-missing", action="store_true", help="List missing entries if duration can be known; normally off")
    p.add_argument("--select", help="Non-interactive selection: number, comma list, range, or all")
    p.add_argument("--format", choices=["wav", "ogg", "flac", "mp3"], default="wav")
    p.add_argument("--copy", action="store_true", help="Stream-copy audio instead of re-encoding; less precise for some formats")
    p.add_argument("--channels", type=int, help="Output audio channels, e.g. 1 or 2")
    p.add_argument("--sr", type=int, help="Output sample rate, e.g. 22050")
    p.add_argument("--csv", help="Write option list CSV")
    args = p.parse_args()

    win_start = parse_dt(args.start)
    if args.end:
        win_end = parse_dt(args.end)
    elif args.duration:
        win_end = win_start + timedelta(seconds=float(args.duration))
    else:
        raise SystemExit("Provide either --end or --duration.")

    if win_end <= win_start:
        raise SystemExit("--end must be after --start.")

    options = load_options(args.yaml, win_start, win_end, args.tier, args.cam, args.include_generated, args.allow_missing)
    if not options:
        print("[!] No overlapping sources found.")
        print("    Try --include-generated, remove --tier/--cam, or check the requested time window.")
        sys.exit(2)

    print_options(options, win_start, win_end)

    if args.csv:
        with open(args.csv, "w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=list(SourceOption.__dataclass_fields__.keys()))
            w.writeheader()
            for o in options:
                d = o.__dict__.copy()
                for k in ("start", "end", "overlap_start", "overlap_end"):
                    d[k] = fmt_dt(d[k])
                w.writerow(d)
        print(f"[list] CSV: {args.csv}")

    if args.select:
        selected = parse_selection(args.select, len(options))
    else:
        raw = input("Select source number to export, comma/range, 'all', or q: ").strip()
        selected = parse_selection(raw, len(options))

    if not selected:
        print("[cancelled]")
        return

    multi = len(selected) > 1
    ok_all = True

    for n in selected:
        opt = options[n - 1]
        out_path = output_path_for_selection(args.out, opt, win_start, win_end, args.format)

        if multi and not (os.path.isdir(args.out) or args.out.endswith(os.sep) or args.out.endswith("/")):
            stem, ext = os.path.splitext(out_path)
            out_path = f"{stem}_choice{n:03d}{ext}"

        ok = ffmpeg_export(opt, out_path, args.format, copy=args.copy, channels=args.channels, sr=args.sr)
        if ok:
            print(f"[export] wrote: {out_path}")
            write_sidecar(out_path, opt, args, win_start, win_end)
        ok_all = ok_all and ok

    if not ok_all:
        sys.exit(1)


if __name__ == "__main__":
    main()
