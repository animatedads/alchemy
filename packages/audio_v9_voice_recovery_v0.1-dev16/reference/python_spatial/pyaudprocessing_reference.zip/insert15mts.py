#!/usr/bin/env python3
"""
insert15mts.py
================================================================================
Forensic Time-Boundary Synchronization & Clock-Aligned Timestamp Generator
================================================================================

Injects clock-aligned 15-minute markers into the Shuttle transcript database.

Fixes:
  - Does not rely on INSERT OR IGNORE alone.
  - Checks for an existing timestamp before inserting.
  - Handles legacy transcript tables where ts is not PRIMARY KEY / UNIQUE.
  - Optional duplicate cleanup for existing duplicate marker rows.

Usage:
    python insert15mts.py --yaml rehab.yaml
    python insert15mts.py --yaml rehab.yaml --dry-run
    python insert15mts.py --yaml rehab.yaml --dedupe-existing
"""

import os
import sys
import yaml
import sqlite3
import argparse
from datetime import datetime, timedelta
from forensic_helper import ForensicHelper as fh


def align_to_next_15m(dt):
    """Rounds a datetime up to the next 15-minute clock boundary."""
    dt = dt.replace(second=0, microsecond=0)
    remainder = dt.minute % 15
    if remainder == 0:
        return dt
    return dt + timedelta(minutes=(15 - remainder))


def table_exists(cursor, table_name):
    cursor.execute(
        "SELECT name FROM sqlite_master WHERE type='table' AND name=?",
        (table_name,)
    )
    return cursor.fetchone() is not None


def get_columns(cursor, table_name):
    cursor.execute(f"PRAGMA table_info({table_name})")
    return [info[1] for info in cursor.fetchall()]


def get_text_column(cursor):
    """Detects if the database uses 'text' or 'content' for the transcript."""
    cols = get_columns(cursor, "transcript")
    if "text" in cols:
        return "text"
    if "content" in cols:
        return "content"

    # Last-resort compatibility: create a text column if a very old table exists.
    cursor.execute("ALTER TABLE transcript ADD COLUMN text TEXT DEFAULT ''")
    return "text"


def has_source_column(cursor):
    """Detects if the transcript table contains a 'source' metadata column."""
    return "source" in get_columns(cursor, "transcript")


def ensure_transcript_table(cursor):
    """
    Creates a sane transcript table if missing.

    Important: CREATE TABLE IF NOT EXISTS does not retrofit PRIMARY KEY / UNIQUE
    constraints onto an existing legacy table. Therefore this script still checks
    manually before insertion.
    """
    if not table_exists(cursor, "transcript"):
        cursor.execute("""
            CREATE TABLE transcript (
                ts TEXT PRIMARY KEY,
                text TEXT,
                source TEXT DEFAULT 'Unknown'
            )
        """)
        return

    cols = get_columns(cursor, "transcript")
    if "ts" not in cols:
        raise RuntimeError("Existing transcript table has no 'ts' column.")

    if "text" not in cols and "content" not in cols:
        cursor.execute("ALTER TABLE transcript ADD COLUMN text TEXT DEFAULT ''")


def audit_log_columns(cursor):
    if not table_exists(cursor, "audit_log"):
        return []
    return get_columns(cursor, "audit_log")


def maybe_write_audit(cursor, now_str, ts_key, marker_text):
    """
    Writes audit trail only if the table has the expected columns.
    Avoids crashing on older audit schemas.
    """
    cols = set(audit_log_columns(cursor))
    required = {"edit_time", "line_ts", "old_text", "new_text", "user", "source_file"}
    if not required.issubset(cols):
        return

    cursor.execute("""
        INSERT INTO audit_log (edit_time, line_ts, old_text, new_text, user, source_file)
        VALUES (?, ?, ?, ?, ?, ?)
    """, (now_str, ts_key, "NULL", marker_text, "ALIGNED_GEN", "SYSTEM"))


def rows_for_ts(cursor, ts_key, text_col, has_src):
    if has_src:
        cursor.execute(
            f"SELECT rowid, {text_col}, source FROM transcript WHERE ts=? ORDER BY rowid ASC",
            (ts_key,)
        )
    else:
        cursor.execute(
            f"SELECT rowid, {text_col}, NULL as source FROM transcript WHERE ts=? ORDER BY rowid ASC",
            (ts_key,)
        )
    return cursor.fetchall()


def dedupe_timestamp_rows(cursor, ts_key, marker_text, text_col, has_src):
    """
    Removes duplicate rows for a timestamp, preserving the most valuable row.

    Preference order:
      1. A non-system/non-marker row, because it may be analyst-entered text.
      2. The first row at that timestamp.

    This is intentionally conservative and only runs when --dedupe-existing is set.
    """
    rows = rows_for_ts(cursor, ts_key, text_col, has_src)
    if len(rows) <= 1:
        return 0

    keep_rowid = None

    for rowid, txt, src in rows:
        txt = txt or ""
        src = src or ""
        is_system_marker = (txt == marker_text) or (src.upper() == "SYSTEM")
        if not is_system_marker:
            keep_rowid = rowid
            break

    if keep_rowid is None:
        keep_rowid = rows[0][0]

    delete_rowids = [rowid for rowid, _, _ in rows if rowid != keep_rowid]
    cursor.executemany(
        "DELETE FROM transcript WHERE rowid=?",
        [(rowid,) for rowid in delete_rowids]
    )
    return len(delete_rowids)


def insert_marker_if_missing(cursor, ts_key, marker_text, text_col, has_src):
    """
    Inserts a marker only when no row already exists for the timestamp.

    This avoids duplicate timestamps even if the legacy DB lacks a UNIQUE/PRIMARY
    KEY constraint on ts.
    """
    existing = rows_for_ts(cursor, ts_key, text_col, has_src)
    if existing:
        return False

    if has_src:
        cursor.execute(
            f"INSERT INTO transcript (ts, {text_col}, source) VALUES (?, ?, ?)",
            (ts_key, marker_text, "SYSTEM")
        )
    else:
        cursor.execute(
            f"INSERT INTO transcript (ts, {text_col}) VALUES (?, ?)",
            (ts_key, marker_text)
        )
    return True


def process_markers(yaml_path, dry_run=False, dedupe_existing=False):
    if not os.path.exists(yaml_path):
        print(f"[!] Error: Project configuration '{yaml_path}' not found.")
        sys.exit(1)

    project_name = os.path.splitext(os.path.basename(yaml_path))[0]
    db_path = f"{project_name}_audit.db"

    print(f"=== Unified Forensic Marker Aligner: {project_name} ===")

    try:
        streams = fh.get_active_streams(yaml_path, datetime.min, datetime.max)
    except Exception as e:
        print(f"[!] Error reading project streams: {e}")
        sys.exit(1)

    if not streams:
        print("[!] Error: No valid files or streams detected in the project config.")
        sys.exit(1)

    global_start = min(s["start_dt"] for s in streams)
    global_end = max(s["end_dt"] for s in streams)
    first_aligned = align_to_next_15m(global_start)

    print(f" [*] Bounds Detected : {global_start:%Y-%m-%d %H:%M:%S} to {global_end:%Y-%m-%d %H:%M:%S}")
    print(f" [*] First Aligned   : {first_aligned:%Y-%m-%d %H:%M:%S}")

    if first_aligned > global_end:
        print("[!] Project duration is too short to align with a 15-minute boundary.")
        return

    if not os.path.exists(db_path):
        print(f"[!] Error: Project audit database '{db_path}' is missing.")
        sys.exit(1)

    inserted_count = 0
    skipped_existing = 0
    removed_duplicates = 0
    current_mark = first_aligned
    now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    with sqlite3.connect(db_path) as conn:
        c = conn.cursor()
        ensure_transcript_table(c)

        text_col = get_text_column(c)
        has_src = has_source_column(c)

        while current_mark <= global_end:
            ts_key = current_mark.strftime("%Y%m%d%H%M%S")
            marker_text = f"-- {current_mark:%Y-%m-%d %H:%M:%S} --"

            if dry_run:
                rows = rows_for_ts(c, ts_key, text_col, has_src)
                if rows:
                    print(f" [DRY RUN] Existing timestamp {ts_key}; would skip marker '{marker_text}'")
                    skipped_existing += 1
                else:
                    print(f" [DRY RUN] Would inject timestamp key {ts_key} -> '{marker_text}'")
                    inserted_count += 1
            else:
                if dedupe_existing:
                    removed_duplicates += dedupe_timestamp_rows(c, ts_key, marker_text, text_col, has_src)

                inserted = insert_marker_if_missing(c, ts_key, marker_text, text_col, has_src)
                if inserted:
                    inserted_count += 1
                    maybe_write_audit(c, now_str, ts_key, marker_text)
                else:
                    skipped_existing += 1

            current_mark += timedelta(minutes=15)

        if not dry_run:
            conn.commit()

    if dry_run:
        print(f"[DRY RUN COMPLETE] Would insert {inserted_count}; would skip {skipped_existing} existing timestamps.")
    else:
        print(f"[SUCCESS] Inserted {inserted_count} new sync markers into '{db_path}'.")
        print(f"[INFO] Skipped {skipped_existing} timestamps that already existed.")
        if dedupe_existing:
            print(f"[INFO] Removed {removed_duplicates} duplicate existing rows.")


def main():
    parser = argparse.ArgumentParser(description="Injects clock-aligned 15m timeline markers.")
    parser.add_argument("legacy_yaml", nargs="?", default=None, help="Positional YAML project (backwards compatibility)")
    parser.add_argument("--yaml", help="Path to project YAML config (preferred)")
    parser.add_argument("--dry-run", action="store_true", help="Calculate boundaries and print operations without writing to disk.")
    parser.add_argument(
        "--dedupe-existing",
        action="store_true",
        help="Conservatively remove duplicate rows for marker timestamps, preserving analyst-entered rows."
    )
    args = parser.parse_args()

    target_yaml = args.yaml if args.yaml else args.legacy_yaml

    if not target_yaml:
        print("Error: A project config YAML must be provided.")
        print("Usage:")
        print("  python insert15mts.py --yaml rehab.yaml")
        print("  python insert15mts.py rehab.yaml")
        sys.exit(1)

    process_markers(
        target_yaml,
        dry_run=args.dry_run,
        dedupe_existing=args.dedupe_existing
    )


if __name__ == "__main__":
    main()
