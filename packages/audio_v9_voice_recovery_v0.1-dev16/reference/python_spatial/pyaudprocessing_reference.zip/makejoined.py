import os
import glob
import numpy as np
import librosa
import soundfile as sf
import re
from datetime import datetime, timedelta

# --- CONFIGURATION ---
CAM_A_MAP = {
    'enhanced_output0-30tp00006.ogg': '20231010_093912',
    'enhanced_output30-45tp00006.ogg': '20231010_100912',
    'enhanced_output45-1htp00006.ogg': '20231010_102412',
    'enhanced_output1h-01h15tp00006.ogg': '20231010_103912',
    'enhanced_output0m-30mtp0007.ogg': '20231010_111449',
    'enhanced_output30m-1htp0007.ogg': '20231010_114449',
    'enhanced_output1h-1h30mtp0007.ogg': '20231010_121449',
    'enhanced_output1h30m-endtp0007.ogg': '20231010_124449',
    'enhanced_output_0m-30m20231010_125918_tp0008.ogg': '20231010_125918',
    'enhanced_output_30m-1h_20231010_125918_tp0008.ogg': '20231010_132918',
    'enhanced_output_1h-1h30m_20231010_125918_tp0008.ogg': '20231010_135918',
    'enhanced_output_1h30m_end20231010_125918_tp0008.ogg': '20231010_142918',
}

SR = 22050
BLOCK_SIZE_SEC = 10 # Smaller blocks for even lower memory footprint

def load_at_time(target_t, file_list, duration):
    for f in file_list:
        name = os.path.basename(f)
        start_t = None
        if name in CAM_A_MAP:
            start_t = datetime.strptime(CAM_A_MAP[name], '%Y%m%d_%H%M%S')
        else:
            match = re.search(r'(\d{8}_\d{6})', name)
            if match:
                start_t = datetime.strptime(match.group(1), '%Y%m%d_%H%M%S')

        if start_t:
            file_dur = librosa.get_duration(path=f)
            end_t = start_t + timedelta(seconds=file_dur)
            if start_t <= target_t <= end_t:
                offset = (target_t - start_t).total_seconds()
                try:
                    y, _ = librosa.load(f, sr=SR, offset=offset, duration=duration)
                    target_samples = int(duration * SR)
                    if len(y) < target_samples:
                        y = np.pad(y, (0, target_samples - len(y)))
                    return y
                except:
                    return None
    return None

def sync_and_extract_stream():
    print("--- Voices Extraction: Persistent Streaming Mode ---")
    files_a = glob.glob("*tp000*[678].ogg")
    files_b = glob.glob("*tp000*[23][0-9].ogg")

    start_target = datetime.strptime('20231010_101338', '%Y%m%d_%H%M%S')
    end_target = datetime.strptime('20231010_143200', '%Y%m%d_%H%M%S')
    duration_secs = int((end_target - start_target).total_seconds())

    output_file = 'extracted_voices_streaming.wav'

    # Open the file for writing in advance
    with sf.SoundFile(output_file, mode='w', samplerate=SR, channels=2) as out:
        for sec in range(0, duration_secs, BLOCK_SIZE_SEC):
            current_t = start_target + timedelta(seconds=sec)

            y_a = load_at_time(current_t, files_a, BLOCK_SIZE_SEC)
            y_b = load_at_time(current_t, files_b, BLOCK_SIZE_SEC)

            # If audio exists for this block
            if y_a is not None and y_b is not None:
                # STFT Denoising
                stft_a = librosa.stft(y_a)
                stft_b = librosa.stft(y_b)
                mag_a, _ = librosa.magphase(stft_a)
                mag_b, _ = librosa.magphase(stft_b)

                # Spectral Coherence Mask
                # This keeps only what is common to both mics
                mask = np.minimum(mag_a, mag_b) / (np.maximum(mag_a, mag_b) + 1e-6)
                mask = np.power(mask, 1.5) # Tuning factor (1.0-2.0)

                clean_a = librosa.istft(stft_a * mask)
                clean_b = librosa.istft(stft_b * mask)

                # Ensure length consistency for the writer
                min_len = min(len(clean_a), len(clean_b))
                combined = np.vstack((clean_a[:min_len], clean_b[:min_len])).T

                # Write directly to disk
                out.write(combined)
            else:
                # Write silence if one or both cams are missing for this block
                silence = np.zeros((int(BLOCK_SIZE_SEC * SR), 2))
                out.write(silence)

            if sec % 60 == 0:
                print(f"  Processed {sec//60} / {duration_secs//60} minutes...", end='\r')

    print(f"\nExtraction complete. File saved to: {output_file}")

if __name__ == "__main__":
    sync_and_extract_stream()
