import os
import sys
import yaml
import json
import librosa
import numpy as np
import soundfile as sf
import scipy.signal as signal
from datetime import datetime, timedelta

def parse_dt(s):
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M", "%Y-%m-%d"):
        try: return datetime.strptime(s, fmt)
        except: continue
    return None

class AITrialGenerator:
    def __init__(self, yaml_path, json_path):
        self.yaml_path = yaml_path
        self.json_path = json_path

        with open(yaml_path, 'r') as f: self.config = yaml.safe_load(f)
        with open(json_path, 'r') as f: self.strategies = json.load(f)

    def matches_mode(self, path, label, mode):
        """Ensures apples-to-apples comparison by rigorously isolating track types."""
        p = path.lower()
        l = label.lower()
        if mode == "plus20" and ("plus20" in p or "+20db" in l): return True
        if mode == "amp32" and ("amp32" in p or "+32db" in l) and "plus20" not in p and "enhanced" not in p: return True
        if mode == "enhanced" and ("enhanced" in p or "enhanced" in l) and "plus20" not in p: return True
        if mode == "original" and "original" in p: return True
        return False

    def get_overlapping_streams(self, start_dt, end_dt, mode):
        """Finds all matching mode files in the YAML that overlap with the requested trial window."""
        active = []
        for entry in self.config.get('files', []):
            if not self.matches_mode(entry['path'], entry.get('type', ''), mode):
                continue

            f_start = parse_dt(entry['start'])
            if not f_start: continue

            # Assume max 3 hours per file to catch any long-running overlaps
            f_end = f_start + timedelta(hours=3)

            if f_start < end_dt and f_end > start_dt:

                # Determine Camera A vs Camera B
                path_lower = entry['path'].lower()
                lbl_lower = entry.get('type', '').lower()
                if "tp00024" in path_lower or "tp24" in path_lower or "(1)" in path_lower or "fd feed" in lbl_lower or "camb" in lbl_lower:
                    cam_id = 'Cam B'
                else:
                    cam_id = 'Cam A'

                # Probe File Properties
                native_sr = "Unknown"
                channels = "Unknown"
                dur = 0.0
                peak = 0.0
                rms = 0.0

                if os.path.exists(entry['path']):
                    try:
                        # CRITICAL FIX: Use librosa for accurate .ogg durations!
                        dur = librosa.get_duration(path=entry['path'])

                        with sf.SoundFile(entry['path']) as f:
                            native_sr = f.samplerate
                            channels = f.channels

                            # Seek to the middle using the accurate librosa duration
                            f.seek(max(0, int((dur / 2) * native_sr)))
                            y_samp = f.read(int(5 * native_sr), dtype='float32')
                            if len(y_samp) > 0:
                                peak = float(np.max(np.abs(y_samp)))
                                rms = float(np.sqrt(np.mean(y_samp**2)))
                    except Exception as e:
                        pass

                # Get the AI assessment if available
                strat = self.strategies.get(entry['path'], {})
                active.append({
                    'cam_id': cam_id,
                    'path': entry['path'],
                    'start': entry['start'],
                    'type': entry.get('type', 'Unknown'),
                    'assessment': strat.get('explanation', 'No AI assessment available.'),
                    'lp_cut': strat.get('low_pass_cutoff', 8000),
                    'hp_cut': strat.get('high_pass_cutoff', 20),
                    'notches': strat.get('notch_filters', []),
                    'native_sr': native_sr,
                    'channels': channels,
                    'duration': dur,
                    'peak': peak,
                    'rms': rms
                })
        return active

    def fetch_block(self, t_current, block_sec, active_streams, cam_id, sr=22050):
        """Streams a specific time block safely from disk, handling sample rate conversions."""
        frames_to_read = int(block_sec * sr)

        for s in active_streams:
            if s['cam_id'] != cam_id: continue
            st = parse_dt(s['start'])
            if not st: continue

            if st <= t_current < st + timedelta(hours=3):
                offset_sec = (t_current - st).total_seconds()

                try:
                    with sf.SoundFile(s['path']) as f:
                        native_sr = f.samplerate

                        # Calculate exactly where to seek in the native file format
                        native_offset_frames = int(offset_sec * native_sr)
                        native_frames_to_read = int(block_sec * native_sr)

                        f.seek(native_offset_frames)
                        y_native = f.read(native_frames_to_read, dtype='float32')

                        if y_native.ndim > 1: y_native = y_native.mean(axis=1) # force mono

                        # Fixes Chipmunk Effect: Resample to pipeline standard rate
                        if native_sr != sr and len(y_native) > 0:
                            y = librosa.resample(y_native, orig_sr=native_sr, target_sr=sr)
                        else:
                            y = y_native

                        # Ensure output matches expected exact block size
                        if len(y) < frames_to_read:
                            y = np.pad(y, (0, frames_to_read - len(y)))
                        return y[:frames_to_read], s
                except Exception as e:
                    pass # Fall through to silence

        return np.zeros(frames_to_read, dtype=np.float32), None

    def apply_filters(self, data, sr, strat):
        """Applies dynamic AI filters per-block based on strategy JSON."""
        nyq = 0.5 * sr
        hp = strat.get('hp_cut', 20)
        lp = strat.get('lp_cut', 8000)
        notches = strat.get('notches', [])

        data = np.nan_to_num(data)

        if hp and 0 < hp < nyq:
            b, a = signal.butter(4, hp / nyq, btype='high')
            data = signal.lfilter(b, a, data)
        if lp and 0 < lp < nyq:
            b, a = signal.butter(4, lp / nyq, btype='low')
            data = signal.lfilter(b, a, data)
        for freq in notches:
            if 0 < freq < nyq:
                b, a = signal.iirnotch(freq, 30, sr)
                data = signal.lfilter(b, a, data)

        return data

    def generate_mix(self, active_streams, t_start, t_end, out_filename):
        """Built-in DSP Pipeline using robust Overlap-Add (OLA) Chunking."""
        sr = 22050
        block_sec = 8.0
        hop_frac = 0.5
        hop_sec = block_sec * hop_frac

        hop_samples = int(hop_sec * sr)
        block_samples = int(block_sec * sr)
        total_samples = int((t_end - t_start).total_seconds() * sr)

        ola_buf = np.zeros((block_samples * 2, 2), dtype=np.float32)
        win = signal.get_window('hann', block_samples)

        current_t = t_start
        samples_written = 0
        blocks_processed = 0

        print(f"\n>> Executing Built-in Native DSP Pipeline...")

        with sf.SoundFile(out_filename, 'w', samplerate=sr, channels=2, format='OGG') as out_f:
            while current_t < t_end:
                y_a, strat_a = self.fetch_block(current_t, block_sec, active_streams, 'Cam A', sr)
                y_b, strat_b = self.fetch_block(current_t, block_sec, active_streams, 'Cam B', sr)

                # Apply Dynamic Strategy Filters
                if strat_a: y_a = self.apply_filters(y_a, sr, strat_a)
                if strat_b: y_b = self.apply_filters(y_b, sr, strat_b)

                # Cross-Channel Spectral Coherence Masking (if both cams are present)
                if strat_a and strat_b and np.any(y_a) and np.any(y_b):
                    stft_a = librosa.stft(y_a, n_fft=2048, hop_length=512)
                    stft_b = librosa.stft(y_b, n_fft=2048, hop_length=512)

                    mag_a, _ = librosa.magphase(stft_a)
                    mag_b, _ = librosa.magphase(stft_b)

                    # Mask retains only audio common to both feeds
                    mask = np.minimum(mag_a, mag_b) / (np.maximum(mag_a, mag_b) + 1e-6)
                    mask = np.power(mask, 1.5)

                    y_a = librosa.istft(stft_a * mask, hop_length=512, length=block_samples)
                    y_b = librosa.istft(stft_b * mask, hop_length=512, length=block_samples)

                # Apply Overlap-Add Windowing
                ola_buf[:block_samples, 0] += y_a * win
                ola_buf[:block_samples, 1] += y_b * win

                chunk = ola_buf[:hop_samples, :]

                # Trim the final block to exactly match requested duration
                if samples_written + len(chunk) > total_samples:
                    chunk = chunk[:total_samples - samples_written, :]

                # Soft limiter to prevent clipping
                peak = np.max(np.abs(chunk))
                if peak > 0.99: chunk = chunk / (peak + 0.05)

                out_f.write(chunk)
                samples_written += len(chunk)

                # Shift buffer
                ola_buf[:block_samples, :] = ola_buf[hop_samples:hop_samples+block_samples, :]
                ola_buf[block_samples:, :] = 0

                current_t += timedelta(seconds=hop_sec)
                blocks_processed += 1

                if blocks_processed % 5 == 0:
                    pct = min(100.0, 100 * samples_written / total_samples)
                    print(f"  [{pct:5.1f}%] {current_t.strftime('%H:%M:%S')}...", end='\r')

        print(f"\n[+] SUCCESS! Trial audio saved to '{out_filename}'")

    def run(self):
        print(f"=== AI Trial Audio Generator (Native DSP) ===")

        print("\nSelect the audio tier for comparison (ensures apples-to-apples).")
        print("Options: original, amp32, enhanced, plus20")
        mode = input("Tier [plus20]: ").strip().lower() or "plus20"

        print("\nSpecify the timeframe you want to render a trial mix for.")
        t_start_str = input("Start time (YYYY-MM-DD HH:MM:SS): ").strip()
        dur_str = input("Duration in seconds (e.g. 60): ").strip()

        t_start = parse_dt(t_start_str)
        if not t_start:
            print("Invalid start time.")
            return

        try: dur_sec = int(dur_str)
        except: dur_sec = 60
        t_end = t_start + timedelta(seconds=dur_sec)

        active = self.get_overlapping_streams(t_start, t_end, mode)
        if not active:
            print(f"No '{mode}' audio streams overlap with this timeframe.")
            return

        print(f"\nFound {len(active)} overlapping '{mode}' streams in this window.")
        for s in active:
            print(f" - [{s['cam_id']}] {os.path.basename(s['path'])}")
            print(f"       -> SR: {s['native_sr']}Hz | Ch: {s['channels']} | Peak: {s['peak']:.3f} | RMS: {s['rms']:.4f}")

        safe_start = t_start.strftime('%Y%m%d_%H%M%S')
        safe_end = t_end.strftime('%H%M%S')
        base_filename = f"trial_mix_{mode}_{safe_start}_to_{safe_end}"
        audio_filename = f"{base_filename}.ogg"
        log_filename = f"{base_filename}_strategy_log.txt"

        # Write strategy log
        with open(log_filename, 'w') as log_f:
            log_f.write(f"TRIAL AUDIO STRATEGY LOG\n")
            log_f.write(f"========================\n")
            log_f.write(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
            log_f.write(f"Time Window: {t_start_str} to {t_end.strftime('%Y-%m-%d %H:%M:%S')}\n")
            log_f.write(f"Audio Tier: {mode}\n\n")
            log_f.write("OVERLAPPING STREAMS, PROPERTIES & ASSESSMENTS:\n")
            for s in active:
                log_f.write(f"\n[{s['cam_id']}] File: {os.path.basename(s['path'])}\n")
                log_f.write(f"  Start Offset: {s['start']}\n")
                log_f.write(f"  Properties: {s['native_sr']}Hz, {s['channels']}ch, Peak={s['peak']:.3f}, RMS={s['rms']:.4f}\n")
                log_f.write(f"  AI Verdict: {s['assessment']}\n")
                log_f.write(f"  Filter Targets: LP {s['lp_cut']}Hz | HP {s['hp_cut']}Hz | Notches {s['notches']}\n")

        print(f"\n[+] Saved strategy log to: {log_filename}")

        # Execute DSP Generation directly
        self.generate_mix(active, t_start, t_end, audio_filename)

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Generate Trial Audio directly from AI Strategies and Timeline Overlaps.")
    parser.add_argument("--yaml", required=True, help="Project YAML file")
    parser.add_argument("--json", required=True, help="AI Strategies JSON file")
    args = parser.parse_args()

    generator = AITrialGenerator(args.yaml, args.json)
    generator.run()
