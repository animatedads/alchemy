import os
import glob
import yaml
import sqlite3
import asyncio
import subprocess
import hashlib
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
from typing import Optional, Dict, Any, List, Tuple
from contextlib import asynccontextmanager
from fastapi import FastAPI, WebSocket, WebSocketDisconnect, Request, Header, HTTPException
from fastapi.responses import HTMLResponse, StreamingResponse, JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import uvicorn

# ---------------------------------------------------------------------------
# STARTUP DURATION CACHE
# ---------------------------------------------------------------------------
# The UI needs file durations to calculate global timeline bounds. Previously
# /api/project/{id}/config ran ffprobe for every file when the project was
# opened, which made large cases stall. This cache is populated at server
# startup for every media file referenced by every YAML project the server can
# see. Project config loading then becomes a SQLite lookup rather than thousands
# of ffprobe calls.

DURATION_CACHE_DB = os.environ.get("SHUTTLE_DURATION_CACHE", "shuttle_duration_cache.db")
DURATION_PROBE_WORKERS = max(1, int(os.environ.get("SHUTTLE_DURATION_WORKERS", "4")))
DURATION_PROBE_TIMEOUT = float(os.environ.get("SHUTTLE_DURATION_TIMEOUT", "12"))
STREAM_WINDOW_SEC = float(os.environ.get("SHUTTLE_STREAM_WINDOW_SEC", "1800"))
STREAM_READ_CHUNK = int(os.environ.get("SHUTTLE_STREAM_READ_CHUNK", str(32 * 1024)))
MEDIA_EXTENSIONS = {".ogg", ".oga", ".wav", ".flac", ".mp3", ".m4a", ".aac", ".mp4", ".m4v", ".mov", ".mkv", ".webm", ".avi"}

duration_cache_status: Dict[str, Any] = {
    "state": "not_started",
    "started_at": None,
    "finished_at": None,
    "total": 0,
    "cached": 0,
    "probed": 0,
    "failed": 0,
    "missing": 0,
}

def _duration_cache_connect():
    conn = sqlite3.connect(DURATION_CACHE_DB)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS file_durations (
            path TEXT PRIMARY KEY,
            duration REAL NOT NULL DEFAULT 0,
            size INTEGER NOT NULL DEFAULT -1,
            mtime_ns INTEGER NOT NULL DEFAULT -1,
            ok INTEGER NOT NULL DEFAULT 0,
            error TEXT DEFAULT '',
            updated_at REAL NOT NULL
        )
    """)
    conn.execute("CREATE INDEX IF NOT EXISTS idx_file_durations_fingerprint ON file_durations(size, mtime_ns)")
    return conn

def _file_fingerprint(path: str) -> Optional[Tuple[int, int]]:
    try:
        st = os.stat(path)
        return int(st.st_size), int(st.st_mtime_ns)
    except OSError:
        return None

def _duration_from_cache(path: str) -> Optional[float]:
    fp = _file_fingerprint(path)
    if fp is None:
        return None
    size, mtime_ns = fp
    abs_path = os.path.abspath(path)
    try:
        with _duration_cache_connect() as conn:
            row = conn.execute(
                "SELECT duration FROM file_durations WHERE path=? AND size=? AND mtime_ns=? AND ok=1",
                (abs_path, size, mtime_ns),
            ).fetchone()
            if row is not None:
                return float(row[0])
    except sqlite3.Error:
        return None
    return None

def _write_duration_cache(path: str, duration: float, ok: bool, error: str = "") -> None:
    fp = _file_fingerprint(path)
    abs_path = os.path.abspath(path)
    size, mtime_ns = fp if fp is not None else (-1, -1)
    with _duration_cache_connect() as conn:
        conn.execute(
            """
            INSERT INTO file_durations(path, duration, size, mtime_ns, ok, error, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(path) DO UPDATE SET
                duration=excluded.duration,
                size=excluded.size,
                mtime_ns=excluded.mtime_ns,
                ok=excluded.ok,
                error=excluded.error,
                updated_at=excluded.updated_at
            """,
            (abs_path, float(duration or 0), int(size), int(mtime_ns), 1 if ok else 0, str(error or "")[:500], time.time()),
        )

def _probe_duration(path: str) -> Tuple[str, float, bool, str]:
    if not os.path.exists(path):
        return path, 0.0, False, "missing"
    cmd = [
        'ffprobe', '-v', 'error',
        '-show_entries', 'format=duration',
        '-of', 'default=noprint_wrappers=1:nokey=1',
        path,
    ]
    try:
        res = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=DURATION_PROBE_TIMEOUT)
        out = (res.stdout or '').strip()
        if res.returncode != 0:
            return path, 0.0, False, (res.stderr or f"ffprobe exited {res.returncode}").strip()
        duration = float(out) if out else 0.0
        if duration < 0:
            duration = 0.0
        return path, duration, True, ""
    except Exception as e:
        return path, 0.0, False, str(e)

def _iter_project_yaml_files() -> List[str]:
    return sorted(glob.glob("*.yaml"))

def _collect_known_media_files() -> List[str]:
    known: Dict[str, str] = {}
    for yaml_path in _iter_project_yaml_files():
        try:
            with open(yaml_path, 'r') as f:
                config = yaml.safe_load(f) or {}
        except Exception as e:
            print(f"[duration-cache] skipped YAML {yaml_path}: {e}")
            continue
        for entry in config.get('files', []) or []:
            path = entry.get('path') if isinstance(entry, dict) else None
            if not path:
                continue
            ext = os.path.splitext(str(path))[1].lower()
            if ext and ext not in MEDIA_EXTENSIONS:
                continue
            known[os.path.abspath(str(path))] = str(path)
    return sorted(known.keys())

def warm_duration_cache() -> None:
    global duration_cache_status
    paths = _collect_known_media_files()
    duration_cache_status.update({
        "state": "running",
        "started_at": datetime.now().isoformat(timespec="seconds"),
        "finished_at": None,
        "total": len(paths),
        "cached": 0,
        "probed": 0,
        "failed": 0,
        "missing": 0,
    })
    print(f"[duration-cache] preparing durations for {len(paths)} known files using {DURATION_PROBE_WORKERS} workers")

    to_probe = []
    for path in paths:
        if not os.path.exists(path):
            duration_cache_status["missing"] += 1
            _write_duration_cache(path, 0.0, False, "missing")
            continue
        cached = _duration_from_cache(path)
        if cached is not None:
            duration_cache_status["cached"] += 1
        else:
            to_probe.append(path)

    if to_probe:
        with ThreadPoolExecutor(max_workers=DURATION_PROBE_WORKERS) as pool:
            futures = [pool.submit(_probe_duration, path) for path in to_probe]
            for i, future in enumerate(as_completed(futures), start=1):
                path, duration, ok, error = future.result()
                _write_duration_cache(path, duration, ok, error)
                if ok:
                    duration_cache_status["probed"] += 1
                else:
                    duration_cache_status["failed"] += 1
                if i % 100 == 0 or i == len(to_probe):
                    print(f"[duration-cache] probed {i}/{len(to_probe)} pending files")

    duration_cache_status["state"] = "ready"
    duration_cache_status["finished_at"] = datetime.now().isoformat(timespec="seconds")
    print(
        "[duration-cache] ready: "
        f"{duration_cache_status['cached']} cached, "
        f"{duration_cache_status['probed']} probed, "
        f"{duration_cache_status['failed']} failed, "
        f"{duration_cache_status['missing']} missing"
    )

def get_cached_duration(path: str) -> float:
    cached = _duration_from_cache(path)
    if cached is not None:
        return cached
    # Startup should have prepared this. Return quickly rather than blocking
    # project opening with ffprobe. Queueing/warming on next restart will fill it.
    return 0.0

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Run duration preparation before the app accepts requests. That moves the
    # large-project delay from project-open time to server-start time.
    await asyncio.to_thread(warm_duration_cache)
    watcher_task = asyncio.create_task(watch_all_databases())
    try:
        yield
    finally:
        watcher_task.cancel()
        try:
            await watcher_task
        except asyncio.CancelledError:
            pass

app = FastAPI(lifespan=lifespan)
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])

def verify_password(stored_hash_str, password):
    try:
        salt, hash_val = stored_hash_str.split('$')
        return hashlib.sha256((salt + password).encode()).hexdigest() == hash_val
    except: return False

def get_text_column(cursor):
    cursor.execute("PRAGMA table_info(transcript)")
    cols = [info[1] for info in cursor.fetchall()]
    return 'text' if 'text' in cols else 'content'

# --- FRONTEND UI ---
HTML_UI = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Forensic Shuttle</title>
    <style>
        body { font-family: 'Segoe UI', sans-serif; background: #121212; color: #fff; margin: 0; display: flex; flex-direction: column; height: 100dvh; overflow: hidden; }
        header { background: #1e1e1e; padding: 4px 10px; text-align: center; border-bottom: 1px solid #333; position: relative; height: 32px; flex-shrink: 0;}
        header h2 { font-size: 0.9rem; margin: 3px 0; }
        #btn-close-project { position: absolute; top: 4px; right: 8px; background: #444; color: #fff; border: none; padding: 2px 6px; border-radius: 4px; font-size: 0.7rem; }
        .hidden { display: none !important; }

        #workspace { display: flex; flex-direction: column; flex: 1; overflow: hidden; }
        #player-container { padding: 4px 8px; background: #1a1a1a; border-bottom: 1px solid #333; flex-shrink: 0;}

        /* TOP CONTROLS (Zoom & Skips) */
        .top-controls-row { display: flex; justify-content: space-between; align-items: center; margin-bottom: 4px; padding-top: 2px;}
        .zoom-group { display: flex; gap: 4px; align-items: center; background: #222; padding: 2px 4px; border-radius: 4px; border: 1px solid #333;}
        .zoom-btn { background: #333; color: #ffaa00; border: 1px solid #555; padding: 2px 8px; border-radius: 3px; font-weight: bold; font-size: 0.75rem; cursor: pointer;}
        .skip-group { display: flex; gap: 10px;}
        .skip-btn { background: #222; color: #00ffcc; border: 1px solid #444; padding: 2px 10px; border-radius: 4px; font-weight: bold; font-family: monospace; font-size: 0.8rem; }

        /* TIMELINE CONTAINER */
        #timeline-container { display: flex; align-items: center; gap: 6px; margin-bottom: 4px;}
        .time-label { color: #00ffcc; font-family: monospace; font-size: 0.6rem; min-width: 65px; line-height: 1.1; text-align: center; }

        #scrubber-container { flex: 1; position: relative; display: flex; align-items: center; background: #333; border-radius: 4px; height: 10px; }
        #global-scrubber { width: 100%; cursor: pointer; height: 100%; appearance: none; background: transparent; position: relative; z-index: 5; margin: 0; outline: none; }
        #global-scrubber::-webkit-slider-thumb { appearance: none; width: 16px; height: 16px; border-radius: 50%; background: #00ffcc; border: 2px solid #121212; }
        #loop-highlight { position: absolute; height: 100%; top: 0; background: rgba(255, 170, 0, 0.6); pointer-events: none; z-index: 3; border-radius: 4px; }

        audio { width: 100%; height: 28px; margin-bottom: 4px; }

        .controls { display: flex; justify-content: center; gap: 3px; flex-wrap: wrap; margin-bottom: 4px;}
        .controls button { background: #333; color: #eee; border: 1px solid #444; padding: 4px 6px; border-radius: 3px; font-size: 0.65rem;}

        .filter-group { display: flex; justify-content: center; gap: 8px; margin-bottom: 4px; }
        .toggle-btn { background: #222; color: #666; border: 1px solid #333; padding: 2px 10px; border-radius: 10px; font-weight: bold; font-size: 0.6rem; transition: 0.2s;}
        .toggle-btn.on { background: #27ae60; color: #fff; border-color: #2ecc71; }
        .toggle-btn.speech-on { background: #8e44ad; color: #fff; border-color: #9b59b6; }

        .status-bar { display: flex; justify-content: space-around; font-size: 0.6rem; color: #555; background: #000; padding: 1px; }

        #transcript-container { flex: 1; overflow-y: auto; padding: 6px; background: #121212; scroll-behavior: smooth; }
        .line { padding: 4px; border-bottom: 1px solid #1a1a1a; border-left: 3px solid transparent; display: flex; gap: 6px; align-items: flex-start; cursor: pointer; font-size: 0.8rem;}
        .line.active-line { background: #1a2a3a; border-left-color: #00ffcc; }
        .ts { color: #00ffcc; font-family: monospace; min-width: 90px; font-size: 0.65rem; padding-top: 2px;}
        .source-badge { background: #0078D7; color: white; font-size: 0.5rem; padding: 1px 3px; border-radius: 8px; font-weight: bold; margin-top: 2px; }
        .text { flex: 1; line-height: 1.2; word-break: break-word; }
        .marker-text { color: #ff3333; font-weight: 900; background: rgba(255, 0, 0, 0.1); padding: 0 3px; border-radius: 2px; }

        #input-container { padding: 6px; background: #1a1a1a; border-top: 1px solid #333; display: flex; gap: 5px; flex-shrink: 0;}
        #transcript-input { flex: 1; padding: 6px; background: #000; color: #fff; border: 1px solid #333; border-radius: 4px; font-size: 0.8rem; }
        #submit-btn { padding: 5px 10px; background: #0078D7; color: #fff; border: none; border-radius: 4px; font-weight: bold; font-size: 0.75rem;}

        #lobby, #login-view { padding: 20px; text-align: center; }
        .project-btn { background: #0078D7; color: white; border: none; padding: 12px; margin: 8px auto; border-radius: 5px; width: 100%; max-width: 280px;}
    </style>
</head>
<body>
    <header>
        <div id="user-badge" class="hidden"></div>
        <button id="btn-close-project" class="hidden">Exit</button>
        <h2 id="app-title">Forensic Shuttle</h2>
    </header>

    <div id="lobby"><h3>Case Selection</h3><div id="project-list"></div></div>

    <div id="login-view" class="hidden">
        <h3 id="login-title"></h3>
        <input type="text" id="login-user" placeholder="Analyst" style="padding:10px; margin-bottom:10px; width:70%"><br>
        <input type="password" id="login-pass" placeholder="Pass" style="padding:10px; margin-bottom:10px; width:70%"><br>
        <button id="btn-login" style="padding:10px 20px; background:#00ffcc; color:black; font-weight:bold; border:none; border-radius:4px;">LOGIN</button>
    </div>

    <div id="workspace" class="hidden">
        <div id="player-container">
            <div class="top-controls-row">
                <div class="zoom-group">
                    <button id="btn-zoom-out" class="zoom-btn">-</button>
                    <span id="zoom-level-display" style="color:#aaa; font-size:0.6rem; min-width:28px; text-align:center;">FULL</span>
                    <button id="btn-zoom-in" class="zoom-btn">+</button>
                </div>
                <div class="skip-group">
                    <button id="btn-skip-m30" class="skip-btn">&lt;&lt;</button>
                    <button id="btn-skip-m5" class="skip-btn">&lt;</button>
                    <button id="btn-skip-p5" class="skip-btn">&gt;</button>
                    <button id="btn-skip-p30" class="skip-btn">&gt;&gt;</button>
                </div>
            </div>
            <div id="timeline-container">
                <span id="global-time-display" class="time-label">--</span>
                <div id="scrubber-container">
                    <input type="range" id="global-scrubber" value="0">
                    <div id="loop-highlight" class="hidden"></div>
                </div>
                <span id="global-end-display" class="time-label">--</span>
            </div>
            <audio id="media-player" controls crossorigin="anonymous"></audio>
            <div class="controls">
                <button id="btn-drop-marker" style="background:#e63946;">Marker</button>
                <button id="btn-switch-source">Source</button>
                <button id="btn-loop-start">Start</button>
                <button id="btn-loop-end">End</button>
                <button id="btn-loop-catch" style="background:#ffaa00; color:black;">Catch</button>
                <button id="btn-loop-clear">Clear</button>
            </div>
            <div class="filter-group">
                <button id="btn-toggle-damp" class="toggle-btn">Damp</button>
                <button id="btn-toggle-speech" class="toggle-btn">Speech</button>
                <button id="btn-toggle-boost" class="toggle-btn">Boost</button>
            </div>
            <div class="status-bar">
                <div id="source-name-display">--</div>
                <div id="loop-status-display">Loop: OFF</div>
            </div>
        </div>
        <div id="transcript-container"></div>
        <div id="input-container">
            <input type="text" id="transcript-input" placeholder="Transcript..." autocomplete="off">
            <button id="submit-btn">Save</button>
            <button id="cancel-btn" class="hidden" style="background:#444; color:#fff; border:none; padding:5px; border-radius:4px;">X</button>
        </div>
    </div>

    <script>
        let sessionUser, sessionPerm, currentProject, projectFiles = [], macros = {};
        let activeFileIdx = 0, globalTimeMs = 0, projectStartMs = 0, projectEndMs = 0;
        let isDampOn = false, isBoostOn = false, isSpeechOn = false, isSwitchingSource = false;
        let loopStartMs = null, loopEndMs = null, editingTs = null, ws = null;
        let transcriptLinesData = [];

        // ZOOM STATE VARIABLES
        const ZOOM_LEVELS = [null, 24*60*60*1000, 60*60*1000, 5*60*1000]; // null=FULL, 24h, 1h, 5m
        const ZOOM_NAMES = ["FULL", "24H", "1H", "5M"];
        let currentZoomIdx = 0;
        let viewStartMs = 0;
        let viewEndMs = 0;

        const player = document.getElementById('media-player');
        const scrubber = document.getElementById('global-scrubber');
        const loopHighlight = document.getElementById('loop-highlight');
        const transcriptContainer = document.getElementById('transcript-container');
        const inputField = document.getElementById('transcript-input');
        const submitBtn = document.getElementById('submit-btn');
        const cancelBtn = document.getElementById('cancel-btn');

        ['wheel', 'touchstart', 'mousedown'].forEach(evt => {
            transcriptContainer.addEventListener(evt, () => {
                window.isUserScrollingTranscript = true;
                clearTimeout(window.scrollTimeout);
                window.scrollTimeout = setTimeout(() => window.isUserScrollingTranscript = false, 4000);
            }, {passive: true});
        });

        function getActiveFile() { return projectFiles.find(f => f.original_idx === activeFileIdx); }

        function applyZoomWindow(forceRecenter = false) {
            const windowSize = ZOOM_LEVELS[currentZoomIdx];

            if (!windowSize) {
                viewStartMs = projectStartMs;
                viewEndMs = projectEndMs;
            } else {
                if (forceRecenter || globalTimeMs < viewStartMs || globalTimeMs > viewEndMs) {
                    viewStartMs = globalTimeMs - (windowSize / 2);
                    viewEndMs = globalTimeMs + (windowSize / 2);
                }
            }

            // Clamp to absolute bounds
            if (viewStartMs < projectStartMs) {
                viewStartMs = projectStartMs;
                viewEndMs = Math.min(projectEndMs, viewStartMs + (windowSize || projectEndMs));
            }
            if (viewEndMs > projectEndMs) {
                viewEndMs = projectEndMs;
                viewStartMs = Math.max(projectStartMs, viewEndMs - (windowSize || projectEndMs));
            }

            scrubber.max = viewEndMs - viewStartMs;
            scrubber.value = globalTimeMs - viewStartMs;

            document.getElementById('global-time-display').innerHTML = formatDisplayTime(globalTimeMs); // Left label shows exact playhead
            document.getElementById('global-end-display').innerHTML = formatDisplayTime(viewEndMs);   // Right label shows right-edge of view

            updateLoopUI();
        }

        document.getElementById('btn-zoom-in').onclick = () => {
            if (currentZoomIdx < ZOOM_LEVELS.length - 1) {
                currentZoomIdx++;
                document.getElementById('zoom-level-display').innerText = ZOOM_NAMES[currentZoomIdx];
                applyZoomWindow(true);
            }
        };

        document.getElementById('btn-zoom-out').onclick = () => {
            if (currentZoomIdx > 0) {
                currentZoomIdx--;
                document.getElementById('zoom-level-display').innerText = ZOOM_NAMES[currentZoomIdx];
                applyZoomWindow(true);
            }
        };

        function updateLoopUI() {
            if (loopStartMs !== null && loopEndMs !== null && loopEndMs > loopStartMs) {
                const totalDur = viewEndMs - viewStartMs;
                let start = Math.max(viewStartMs, loopStartMs);
                let end = Math.min(viewEndMs, loopEndMs);

                if (start > viewEndMs || end < viewStartMs) {
                    // Loop is active but outside of the zoomed view window
                    loopHighlight.classList.add('hidden');
                } else {
                    const leftPct = ((start - viewStartMs) / totalDur) * 100;
                    const widthPct = ((end - start) / totalDur) * 100;
                    loopHighlight.style.left = leftPct + "%";
                    loopHighlight.style.width = widthPct + "%";
                    loopHighlight.classList.remove('hidden');
                }
                document.getElementById('loop-status-display').innerText = "Looping...";
            } else {
                loopHighlight.classList.add('hidden');
                document.getElementById('loop-status-display').innerText = "Loop: OFF";
            }
        }

        function reloadVirtualStream() {
            const file = getActiveFile();
            if (!file) return;
            const safeOffsetSec = Math.max(0, (globalTimeMs - file.start_ms) / 1000);
            isSwitchingSource = true;
            document.getElementById('source-name-display').innerText = file.path.split(/[\\\\/]/).pop();
            const url = new URL(`/stream/${currentProject}`, window.location.origin);
            url.searchParams.set('source_idx', activeFileIdx);
            url.searchParams.set('t', safeOffsetSec.toFixed(3));
            if (isDampOn) url.searchParams.set('damp', 'true');
            if (isBoostOn) url.searchParams.set('boost', 'true');
            if (isSpeechOn) url.searchParams.set('speech', 'true');
            url.searchParams.set('cb', Date.now());
            const wasPlaying = !player.paused;
            player.src = url.toString();
            player.onloadedmetadata = () => { isSwitchingSource = false; if (wasPlaying) player.play(); };
        }

        player.ontimeupdate = () => {
            if (isSwitchingSource) return;
            const file = getActiveFile();
            if (!file) return;
            const urlParams = new URLSearchParams(player.src.split('?')[1]);
            const startOffsetSec = parseFloat(urlParams.get('t') || 0);
            globalTimeMs = file.start_ms + (startOffsetSec * 1000) + (player.currentTime * 1000);

            // Check if playhead exited zoom window
            if (globalTimeMs < viewStartMs || globalTimeMs > viewEndMs) {
                applyZoomWindow(true);
            } else {
                // Regular UI update without full recentering
                document.getElementById('global-time-display').innerHTML = formatDisplayTime(globalTimeMs);
                scrubber.value = globalTimeMs - viewStartMs;
            }

            if (loopStartMs && loopEndMs && globalTimeMs >= loopEndMs) seekGlobal(loopStartMs);

            let activeId = null;
            for (let i = transcriptLinesData.length - 1; i >= 0; i--) {
                if (globalTimeMs >= transcriptLinesData[i].ms) { activeId = transcriptLinesData[i].id; break; }
            }
            if (activeId && window.lastActiveLineId !== activeId) {
                if (window.lastActiveLineId) {
                    const old = document.getElementById(window.lastActiveLineId);
                    if (old) old.classList.remove('active-line');
                }
                const el = document.getElementById(activeId);
                if (el) {
                    el.classList.add('active-line');
                    if (!window.isUserScrollingTranscript) el.scrollIntoView({ behavior: 'smooth', block: 'center' });
                }
                window.lastActiveLineId = activeId;
            }
        };

        player.onended = () => {
            if (isSwitchingSource) return;
            const file = getActiveFile();
            if (!file) return;

            // Continue automatically when the backend's bounded MP3 window ends.
            // The current globalTimeMs has been updated by ontimeupdate; step
            // slightly forward so reloadVirtualStream requests the next window.
            const nextMs = Math.min(projectEndMs, globalTimeMs + 250);
            if (nextMs < projectEndMs) {
                seekGlobal(nextMs);
                setTimeout(() => {
                    if (player.paused) player.play().catch(() => {});
                }, 50);
            }
        };

        function seekGlobal(targetMs) {
            targetMs = Math.max(projectStartMs, Math.min(projectEndMs, targetMs));
            const activeFile = getActiveFile();
            if (!activeFile || targetMs < activeFile.start_ms || targetMs >= activeFile.end_ms) {
                const valid = projectFiles.filter(f => targetMs >= f.start_ms && targetMs < f.end_ms);
                if (valid.length > 0) activeFileIdx = valid[0].original_idx;
                else {
                    const future = projectFiles.filter(f => f.start_ms >= targetMs).sort((a,b) => a.start_ms - b.start_ms);
                    if (future.length > 0) { activeFileIdx = future[0].original_idx; targetMs = future[0].start_ms; }
                }
            }
            globalTimeMs = targetMs;

            // Force window check upon seeking
            if (globalTimeMs < viewStartMs || globalTimeMs > viewEndMs) {
                applyZoomWindow(true);
            }

            reloadVirtualStream();
        }

        scrubber.onchange = () => seekGlobal(viewStartMs + parseInt(scrubber.value));
        document.getElementById('btn-skip-m30').onclick = () => seekGlobal(globalTimeMs - 30000);
        document.getElementById('btn-skip-m5').onclick = () => seekGlobal(globalTimeMs - 5000);
        document.getElementById('btn-skip-p5').onclick = () => seekGlobal(globalTimeMs + 5000);
        document.getElementById('btn-skip-p30').onclick = () => seekGlobal(globalTimeMs + 30000);

        document.getElementById('btn-switch-source').onclick = () => {
            const overlaps = projectFiles.filter(f => globalTimeMs >= f.start_ms && globalTimeMs <= f.end_ms);
            if (overlaps.length > 1) {
                const curIdx = overlaps.findIndex(f => f.original_idx === activeFileIdx);
                activeFileIdx = overlaps[(curIdx + 1) % overlaps.length].original_idx;
                reloadVirtualStream();
            }
        };

        document.getElementById('btn-toggle-damp').onclick = (e) => { isDampOn = !isDampOn; e.target.classList.toggle('on', isDampOn); reloadVirtualStream(); };
        document.getElementById('btn-toggle-speech').onclick = (e) => { isSpeechOn = !isSpeechOn; e.target.classList.toggle('speech-on', isSpeechOn); reloadVirtualStream(); };
        document.getElementById('btn-toggle-boost').onclick = (e) => { isBoostOn = !isBoostOn; e.target.classList.toggle('on', isBoostOn); reloadVirtualStream(); };

        document.getElementById('btn-loop-start').onclick = () => { loopStartMs = globalTimeMs; updateLoopUI(); };
        document.getElementById('btn-loop-end').onclick = () => { loopEndMs = globalTimeMs; updateLoopUI(); };
        document.getElementById('btn-loop-clear').onclick = () => { loopStartMs = null; loopEndMs = null; updateLoopUI(); };
        document.getElementById('btn-loop-catch').onclick = () => {
            if (!loopEndMs) loopEndMs = globalTimeMs;
            loopStartMs = loopStartMs ? loopStartMs - 5000 : globalTimeMs - 15000;
            updateLoopUI(); seekGlobal(loopStartMs);
        };

        function appendLine(line) {
            const div = document.createElement('div');
            div.className = 'line';
            div.id = 'line-' + line.ts;
            let badge = '';
            if (line.source && line.source !== 'Unknown') {
                const fMatch = projectFiles.find(f => f.path.includes(line.source) || line.source.includes(f.path.split(/[\\\\/]/).pop()));
                badge = `<span class=\"source-badge\" onclick=\"alert('${line.source}'); event.stopPropagation();\">S${fMatch ? fMatch.original_idx + 1 : '?'}</span>`;
            }
            const txtClass = line.text.includes("*** MARKER ***") ? "text marker-text" : "text";
            div.innerHTML = `<span class=\"ts\">[${line.ts}]</span>${badge}<span class=\"${txtClass}\">${line.text}</span>`;
            div.onclick = () => {
                seekGlobal(parseCompactTsToMs(line.ts));
                if (sessionPerm === 'EDIT') {
                    inputField.value = line.text.replace("*** MARKER ***", "").replace(/^\\s*\\|\\s*/, "").trim();
                    editingTs = line.ts; submitBtn.innerText = "Update"; cancelBtn.classList.remove('hidden'); inputField.focus();
                }
            };
            transcriptContainer.appendChild(div);
        }

        async function saveLine() {
            const text = inputField.value.trim();
            if (!text || sessionPerm !== 'EDIT') return;
            const file = getActiveFile();
            const payload = { text, ts: editingTs || msToCompactTs(globalTimeMs), source_file: file ? file.path.split(/[\\\\/]/).pop() : "Unknown", old_ts: editingTs, username: sessionUser };
            await fetch(`/api/transcript/${currentProject}`, { method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(payload) });
            cancelEdit();
        }

        function cancelEdit() { editingTs = null; inputField.value = ""; submitBtn.innerText = "Save"; cancelBtn.classList.add('hidden'); }
        submitBtn.onclick = saveLine;
        cancelBtn.onclick = cancelEdit;

        document.getElementById('btn-drop-marker').onclick = async () => {
            if (sessionPerm !== 'EDIT') return;
            const file = getActiveFile();
            const payload = { text: "*** MARKER ***", ts: msToCompactTs(globalTimeMs), source_file: file ? file.path.split(/[\\\\/]/).pop() : "Unknown", username: sessionUser };
            await fetch(`/api/transcript/${currentProject}`, { method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(payload) });
        };

        function formatDisplayTime(ms) {
            const d = new Date(ms);
            const dateStr = d.getFullYear() + "-" + (d.getMonth()+1).toString().padStart(2,'0') + "-" + d.getDate().toString().padStart(2,'0');
            const timeStr = d.getHours().toString().padStart(2,'0') + ":" + d.getMinutes().toString().padStart(2,'0') + ":" + d.getSeconds().toString().padStart(2,'0');
            return dateStr + "<br>" + timeStr;
        }
        function parseLocalToMs(ds) { const [d, t] = ds.split(' '); const [y, m, da] = d.split('-'); const [h, mi, s] = t.split(':'); return new Date(y, m-1, da, h, mi, s).getTime(); }
        function msToCompactTs(ms) { const d = new Date(ms); return d.getFullYear().toString() + (d.getMonth()+1).toString().padStart(2,'0') + d.getDate().toString().padStart(2,'0') + d.getHours().toString().padStart(2,'0') + d.getMinutes().toString().padStart(2,'0') + d.getSeconds().toString().padStart(2,'0'); }
        function parseCompactTsToMs(ts) {
            if(ts.includes('-')) return parseLocalToMs(ts);
            const y = ts.slice(0,4), m = ts.slice(4,6)-1, d = ts.slice(6,8), h = ts.slice(8,10), mi = ts.slice(10,12), s = ts.slice(12,14);
            return new Date(y, m, d, h, mi, s).getTime();
        }

        document.getElementById('btn-close-project').onclick = () => location.reload();
        fetch('/api/projects').then(r => r.json()).then(data => {
            data.projects.forEach(p => {
                const b = document.createElement('button'); b.className='project-btn'; b.innerText=p.id;
                b.onclick = () => { currentProject=p.id; document.getElementById('lobby').classList.add('hidden'); document.getElementById('login-view').classList.remove('hidden'); document.getElementById('login-title').innerText=p.id; };
                document.getElementById('project-list').appendChild(b);
            });
        });

        document.getElementById('btn-login').onclick = async () => {
            const u = document.getElementById('login-user').value.trim();
            const p = document.getElementById('login-pass').value.trim();
            const res = await fetch(`/api/project/${currentProject}/login`, {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({username:u, password:p})});
            if(res.ok) { const data = await res.json(); sessionUser = data.username; sessionPerm = data.perm; loadCase(); }
        };

        async function loadCase() {
            document.getElementById('workspace').classList.remove('hidden');
            document.getElementById('login-view').classList.add('hidden');
            document.getElementById('btn-close-project').classList.remove('hidden');
            document.getElementById('user-badge').innerText = sessionUser;

            if (sessionPerm !== 'EDIT') {
                document.getElementById('btn-drop-marker').classList.add('hidden');
                document.getElementById('input-container').classList.add('hidden');
            }

            const conf = await (await fetch(`/api/project/${currentProject}/config`)).json();
            macros = conf.macros;
            projectFiles = conf.files.map((f, i) => { const s = parseLocalToMs(f.start); return {...f, original_idx: i, start_ms: s, end_ms: s + (f.duration*1000)}; });
            projectStartMs = Math.min(...projectFiles.map(f => f.start_ms));
            projectEndMs = Math.max(...projectFiles.map(f => f.end_ms));

            // Initialize Zoom Window
            currentZoomIdx = 0;
            globalTimeMs = projectStartMs;
            applyZoomWindow(true);

            reloadVirtualStream();
            connectWS(currentProject);
        }

        function connectWS(pid) {
            ws = new WebSocket(`${location.protocol==='https:'?'wss:':'ws:'}//${location.host}/ws/${pid}`);
            ws.onmessage = (e) => {
                const d = JSON.parse(e.data);
                if(d.type === "full_sync") {
                    transcriptContainer.innerHTML = ""; transcriptLinesData = [];
                    d.lines.forEach(l => { appendLine(l); transcriptLinesData.push({id: 'line-'+l.ts, ms: parseCompactTsToMs(l.ts)}); });
                }
            };
        }
    </script>
</body>
</html>
"""

# --- BACKEND API ---

class LoginPayload(BaseModel):
    username: str
    password: str

class TranscriptPayload(BaseModel):
    text: str
    ts: str
    source_file: str
    username: str
    old_ts: Optional[str] = None

@app.get("/", response_class=HTMLResponse)
async def get_ui(): return HTML_UI

@app.get("/api/projects")
async def list_projects():
    return {"projects": [{"id": os.path.splitext(f)[0]} for f in glob.glob("*.yaml")]}

@app.post("/api/project/{project_id}/login")
async def project_login(project_id: str, payload: LoginPayload):
    with open(f"{project_id}.yaml", 'r') as f: config = yaml.safe_load(f)
    user = config.get('users', {}).get(payload.username)
    if user and verify_password(user.get('hash', ''), payload.password):
        return {"success": True, "username": payload.username, "perm": user.get('perm', 'EDIT')}
    raise HTTPException(status_code=401)

@app.get("/api/project/{project_id}/config")
async def get_project_config(project_id: str):
    with open(f"{project_id}.yaml", 'r') as f: config = yaml.safe_load(f)
    files = []
    for entry in config.get('files', []):
        path = entry.get('path')
        if path and os.path.exists(path):
            # Do not ffprobe here. Durations are prepared at startup and read
            # from the cache so large projects open immediately.
            item = dict(entry)
            item['duration'] = get_cached_duration(path)
            files.append(item)
    return {"files": files, "macros": config.get('macros', {}), "duration_cache": duration_cache_status}

@app.get("/api/duration-cache/status")
async def get_duration_cache_status():
    return duration_cache_status

@app.get("/stream/{project_id}")
async def stream_media(
    project_id: str,
    source_idx: int = 0,
    t: float = 0,
    damp: bool = False,
    boost: bool = False,
    speech: bool = False,
    window: Optional[float] = None,
):
    """
    Browser-friendly filtered audio streaming.

    The old endpoint piped an open-ended ffmpeg MP3 stream. Some browsers close
    chunked media pipes early because there is no finite media duration/range
    contract, which looks like "the OGG only plays for ~2 seconds".

    This endpoint serves a bounded MP3 window from the requested offset. The
    frontend automatically requests the next window when the player reaches
    the end, so long OGG files continue to play without forcing project-open
    ffprobe delays.
    """
    with open(f"{project_id}.yaml", 'r') as f:
        config = yaml.safe_load(f)

    v_files = [f for f in config.get('files', []) if os.path.exists(f.get('path', ''))]
    if source_idx < 0 or source_idx >= len(v_files):
        raise HTTPException(status_code=404)

    path = v_files[source_idx]['path']
    safe_t = max(0.0, float(t or 0.0))

    duration = get_cached_duration(path)
    remaining = max(0.0, duration - safe_t) if duration and duration > 0 else 0.0
    requested_window = float(window or STREAM_WINDOW_SEC)
    requested_window = max(1.0, min(requested_window, STREAM_WINDOW_SEC))

    if remaining > 0:
        stream_window = min(requested_window, remaining)
        if stream_window <= 0.05:
            raise HTTPException(status_code=416, detail="Requested offset is beyond end of media")
    else:
        # If duration is unknown, still avoid an unbounded pipe. This keeps the
        # browser happy and the frontend will request the next window.
        stream_window = requested_window

    filters = []
    if speech:
        filters.append("afftdn=nf=-25,highpass=f=200,lowpass=f=3000")
    if boost:
        filters.append("volume=3.5")
    if damp:
        filters.append("acompressor=threshold=-12dB:ratio=10:attack=1:release=50:makeup=2")

    cmd = [
        'ffmpeg',
        '-nostdin',
        '-hide_banner',
        '-loglevel', 'error',
        '-ss', f"{safe_t:.3f}",
        '-i', path,
        '-vn', '-sn', '-dn',
        '-map', '0:a:0?',
    ]

    if filters:
        cmd.extend(['-af', ",".join(filters)])

    cmd.extend([
        '-t', f"{stream_window:.3f}",
        '-ar', '44100',
        '-ac', '2',
        '-f', 'mp3',
        '-codec:a', 'libmp3lame',
        '-b:a', '128k',
        '-write_xing', '0',
        '-'
    ])

    p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

    def it():
        try:
            while True:
                c = p.stdout.read(STREAM_READ_CHUNK)
                if not c:
                    break
                yield c
        finally:
            if p.poll() is None:
                p.kill()
            try:
                p.wait(timeout=1)
            except Exception:
                pass

    headers = {
        "Cache-Control": "no-store, no-cache, must-revalidate, max-age=0",
        "Pragma": "no-cache",
        "Accept-Ranges": "none",
        "X-Stream-Start": f"{safe_t:.3f}",
        "X-Stream-Window": f"{stream_window:.3f}",
        "X-Source-Path": os.path.basename(path),
    }
    return StreamingResponse(it(), media_type="audio/mpeg", headers=headers)


@app.post("/api/transcript/{project_id}")
async def save_transcript_line(project_id: str, payload: TranscriptPayload):
    db = f"{project_id}_audit.db"
    with sqlite3.connect(db) as conn:
        c = conn.cursor()
        c.execute("CREATE TABLE IF NOT EXISTS transcript (ts TEXT PRIMARY KEY, text TEXT)")
        c.execute("PRAGMA table_info(transcript)")
        if 'source' not in [i[1] for i in c.fetchall()]: c.execute("ALTER TABLE transcript ADD COLUMN source TEXT DEFAULT 'Unknown'")
        col = get_text_column(c)
        if payload.old_ts:
            c.execute(f"UPDATE transcript SET ts=?, {col}=?, source=? WHERE ts=?", (payload.ts, payload.text, payload.source_file, payload.old_ts))
        else:
            c.execute(f"SELECT {col} FROM transcript WHERE ts=?", (payload.ts,))
            ex = c.fetchone()
            if ex: c.execute(f"UPDATE transcript SET {col}=?, source=? WHERE ts=?", (ex[0]+" | "+payload.text, payload.source_file, payload.ts))
            else: c.execute(f"INSERT INTO transcript (ts, {col}, source) VALUES (?,?,?)", (payload.ts, payload.text, payload.source_file))
        conn.commit()
    await manager.broadcast_to_room(project_id, {"type": "full_sync", "lines": get_current_transcript(project_id)})
    return {"status": "success"}

class ConnectionManager:
    def __init__(self): self.rooms = {}
    async def connect(self, ws, pid): await ws.accept(); self.rooms.setdefault(pid, []).append(ws)
    def disconnect(self, ws, pid): self.rooms[pid].remove(ws)
    async def broadcast_to_room(self, pid, msg):
        for ws in self.rooms.get(pid, []):
            try: await ws.send_json(msg)
            except: pass

manager = ConnectionManager()

def get_current_transcript(pid):
    db = f"{pid}_audit.db"
    lines = []
    if os.path.exists(db):
        with sqlite3.connect(db) as conn:
            c = conn.cursor()
            c.execute("CREATE TABLE IF NOT EXISTS transcript (ts TEXT PRIMARY KEY, text TEXT)")
            c.execute("PRAGMA table_info(transcript)")
            if 'source' not in [i[1] for i in c.fetchall()]: c.execute("ALTER TABLE transcript ADD COLUMN source TEXT DEFAULT 'Unknown'")
            col = get_text_column(c)
            c.execute(f"SELECT ts, {col}, source FROM transcript ORDER BY ts ASC")
            for r in c.fetchall(): lines.append({"ts": r[0], "text": r[1], "source": r[2]})
    return lines

@app.websocket("/ws/{pid}")
async def websocket_endpoint(ws: WebSocket, pid: str):
    await manager.connect(ws, pid)
    await ws.send_json({"type": "full_sync", "lines": get_current_transcript(pid)})
    try:
        while True: await ws.receive_text()
    except WebSocketDisconnect: manager.disconnect(ws, pid)

async def watch_all_databases():
    last_mtimes = {}
    while True:
        for db_file in glob.glob("*_audit.db"):
            pid = db_file.replace("_audit.db", "")
            mtime = os.path.getmtime(db_file)
            if mtime > last_mtimes.get(db_file, 0):
                last_mtimes[db_file] = mtime
                await manager.broadcast_to_room(pid, {"type": "full_sync", "lines": get_current_transcript(pid)})
        await asyncio.sleep(1)

if __name__ == "__main__":
    uvicorn.run("server:app", host="0.0.0.0", port=8080, ssl_keyfile="key.pem", ssl_certfile="cert.pem")
