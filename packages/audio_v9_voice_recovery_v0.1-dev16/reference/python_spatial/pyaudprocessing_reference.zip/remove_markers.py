import sys
import os
import yaml
import sqlite3

def get_text_column(cursor):
    cursor.execute("PRAGMA table_info(transcript)")
    cols = [info[1] for info in cursor.fetchall()]
    return 'content' if 'content' in cols else 'text'

def clean_erroneous_markers(yaml_path):
    if not os.path.exists(yaml_path):
        print(f"Error: YAML file '{yaml_path}' not found.")
        return

    # 1. Identify Database
    project_name = os.path.splitext(os.path.basename(yaml_path))[0]
    db_path = f"{project_name}_audit.db"

    if not os.path.exists(db_path):
        print(f"Error: Database '{db_path}' not found.")
        return

    # Range based on your specific erroneous run
    start_ts = "20231010093912"
    end_ts = "20231010165352"

    print(f"Cleaning erroneous markers in {db_path}...")

    with sqlite3.connect(db_path) as conn:
        c = conn.cursor()
        text_col = get_text_column(c)

        # We fetch potential markers to check their alignment in Python for precision
        c.execute(f"SELECT ts, {text_col} FROM transcript WHERE ts BETWEEN ? AND ?", (start_ts, end_ts))
        rows = c.fetchall()

        to_delete = []
        for ts, text in rows:
            # Check if it looks like a marker: -- YYYY-MM-DD HH:MM:SS --
            if str(text).startswith("-- ") and str(text).endswith(" --"):
                # Check if it is NOT aligned to the 15-minute clock grid
                # Aligned markers end in 0000, 1500, 3000, or 4500
                minute_sec = ts[-4:]
                if minute_sec not in ["0000", "1500", "3000", "4500"]:
                    to_delete.append(ts)

        if not to_delete:
            print("No erroneous markers found in that range.")
            return

        print(f"Found {len(to_delete)} unaligned markers. Deleting...")

        # Delete from transcript
        c.executemany("DELETE FROM transcript WHERE ts = ?", [(ts,) for ts in to_delete])

        # Delete from audit_log to maintain forensic cleanliness
        c.executemany("DELETE FROM audit_log WHERE line_ts = ? AND user = 'TIMELINE_GEN'", [(ts,) for ts in to_delete])

        conn.commit()
        print("Cleanup complete.")

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python remove_bad_markers.py <project.yaml>")
    else:
        clean_erroneous_markers(sys.argv[1])
