import os
import re
import yaml
import subprocess
import sys
from datetime import datetime

# Import your existing streaming enhancement logic
try:
    from testaudiostream import enhance_large_audio
except ImportError:
    print("Error: testaudiostream.py must be in the same directory.")
    sys.exit(1)

# Configuration
INPUT_DIR = "fcpaphos"
FILELIST = "filelist.txt"
OUTPUT_YAML = "fcpaphos_project.yaml"

# Timestamp Regex: matches YYYYMMDD_HHMMSS
TS_REGEX = re.compile(r'(\d{4})(\d{2})(\d{2})_(\d{2})(\d{2})(\d{2})')

def get_timestamp(filename):
    match = TS_REGEX.search(filename)
    if match:
        y, m, d, hh, mm, ss = match.groups()
        return f"{y}-{m}-{d} {hh}:{mm}:{ss}"
    return "UNKNOWN_TIME"

def process_paphos_files():
    print(f"--- Diagnostic Startup ---")

    if not os.path.exists(FILELIST):
        print(f"CRITICAL ERROR: {FILELIST} not found in the current folder.")
        return

    if not os.path.exists(INPUT_DIR):
        print(f"CRITICAL ERROR: Folder '{INPUT_DIR}' not found. Ensure your audio files are in a folder named '{INPUT_DIR}'.")
        return

    filenames = []
    with open(FILELIST, 'r') as f:
        for line in f:
            line = line.strip()
            # Skip empty lines, 'total' lines, or directory indicators
            if not line or line.startswith('total') or line.startswith('d'):
                continue

            parts = line.split()
            if not parts: continue

            fname = parts[-1]
            # Ignore directory navigation dots
            if fname in ['./', '../', '.', '..']: continue
            filenames.append(fname)

    print(f"Extracted {len(filenames)} candidate filenames from {FILELIST}.")

    project_entries = []
    processed_count = 0

    for fname in filenames:
        raw_wav_input = os.path.join(INPUT_DIR, fname)

        # DEBUG: Show what the script is looking for
        if not os.path.isfile(raw_wav_input):
            print(f"SKIPPING: File not found at path -> {raw_wav_input}")
            continue

        processed_count += 1
        print(f"\n{'='*60}\nPROCESSING ({processed_count}): {fname}\n{'='*60}")
        timestamp = get_timestamp(fname)
        base_name = os.path.splitext(fname)[0]
        if base_name.endswith('.mp4'): base_name = os.path.splitext(base_name)[0]

        # PHASE 1: HIGH-FIDELITY PROCESSING (WAV ONLY)
        raw_amp32_wav = os.path.join(INPUT_DIR, f"{base_name}_amp32_TEMP.wav")
        print("Step 1: Applying +32dB Amp (WAV)...")
        subprocess.run(['ffmpeg', '-y', '-i', raw_wav_input, '-af', 'volume=32dB', raw_amp32_wav], capture_output=True)

        enhanced_wav = os.path.join(INPUT_DIR, f"enhanced_{base_name}_TEMP.wav")
        print("Step 2: Audio Enhancement (Streaming to WAV)...")
        enhance_large_audio(raw_amp32_wav, enhanced_wav)

        enhanced_plus20_wav = os.path.join(INPUT_DIR, f"enhanced_{base_name}_plus20_TEMP.wav")
        print("Step 3: Final +20dB Amp (WAV)...")
        subprocess.run(['ffmpeg', '-y', '-i', enhanced_wav, '-af', 'volume=20dB', enhanced_plus20_wav], capture_output=True)

        # PHASE 2: FINAL CONVERSION TO OGG (QUALITY 10)
        print("Phase 2: Archiving to Ogg Q10...")
        conversion_map = [
            (raw_wav_input, f"{base_name}_original.ogg", "Original (Ogg Q10)"),
            (raw_amp32_wav, f"{base_name}_amp32.ogg", "Raw Amp +32dB (Ogg Q10)"),
            (enhanced_wav, f"enhanced_{base_name}.ogg", "Enhanced (Ogg Q10)"),
            (enhanced_plus20_wav, f"enhanced_{base_name}_plus20.ogg", "Enhanced Amp +20dB (Ogg Q10)")
        ]

        for src_wav, out_name, label in conversion_map:
            out_path = os.path.join(INPUT_DIR, out_name)
            subprocess.run(['ffmpeg', '-y', '-i', src_wav, '-c:a', 'libvorbis', '-q:a', '10', out_path], capture_output=True)

            project_entries.append({
                'path': out_path,
                'start': timestamp,
                'type': label
            })

        # PHASE 3: CLEANUP
        for temp_wav in [raw_amp32_wav, enhanced_wav, enhanced_plus20_wav]:
            if os.path.exists(temp_wav): os.remove(temp_wav)

    if not project_entries:
        print("\n[!] FAILURE: No files were successfully processed. Check file paths above.")
    else:
        project_config = {'files': project_entries}
        with open(OUTPUT_YAML, 'w') as f:
            yaml.dump(project_config, f, default_flow_style=False, sort_keys=False)
        print(f"\nMISSION COMPLETE: {processed_count} files processed. Generated {OUTPUT_YAML}")

if __name__ == "__main__":
    process_paphos_files()
