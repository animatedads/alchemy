#!/usr/bin/env python3

import sys
import subprocess
import yaml
import os
from datetime import datetime

MASTER_FILE = "dual_master.ogg"


class Segment:
    def __init__(self, time, camera, score, file):
        self.time = datetime.strptime(time, "%Y-%m-%d %H:%M:%S")
        self.camera = camera
        self.score = score
        self.file = file


def parse_plan(lines):
    """
    Parse coverage plan printed by forge_track
    """
    segments = []

    for l in lines:
        l = l.strip()

        if not l or l.startswith("["):
            continue

        parts = l.split()

        if len(parts) < 4:
            continue

        try:
            dt = parts[0] + " " + parts[1]
            cam = parts[3]

            # find score
            score_index = parts.index("score:")
            score = float(parts[score_index + 1])

            file = parts[-1]

            segments.append(Segment(dt, cam, score, file))

        except:
            continue

    return segments


def sort_segments(segments):
    return sorted(segments, key=lambda s: s.time)


def build_concat_file(segments):
    """
    ffmpeg concat list
    """
    concat_file = "forge_concat.txt"

    with open(concat_file, "w") as f:
        for s in segments:
            if os.path.exists(s.file):
                f.write(f"file '{s.file}'\n")
            else:
                print("[forge_master] missing:", s.file)

    return concat_file


def build_master(concat_file):

    cmd = [
        "ffmpeg",
        "-y",
        "-f",
        "concat",
        "-safe", "0",
        "-i", concat_file,
        "-c", "copy",
        MASTER_FILE
    ]

    print("[forge_master] building master track")

    subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

    print("[forge_master] output:", MASTER_FILE)


def ab_cancel(a_file, b_file, output):
    """
    Optional A/B phase cancellation
    """

    cmd = [
        "ffmpeg",
        "-y",
        "-i", a_file,
        "-i", b_file,
        "-filter_complex",
        "[1:a]volume=-1[a2];[0:a][a2]amix=inputs=2",
        output
    ]

    subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def main():

    if len(sys.argv) != 2:
        print("usage: forge_master.py coverage_plan.txt")
        return

    plan_file = sys.argv[1]

    with open(plan_file) as f:
        lines = f.readlines()

    segments = parse_plan(lines)

    if not segments:
        print("[forge_master] no segments found")
        return

    segments = sort_segments(segments)

    print("[forge_master] segments:", len(segments))

    concat_file = build_concat_file(segments)

    build_master(concat_file)


if __name__ == "__main__":
    main()
