import os
import re
import yaml
import subprocess
import sys
from datetime import datetime

# Import your existing streaming enhancement logic
try:
    from testaudiostream import enhance_large_audio
except ImportError:
    print("Error: testaudiostream.py must be in the same directory.")
    sys.exit(1)

# Configuration
INPUT_DIR = "fcpaphos"
FILELIST = "filelist.txt"
OUTPUT_YAML = "fd_project.yaml"

# Timestamp Regex: matches YYYYMMDD_HHMMSS
TS_REGEX = re.compile(r'(\d{4})(\d{2})(\d{2})_(\d{2})(\d{2})(\d{2})')

def get_timestamp(filename):
    match = TS_REGEX.search(filename)
    if match:
        y, m, d, hh, mm, ss = match.groups()
        return f"{y}-{m}-{d} {hh}:{mm}:{ss}"
    return "UNKNOWN_TIME"

def process_fd_files():
    print(f"--- FD Feed Forensic Prepper Engaged ---")

    if not os.path.exists(FILELIST):
        print(f"CRITICAL ERROR: {FILELIST} not found.")
        return

    raw_files = []
    with open(FILELIST, 'r') as f:
        for line in f:
            line = line.strip()
            if not line or not line.endswith('.mp4'):
                continue
            raw_files.append(line)

    total_files = len(raw_files)
    print(f"Detected {total_files} FD Feed MP4 files for processing.")

    project_entries = []
    processed_count = 0

    for full_path in raw_files:
        if not os.path.isfile(full_path):
            print(f"SKIPPING: File not found -> {full_path}")
            continue

        processed_count += 1
        fname = os.path.basename(full_path)
        parent_dir = os.path.dirname(full_path)

        print(f"\n{'='*70}")
        print(f" PROCESSING FILE {processed_count} of {total_files}")
        print(f" TARGET: {fname}")
        print(f"{'='*70}")

        timestamp = get_timestamp(fname)
        base_name = os.path.splitext(fname)[0]
        if base_name.endswith('.mp4'): base_name = os.path.splitext(base_name)[0]

        # PHASE 1: HIGH-FIDELITY PROCESSING (WAV INTERMEDIATES)
        raw_amp32_wav = os.path.join(parent_dir, f"{base_name}_amp32_TEMP.wav")
        print(f" -> Step 1/3: Applying +32dB Pre-Amp...")
        # Removed capture_output so you can see ffmpeg progress
        subprocess.run(['ffmpeg', '-y', '-i', full_path, '-af', 'volume=32dB', '-hide_banner', '-loglevel', 'error', '-stats', raw_amp32_wav])

        enhanced_wav = os.path.join(parent_dir, f"enhanced_{base_name}_TEMP.wav")
        print(f" -> Step 2/3: Neural Streaming Enhancement (This may take a while)...")
        enhance_large_audio(raw_amp32_wav, enhanced_wav)

        enhanced_plus20_wav = os.path.join(parent_dir, f"enhanced_{base_name}_plus20_TEMP.wav")
        print(f" -> Step 3/3: Final +20dB Post-Amp Recovery...")
        subprocess.run(['ffmpeg', '-y', '-i', enhanced_wav, '-af', 'volume=20dB', '-hide_banner', '-loglevel', 'error', '-stats', enhanced_plus20_wav])

        # PHASE 2: FORENSIC ARCHIVING (OGG QUALITY 10)
        print(f"\n -> Phase 2: Archiving Multi-Stage Tracks to Ogg Q10...")
        conversion_map = [
            (full_path, f"{base_name}_original.ogg", "FD Feed (Original)"),
            (raw_amp32_wav, f"{base_name}_amp32.ogg", "FD Feed (Raw Amp +32dB)"),
            (enhanced_wav, f"enhanced_{base_name}.ogg", "FD Feed (Enhanced)"),
            (enhanced_plus20_wav, f"enhanced_{base_name}_plus20.ogg", "FD Feed (Enhanced +20dB)")
        ]

        for i, (src_path, out_name, label) in enumerate(conversion_map):
            out_path = os.path.join(parent_dir, out_name)
            print(f"    [{i+1}/{len(conversion_map)}] Archiving {label}...")
            # Using -stats to show encoding progress in real-time
            subprocess.run(['ffmpeg', '-y', '-i', src_path, '-c:a', 'libvorbis', '-q:a', '10', '-hide_banner', '-loglevel', 'error', '-stats', out_path])

            project_entries.append({
                'path': out_path,
                'start': timestamp,
                'type': label
            })

        # PHASE 3: CLEANUP INTERMEDIATE WAVS
        print(f" -> Phase 3: Cleaning up intermediate forensic WAVs...")
        for temp_wav in [raw_amp32_wav, enhanced_wav, enhanced_plus20_wav]:
            if os.path.exists(temp_wav):
                try:
                    os.remove(temp_wav)
                    print(f"    - Removed {os.path.basename(temp_wav)}")
                except:
                    print(f"    [!] Error removing {temp_wav}")

    if not project_entries:
        print("\n[!] FAILURE: No files processed. Verify paths in filelist.txt.")
    else:
        project_config = {'files': project_entries}
        with open(OUTPUT_YAML, 'w') as f:
            yaml.dump(project_config, f, default_flow_style=False, sort_keys=False)
        print(f"\n{'*'*70}")
        print(f" MISSION COMPLETE: {processed_count} FD Feed files processed.")
        print(f" Generated Project YAML: {OUTPUT_YAML}")
        print(f"{'*'*70}")

if __name__ == "__main__":
    process_fd_files()
