import os
import sys
import yaml
import json
import librosa
import librosa.display  # <-- MOVED TO GLOBAL SCOPE
import numpy as np
import requests
import base64
import io
import time
import matplotlib.pyplot as plt
from datetime import datetime

# --- CONFIGURATION ---
# We probe 10 minutes in to avoid start-of-file artifacts and get a stable noise profile
TARGET_OFFSET_SEC = 600.0
PROBE_DURATION    = 10.0
SPECTROGRAM_DPI   = 100

def parse_dt(s):
    """Flexible datetime parser for selective ranging."""
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M", "%Y-%m-%d"):
        try:
            return datetime.strptime(s, fmt)
        except ValueError:
            continue
    return None

class ForensicStrategist:
    def __init__(self, yaml_path, api_key_path="openai_key.txt"):
        self.yaml_path = yaml_path
        self.project_name = os.path.splitext(os.path.basename(yaml_path))[0]
        self.api_key = ""

        if os.path.exists(api_key_path):
            with open(api_key_path, 'r') as f:
                self.api_key = f.read().strip()
        else:
            print(f"Warning: {api_key_path} not found. OpenAI API calls will fail.")

        with open(yaml_path, 'r') as f:
            self.config = yaml.safe_load(f)

    def determine_camera_and_tier(self, yaml_type):
        """
        RELIABLE IDENTIFICATION:
        Relies exclusively on the YAML 'type' description to assign camera and tier.
        """
        yaml_type_lower = yaml_type.lower()

        # 1. Camera Detection
        if "fd feed" in yaml_type_lower:
            cam_id = "Camera B (FD Feed)"
        else:
            cam_id = "Camera A (Main)"

        # 2. Tier Detection
        tier = "Original"
        if "plus20" in yaml_type_lower or "+20db" in yaml_type_lower:
            tier = "Enhanced +20dB"
        elif "amp32" in yaml_type_lower or "+32db" in yaml_type_lower:
            tier = "Raw Amp +32dB"
        elif "enhanced" in yaml_type_lower:
            tier = "Enhanced"

        return cam_id, tier

    def generate_spectrogram_base64(self, path):
        # Probe 10 minutes in, or middle of file if shorter
        duration = librosa.get_duration(path=path)
        offset = TARGET_OFFSET_SEC if duration > (TARGET_OFFSET_SEC + PROBE_DURATION) else max(0, duration / 2 - PROBE_DURATION / 2)

        y, sr = librosa.load(path, sr=22050, offset=offset, duration=PROBE_DURATION)

        D = librosa.amplitude_to_db(np.abs(librosa.stft(y)), ref=np.max)

        plt.figure(figsize=(10, 4))
        # No local import here anymore
        librosa.display.specshow(D, sr=sr, x_axis='time', y_axis='linear')
        plt.colorbar(format='%+2.0f dB')
        plt.title('Audio Spectrogram')
        plt.tight_layout()

        buf = io.BytesIO()
        plt.savefig(buf, format='png', dpi=SPECTROGRAM_DPI)
        plt.close()
        buf.seek(0)
        return base64.b64encode(buf.read()).decode('utf-8')

    def call_openai_vision(self, b64_img, cam_id, tier):
        if not self.api_key:
            return {
                "explanation": f"API Key Missing. Mock analysis for {cam_id} ({tier})",
                "low_pass_cutoff": 4000,
                "high_pass_cutoff": 200,
                "notches": []
            }

        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self.api_key}"
        }

        payload = {
            "model": "gpt-4o",
            "messages": [
                {
                    "role": "system",
                    "content": "You are a forensic audio expert analyzing spectrograms. Identify dominant noise bands and suggest high-pass/low-pass cutoffs. Return JSON only in this format: {\"explanation\": \"...\", \"low_pass_cutoff\": 4000, \"high_pass_cutoff\": 150, \"notches\": []}"
                },
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "text",
                            "text": f"Analyze this spectrogram. This is from {cam_id}, processed with {tier}. Suggest precise EQ cuts to isolate human speech."
                        },
                        {
                            "type": "image_url",
                            "image_url": {
                                "url": f"data:image/png;base64,{b64_img}"
                            }
                        }
                    ]
                }
            ],
            "max_tokens": 300
        }

        response = requests.post("https://api.openai.com/v1/chat/completions", headers=headers, json=payload)
        response.raise_for_status()

        content = response.json()['choices'][0]['message']['content']

        # Clean markdown JSON formatting if present
        if content.startswith('```json'):
            content = content[7:-3]
        elif content.startswith('```'):
            content = content[3:-3]

        return json.loads(content)

    def devise_strategies(self, filter_type):
        print(f"[*] Starting AI Vision Strategist for tracks matching '{filter_type}'...")
        strategy_path = f"{self.project_name}_ai_strategies.json"
        strategies = {}

        # Load existing strategies so we don't re-run expensive API calls
        if os.path.exists(strategy_path):
            with open(strategy_path, 'r') as f:
                strategies = json.load(f)

        files_to_process = []
        for entry in self.config.get('files', []):
            yaml_type = entry.get('type', '')

            # Selectively target the requested tier (e.g. 'plus20')
            if filter_type.lower() in yaml_type.lower():
                if entry['path'] not in strategies:
                    files_to_process.append(entry)

        if not files_to_process:
            print("All files for this filter already have strategies, or none matched.")
            return

        print(f"[*] Found {len(files_to_process)} new files to analyze.")

        for i, entry in enumerate(files_to_process):
            path = entry['path']
            yaml_type = entry.get('type', 'Unknown')

            cam_id, tier = self.determine_camera_and_tier(yaml_type)

            print(f"\n[{i+1}/{len(files_to_process)}] Analyzing: {path}")
            print(f"      YAML Type  : {yaml_type}")
            print(f"      Resolved to: {cam_id} | {tier}")

            if not os.path.exists(path):
                print("      [!] File missing from disk. Skipping.")
                continue

            try:
                b64_img = self.generate_spectrogram_base64(path)
                strategy = self.call_openai_vision(b64_img, cam_id, tier)

                if strategy:
                    print(f"      AI Verdict: {strategy.get('explanation')}")
                    print(f"      Plan: LP {strategy.get('low_pass_cutoff')}Hz | HP {strategy.get('high_pass_cutoff')}Hz")

                    strategy['cam_id'] = cam_id
                    strategy['tier'] = tier
                    strategy['yaml_type'] = yaml_type

                    strategies[path] = strategy
                else:
                    print("      [!] Analysis aborted for this file (API error).")

            except Exception as e:
                print(f"      [!] Error analyzing file: {e}")

        # Save the cumulative strategy map
        if strategies:
            with open(strategy_path, 'w') as f:
                json.dump(strategies, f, indent=4)
            print(f"\n{'='*60}")
            print(f"Strategy Session Complete. Profiles saved to: {strategy_path}")

if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="OpenAI Vision-based Forensic Strategist")
    parser.add_argument("--yaml", required=True, help="Project YAML file")
    parser.add_argument("--type", default="plus20", help="Filter (e.g. plus20, amp32, original)")
    args = parser.parse_args()

    strategist = ForensicStrategist(args.yaml)
    strategist.devise_strategies(args.type)
