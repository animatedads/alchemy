import os, yaml, curses, hashlib, secrets, sqlite3, re, subprocess, json, shutil
import requests
from datetime import datetime, timedelta

# --- TOURNAMENT ENGINE ---
class TournamentEngine:
    def __init__(self, keys):
        self.keys = keys
        self.chunk_dir = "temp_chunks"
        self.debug_log = "tournament_debug.log"

    def log_debug(self, source, content):
        with open(self.debug_log, "a") as f:
            f.write(f"\n--- {datetime.now()} | {source} ---\n")
            f.write(json.dumps(content, indent=2) if isinstance(content, (dict, list)) else str(content))
            f.write("\n" + "="*50 + "\n")

    def chunk_audio(self, file_path, chunk_seconds=600):
        if os.path.exists(self.chunk_dir): shutil.rmtree(self.chunk_dir)
        os.makedirs(self.chunk_dir)
        output_pattern = os.path.join(self.chunk_dir, "chunk_%03d.mp3")
        cmd = ['ffmpeg', '-y', '-i', file_path, '-f', 'segment', '-segment_time', str(chunk_seconds),
               '-c:a', 'libmp3lame', '-b:a', '128k', output_pattern]
        subprocess.run(cmd, capture_output=True)
        return sorted([os.path.join(self.chunk_dir, f) for f in os.listdir(self.chunk_dir)])

    def ai_pass_1_openai(self, chunk_path, base_start_dt, offset):
        headers = {"Authorization": f"Bearer {self.keys.get('openai','')}"}
        with open(chunk_path, "rb") as f:
            files = {"file": f, "model": (None, "whisper-1"), "response_format": (None, "verbose_json")}
            r = requests.post("https://api.openai.com/v1/audio/transcriptions", headers=headers, files=files)
        results = []
        if r.status_code == 200:
            for seg in r.json().get('segments', []):
                ts = (base_start_dt + timedelta(seconds=offset + seg['start'])).strftime('%Y%m%d%H%M%S')
                results.append({"ts": ts, "text": seg['text'].strip()})
        return results

    def ai_pass_2_deepseek(self, chunk_id, openai_raw):
        if 'deepseek' not in self.keys: return openai_raw
        prompt = (
            "FORENSIC MISSION: CCTV DE-POLLUTION. \n"
            "Examine this raw transcription. Provide phonetic best guesses for muffled speech. "
            "Translate or phonetically transcribe foreign fragments. \n"
            "RETURN ONLY RAW JSON [[ts, text], ...]. \n\n DATA: " + json.dumps(openai_raw)
        )
        headers = {"Authorization": f"Bearer {self.keys['deepseek']}", "Content-Type": "application/json"}
        payload = {"model": "deepseek-chat", "messages": [{"role": "user", "content": prompt}]}
        r = requests.post("https://api.deepseek.com/v1/chat/completions", headers=headers, json=payload)
        try:
            match = re.search(r'\[\s*\[.*\]\s*\]', r.json()['choices'][0]['message']['content'], re.DOTALL)
            return json.loads(match.group()) if match else openai_raw
        except: return openai_raw

    def ai_pass_3_gemini_review(self, chunk_id, openai_v, deepseek_v):
        if 'gemini' not in self.keys: return deepseek_v
        prompt = (
            "FORENSIC MISSION: RECIPROCAL PEER REVIEW. \n"
            "Grade the work of two other AI models transcribing noisy CCTV. \n"
            "Resolve discrepancies and prioritize phonetic clarity for muffled audio. \n"
            f"VERSION 1: {json.dumps(openai_v)}\nVERSION 2: {json.dumps(deepseek_v)}\n"
            "\nOutput final consensus as raw JSON: [[ts, text], ...]"
        )
        url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-3-flash-preview:generateContent?key={self.keys['gemini']}"
        r = requests.post(url, json={"contents": [{"parts": [{"text": prompt}]}]})
        try:
            match = re.search(r'\[\s*\[.*\]\s*\]', r.json()['candidates'][0]['content']['parts'][0]['text'], re.DOTALL)
            return json.loads(match.group()) if match else deepseek_v
        except: return deepseek_v

# --- MAIN PROJECT MANAGER ---
class ProjectManager:
    def __init__(self):
        self.current_config, self.filename = None, ""
        self.ai_keys = self.detect_ai_keys()
        self.engine = TournamentEngine(self.ai_keys)
        self.selector = 0

    def detect_ai_keys(self):
        keys = {}
        mapping = {'gemini': 'gemini3_key.txt', 'openai': 'openai_key.txt', 'deepseek': 'deepseek_key.txt'}
        for p, f in mapping.items():
            if os.path.exists(f):
                with open(f, 'r') as k: keys[p] = k.read().strip()
        return keys

    def safe_addstr(self, stdscr, y, x, string, attr=0):
        my, mx = stdscr.getmaxyx()
        if y < my: stdscr.addstr(y, x, string[:mx-x-1], attr)

    def get_input(self, stdscr, prompt, y, x, secret=False):
        stdscr.move(y, x); stdscr.clrtoeol()
        self.safe_addstr(stdscr, y, x, f"{prompt}: ")
        curses.noecho() if secret else curses.echo()
        curses.curs_set(1)
        val = stdscr.getstr().decode().strip()
        curses.noecho(); curses.curs_set(0)
        return val

    def save_project(self, stdscr):
        with open(self.filename, 'w') as f:
            yaml.dump(self.current_config, f, default_flow_style=False)
        my, _ = stdscr.getmaxyx()
        self.safe_addstr(stdscr, my-2, 2, "Mission Data Saved.", curses.A_REVERSE)
        stdscr.refresh(); curses.napms(600)

    def verify_database_schema(self):
        if not self.filename: return
        db_path = f"{os.path.splitext(self.filename)[0]}_audit.db"
        with sqlite3.connect(db_path) as conn:
            c = conn.cursor()
            c.execute('CREATE TABLE IF NOT EXISTS transcript (id INTEGER PRIMARY KEY, ts TEXT, content TEXT)')
            c.execute("CREATE TABLE IF NOT EXISTS audit_log (id INTEGER PRIMARY KEY, edit_time TEXT, line_ts TEXT, old_text TEXT, new_text TEXT, user TEXT, source_file TEXT)")
            conn.commit()

    def edit_settings(self, stdscr):
        while True:
            stdscr.erase(); my, mx = stdscr.getmaxyx()
            self.safe_addstr(stdscr, 0, 0, " MISSION METADATA ".center(mx, " "), curses.A_REVERSE)
            ps = self.current_config.setdefault('project_settings', {})
            self.safe_addstr(stdscr, 2, 2, f"1. Friendly Name : {ps.get('friendly_name', 'UNSET')}")
            self.safe_addstr(stdscr, 3, 2, f"2. Case Number   : {ps.get('case_number', 'UNSET')}")
            self.safe_addstr(stdscr, 4, 2, f"3. Case Officer  : {ps.get('case_officer', 'UNSET')}")
            self.safe_addstr(stdscr, my-2, 2, "[1-3] Edit Field | [F12] Back", curses.A_DIM)
            ch = stdscr.getch()
            if ch == curses.KEY_F12: break
            elif ch == ord('1'): ps['friendly_name'] = self.get_input(stdscr, "Enter Project/Mission Name", my-3, 2); self.save_project(stdscr)
            elif ch == ord('2'): ps['case_number'] = self.get_input(stdscr, "Enter Legal Case Number", my-3, 2); self.save_project(stdscr)
            elif ch == ord('3'): ps['case_officer'] = self.get_input(stdscr, "Enter Officer in Charge", my-3, 2); self.save_project(stdscr)

    def manage_users(self, stdscr):
        while True:
            stdscr.erase(); my, mx = stdscr.getmaxyx()
            self.safe_addstr(stdscr, 0, 0, " AUTHORIZED OPERATORS ".center(mx, " "), curses.A_REVERSE)
            users = self.current_config.setdefault('users', {})
            for i, (u, d) in enumerate(users.items()):
                self.safe_addstr(stdscr, 2+i, 2, f"- {u} (Access: {d['perm']})")
            self.safe_addstr(stdscr, my-2, 2, "[A] Add User | [D] Delete User | [F12] Back", curses.A_DIM)
            ch = stdscr.getch()
            if ch == curses.KEY_F12: break
            elif ch in [ord('a'), ord('A')]:
                u = self.get_input(stdscr, "Operator ID", my-5, 2)
                p = self.get_input(stdscr, "Operator Password", my-4, 2, True)
                pm = self.get_input(stdscr, "Permissions (EDIT/READ)", my-3, 2)
                if u and p:
                    salt = secrets.token_hex(8); h = hashlib.sha256((salt + p).encode()).hexdigest()
                    users[u] = {'hash': f"{salt}${h}", 'perm': pm.upper()}; self.save_project(stdscr)
            elif ch in [ord('d'), ord('D')]:
                u = self.get_input(stdscr, "Enter User ID to DELETE", my-3, 2)
                if u in users:
                    conf = self.get_input(stdscr, f"Are you sure? (y/n)", my-2, 2)
                    if conf.lower() == 'y': del users[u]; self.save_project(stdscr)

    def manage_files(self, stdscr):
        while True:
            stdscr.erase(); my, mx = stdscr.getmaxyx()
            self.safe_addstr(stdscr, 0, 0, " EVIDENCE REGISTRY ".center(mx, " "), curses.A_REVERSE)
            files = self.current_config.setdefault('files', [])
            for i, f in enumerate(files):
                self.safe_addstr(stdscr, 2+i, 2, f"{i+1}. {os.path.basename(f['path'])} | Start: {f['start']}")
            self.safe_addstr(stdscr, my-2, 2, "[A] Add File | [D] Remove File | [F12] Back", curses.A_DIM)
            ch = stdscr.getch()
            if ch == curses.KEY_F12: break
            elif ch in [ord('a'), ord('A')]:
                p = self.get_input(stdscr, "Path to Audio/Video File", my-4, 2)
                s = self.get_input(stdscr, "Mission Start Time (YYYY-MM-DD HH:MM:SS)", my-3, 2)
                if p and s: files.append({'path': p, 'start': s}); self.save_project(stdscr)

    def manage_macros(self, stdscr):
        while True:
            stdscr.erase(); my, mx = stdscr.getmaxyx()
            self.safe_addstr(stdscr, 0, 0, " SHORTHAND & MACROS ".center(mx, " "), curses.A_REVERSE)
            macros = self.current_config.setdefault('macros', {})
            for i, (k, v) in enumerate(macros.items()):
                self.safe_addstr(stdscr, 2+i, 2, f"  {k:10} expands to -->  {v}")
            self.safe_addstr(stdscr, my-2, 2, "[A] Add Macro | [D] Delete Macro | [F12] Back", curses.A_DIM)
            ch = stdscr.getch()
            if ch == curses.KEY_F12: break
            elif ch in [ord('a'), ord('A')]:
                t = self.get_input(stdscr, "Enter shorthand trigger (e.g. /p)", my-4, 2)
                e = self.get_input(stdscr, "Enter full text expansion", my-3, 2)
                if t and e: macros[t] = e; self.save_project(stdscr)
            elif ch in [ord('d'), ord('D')]:
                t = self.get_input(stdscr, "Enter trigger to DELETE", my-3, 2)
                if t in macros: del macros[t]; self.save_project(stdscr)

    def run_tournament_menu(self, stdscr):
        my, mx = stdscr.getmaxyx(); stdscr.erase()
        self.safe_addstr(stdscr, 0, 0, " TRIPLE-AI RECIPROCAL TOURNAMENT ".center(mx, " "), curses.A_REVERSE)
        files = self.current_config.get('files', [])
        for i, f in enumerate(files[:15]): self.safe_addstr(stdscr, 2+i, 2, f"{i+1}. {os.path.basename(f['path'])}")
        sel = self.get_input(stdscr, "Select Evidence File #", my-3, 2)
        if not sel.isdigit() or int(sel) > len(files): return
        target = files[int(sel)-1]; base_start = datetime.strptime(target['start'], '%Y-%m-%d %H:%M:%S')
        chunks = self.engine.chunk_audio(target['path'])
        self.safe_addstr(stdscr, my-4, 2, f"ANALYZING {len(chunks)} SEGMENTS. CHECK TOURNAMENT_DEBUG.LOG", curses.A_BOLD)
        stdscr.refresh()
        db_path = f"{os.path.splitext(self.filename)[0]}_audit.db"
        now_str = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        with sqlite3.connect(db_path) as conn:
            c = conn.cursor()
            for i, chunk_path in enumerate(chunks):
                offset = i * 600; chunk_id = f"{i+1:03}"
                self.safe_addstr(stdscr, my-3, 2, f"PROGRESS: Segment {chunk_id}/{len(chunks)} - Final Review Pass...")
                stdscr.refresh()
                op_v = self.engine.ai_pass_1_openai(chunk_path, base_start, offset)
                ds_v = self.engine.ai_pass_2_deepseek(chunk_id, op_v)
                final = self.engine.ai_pass_3_gemini_review(chunk_id, op_v, ds_v)
                for r in final:
                    ts, txt = (r[0], r[1]) if isinstance(r, list) else (r['ts'], r['text'])
                    c.execute("INSERT INTO transcript (ts, content) VALUES (?,?)", (ts, txt))
                    c.execute("INSERT INTO audit_log (edit_time, line_ts, old_text, new_text, user, source_file) VALUES (?,?,?,?,?,?)",
                              (now_str, ts, "TRIPLE_AI_FORENSIC", txt, "TOURNAMENT", os.path.basename(target['path'])))
                conn.commit()
        self.safe_addstr(stdscr, my-2, 2, "DONE. PRESS ANY KEY.", curses.A_REVERSE); stdscr.getch()

    def import_transcript(self, stdscr):
        stdscr.erase(); my, mx = stdscr.getmaxyx()
        self.safe_addstr(stdscr, 0, 0, " IMPORT EXTERNAL TRANSCRIPT ".center(mx, " "), curses.A_REVERSE)
        p = self.get_input(stdscr, "Path to .txt file for import", 2, 2)
        if not os.path.exists(p): stdscr.getch(); return
        db_path = f"{os.path.splitext(self.filename)[0]}_audit.db"
        now_str = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        count = 0
        with sqlite3.connect(db_path) as conn:
            c = conn.cursor()
            with open(p, 'r') as f:
                for line in f:
                    m = re.match(r'\[(\d{14})\]\s+(.*)', line.strip())
                    if m:
                        ts, txt = m.group(1), m.group(2)
                        c.execute("INSERT INTO transcript (ts, content) VALUES (?,?)", (ts, txt))
                        c.execute("INSERT INTO audit_log (edit_time, line_ts, old_text, new_text, user, source_file) VALUES (?,?,?,?,?,?)",
                                  (now_str, ts, "NULL (IMPORT)", txt, "SYSTEM", os.path.basename(p)))
                        count += 1
            conn.commit()
        self.safe_addstr(stdscr, 5, 2, f"Imported {count} lines. Press any key.", curses.A_REVERSE); stdscr.getch()

    def export_transcript(self, stdscr):
        stdscr.erase(); my, mx = stdscr.getmaxyx()
        self.safe_addstr(stdscr, 0, 0, " EXPORT FINAL RECORD ".center(mx, " "), curses.A_REVERSE)
        db_path = f"{os.path.splitext(self.filename)[0]}_audit.db"
        out = f"{os.path.splitext(self.filename)[0]}_FINAL.txt"
        with sqlite3.connect(db_path) as conn, open(out, 'w') as f:
            ps = self.current_config.get('project_settings', {})
            f.write(f"OFFICIAL RECORD: {ps.get('friendly_name', 'N/A')}\nCASE NO: {ps.get('case_number', 'N/A')}\n\n")
            data = conn.cursor().execute("SELECT ts, content FROM transcript ORDER BY ts ASC").fetchall()
            for ts, c in data: f.write(f"[{ts}] {c}\n")
        self.safe_addstr(stdscr, 3, 2, f"Export complete: {out}", curses.A_REVERSE); stdscr.getch()

    def review_audit(self, stdscr):
        db_path = f"{os.path.splitext(self.filename)[0]}_audit.db"
        if not os.path.exists(db_path): return
        page = 0
        while True:
            stdscr.erase(); my, mx = stdscr.getmaxyx()
            self.safe_addstr(stdscr, 0, 0, " FORENSIC AUDIT LEDGER ".center(mx, " "), curses.A_REVERSE)
            with sqlite3.connect(db_path) as conn:
                logs = conn.cursor().execute("SELECT edit_time, user, new_text FROM audit_log ORDER BY id DESC").fetchall()
            for i, l in enumerate(logs[page*15 : (page+1)*15]):
                self.safe_addstr(stdscr, 2+i, 1, f"{l[0]} | {str(l[1])[:10]} | {str(l[2])[:mx-35]}")
            ch = stdscr.getch()
            if ch == curses.KEY_F12: break
            elif ch == curses.KEY_PPAGE: page = max(0, page-1)
            elif ch == curses.KEY_NPAGE: page += 1

    def main_menu(self, stdscr):
        curses.curs_set(0)
        while True:
            stdscr.erase(); my, mx = stdscr.getmaxyx()
            keys = ", ".join(self.ai_keys.keys()) if self.ai_keys else "NONE"
            self.safe_addstr(stdscr, 0, 0, f" SHUTTLE MANAGER v1.46 | AI: {keys} ".center(mx, " "), curses.A_REVERSE)
            opts = [("1. Create New Project", "create"), ("2. Load Existing Project", "load")]
            if self.current_config:
                opts += [("3. Project Metadata", "settings"), ("4. Authorized Operators", "users"), ("5. Evidence Registry", "files"),
                         ("6. Shorthand & Macros", "macros"), ("7. RUN AI TOURNAMENT", "tournament"), ("8. Import Transcript", "import"),
                         ("9. Export Transcript", "export"), ("0. Review Audit Ledger", "audit")]
            opts.append(("Q. Quit", "quit"))
            for i, (l, _) in enumerate(opts):
                self.safe_addstr(stdscr, 6+i, 4, l, curses.A_REVERSE if i == self.selector else curses.A_NORMAL)
            ch = stdscr.getch()
            if ch == curses.KEY_UP: self.selector = (self.selector - 1) % len(opts)
            elif ch == curses.KEY_DOWN: self.selector = (self.selector + 1) % len(opts)
            elif ch in [10, 13, curses.KEY_ENTER]:
                a = opts[self.selector][1]
                if a == "quit": break
                elif a == "create":
                    n = self.get_input(stdscr, "New Mission Name", my-2, 2)
                    if n: self.filename = f"{n}.yaml"; self.current_config = {'project_settings':{'friendly_name':n}, 'users':{}, 'files':[], 'macros':{}}; self.save_project(stdscr); self.verify_database_schema()
                elif a == "load":
                    y = sorted([f for f in os.listdir('.') if f.endswith('.yaml')])
                    for i, f in enumerate(y): self.safe_addstr(stdscr, my-len(y)-2+i, 4, f"{i+1}. {f}")
                    s = self.get_input(stdscr, "Select Project #", my-1, 2)
                    if s.isdigit() and 1 <= int(s) <= len(y):
                        self.filename = y[int(s)-1]
                        with open(self.filename, 'r') as f: self.current_config = yaml.safe_load(f)
                        self.verify_database_schema(); self.selector = 0
                elif a == "settings": self.edit_settings(stdscr)
                elif a == "users": self.manage_users(stdscr)
                elif a == "files": self.manage_files(stdscr)
                elif a == "macros": self.manage_macros(stdscr)
                elif a == "tournament": self.run_tournament_menu(stdscr)
                elif a == "import": self.import_transcript(stdscr)
                elif a == "export": self.export_transcript(stdscr)
                elif a == "audit": self.review_audit(stdscr)
            elif ch in [ord('q'), ord('Q')]: break

if __name__ == "__main__":
    curses.wrapper(ProjectManager().main_menu)
