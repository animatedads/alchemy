#!/usr/bin/env python3
"""
dual_feed_enhance_v6_helper_consistent.py
=======================================
Forensic Audio Enhancement — Dual-Feed Pipeline v6 using ForensicHelper plumbing

Purpose of this compatibility edition:
- Keep the original V6 DSP technique intact.
- Replace the duplicated YAML/camera/time/duration code with forensic_helper.py.
- Use the same camera identification, tier matching, duration handling, stream loading,
  time parsing, and YAML output registration style across V3/V4/V5/V6.

V6 DSP retained: spatial, echo, wavefront, modulation, harmonic fusion.
"""

import os
import argparse
import yaml
import numpy as np
import soundfile as sf
import librosa
from datetime import datetime, timedelta
from scipy.fftpack import fft, ifft
from scipy.ndimage import uniform_filter1d
import scipy.signal

from forensic_helper import ForensicHelper as fh

SR = 22050
BLOCK_SEC = 8.0

# ---------------------------------------------------------------------------
# HELPER-CONSISTENT PLUMBING
# ---------------------------------------------------------------------------

def parse_dt(s):
    dt = fh.parse_dt(s)
    if not dt:
        raise ValueError(f"Time data {s!r} does not match recognized formats")
    return dt


def determine_camera(yaml_type, path=""):
    cam = fh.identify_camera(path, yaml_type)
    return "cam_b" if cam == "Cam B" else "cam_a"


def matches_tier(yaml_type, target_tier, path=""):
    yt = str(yaml_type or "").lower()
    pt = str(path or "").lower()
    tt = str(target_tier or "").lower()
    blob = yt + " " + pt

    if tt == "amp32":
        return "+32db" in blob or "amp32" in blob or "raw amp +32" in blob
    if tt == "plus20":
        return "+20db" in blob or "+20" in blob or "plus20" in blob or "ampamp" in blob
    if tt == "enhanced":
        return "enhanced" in blob and "+20" not in blob and "plus20" not in blob
    if tt == "original":
        return "original" in blob
    return tt in blob


def load_project_streams(yaml_path, tier):
    """Load all valid streams once using ForensicHelper, then apply old tier semantics."""
    raw_streams = fh.get_active_streams(yaml_path, datetime.min, datetime.max)
    streams = []
    for s in raw_streams:
        label = s.get("filter") or s.get("type") or ""
        path = s.get("path", "")
        if matches_tier(label, tier, path):
            streams.append(s)

    streams.sort(key=lambda s: (s.get("start_dt"), s.get("cam_id"), s.get("path")))
    return streams


def get_stream_for_time(streams, cam_id, current_t):
    """Return the active stream for a camera at current_t, preferring the latest start."""
    candidates = [
        s for s in streams
        if s.get("cam_id") == cam_id and s.get("start_dt") <= current_t < s.get("end_dt")
    ]
    if not candidates:
        return None
    return max(candidates, key=lambda s: s.get("start_dt"))


def load_audio_segment(stream_info, target_t, duration_sec, sr=SR):
    if not stream_info:
        return None
    y = fh.read_stream_block(stream_info, target_t, duration_sec, sr)
    if y is None or not np.any(y):
        return None
    target_len = int(duration_sec * sr)
    if len(y) < target_len:
        y = np.pad(y, (0, target_len - len(y)))
    return y[:target_len]


def handle_time_arg(time_str, default_dt):
    if not time_str:
        return default_dt
    if "-" in str(time_str):
        return parse_dt(time_str)
    parts = str(time_str).split(":")
    if len(parts) == 2:
        time_str = f"{time_str}:00"
    return parse_dt(f"{default_dt.strftime('%Y-%m-%d')} {time_str}")


def safe_output_format(out_path):
    fmt = "OGG" if out_path.lower().endswith(".ogg") else None
    subtype = "VORBIS" if fmt == "OGG" else None
    return fmt, subtype


def ensure_output_dir(out_path):
    d = os.path.dirname(os.path.abspath(out_path))
    if d:
        os.makedirs(d, exist_ok=True)


def register_output_in_yaml(yaml_path, out_path, start_time, label):
    """Register/update generated output in the YAML consistently across old pipelines."""
    with open(yaml_path, "r") as f:
        config = yaml.safe_load(f) or {}
    config.setdefault("files", [])

    new_entry = {
        "path": out_path,
        "start": start_time.strftime("%Y-%m-%d %H:%M:%S"),
        "type": label,
    }

    updated = False
    for entry in config["files"]:
        if os.path.normpath(entry.get("path", "")) == os.path.normpath(out_path):
            entry.update(new_entry)
            updated = True
            break
    if not updated:
        config["files"].append(new_entry)

    config["files"].sort(key=lambda x: x.get("start", ""))
    with open(yaml_path, "w") as f:
        yaml.dump(config, f, default_flow_style=False, sort_keys=False)


def make_three_channel(a, b, c, sr=SR):
    n = int(BLOCK_SEC * sr)
    def fix(y):
        if y is None:
            return np.zeros(n, dtype=np.float32)
        if len(y) < n:
            y = np.pad(y, (0, n - len(y)))
        return np.nan_to_num(y[:n], nan=0.0, posinf=0.0, neginf=0.0)
    return np.vstack((fix(a), fix(b), fix(c))).T

# ---------------------------------------------------------------------------
# V6 ADVANCED DSP: 5-DOMAIN PROBABILITY FUSION
# ---------------------------------------------------------------------------

def profile_room_acoustics(y, sr=22050):
    onset_env = librosa.onset.onset_strength(y=y, sr=sr)
    min_frames = int(0.010 * sr / 512)
    max_frames = int(0.150 * sr / 512)
    ac = librosa.autocorrelate(onset_env, max_size=max_frames)
    ac[:min_frames] = 0
    peaks, _ = scipy.signal.find_peaks(ac, distance=2, prominence=np.max(ac)*0.05)

    if len(peaks) < 2: return np.array([15, 30, 45, 60, 80])
    delays_ms = (peaks * 512 / sr) * 1000.0
    return np.sort(delays_ms)[:6]

def gcc_phat_align(sig, refsig, fs=22050, max_tau=0.15):
    n = sig.shape[0] + refsig.shape[0]
    SIG = fft(sig, n=n)
    REFSIG = fft(refsig, n=n)
    R = SIG * np.conj(REFSIG)
    denom = np.maximum(np.abs(R), 1e-6)
    cc = np.real(ifft(R / denom))

    max_shift = int(max_tau * fs)
    cc = np.concatenate((cc[-max_shift:], cc[:max_shift+1]))
    shift = np.argmax(cc) - max_shift
    return np.roll(sig, shift)

def five_domain_coherence_fusion(y_a, y_b, room_delays_ms, sr=22050, n_fft=2048, hop=512):
    """
    The 5-Domain Reality Detector.
    """
    if len(y_a) < n_fft or len(y_b) < n_fft: return y_a

    S_a = librosa.stft(y_a, n_fft=n_fft, hop_length=hop)
    S_b = librosa.stft(y_b, n_fft=n_fft, hop_length=hop)
    mag_a, mag_b = np.abs(S_a), np.abs(S_b)
    phase_a = np.angle(S_a)

    # 1. SPATIAL COHERENCE (Beamformer)
    cps = S_a * np.conj(S_b)
    spatial_score = np.abs(cps) / (mag_a * mag_b + 1e-8)

    # 2. WAVEFRONT PERSISTENCE (Phase Continuity)
    dphase = np.angle(np.exp(1j * np.diff(phase_a, axis=1)))
    dphase = np.pad(dphase, ((0, 0), (1, 0)), mode='edge')
    local_mean_dp = uniform_filter1d(dphase, size=3, axis=1)
    local_var_dp = uniform_filter1d((dphase - local_mean_dp)**2, size=3, axis=1)
    wavefront_score = np.exp(-3.0 * local_var_dp)

    # 3. TUNED ECHO CONSTELLATION (Using Profiled Room Dimensions)
    delays_frames = (np.array(room_delays_ms) / 1000.0 * sr / hop).astype(int)
    delays_frames = delays_frames[delays_frames > 0]

    echo_raw = np.zeros_like(mag_a)
    for d in delays_frames:
        shifted_mag = np.pad(mag_a[:, :-d], ((0, 0), (d, 0)), mode='constant')
        echo_raw += np.sqrt(mag_a * shifted_mag)
    echo_raw /= max(1, len(delays_frames))

    local_max = uniform_filter1d(echo_raw, size=int((sr/hop)*2.0), axis=1) + 1e-8
    echo_score = echo_raw / local_max

    # 4. SYLLABIC MODULATION (2-8 Hz Human Jaw Speed)
    # Calculates a fast envelope and a slow envelope. The difference reveals
    # the pulsing amplitude characteristic of human speech.
    env_fast = uniform_filter1d(mag_a, size=int(0.05 * sr / hop), axis=1)
    env_slow = uniform_filter1d(mag_a, size=int(0.30 * sr / hop), axis=1)
    modulation_raw = np.maximum(0, env_fast - env_slow)
    modulation_score = modulation_raw / (np.max(modulation_raw, axis=1, keepdims=True) + 1e-8)

    # 5. HARMONIC STRUCTURE (Simplified Harmonic Product Spectrum)
    # Drops the spectrum by a factor of 2 to see if frequencies stack nicely.
    half_f = mag_a.shape[0] // 2
    harm_score = np.zeros_like(mag_a)
    # Multiply f by 2f to verify vocal cord multiples
    harm_score[:half_f, :] = np.sqrt(mag_a[:half_f, :] * mag_a[0:half_f*2:2, :])
    harm_score = harm_score / (np.max(harm_score, axis=0) + 1e-8)

    # --- FUSION WEIGHTS ---
    # We carefully balance spatial physics with biological mechanics.
    fused_probability = (
        (spatial_score * 0.35) +
        (echo_score * 0.25) +
        (wavefront_score * 0.15) +
        (modulation_score * 0.15) +
        (harm_score * 0.10)
    )

    # Soft thresholding sigmoid mask
    final_mask = 1.0 / (1.0 + np.exp(-12 * (fused_probability - 0.35)))
    final_mask = uniform_filter1d(final_mask, size=3, axis=1)

    S_clean = S_a * final_mask
    return librosa.istft(S_clean, length=len(y_a))


# ---------------------------------------------------------------------------
# MAIN PROCESSOR
# ---------------------------------------------------------------------------

def run_v6_pipeline(yaml_path, tier, start_time, end_time, out_path):
    sr = SR
    block_sec = BLOCK_SEC
    streams = load_project_streams(yaml_path, tier)

    if not streams:
        raise SystemExit(f"[!] No streams found for tier {tier!r} in {yaml_path}")

    ensure_output_dir(out_path)
    fmt, subtype = safe_output_format(out_path)

    print(f"[*] MDCF Pipeline v6 (5-Domain Reality Detector, Helper-Consistent)")
    print(f"[*] Processing: {start_time} to {end_time}")
    print(f"[*] Target Tier: {tier!r}")
    print(f"[*] Streams loaded via ForensicHelper: {len(streams)}")

    print("[*] Extracting acoustic fingerprint of the room...")
    profile_stream = get_stream_for_time(streams, "Cam A", start_time)
    y_profile = load_audio_segment(profile_stream, start_time, 10.0, sr)
    if y_profile is not None:
        room_delays = profile_room_acoustics(y_profile, sr=sr)
        formatted_delays = ", ".join([f"{d:.1f}ms" for d in room_delays])
        print(f"    [+] Room fingerprint locked. Dominant reflections: {formatted_delays}")
    else:
        room_delays = [15, 30, 45, 60]
        print("    [!] Profiler failed. Using fallback room dimensions.")

    with sf.SoundFile(out_path, mode="w", samplerate=sr, channels=3, format=fmt, subtype=subtype) as out:
        current_t = start_time
        blocks_dual = 0
        blocks_mono = 0
        blocks_silent = 0

        while current_t < end_time:
            stream_a = get_stream_for_time(streams, "Cam A", current_t)
            stream_b = get_stream_for_time(streams, "Cam B", current_t)

            y_a = load_audio_segment(stream_a, current_t, block_sec, sr)
            y_b = load_audio_segment(stream_b, current_t, block_sec, sr)

            if y_a is not None and y_b is not None:
                blocks_dual += 1
                y_a_aligned = gcc_phat_align(y_a, y_b, fs=sr)
                center_beam = five_domain_coherence_fusion(y_a_aligned, y_b, room_delays, sr=sr)
                chunk = make_three_channel(y_a_aligned, y_b, center_beam, sr)

            elif y_a is not None:
                blocks_mono += 1
                chunk = make_three_channel(y_a, y_a, y_a, sr)

            elif y_b is not None:
                blocks_mono += 1
                chunk = make_three_channel(y_b, y_b, y_b, sr)

            else:
                blocks_silent += 1
                chunk = np.zeros((int(block_sec * sr), 3), dtype=np.float32)

            out.write(chunk)
            current_t += timedelta(seconds=block_sec)
            print(
                f"  Progress: {current_t:%Y-%m-%d %H:%M:%S} | Dual: {blocks_dual} Mono: {blocks_mono} Silent: {blocks_silent}",
                end="\r",
            )

    print(f"\n\n{'='*60}")
    print(f"  Audio Generation Complete: {out_path}")
    print(f"  Dual blocks : {blocks_dual}")
    print(f"  Mono blocks : {blocks_mono}")
    print(f"  Silent      : {blocks_silent}")

    register_output_in_yaml(
        yaml_path,
        out_path,
        start_time,
        f"Coverage - MDCF Master v6 ({tier})",
    )
    print(f"  YAML Updated: {yaml_path}")
    print(f"{'='*60}")


def main():
    parser = argparse.ArgumentParser(description="Dual-feed forensic audio enhancement v6 using ForensicHelper plumbing")
    parser.add_argument("--yaml", required=True, help="Project YAML configuration")
    parser.add_argument("--tier", default="amp32", help="Tier: original, amp32, enhanced, plus20")
    parser.add_argument("--start", help="YYYY-MM-DD HH:MM:SS, YYYY-MM-DD HH:MM, HH:MM, or HH:MM:SS")
    parser.add_argument("--end", help="YYYY-MM-DD HH:MM:SS, YYYY-MM-DD HH:MM, HH:MM, or HH:MM:SS")
    parser.add_argument("--out", default="fcpaphos/master_v6_mdcf.ogg")
    args = parser.parse_args()

    streams = load_project_streams(args.yaml, args.tier)
    if not streams:
        raise SystemExit(f"[!] No streams found for tier {args.tier!r} in {args.yaml}")

    starts = sorted(s["start_dt"] for s in streams)
    ends = sorted(s["end_dt"] for s in streams)
    t0 = handle_time_arg(args.start, starts[0])
    t1 = handle_time_arg(args.end, ends[-1])

    if t1 <= t0:
        raise SystemExit(f"[!] Invalid time window: {t0} -> {t1}")

    run_v6_pipeline(args.yaml, args.tier, t0, t1, args.out)


if __name__ == "__main__":
    main()
