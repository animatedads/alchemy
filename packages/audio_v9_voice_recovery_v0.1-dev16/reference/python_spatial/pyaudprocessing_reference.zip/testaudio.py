import numpy as np
import librosa
import soundfile as sf
from scipy.ndimage import uniform_filter1d

def enhance_audio_with_guess(input_file, output_file, moving_avg_window=5, overlay_ratio=0.4):
    # 1. Load the audio
    y, sr = librosa.load(input_file, sr=None)
    
    # 2. Spectral Analysis
    # We do this first to ensure our frame counts match exactly
    stft = librosa.stft(y)
    magnitude, phase = librosa.magphase(stft)
    
    # 3. Estimate Noise Floor (The "Guessing" Part)
    # Calculate RMS directly from the magnitude to ensure index alignment
    rms = librosa.feature.rms(S=magnitude)[0]
    
    # Identify the indices of the bottom 10% energy frames
    noise_threshold_val = np.percentile(rms, 10)
    noise_frames = np.where(rms <= noise_threshold_val)[0]
    
    # Ensure we don't index out of bounds
    max_frame = magnitude.shape[1]
    noise_frames = noise_frames[noise_frames < max_frame]
    
    # 4. Spectral Fingerprinting
    if len(noise_frames) > 0:
        noise_mask = magnitude[:, noise_frames].mean(axis=1, keepdims=True)
    else:
        noise_mask = np.median(magnitude, axis=1, keepdims=True)

    # 5. Processing
    # Subtract noise floor but keep a 10% 'floor' to avoid robotic chopping
    magnitude_clean = np.maximum(magnitude - (noise_mask * 1.5), magnitude * 0.1)
    y_spectral = librosa.istft(magnitude_clean * phase)
    
    # Moving Average (Your radar-style integration)
    y_smoothed = uniform_filter1d(y_spectral, size=moving_avg_window)
    
    # 6. Overlay Original (Parallel Processing)
    min_len = min(len(y), len(y_smoothed))
    y_final = (y[:min_len] * overlay_ratio) + (y_smoothed[:min_len] * (1 - overlay_ratio))
    
    # Normalize
    y_final = librosa.util.normalize(y_final)
    
    sf.write(output_file, y_final, sr)
    print(f"Success! Saved to {output_file}")

# This part handles the command line argument
if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1:
        enhance_audio_with_guess(sys.argv[1], 'enhanced_output.wav')
    else:
        print("Usage: python testaudio.py <input_file>")
