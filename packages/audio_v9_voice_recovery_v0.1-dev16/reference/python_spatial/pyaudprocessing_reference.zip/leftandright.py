import os
import glob
import numpy as np
import librosa
import soundfile as sf
import re
from datetime import datetime, timedelta

# --- CONFIGURATION ---
CAM_A_MAP = {
    'enhanced_output0-30tp00006.ogg': '20231010_093912',
    'enhanced_output30-45tp00006.ogg': '20231010_100912',
    'enhanced_output45-1htp00006.ogg': '20231010_102412',
    'enhanced_output1h-01h15tp00006.ogg': '20231010_103912',
    'enhanced_output0m-30mtp0007.ogg': '20231010_111449',
    'enhanced_output30m-1htp0007.ogg': '20231010_114449',
    'enhanced_output1h-1h30mtp0007.ogg': '20231010_121449',
    'enhanced_output1h30m-endtp0007.ogg': '20231010_124449',
    'enhanced_output_0m-30m20231010_125918_tp0008.ogg': '20231010_125918',
    'enhanced_output_30m-1h_20231010_125918_tp0008.ogg': '20231010_132918',
    'enhanced_output_1h-1h30m_20231010_125918_tp0008.ogg': '20231010_135918',
    'enhanced_output_1h30m_end20231010_125918_tp0008.ogg': '20231010_142918',
}

SR = 22050
BLOCK_SIZE_SEC = 15 # Loading in 15-second chunks

def load_at_time(target_t, file_list, duration):
    """Finds and loads audio for the specific window."""
    for f in file_list:
        name = os.path.basename(f)
        start_t = None
        if name in CAM_A_MAP:
            start_t = datetime.strptime(CAM_A_MAP[name], '%Y%m%d_%H%M%S')
        else:
            match = re.search(r'(\d{8}_\d{6})', name)
            if match:
                start_t = datetime.strptime(match.group(1), '%Y%m%d_%H%M%S')

        if start_t:
            file_dur = librosa.get_duration(path=f)
            end_t = start_t + timedelta(seconds=file_dur)

            if start_t <= target_t <= end_t:
                offset = (target_t - start_t).total_seconds()
                try:
                    y, _ = librosa.load(f, sr=SR, offset=offset, duration=duration)
                    # Standardize sample length
                    target_samples = int(duration * SR)
                    if len(y) < target_samples:
                        y = np.pad(y, (0, target_samples - len(y)))
                    return y
                except:
                    return None
    return None

def create_raw_sync_stereo():
    print("--- Generating Raw Synchronized Stereo Track ---")
    files_a = glob.glob("*tp000*[678].ogg")
    files_b = glob.glob("*tp000*[23][0-9].ogg")

    # Sync window based on your data logs
    start_target = datetime.strptime('20231010_093912', '%Y%m%d_%H%M%S') # Early start for Cam A
    end_target = datetime.strptime('20231010_143200', '%Y%m%d_%H%M%S') # End for Cam B
    duration_secs = int((end_target - start_target).total_seconds())

    output_file = 'RAW_SYNC_A_B.wav'

    with sf.SoundFile(output_file, mode='w', samplerate=SR, channels=2) as out:
        for sec in range(0, duration_secs, BLOCK_SIZE_SEC):
            current_t = start_target + timedelta(seconds=sec)

            # Load Raw Chunks
            y_a = load_at_time(current_t, files_a, BLOCK_SIZE_SEC)
            y_b = load_at_time(current_t, files_b, BLOCK_SIZE_SEC)

            # Assign silence if file missing for this window
            if y_a is None:
                y_a = np.zeros(int(BLOCK_SIZE_SEC * SR))
            if y_b is None:
                y_b = np.zeros(int(BLOCK_SIZE_SEC * SR))

            # Combine into stereo block
            # Axis 0: Time, Axis 1: Channels [L, R]
            combined = np.vstack((y_a, y_b)).T

            out.write(combined)

            if sec % 60 == 0:
                print(f"  Synced: {current_t:%H:%M:%S} ({sec//60}m / {duration_secs//60}m)", end='\r')

    print(f"\nSuccess! Raw stereo file saved: {output_file}")

if __name__ == "__main__":
    create_raw_sync_stereo()
