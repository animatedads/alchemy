import os
import glob
import numpy as np
import librosa
import soundfile as sf
import re
from datetime import datetime, timedelta

# --- CONFIGURATION ---
START_TIME_STR = '20231010_143144'
STREAMING_PART2_FILE = 'extracted_voices_streaming_part2_midamp.ogg'
OUTPUT_FILE = 'extracted_voices_streaming_part2_midamp_a.ogg'

CAM_A_MAP = {
    'enhanced_output_1h30m_end20231010_125918_tp0008.ogg': '20231010_125918',
    '20231010_144510_tp00009amp.ogg': '20231010_144510'
}

SR = 22050
BLOCK_SIZE_SEC = 10
TARGET_SAMPLES = int(BLOCK_SIZE_SEC * SR)

def load_cam_at_time(target_t, file_list, duration):
    """Lifts a block from the raw-amp camera files based on the timeline."""
    for f in file_list:
        name = os.path.basename(f)
        start_t = None
        if name in CAM_A_MAP:
            start_t = datetime.strptime(CAM_A_MAP[name], '%Y%m%d_%H%M%S')
        else:
            match = re.search(r'(\d{8}_\d{6})', name)
            if match:
                start_t = datetime.strptime(match.group(1), '%Y%m%d_%H%M%S')

        if start_t:
            file_dur = librosa.get_duration(path=f)
            end_t = start_t + timedelta(seconds=file_dur)
            if start_t <= target_t <= end_t:
                offset = (target_t - start_t).total_seconds()
                try:
                    # Forensic load with exact sample count
                    y, _ = librosa.load(f, sr=SR, offset=offset, duration=duration)
                    if len(y.shape) > 1: y = librosa.to_mono(y)

                    # Ensure exact length for broadcasting
                    if len(y) < TARGET_SAMPLES:
                        y = np.pad(y, (0, TARGET_SAMPLES - len(y)))
                    elif len(y) > TARGET_SAMPLES:
                        y = y[:TARGET_SAMPLES]
                    return y
                except:
                    return None
    return None

def create_midamp_mix():
    print(f"--- Creating Mid-Amp Mix: {OUTPUT_FILE} ---")

    if not os.path.exists(STREAMING_PART2_FILE):
        print(f"Error: {STREAMING_PART2_FILE} not found.")
        return

    raw_files_a = glob.glob("*tp000*[89]*.ogg")
    raw_files_b = glob.glob("*tp000*[3][0-9]*amp*.ogg") + glob.glob("enhanced_audio_*tp00034.ogg")

    start_target = datetime.strptime(START_TIME_STR, '%Y%m%d_%H%M%S')
    total_duration = librosa.get_duration(path=STREAMING_PART2_FILE)
    duration_secs = int(total_duration)

    with sf.SoundFile(OUTPUT_FILE, mode='w', samplerate=SR, channels=2) as out:
        for sec in range(0, duration_secs, BLOCK_SIZE_SEC):
            current_t = start_target + timedelta(seconds=sec)

            # 1. Load the denoised voice stream
            try:
                # Load as stereo
                y_stream, _ = librosa.load(STREAMING_PART2_FILE, sr=SR, offset=sec, duration=BLOCK_SIZE_SEC, mono=False)

                # Check for end-of-file short blocks and pad
                if y_stream.shape[1] < TARGET_SAMPLES:
                    padding = TARGET_SAMPLES - y_stream.shape[1]
                    y_stream = np.pad(y_stream, ((0,0), (0, padding)))
            except Exception as e:
                print(f"\nFinished at {sec}s (End of File).")
                break

            # 2. Load the corresponding raw-amp segments
            y_raw_a = load_cam_at_time(current_t, raw_files_a, BLOCK_SIZE_SEC)
            y_raw_b = load_cam_at_time(current_t, raw_files_b, BLOCK_SIZE_SEC)

            # 3. Perform 50/50 Mix with Broadcast Safety
            # Process Cam A (Left)
            if y_raw_a is not None:
                mixed_a = (0.5 * y_stream[0]) + (0.5 * y_raw_a)
            else:
                mixed_a = y_stream[0]

            # Process Cam B (Right)
            if y_raw_b is not None:
                mixed_b = (0.5 * y_stream[1]) + (0.5 * y_raw_b)
            else:
                mixed_b = y_stream[1]

            # Stack back to Stereo
            combined = np.vstack((mixed_a, mixed_b)).T
            out.write(combined)

            if sec % 60 == 0:
                print(f"  Mixing Progress: {sec//60} / {duration_secs//60} minutes...", end='\r')

    print(f"\nMix complete. Output: {OUTPUT_FILE}")

if __name__ == "__main__":
    create_midamp_mix()
