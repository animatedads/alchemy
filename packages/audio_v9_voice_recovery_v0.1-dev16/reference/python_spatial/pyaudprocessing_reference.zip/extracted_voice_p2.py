import os
import glob
import numpy as np
import librosa
import soundfile as sf
import re
from datetime import datetime, timedelta

# --- CONFIGURATION ---
# We preserve the mapping for the Cam 8 segment to handle the crossover at 14:31:44
CAM_A_MAP = {
    'enhanced_output_1h30m_end20231010_125918_tp0008.ogg': '20231010_142918',
    '20231010_144510_tp00009amp.ogg': '20231010_144510'
}

SR = 22050
BLOCK_SIZE_SEC = 10 # Matches the original windowing strategy

def load_at_time(target_t, file_list, duration):
    for f in file_list:
        name = os.path.basename(f)
        start_t = None
        # Check explicit map first
        if name in CAM_A_MAP:
            start_t = datetime.strptime(CAM_A_MAP[name], '%Y%m%d_%H%M%S')
        else:
            # Fallback to filename timestamp detection
            match = re.search(r'(\d{8}_\d{6})', name)
            if match:
                start_t = datetime.strptime(match.group(1), '%Y%m%d_%H%M%S')

        if start_t:
            # Check if target time falls within this file's duration
            file_dur = librosa.get_duration(path=f)
            end_t = start_t + timedelta(seconds=file_dur)
            if start_t <= target_t <= end_t:
                offset = (target_t - start_t).total_seconds()
                try:
                    y, _ = librosa.load(f, sr=SR, offset=offset, duration=duration)
                    target_samples = int(duration * SR)
                    if len(y) < target_samples:
                        y = np.pad(y, (0, target_samples - len(y)))
                    return y
                except:
                    return None
    return None

def sync_and_extract_part2():
    print("--- Voices Extraction: Part 2 (Post-14:31:44) ---")

    # Selecting the A-series (Cams 8/9) and B-series (Cams 34-38)
    files_a = glob.glob("*tp000*[89]*.ogg")
    files_b = glob.glob("*tp000*[3][0-9]*amp*.ogg") + glob.glob("enhanced_audio_*tp00034.ogg")

    # Timeline calculation: 10:13:38 + 4h18m06s = 14:31:44
    start_target = datetime.strptime('20231010_143144', '%Y%m%d_%H%M%S')
    # Ending at the conclusion of Cam 38 (approx 16:53:00)
    end_target = datetime.strptime('20231010_165300', '%Y%m%d_%H%M%S')
    duration_secs = int((end_target - start_target).total_seconds())

    output_file = 'extracted_voices_streaming_part2.wav'

    with sf.SoundFile(output_file, mode='w', samplerate=SR, channels=2) as out:
        for sec in range(0, duration_secs, BLOCK_SIZE_SEC):
            current_t = start_target + timedelta(seconds=sec)

            y_a = load_at_time(current_t, files_a, BLOCK_SIZE_SEC)
            y_b = load_at_time(current_t, files_b, BLOCK_SIZE_SEC)

            # Perform Spectral Coherence Masking if both sources are active
            if y_a is not None and y_b is not None:
                stft_a = librosa.stft(y_a)
                stft_b = librosa.stft(y_b)
                mag_a, _ = librosa.magphase(stft_a)
                mag_b, _ = librosa.magphase(stft_b)

                # Coherence Mask: Retain only overlapping frequencies (common voices)
                mask = np.minimum(mag_a, mag_b) / (np.maximum(mag_a, mag_b) + 1e-6)
                mask = np.power(mask, 1.5) # Hardness tuning factor

                clean_a = librosa.istft(stft_a * mask)
                clean_b = librosa.istft(stft_b * mask)

                min_len = min(len(clean_a), len(clean_b))
                combined = np.vstack((clean_a[:min_len], clean_b[:min_len])).T
                out.write(combined)
            else:
                # Fill gaps with silence to maintain timeline integrity
                silence = np.zeros((int(BLOCK_SIZE_SEC * SR), 2))
                out.write(silence)

            if sec % 60 == 0:
                print(f"  Processed {sec//60} / {duration_secs//60} minutes...", end='\r')

    print(f"\nExtraction Part 2 complete. Output: {output_file}")

if __name__ == "__main__":
    sync_and_extract_part2()
