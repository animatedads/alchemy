#!/usr/bin/env python3
"""
calibrate_tdoa_event.py
=======================
Known-event TDOA calibration helper for V10.1 dual-mic site models.

Use this when you have exported the same short absolute time window from two
camera/mic sources and you know where the sound happened, e.g. an alarm/claxon
above the stair CCTV.

It measures:
  - GCC-PHAT sample lag
  - envelope lag
  - peak/onset timing
  - per-channel RMS/peak
  - sample-rate/channel information

It writes a calibration JSON that can be attached to the site model and used to
refine Cam A / Cam B coordinates later.

Example:
  python calibrate_tdoa_event.py \
    --cam-a exports/...Cam_A....wav \
    --cam-b exports/...Cam_B....wav \
    --cam-a-json exports/...Cam_A....wav.json \
    --cam-b-json exports/...Cam_B....wav.json \
    --event-label "stair_alarm_claxon" \
    --known-zone "stairwell" \
    --known-x 5.8 --known-y 1.8 --known-z 2.8 \
    --out fcpaphos_alarm_105524_tdoa_calibration.json
"""

from __future__ import annotations

import argparse
import json
import math
import os
from datetime import datetime
from typing import Dict, Any, Tuple

import numpy as np
import soundfile as sf
from scipy import signal

try:
    import librosa
except Exception:
    librosa = None


def load_mono(path: str, target_sr: int) -> Tuple[np.ndarray, int, Dict[str, Any]]:
    y, sr = sf.read(path, always_2d=True)
    info = {
        "path": path,
        "native_sr": int(sr),
        "native_channels": int(y.shape[1]),
        "native_samples": int(y.shape[0]),
        "native_duration_sec": float(y.shape[0] / sr),
    }

    y = np.mean(y, axis=1).astype(np.float64)
    y = np.nan_to_num(y)

    if sr != target_sr:
        if librosa is None:
            # scipy fallback
            n = int(round(len(y) * target_sr / sr))
            y = signal.resample(y, n)
        else:
            y = librosa.resample(y, orig_sr=sr, target_sr=target_sr)
        sr = target_sr

    info["analysis_sr"] = int(sr)
    info["analysis_samples"] = int(len(y))
    info["analysis_duration_sec"] = float(len(y) / sr)
    info["rms_dbfs"] = 20 * math.log10(max(float(np.sqrt(np.mean(y*y) + 1e-12)), 1e-12))
    info["peak"] = float(np.max(np.abs(y)) if len(y) else 0.0)
    return y.astype(np.float64), sr, info


def butter_band(y: np.ndarray, sr: int, lo: float, hi: float) -> np.ndarray:
    hi = min(hi, sr / 2 - 100)
    lo = max(20, lo)
    if hi <= lo:
        return y
    b, a = signal.butter(4, [lo / (sr / 2), hi / (sr / 2)], btype="band")
    return signal.filtfilt(b, a, y)


def gcc_phat(y_a: np.ndarray, y_b: np.ndarray, sr: int, max_lag_sec: float) -> Dict[str, Any]:
    n = min(len(y_a), len(y_b))
    y_a = y_a[:n] - np.mean(y_a[:n])
    y_b = y_b[:n] - np.mean(y_b[:n])

    if not np.any(y_a) or not np.any(y_b):
        return {"lag_samples": 0, "lag_sec": 0.0, "confidence": 0.0}

    nfft = 1 << int(np.ceil(np.log2(max(2, len(y_a) + len(y_b) - 1))))
    A = np.fft.rfft(y_a, nfft)
    B = np.fft.rfft(y_b, nfft)
    R = A * np.conj(B)
    cc = np.fft.irfft(R / (np.abs(R) + 1e-10), nfft)

    max_lag = int(max_lag_sec * sr)
    search = np.concatenate([cc[-max_lag:], cc[:max_lag + 1]])
    abs_search = np.abs(search)

    idx = int(np.argmax(abs_search))
    lag = idx - max_lag
    peak = float(abs_search[idx])
    med = float(np.median(abs_search) + 1e-12)
    conf = peak / med

    return {
        "lag_samples": int(lag),
        "lag_sec": float(lag / sr),
        "lag_ms": float(lag / sr * 1000),
        "confidence": float(conf),
        "convention": "positive lag means Cam B appears later than Cam A in A*conj(B) GCC-PHAT convention"
    }


def envelope_lag(y_a: np.ndarray, y_b: np.ndarray, sr: int, max_lag_sec: float) -> Dict[str, Any]:
    n = min(len(y_a), len(y_b))
    y_a = y_a[:n]
    y_b = y_b[:n]

    ea = np.abs(signal.hilbert(y_a))
    eb = np.abs(signal.hilbert(y_b))

    # Smooth envelope enough to track alarm onset/shape rather than carrier phase.
    kernel = max(5, int(0.015 * sr) | 1)
    ea = signal.medfilt(ea, kernel_size=kernel)
    eb = signal.medfilt(eb, kernel_size=kernel)

    ea = (ea - np.mean(ea)) / (np.std(ea) + 1e-9)
    eb = (eb - np.mean(eb)) / (np.std(eb) + 1e-9)

    corr = signal.correlate(ea, eb, mode="full")
    lags = np.arange(-len(eb) + 1, len(ea))
    mask = np.abs(lags) <= int(max_lag_sec * sr)

    sub = corr[mask]
    sub_lags = lags[mask]
    idx = int(np.argmax(sub))
    lag = int(sub_lags[idx])
    score = float(sub[idx] / max(1, n))

    return {
        "lag_samples": lag,
        "lag_sec": float(lag / sr),
        "lag_ms": float(lag / sr * 1000),
        "score": score,
        "convention": "positive lag means Cam B envelope appears later than Cam A"
    }


def peak_time(y: np.ndarray, sr: int) -> Dict[str, Any]:
    env = np.abs(signal.hilbert(y))
    kernel = max(5, int(0.02 * sr) | 1)
    env = signal.medfilt(env, kernel_size=kernel)
    idx = int(np.argmax(env))
    return {"peak_sample": idx, "peak_sec": float(idx / sr)}


def read_json(path: str | None) -> Dict[str, Any]:
    if not path:
        return {}
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def main() -> None:
    ap = argparse.ArgumentParser(description="Calibrate a known dual-mic event for V10.1 site models.")
    ap.add_argument("--cam-a", required=True)
    ap.add_argument("--cam-b", required=True)
    ap.add_argument("--cam-a-json")
    ap.add_argument("--cam-b-json")
    ap.add_argument("--event-label", default="known_event")
    ap.add_argument("--known-zone", default="")
    ap.add_argument("--known-x", type=float)
    ap.add_argument("--known-y", type=float)
    ap.add_argument("--known-z", type=float)
    ap.add_argument("--analysis-sr", type=int, default=16000)
    ap.add_argument("--band-lo", type=float, default=500.0)
    ap.add_argument("--band-hi", type=float, default=4000.0)
    ap.add_argument("--max-lag-ms", type=float, default=1000.0)
    ap.add_argument("--out", default="tdoa_calibration_event.json")
    args = ap.parse_args()

    y_a, sr, info_a = load_mono(args.cam_a, args.analysis_sr)
    y_b, sr, info_b = load_mono(args.cam_b, args.analysis_sr)

    n = min(len(y_a), len(y_b))
    y_a = y_a[:n]
    y_b = y_b[:n]

    ya_band = butter_band(y_a, sr, args.band_lo, args.band_hi)
    yb_band = butter_band(y_b, sr, args.band_lo, args.band_hi)

    max_lag_sec = args.max_lag_ms / 1000.0

    result = {
        "event_label": args.event_label,
        "created_at": datetime.now().isoformat(timespec="seconds"),
        "known_location": {
            "zone": args.known_zone,
            "x": args.known_x,
            "y": args.known_y,
            "z": args.known_z,
        },
        "cam_a": {
            "audio": info_a,
            "sidecar": read_json(args.cam_a_json),
            "peak_time": peak_time(ya_band, sr),
        },
        "cam_b": {
            "audio": info_b,
            "sidecar": read_json(args.cam_b_json),
            "peak_time": peak_time(yb_band, sr),
        },
        "analysis": {
            "analysis_sr": sr,
            "duration_sec": float(n / sr),
            "bandpass_hz": [args.band_lo, args.band_hi],
            "gcc_phat": gcc_phat(ya_band, yb_band, sr, max_lag_sec),
            "envelope_lag": envelope_lag(ya_band, yb_band, sr, max_lag_sec),
            "notes": [
                "Tonal alarms can give ambiguous phase/GCC peaks.",
                "Envelope lag is often more useful for claxon/alarm onset timing.",
                "Use this event as a calibration constraint: predicted TDOA at known location should match measured lag."
            ]
        }
    }

    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(result, f, indent=2, sort_keys=True)

    print(json.dumps(result["analysis"], indent=2))
    print(f"Wrote {args.out}")


if __name__ == "__main__":
    main()
