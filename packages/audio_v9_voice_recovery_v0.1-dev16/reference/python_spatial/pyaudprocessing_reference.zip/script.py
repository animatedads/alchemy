import os
import glob
import re
import numpy as np
import librosa
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from datetime import datetime, timedelta

# --- HARDCODED TIMESTAMPS ---
# Direct mapping of filename -> Exact Start Time
FIXED_MAP = {
    # tp00006 Group (Base: 09:39:12)
    'enhanced_output0-30tp00006.ogg': '20231010_093912',
    'enhanced_output30-45tp00006.ogg': '20231010_100912',
    'enhanced_output45-1htp00006.ogg': '20231010_102412',
    'enhanced_output1h-01h15tp00006.ogg': '20231010_103912',

    # tp0007 Group (Base: 11:14:49)
    'enhanced_output0m-30mtp0007.ogg': '20231010_111449',
    'enhanced_output30m-1htp0007.ogg': '20231010_114449',
    'enhanced_output1h-1h30mtp0007.ogg': '20231010_121449',
    'enhanced_output1h30m-endtp0007.ogg': '20231010_124449',

    # tp0008 Group (Base: 12:59:18)
    'enhanced_output_0m-30m20231010_125918_tp0008.ogg': '20231010_125918',
    'enhanced_output_30m-1h_20231010_125918_tp0008.ogg': '20231010_132918',
    'enhanced_output_1h-1h30m_20231010_125918_tp0008.ogg': '20231010_135918',
    'enhanced_output_1h30m_end20231010_125918_tp0008.ogg': '20231010_142918',
}

# General Settings
FPS = 5
SR_GLOBAL = 22050
MIC_A_POS = [5, 10]
MIC_B_POS = [10, 5]

def extract_timestamp(filename):
    name = os.path.basename(filename)

    # 1. Try Hardcoded Map First (Camera A)
    if name in FIXED_MAP:
        return datetime.strptime(FIXED_MAP[name], '%Y%m%d_%H%M%S')

    # 2. Camera B/N (Standard timestamps)
    match_ts = re.search(r'(\d{8}_\d{6})', name)
    if match_ts:
        return datetime.strptime(match_ts.group(1), '%Y%m%d_%H%M%S')

    return None

def get_file_metadata(pattern, label, target_is_a=False):
    metadata = []
    files = sorted(glob.glob(pattern))
    print(f"Scanning {label}...")
    for f in files:
        name = os.path.basename(f)
        # Check if it's a B-ID (25-34)
        is_b = re.search(r'tp0*(2[5-9]|3[0-4])', name)

        if target_is_a and is_b: continue
        if not target_is_a and not is_b: continue

        ts = extract_timestamp(f)
        if ts:
            try:
                duration = librosa.get_duration(path=f)
                metadata.append({'path': f, 'start': ts, 'end': ts + timedelta(seconds=duration)})
                print(f"  [FIXED] {name} -> Sync: {ts:%H:%M:%S}")
            except: pass
    return metadata

def run_analysis():
    print("--- Initializing Forensic Heatmap (HARDCODED TIMING) ---")
    meta_a = get_file_metadata("*tp000*[678].ogg", "Camera A", target_is_a=True)
    meta_b = get_file_metadata("*tp000*[23][0-9].ogg", "Camera B/N", target_is_a=False)

    if not meta_a or not meta_b: return

    global_start = min(m['start'] for m in meta_a + meta_b)
    global_end = max(m['end'] for m in meta_a + meta_b)
    total_seconds = int((global_end - global_start).total_seconds())

    fig, ax = plt.subplots(figsize=(8, 8))
    x_g, y_g = np.meshgrid(np.linspace(0, 10, 50), np.linspace(0, 10, 50))
    d_a = np.sqrt((x_g-MIC_A_POS[0])**2 + (y_g-MIC_A_POS[1])**2)
    d_b = np.sqrt((x_g-MIC_B_POS[0])**2 + (y_g-MIC_B_POS[1])**2)

    def get_energy(curr_time, metadata):
        energy = 0.0
        for m in metadata:
            if m['start'] <= curr_time <= m['end']:
                off = (curr_time - m['start']).total_seconds()
                try:
                    y, _ = librosa.load(m['path'], sr=SR_GLOBAL, offset=off, duration=1/FPS)
                    if len(y) > 0: energy += np.sqrt(np.mean(y**2))
                except: pass
        return energy

    def update(frame_idx):
        ax.clear()
        curr_time = global_start + timedelta(seconds=frame_idx/FPS)
        e_a, e_b = get_energy(curr_time, meta_a), get_energy(curr_time, meta_b)

        z = (e_a / (d_a + 0.5)) + (e_b / (d_b + 0.5))
        ax.imshow(z, extent=[0, 10, 0, 10], origin='lower', cmap='magma', vmin=0, vmax=0.02)

        ax.set_title(f"Forensic Heatmap | {curr_time:%Y-%m-%d %H:%M:%S}")
        ax.scatter(*MIC_A_POS, c='cyan', s=120, edgecolors='white', label='Door')
        ax.scatter(*MIC_B_POS, c='lime', s=120, edgecolors='white', label='Kitchen')

        if e_a > 0.003: ax.text(MIC_A_POS[0], MIC_A_POS[1]+0.6, "SOUND", color='cyan', weight='bold', ha='center')
        if e_b > 0.003: ax.text(MIC_B_POS[0], MIC_B_POS[1]+0.6, "SOUND", color='lime', weight='bold', ha='center')
        ax.legend(loc='lower right')

    print(f"\nRendering {total_seconds/60:.1f} minutes...")
    ani = animation.FuncAnimation(fig, update, frames=range(0, total_seconds * FPS, 2))
    ani.save('forensic_heatmap_hardcoded.mp4', writer='ffmpeg', fps=2)
    print("Export Complete.")

if __name__ == "__main__":
    run_analysis()
