#!/usr/bin/env python3
"""
dual_feed_enhance_v3_helper_consistent.py
=======================================
Forensic Audio Enhancement — Dual-Feed Pipeline v3 using ForensicHelper plumbing

Purpose of this compatibility edition:
- Keep the original V3 DSP technique intact.
- Replace the duplicated YAML/camera/time/duration code with forensic_helper.py.
- Use the same camera identification, tier matching, duration handling, stream loading,
  time parsing, and YAML output registration style across V3/V4/V5/V6.

V3 DSP retained: GCC-PHAT + phase-coherence mask.
"""

import os
import argparse
import yaml
import numpy as np
import soundfile as sf
import librosa
from datetime import datetime, timedelta
from scipy.fftpack import fft, ifft
from scipy.ndimage import uniform_filter1d


from forensic_helper import ForensicHelper as fh

SR = 22050
BLOCK_SEC = 8.0

# ---------------------------------------------------------------------------
# HELPER-CONSISTENT PLUMBING
# ---------------------------------------------------------------------------

def parse_dt(s):
    dt = fh.parse_dt(s)
    if not dt:
        raise ValueError(f"Time data {s!r} does not match recognized formats")
    return dt


def determine_camera(yaml_type, path=""):
    cam = fh.identify_camera(path, yaml_type)
    return "cam_b" if cam == "Cam B" else "cam_a"


def matches_tier(yaml_type, target_tier, path=""):
    yt = str(yaml_type or "").lower()
    pt = str(path or "").lower()
    tt = str(target_tier or "").lower()
    blob = yt + " " + pt

    if tt == "amp32":
        return "+32db" in blob or "amp32" in blob or "raw amp +32" in blob
    if tt == "plus20":
        return "+20db" in blob or "+20" in blob or "plus20" in blob or "ampamp" in blob
    if tt == "enhanced":
        return "enhanced" in blob and "+20" not in blob and "plus20" not in blob
    if tt == "original":
        return "original" in blob
    return tt in blob


def load_project_streams(yaml_path, tier):
    """Load all valid streams once using ForensicHelper, then apply old tier semantics."""
    raw_streams = fh.get_active_streams(yaml_path, datetime.min, datetime.max)
    streams = []
    for s in raw_streams:
        label = s.get("filter") or s.get("type") or ""
        path = s.get("path", "")
        if matches_tier(label, tier, path):
            streams.append(s)

    streams.sort(key=lambda s: (s.get("start_dt"), s.get("cam_id"), s.get("path")))
    return streams


def get_stream_for_time(streams, cam_id, current_t):
    """Return the active stream for a camera at current_t, preferring the latest start."""
    candidates = [
        s for s in streams
        if s.get("cam_id") == cam_id and s.get("start_dt") <= current_t < s.get("end_dt")
    ]
    if not candidates:
        return None
    return max(candidates, key=lambda s: s.get("start_dt"))


def load_audio_segment(stream_info, target_t, duration_sec, sr=SR):
    if not stream_info:
        return None
    y = fh.read_stream_block(stream_info, target_t, duration_sec, sr)
    if y is None or not np.any(y):
        return None
    target_len = int(duration_sec * sr)
    if len(y) < target_len:
        y = np.pad(y, (0, target_len - len(y)))
    return y[:target_len]


def handle_time_arg(time_str, default_dt):
    if not time_str:
        return default_dt
    if "-" in str(time_str):
        return parse_dt(time_str)
    parts = str(time_str).split(":")
    if len(parts) == 2:
        time_str = f"{time_str}:00"
    return parse_dt(f"{default_dt.strftime('%Y-%m-%d')} {time_str}")


def safe_output_format(out_path):
    fmt = "OGG" if out_path.lower().endswith(".ogg") else None
    subtype = "VORBIS" if fmt == "OGG" else None
    return fmt, subtype


def ensure_output_dir(out_path):
    d = os.path.dirname(os.path.abspath(out_path))
    if d:
        os.makedirs(d, exist_ok=True)


def register_output_in_yaml(yaml_path, out_path, start_time, label):
    """Register/update generated output in the YAML consistently across old pipelines."""
    with open(yaml_path, "r") as f:
        config = yaml.safe_load(f) or {}
    config.setdefault("files", [])

    new_entry = {
        "path": out_path,
        "start": start_time.strftime("%Y-%m-%d %H:%M:%S"),
        "type": label,
    }

    updated = False
    for entry in config["files"]:
        if os.path.normpath(entry.get("path", "")) == os.path.normpath(out_path):
            entry.update(new_entry)
            updated = True
            break
    if not updated:
        config["files"].append(new_entry)

    config["files"].sort(key=lambda x: x.get("start", ""))
    with open(yaml_path, "w") as f:
        yaml.dump(config, f, default_flow_style=False, sort_keys=False)


def make_three_channel(a, b, c, sr=SR):
    n = int(BLOCK_SEC * sr)
    def fix(y):
        if y is None:
            return np.zeros(n, dtype=np.float32)
        if len(y) < n:
            y = np.pad(y, (0, n - len(y)))
        return np.nan_to_num(y[:n], nan=0.0, posinf=0.0, neginf=0.0)
    return np.vstack((fix(a), fix(b), fix(c))).T

# ---------------------------------------------------------------------------
# RADAR / SONAR DSP TECHNIQUES
# ---------------------------------------------------------------------------

def gcc_phat_align(sig, refsig, fs=22050, max_tau=0.15):
    """Align sig to refsig using Generalized Cross-Correlation Phase Transform (GCC-PHAT)."""
    n = sig.shape[0] + refsig.shape[0]
    SIG = fft(sig, n=n)
    REFSIG = fft(refsig, n=n)
    R = SIG * np.conj(REFSIG)

    denom = np.maximum(np.abs(R), 1e-6)
    cc = np.real(ifft(R / denom))

    max_shift = int(max_tau * fs)
    cc = np.concatenate((cc[-max_shift:], cc[:max_shift+1]))
    shift = np.argmax(cc) - max_shift

    return np.roll(sig, shift)

def phase_coherence_mask(y_a, y_b, n_fft=2048):
    """
    Phase-coherence Wiener mask (RF interferometry approach).
    Keeps only the frequencies that are phase-aligned across both feeds.
    """
    if len(y_a) < n_fft or len(y_b) < n_fft:
        return y_a

    S_a = librosa.stft(y_a, n_fft=n_fft)
    S_b = librosa.stft(y_b, n_fft=n_fft)

    # Cross-power spectrum
    cps = S_a * np.conj(S_b)
    mag_a, mag_b = np.abs(S_a), np.abs(S_b)

    # Coherence score (0 to 1)
    coherence = np.abs(cps) / (mag_a * mag_b + 1e-8)

    # Apply coherence as a mask to isolate the "beam"
    S_center = S_a * coherence

    # CRITICAL FIX: Pass exactly len(y_a) so ISTFT doesn't truncate samples!
    return librosa.istft(S_center, length=len(y_a))


# ---------------------------------------------------------------------------
# MAIN PROCESSOR
# ---------------------------------------------------------------------------

def run_v3_pipeline(yaml_path, tier, start_time, end_time, out_path):
    sr = SR
    block_sec = BLOCK_SEC
    streams = load_project_streams(yaml_path, tier)

    if not streams:
        raise SystemExit(f"[!] No streams found for tier {tier!r} in {yaml_path}")

    ensure_output_dir(out_path)
    fmt, subtype = safe_output_format(out_path)

    print(f"[*] MVDR Beamformer v3 (Helper-Consistent YAML Engine)")
    print(f"[*] Processing: {start_time} to {end_time}")
    print(f"[*] Target Tier: {tier!r}")
    print(f"[*] Streams loaded via ForensicHelper: {len(streams)}")


    with sf.SoundFile(out_path, mode="w", samplerate=sr, channels=3, format=fmt, subtype=subtype) as out:
        current_t = start_time
        blocks_dual = 0
        blocks_mono = 0
        blocks_silent = 0

        while current_t < end_time:
            stream_a = get_stream_for_time(streams, "Cam A", current_t)
            stream_b = get_stream_for_time(streams, "Cam B", current_t)

            y_a = load_audio_segment(stream_a, current_t, block_sec, sr)
            y_b = load_audio_segment(stream_b, current_t, block_sec, sr)

            if y_a is not None and y_b is not None:
                blocks_dual += 1
                y_a_aligned = gcc_phat_align(y_a, y_b, fs=sr)
                center_beam = phase_coherence_mask(y_a_aligned, y_b)
                chunk = make_three_channel(y_a_aligned, y_b, center_beam, sr)

            elif y_a is not None:
                blocks_mono += 1
                chunk = make_three_channel(y_a, y_a, y_a, sr)

            elif y_b is not None:
                blocks_mono += 1
                chunk = make_three_channel(y_b, y_b, y_b, sr)

            else:
                blocks_silent += 1
                chunk = np.zeros((int(block_sec * sr), 3), dtype=np.float32)

            out.write(chunk)
            current_t += timedelta(seconds=block_sec)
            print(
                f"  Progress: {current_t:%Y-%m-%d %H:%M:%S} | Dual: {blocks_dual} Mono: {blocks_mono} Silent: {blocks_silent}",
                end="\r",
            )

    print(f"\n\n{'='*60}")
    print(f"  Audio Generation Complete: {out_path}")
    print(f"  Dual blocks : {blocks_dual}")
    print(f"  Mono blocks : {blocks_mono}")
    print(f"  Silent      : {blocks_silent}")

    register_output_in_yaml(
        yaml_path,
        out_path,
        start_time,
        f"Coverage - Dual-Feed Master v3 ({tier})",
    )
    print(f"  YAML Updated: {yaml_path}")
    print(f"{'='*60}")


def main():
    parser = argparse.ArgumentParser(description="Dual-feed forensic audio enhancement v3 using ForensicHelper plumbing")
    parser.add_argument("--yaml", required=True, help="Project YAML configuration")
    parser.add_argument("--tier", default="amp32", help="Tier: original, amp32, enhanced, plus20")
    parser.add_argument("--start", help="YYYY-MM-DD HH:MM:SS, YYYY-MM-DD HH:MM, HH:MM, or HH:MM:SS")
    parser.add_argument("--end", help="YYYY-MM-DD HH:MM:SS, YYYY-MM-DD HH:MM, HH:MM, or HH:MM:SS")
    parser.add_argument("--out", default="master_v3_beam.wav")
    args = parser.parse_args()

    streams = load_project_streams(args.yaml, args.tier)
    if not streams:
        raise SystemExit(f"[!] No streams found for tier {args.tier!r} in {args.yaml}")

    starts = sorted(s["start_dt"] for s in streams)
    ends = sorted(s["end_dt"] for s in streams)
    t0 = handle_time_arg(args.start, starts[0])
    t1 = handle_time_arg(args.end, ends[-1])

    if t1 <= t0:
        raise SystemExit(f"[!] Invalid time window: {t0} -> {t1}")

    run_v3_pipeline(args.yaml, args.tier, t0, t1, args.out)


if __name__ == "__main__":
    main()
