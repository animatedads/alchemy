import sqlite3
import os
import yaml
import argparse
from datetime import datetime

def inject_forensic_markers(yaml_path):
    if not os.path.exists(yaml_path):
        print(f"Error: {yaml_path} not found.")
        return

    # Determine the database name based on the YAML filename
    project_id = os.path.splitext(os.path.basename(yaml_path))[0]
    db_path = f"{project_id}_audit.db"

    if not os.path.exists(db_path):
        print(f"Error: Database {db_path} not found.")
        return

    print(f"[*] Processing project: {project_id}")

    with open(yaml_path, 'r') as f:
        config = yaml.safe_load(f)

    if 'files' not in config:
        print("Error: No 'files' section found in YAML.")
        return

    markers_to_inject = {}

    # 1. Map out the unique switch points from the YAML for ALL files
    for entry in config['files']:
        path = entry.get('path', '')
        start_raw = entry.get('start', '')
        file_type = entry.get('type', 'Unknown Track')

        if not path or not start_raw:
            continue

        try:
            dt = datetime.strptime(start_raw, '%Y-%m-%d %H:%M:%S')
            ts = dt.strftime('%Y%m%d%H%M%S')

            # Create a clear marker text combining the track type and the filename
            filename = os.path.basename(path)
            marker_text = f"-- FILE SYNC: {file_type} [{filename}] --"

            # Handle multiple files starting at the exact same timestamp
            if ts in markers_to_inject:
                existing_text, _ = markers_to_inject[ts]
                if marker_text not in existing_text:
                    markers_to_inject[ts] = (f"{existing_text} | {marker_text}", path)
            else:
                markers_to_inject[ts] = (marker_text, path)

        except ValueError:
            print(f"Skipping entry with invalid date format: {start_raw}")

    # 2. Inject into the SQLite Database
    with sqlite3.connect(db_path) as conn:
        c = conn.cursor()

        # Determine column name ('text' or 'content') dynamically
        c.execute("PRAGMA table_info(transcript)")
        columns = [info[1] for info in c.fetchall()]
        text_col = 'text' if 'text' in columns else 'content'

        now_str = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        inserted_count = 0

        for ts, (text, source_file) in markers_to_inject.items():
            # Check if a row already exists for this timestamp
            c.execute(f"SELECT {text_col} FROM transcript WHERE ts=?", (ts,))
            existing = c.fetchone()

            if existing:
                # Append if not already there
                if text not in existing[0]:
                    new_val = f"{existing[0]} | {text}"
                    c.execute(f"UPDATE transcript SET {text_col}=? WHERE ts=?", (new_val, ts))
                    inserted_count += 1
            else:
                # Fresh insert
                c.execute(f"INSERT INTO transcript (ts, {text_col}) VALUES (?, ?)", (ts, text))
                inserted_count += 1

            # Log to audit trail
            c.execute("PRAGMA table_info(audit_log)")
            if c.fetchall():
                c.execute(f"""
                    INSERT INTO audit_log (edit_time, line_ts, old_text, new_text, user, source_file)
                    VALUES (?, ?, 'SYSTEM_SYNC', ?, 'FORENSIC_SYNC', ?)
                """, (now_str, ts, text, source_file))

        conn.commit()

    print(f"\n[!] SUCCESS: {inserted_count} sync markers updated/inserted in {db_path}.")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--yaml", required=True, help="Path to project YAML file (e.g., fcpaphos_project.yaml)")
    args = parser.parse_args()

    inject_forensic_markers(args.yaml)
