import os
import sys
import yaml
import curses
import pygame
import soundfile as sf
import sqlite3
import hashlib
import re
from datetime import datetime, timedelta

class ForensicShuttle:
    def __init__(self, config_path):
        self.config_path = config_path
        p_name = os.path.splitext(os.path.basename(config_path))[0]
        self.db_path = f"{p_name}_audit.db"

        with open(config_path, 'r') as f:
            self.config = yaml.safe_load(f)

        self.users = self.config.get('users', {})
        self.macros = self.config.get('macros', {})
        self.audio_map, self.transcript = [], []

        self.volume = 0.7
        self.current_page = 0
        self.active_file_idx = 0
        self.history_idx = -1
        self.is_playing = False
        self.last_sync_time = None
        self.loop_start = self.loop_end = None
        self.user = None
        self.user_perm = "READ"

        # --- Search Engine State ---
        self.last_search_query = ""
        self.search_matches = []
        self.search_match_idx = -1

        pygame.init()
        pygame.mixer.init(frequency=22050, size=-16, channels=2, buffer=512)

        self.load_metadata()
        self.sync_db()
        self.current_time = min(f['start_dt'] for f in self.audio_map) if self.audio_map else datetime.now()

    def verify_password(self, username, password):
        if username not in self.users: return False
        stored = self.users[username]['hash']
        salt, hash_val = stored.split('$')
        return hashlib.sha256((salt + password).encode()).hexdigest() == hash_val

    def load_metadata(self):
        for f in self.config.get('files', []):
            try:
                start = datetime.strptime(f['start'], '%Y-%m-%d %H:%M:%S')
                dur = sf.info(f['path']).duration if not f['path'].lower().endswith('.mp4') else 1724.0
                f.update({'start_dt': start, 'end_dt': start + timedelta(seconds=dur)})
                self.audio_map.append(f)
            except Exception:
                pass

    def sync_db(self):
        with sqlite3.connect(self.db_path) as conn:
            c = conn.cursor()
            c.execute('CREATE TABLE IF NOT EXISTS transcript (id INTEGER PRIMARY KEY, ts TEXT, content TEXT)')
            c.execute("CREATE TABLE IF NOT EXISTS audit_log (id INTEGER PRIMARY KEY, edit_time TEXT, line_ts TEXT, old_text TEXT, new_text TEXT, user TEXT, source_file TEXT)")
            self.transcript = [{'ts': r[0], 'text': r[1]} for r in c.execute("SELECT ts, content FROM transcript ORDER BY ts ASC").fetchall()]

    def get_source(self):
        avail = [f for f in self.audio_map if f['start_dt'] <= self.current_time <= f['end_dt']]
        return avail[self.active_file_idx % len(avail)] if avail else None

    def play_sync(self):
        src = self.get_source()
        pygame.mixer.music.stop()
        if not src:
            self.is_playing = False
            return
        off = (self.current_time - src['start_dt']).total_seconds()
        try:
            pygame.mixer.music.load(src['path'])
            pygame.mixer.music.set_volume(self.volume)
            pygame.mixer.music.play(start=max(0, off))
            self.is_playing = True
            self.last_sync_time = datetime.now()
        except Exception:
            self.is_playing = False

    def save(self, idx, ts, text):
        if self.user_perm != "EDIT": return
        src = self.get_source()
        src_name = os.path.basename(src['path']) if src else "GAP"
        with sqlite3.connect(self.db_path) as conn:
            c = conn.cursor()
            if idx < len(self.transcript):
                old = self.transcript[idx]['text']
                c.execute("UPDATE transcript SET ts=?, content=? WHERE ts=? AND content=?",
                          (ts, text, self.transcript[idx]['ts'], old))
            else:
                old = "NEW_ENTRY"
                c.execute("INSERT INTO transcript (ts, content) VALUES (?,?)", (ts, text))
            c.execute("INSERT INTO audit_log (edit_time, line_ts, old_text, new_text, user, source_file) VALUES (?,?,?,?,?,?)",
                      (datetime.now().strftime('%Y-%m-%d %H:%M:%S'), ts, old, text, self.user, src_name))
            conn.commit()
        self.sync_db()

    def jump_to_state(self, index=None, target_time=None):
        if index is not None and 0 <= index < len(self.transcript):
            self.history_idx = index
            self.current_page = index // 10
            self.current_time = datetime.strptime(self.transcript[index]['ts'], '%Y%m%d%H%M%S')
        elif target_time:
            self.current_time = target_time
            target_ts = target_time.strftime('%Y%m%d%H%M%S')
            near = [i for i, x in enumerate(self.transcript) if x['ts'] <= target_ts]
            self.current_page = near[-1] // 10 if near else 0
            self.history_idx = -1
        self.play_sync()

    def perform_search(self, query):
        q = query.lower().strip()
        if re.match(r'^[\d:]+[ap]?m?$', q) and any(c.isdigit() for c in q):
            digits = re.sub(r'[^0-9]', '', q)
            try:
                h = int(digits[:2])
                m = int(digits[2:4]) if len(digits) >= 4 else 0
                if "pm" in q and h < 12: h += 12
                self.jump_to_state(target_time=self.current_time.replace(hour=h, minute=m, second=0))
                self.search_matches, self.last_search_query = [], ""
            except Exception: pass
            return
        if q != self.last_search_query:
            self.last_search_query = q
            self.search_matches = [i for i, e in enumerate(self.transcript) if q in e['text'].lower()]
            self.search_match_idx = 0
        else:
            if self.search_matches: self.search_match_idx = (self.search_match_idx + 1) % len(self.search_matches)
        if self.search_matches: self.jump_to_state(index=self.search_matches[self.search_match_idx])

    def run_interface(self, stdscr):
        curses.echo()
        curses.curs_set(1)
        stdscr.addstr(2, 2, "=== SHUTTLE LOGIN ===")
        stdscr.addstr(4, 2, "Username: ")
        u = stdscr.getstr(4, 12).decode().strip()
        stdscr.addstr(5, 2, "Password: ")
        curses.noecho()
        p = stdscr.getstr(5, 12).decode().strip()
        if not self.verify_password(u, p):
            stdscr.addstr(7, 2, "ACCESS DENIED", curses.A_BOLD)
            stdscr.refresh(); curses.napms(1500); return
        self.user = u
        self.user_perm = self.users[u].get('perm', 'READ')
        stdscr.nodelay(True); stdscr.keypad(True)
        curses.start_color(); curses.use_default_colors()
        curses.init_pair(1, curses.COLOR_RED, -1); curses.init_pair(2, curses.COLOR_CYAN, -1)
        in_pt, cursor_pos = "", 0
        search_mode, search_buf = False, ""
        F = [curses.KEY_F0+i for i in range(1, 13)]

        while True:
            stdscr.erase(); max_y, max_x = stdscr.getmaxyx()
            ts_key = self.current_time.strftime('%Y%m%d%H%M%S')
            src = self.get_source()
            stdscr.addstr(0, 0, f" {self.user} | {self.current_time.strftime('%H:%M:%S')} ".center(max_x, "="), curses.A_REVERSE)
            vol_bar = "|" * int(self.volume * 10)
            stdscr.addstr(1, 0, f" VOL: {vol_bar:<10} ({int(self.volume*100)}%)")
            if self.loop_start or self.loop_end:
                ls = self.loop_start.strftime('%H:%M:%S') if self.loop_start else "??"
                le = self.loop_end.strftime('%H:%M:%S') if self.loop_end else "??"
                stdscr.addstr(1, max_x - 22, f"LOOP: {ls}->{le}", curses.color_pair(2))
            stdscr.addstr(2, 0, f" PERM: {self.user_perm}")
            if src: stdscr.addstr(2, max_x - len(os.path.basename(src['path'])) - 5, f"SRC: {os.path.basename(src['path'])}", curses.A_DIM)
            else: stdscr.addstr(2, max_x - 15, "!! GAP !!", curses.color_pair(1) | curses.A_BOLD)
            near = [i for i, x in enumerate(self.transcript) if x['ts'] <= ts_key]
            head = near[-1] if near else -1
            if self.history_idx == -1 and head != -1: self.current_page = head // 10
            for i, idx in enumerate(range(self.current_page * 10, min((self.current_page + 1) * 10, len(self.transcript)))):
                attr = curses.A_REVERSE if idx == self.history_idx else curses.A_NORMAL
                indicator = "> " if idx == head and self.history_idx == -1 else "  "
                stdscr.addstr(5 + i, 0, f"{indicator}[{self.transcript[idx]['ts']}] {self.transcript[idx]['text']}"[:max_x-1], attr)
            prompt_str = f" SEARCH > " if search_mode else f" {self.user_perm} > "
            active_buf = search_buf if search_mode else in_pt
            stdscr.addstr(3, 0, prompt_str + active_buf)
            stdscr.addstr(max_y - 1, 0, "[F1]Play [F2]Src [F3]Loop [F5/F6]Seek [F9]Search [Ctrl+K]Sync [ESC]Quit", curses.A_DIM)
            stdscr.move(3, len(prompt_str) + (len(search_buf) if search_mode else cursor_pos))

            ch = stdscr.getch()
            if ch == -1: pass
            elif ch in [F[11], 19, 11]: # SYNC
                if self.user_perm == "EDIT":
                    target = self.history_idx if self.history_idx != -1 else head
                    if target != -1: self.save(target, ts_key, self.transcript[target]['text']); curses.flash()
            elif ch == F[8]:
                search_mode = not search_mode
                if search_mode: search_buf = self.last_search_query
            elif ch == F[0]:
                if self.is_playing: pygame.mixer.music.stop(); self.is_playing = False
                else: self.play_sync()
            elif ch == F[1]:
                if src: self.active_file_idx += 1; self.play_sync()
            elif ch == F[2]:
                if not self.loop_start: self.loop_end, self.loop_start = self.current_time, self.current_time - timedelta(seconds=15)
                else: self.loop_start -= timedelta(seconds=5)
                self.current_time = self.loop_start; self.play_sync()
            elif ch == F[3]: self.loop_start = self.loop_end = None
            elif ch == F[4]: self.jump_to_state(target_time=self.current_time - timedelta(seconds=5))
            elif ch == F[5]: self.jump_to_state(target_time=self.current_time + timedelta(seconds=5))
            elif ch == F[6]: self.volume = max(0.0, self.volume - 0.1); pygame.mixer.music.set_volume(self.volume)
            elif ch == F[7]: self.volume = min(1.0, self.volume + 0.1); pygame.mixer.music.set_volume(self.volume)
            elif ch == curses.KEY_PPAGE: self.current_page = max(0, self.current_page - 1)
            elif ch == curses.KEY_NPAGE: self.current_page = min((len(self.transcript) - 1) // 10, self.current_page + 1)
            elif search_mode:
                if ch == 10:
                    if search_buf.strip(): self.perform_search(search_buf)
                    search_mode = False
                elif ch == 27: search_mode = False
                elif ch in [127, 8, curses.KEY_BACKSPACE]: search_buf = search_buf[:-1]
                elif 32 <= ch <= 126: search_buf += chr(ch)
            else:
                if 32 <= ch <= 126 and self.history_idx == -1 and self.user_perm == "EDIT" and len(in_pt) == 0:
                    locked_ts = self.current_time.strftime('%Y%m%d%H%M%S')
                    self.save(len(self.transcript), locked_ts, "")
                    for i, x in enumerate(self.transcript):
                        if x['ts'] == locked_ts and x['text'] == "": self.history_idx = i; break
                if ch == 10 and self.user_perm == "EDIT":
                    ts_to_save = self.transcript[self.history_idx]['ts'] if self.history_idx != -1 else ts_key
                    self.save(self.history_idx if self.history_idx != -1 else len(self.transcript), ts_to_save, in_pt)
                    in_pt, cursor_pos, self.history_idx = "", 0, -1
                elif ch == curses.KEY_UP:
                    self.jump_to_state(index=max(0, (self.history_idx if self.history_idx != -1 else head) - 1))
                    in_pt = self.transcript[self.history_idx]['text']; cursor_pos = len(in_pt)
                elif ch == curses.KEY_DOWN:
                    idx = (self.history_idx if self.history_idx != -1 else head) + 1
                    if idx < len(self.transcript): self.jump_to_state(index=idx); in_pt = self.transcript[self.history_idx]['text']
                    else: self.history_idx, in_pt = -1, ""
                    cursor_pos = len(in_pt)
                elif ch == curses.KEY_LEFT: cursor_pos = max(0, cursor_pos - 1)
                elif ch == curses.KEY_RIGHT: cursor_pos = min(len(in_pt), cursor_pos + 1)
                elif ch == curses.KEY_HOME: cursor_pos = 0
                elif ch == curses.KEY_END: cursor_pos = len(in_pt)
                elif ch in [127, 8, curses.KEY_BACKSPACE]:
                    if cursor_pos > 0: in_pt = in_pt[:cursor_pos-1] + in_pt[cursor_pos:]; cursor_pos -= 1
                elif ch == curses.KEY_DC: # DELETE
                    if cursor_pos < len(in_pt): in_pt = in_pt[:cursor_pos] + in_pt[cursor_pos+1:]
                elif ch == ord(' '):
                    words = in_pt[:cursor_pos].split(" ")
                    if words and words[-1] in self.macros:
                        words[-1] = self.macros[words[-1]]
                        expanded = " ".join(words) + " "
                        in_pt = expanded + in_pt[cursor_pos:]
                        cursor_pos = len(expanded)
                    else:
                        in_pt = in_pt[:cursor_pos] + " " + in_pt[cursor_pos:]
                        cursor_pos += 1
                elif 32 <= ch <= 126:
                    in_pt = in_pt[:cursor_pos] + chr(ch) + in_pt[cursor_pos:]
                    cursor_pos += 1
                elif ch == 27: break

            if self.is_playing:
                self.current_time += timedelta(seconds=(datetime.now() - self.last_sync_time).total_seconds())
                self.last_sync_time = datetime.now()
                if self.loop_start and self.loop_end and self.current_time >= self.loop_end:
                    self.current_time = self.loop_start; self.play_sync()
                if not pygame.mixer.get_busy() and not pygame.mixer.music.get_busy(): self.is_playing = False
            curses.napms(20)

        pygame.mixer.music.stop(); pygame.mixer.quit(); pygame.quit()

if __name__ == "__main__":
    y_files = sorted([f for f in os.listdir('.') if f.endswith('.yaml')])
    if not y_files:
        print("No .yaml projects found.")
        sys.exit(1)

    if len(y_files) == 1:
        project = y_files[0]
    else:
        print("\n--- Forensic Projects ---")
        for i, f in enumerate(y_files):
            print(f"{i+1}. {f}")
        try:
            project = y_files[int(input("\nSelect Project #: "))-1]
        except:
            print("Invalid selection.")
            sys.exit(1)

    curses.wrapper(lambda stdscr: ForensicShuttle(project).run_interface(stdscr))
