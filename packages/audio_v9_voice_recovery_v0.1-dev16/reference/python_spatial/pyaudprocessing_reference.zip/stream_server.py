import os
import glob
import yaml
import sqlite3
import asyncio
import subprocess
import hashlib
from datetime import datetime, timedelta
from typing import Optional
from contextlib import asynccontextmanager
from fastapi import FastAPI, WebSocket, WebSocketDisconnect, Request, Header, HTTPException
from fastapi.responses import HTMLResponse, StreamingResponse, JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import uvicorn

# --- PAYLOADS ---
class LoginPayload(BaseModel):
    username: str
    password: str

class TranscriptPayload(BaseModel):
    text: str
    ts: str
    source_file: str
    username: str
    old_ts: Optional[str] = None

@asynccontextmanager
async def lifespan(app: FastAPI):
    watcher_task = asyncio.create_task(watch_all_databases())
    yield
    watcher_task.cancel()

app = FastAPI(lifespan=lifespan)
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])

def verify_password(stored_hash_str, password):
    try:
        salt, hash_val = stored_hash_str.split('$')
        return hashlib.sha256((salt + password).encode()).hexdigest() == hash_val
    except: return False

def get_text_column(cursor):
    cursor.execute("PRAGMA table_info(transcript)")
    cols = [info[1] for info in cursor.fetchall()]
    return 'text' if 'text' in cols else 'content'

# --- THE FULL FORENSIC UI (v7.8) ---
HTML_UI = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Forensic Shuttle v7.8</title>
    <style>
        body { font-family: 'Segoe UI', sans-serif; background: #121212; color: #fff; margin: 0; display: flex; flex-direction: column; height: 100vh; overflow: hidden; }
        header { background: #1e1e1e; padding: 5px 10px; text-align: center; border-bottom: 1px solid #333; height: 35px; flex-shrink: 0; position: relative; }
        header h2 { font-size: 0.9rem; margin: 5px 0; }
        .hidden { display: none !important; }

        #workspace { display: flex; flex-direction: column; flex: 1; overflow: hidden; }
        #player-container { padding: 10px; background: #1a1a1a; border-bottom: 1px solid #333; flex-shrink: 0;}

        .top-row { display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px; }
        .btn-group { display: flex; gap: 4px; }

        button { background: #333; color: #eee; border: 1px solid #444; padding: 4px 8px; border-radius: 4px; cursor: pointer; font-size: 0.7rem; font-weight: bold; }
        button.active { background: #0078d4; color: white; border-color: #005a9e; }
        button:hover { background: #444; }

        /* CHANNEL MATRIX & FILTERS */
        .matrix { display: flex; justify-content: center; background: #000; border: 1px solid #333; border-radius: 4px; padding: 2px; margin: 5px 0; gap: 2px;}
        .matrix button { background: transparent; color: #666; border: none; padding: 4px 8px; font-size: 0.6rem; }
        .matrix button.active { background: #0078d4; color: white; }

        .filter-row { display: flex; justify-content: center; gap: 10px; margin-bottom: 8px; }
        .toggle-btn { background: #222; color: #666; border: 1px solid #333; padding: 2px 12px; border-radius: 12px; font-size: 0.65rem; }
        .toggle-btn.on { background: #27ae60; color: #fff; border-color: #2ecc71; }

        #scrubber-container { position: relative; background: #333; border-radius: 4px; height: 12px; margin: 8px 0; display: flex; align-items: center; }
        #global-scrubber { width: 100%; height: 100%; appearance: none; background: transparent; cursor: pointer; position: relative; z-index: 5; margin: 0; outline: none; }
        #global-scrubber::-webkit-slider-thumb { appearance: none; width: 18px; height: 18px; border-radius: 50%; background: #00ffcc; border: 2px solid #121212; }
        #loop-highlight { position: absolute; height: 100%; top: 0; background: rgba(255, 170, 0, 0.4); z-index: 3; pointer-events: none; border-radius: 4px; }

        #transcript-container { flex: 1; overflow-y: auto; padding: 10px; background: #121212; scroll-behavior: smooth; }
        .line { display: flex; gap: 15px; padding: 6px; border-bottom: 1px solid #1a1a1a; cursor: pointer; font-size: 0.85rem; }
        .line.active-line { background: #1a2a3a; border-left: 4px solid #00ffcc; }
        .ts { color: #00ffcc; font-family: monospace; min-width: 140px; }

        #input-container { padding: 8px; background: #1e1e1e; border-top: 1px solid #333; display: flex; gap: 8px; flex-shrink: 0;}
        #transcript-input { flex: 1; padding: 8px; background: #000; color: #fff; border: 1px solid #444; border-radius: 4px; }

        #lobby, #login-view { padding: 50px; text-align: center; }
        .project-btn { background: #0078d4; color: white; border: none; padding: 15px; margin: 10px; border-radius: 5px; width: 260px; cursor: pointer; font-weight: bold; }
    </style>
</head>
<body>
    <header>
        <button id="btn-exit" class="hidden" onclick="location.reload()" style="position:absolute; left:10px; top:5px;">Exit</button>
        <h2 id="title">Forensic Shuttle v7.8</h2>
    </header>

    <div id="lobby">
        <h3>Project Selection</h3>
        <div id="project-list"></div>
    </div>

    <div id="login-view" class="hidden">
        <h3 id="login-title"></h3>
        <input type="text" id="login-user" placeholder="Analyst" style="padding:10px; margin-bottom:10px; width:250px;"><br>
        <input type="password" id="login-pass" placeholder="Password" style="padding:10px; margin-bottom:10px; width:250px;"><br>
        <button onclick="login()" style="width:270px; background:#00ffcc; color:black; font-weight:bold;">LOGIN</button>
    </div>

    <div id="workspace" class="hidden">
        <div id="player-container">
            <div class="top-row">
                <div class="btn-group">
                    <button onclick="zoomOut()">-</button>
                    <span id="zoom-info" style="font-size:0.6rem; color:#888; width:30px; text-align:center; padding-top:4px;">FULL</span>
                    <button onclick="zoomIn()">+</button>
                </div>
                <div class="btn-group">
                    <button onclick="skip(-30)">&lt;&lt;</button>
                    <button onclick="skip(-5)">&lt;</button>
                    <button onclick="skip(5)">&gt;</button>
                    <button onclick="skip(30)">&gt;&gt;</button>
                </div>
            </div>

            <audio id="media-player" controls crossorigin="anonymous" style="width:100%; height:32px; margin-bottom:5px;"></audio>

            <div class="filter-row">
                <button id="f-speech" class="toggle-btn" onclick="toggleFilter('speech')">SPEECH</button>
                <button id="f-boost" class="toggle-btn" onclick="toggleFilter('boost')">BOOST</button>
                <button id="f-damp" class="toggle-btn" onclick="toggleFilter('damp')">DAMP</button>
            </div>

            <div class="matrix" id="channel-matrix">
                <button onclick="setAudioMode('all')" id="btn-all" class="active">ALL MIX</button>
                <button onclick="setAudioMode(0)" id="btn-0">CH 0 (A)</button>
                <button onclick="setAudioMode(1)" id="btn-1">CH 1 (C)</button>
                <button onclick="setAudioMode(2)" id="btn-2">CH 2 (B)</button>
                <button onclick="setAudioMode(3)" id="btn-3">CH 3</button>
                <button onclick="setAudioMode(4)" id="btn-4">CH 4</button>
            </div>

            <div id="scrubber-container">
                <input type="range" id="global-scrubber" value="0">
                <div id="loop-highlight" class="hidden"></div>
            </div>

            <div style="display:flex; justify-content:space-between; font-size:11px; color:#888; font-family:monospace; margin-bottom:8px;">
                <span id="time-label-current">00:00:00</span>
                <span id="source-label">Source: ---</span>
                <span id="time-label-end">00:00:00</span>
            </div>

            <div class="btn-group" style="justify-content: center;">
                <button onclick="dropMarker()" style="background:#8b0000; color:white;">MARK</button>
                <button onclick="switchSource()">SOURCE</button>
                <button onclick="setLoopStart()" style="color:#00ffcc;">START</button>
                <button onclick="setLoopEnd()" style="color:#00ffcc;">END</button>
                <button onclick="catchLoop()" style="background:#ffaa00; color:black;">CATCH</button>
                <button onclick="clearLoop()">CLEAR</button>
            </div>
        </div>

        <div id="transcript-container"></div>

        <div id="input-container">
            <input type="text" id="transcript-input" placeholder="Type transcript line...">
            <button onclick="saveLine()" style="background:#0078d4;">SAVE</button>
        </div>
    </div>

    <script>
        let currentProject = null;
        let sessionUser = null;
        let ws = null;
        let globalTimeMs = 0;
        let projectFiles = [];
        let projectStartMs = 0;
        let projectEndMs = 0;
        let activeFileIdx = 0;
        let loopStartMs = null;
        let loopEndMs = null;

        const ZOOM_LEVELS = [null, 600000, 300000, 60000, 30000, 10000];
        const ZOOM_NAMES = ["FULL", "10m", "5m", "1m", "30s", "10s"];
        let currentZoomIdx = 0;
        let viewStartMs = 0;
        let viewEndMs = 0;

        let filters = { speech: false, boost: false, damp: false };

        const player = document.getElementById('media-player');
        const scrubber = document.getElementById('global-scrubber');

        // --- WEB AUDIO ---
        let audioCtx, source, splitter, merger, gainL, gainR;
        let currentMode = 'all';

        function initAudio() {
            if (audioCtx) return;
            try {
                audioCtx = new (window.AudioContext || window.webkitAudioContext)();
                source = audioCtx.createMediaElementSource(player);
                splitter = audioCtx.createChannelSplitter(6);
                merger = audioCtx.createChannelMerger(2);
                gainL = audioCtx.createGain(); gainR = audioCtx.createGain();
                source.connect(splitter);
                gainL.connect(merger, 0, 0); gainR.connect(merger, 0, 1);
                merger.connect(audioCtx.destination);
                updateRouting();
            } catch(e) {}
        }

        function updateRouting() {
            if (!splitter) return;
            splitter.disconnect();
            if (currentMode === 'all') {
                splitter.connect(gainL, 0); splitter.connect(gainR, 2);
                splitter.connect(gainL, 1); splitter.connect(gainR, 1);
            } else {
                splitter.connect(gainL, currentMode); splitter.connect(gainR, currentMode);
            }
        }

        function setAudioMode(mode) {
            currentMode = mode; initAudio();
            if (audioCtx && audioCtx.state === 'suspended') audioCtx.resume();
            document.querySelectorAll('.matrix button').forEach(b => b.classList.remove('active'));
            document.getElementById(mode === 'all' ? 'btn-all' : 'btn-' + mode).classList.add('active');
            updateRouting();
        }

        // --- FORENSIC CONTROLS ---
        function toggleFilter(f) {
            filters[f] = !filters[f];
            document.getElementById('f-' + f).classList.toggle('on');
            syncPlayer();
        }

        function formatCompactTs(ms) {
            const d = new Date(ms);
            return d.getFullYear() + String(d.getMonth()+1).padStart(2,'0') + String(d.getDate()).padStart(2,'0') +
                   String(d.getHours()).padStart(2,'0') + String(d.getMinutes()).padStart(2,'0') + String(d.getSeconds()).padStart(2,'0');
        }

        function parseCompactToMs(ts) {
            return new Date(ts.substring(0,4)+'-'+ts.substring(4,6)+'-'+ts.substring(6,8)+'T'+ts.substring(8,10)+':'+ts.substring(10,12)+':'+ts.substring(12,14)).getTime();
        }

        async function loadLobby() {
            const r = await fetch('/api/projects');
            const d = await r.json();
            document.getElementById('project-list').innerHTML = d.projects.map(p =>
                `<button class="project-btn" onclick="selectProject('${p.id}')">${p.id}</button>`
            ).join('');
        }

        function selectProject(pid) {
            currentProject = pid;
            document.getElementById('lobby').classList.add('hidden');
            document.getElementById('login-view').classList.remove('hidden');
            document.getElementById('login-title').innerText = pid;
        }

        async function login() {
            const u = document.getElementById('login-user').value;
            const p = document.getElementById('login-pass').value;
            const r = await fetch(`/api/project/${currentProject}/login`, {
                method:'POST', headers:{'Content-Type':'application/json'},
                body: JSON.stringify({username:u, password:p})
            });
            const d = await r.json();
            if (d.success) {
                sessionUser = u;
                document.getElementById('login-view').classList.add('hidden');
                document.getElementById('workspace').classList.remove('hidden');
                document.getElementById('btn-exit').classList.remove('hidden');
                loadWorkspace();
            } else { alert("Denied"); }
        }

        async function loadWorkspace() {
            const conf = await (await fetch(`/api/project/${currentProject}/config`)).json();
            projectFiles = conf.files.map(f => {
                const s = new Date(f.start.replace(' ', 'T')).getTime();
                return {...f, start_ms: s, end_ms: s + (f.duration * 1000)};
            });
            projectStartMs = Math.min(...projectFiles.map(f => f.start_ms));
            projectEndMs = Math.max(...projectFiles.map(f => f.end_ms));
            globalTimeMs = projectStartMs;
            applyZoom(0); connectWS(); syncPlayer();
        }

        function applyZoom(delta) {
            currentZoomIdx = Math.max(0, Math.min(ZOOM_LEVELS.length - 1, currentZoomIdx + delta));
            const windowSize = ZOOM_LEVELS[currentZoomIdx];
            document.getElementById('zoom-info').innerText = ZOOM_NAMES[currentZoomIdx];
            if (!windowSize) {
                viewStartMs = projectStartMs; viewEndMs = projectEndMs;
            } else {
                viewStartMs = globalTimeMs - (windowSize / 2);
                viewEndMs = globalTimeMs + (windowSize / 2);
            }
            if (viewStartMs < projectStartMs) { viewStartMs = projectStartMs; viewEndMs = viewStartMs + (windowSize || projectEndMs - projectStartMs); }
            if (viewEndMs > projectEndMs) { viewEndMs = projectEndMs; viewStartMs = viewEndMs - (windowSize || projectEndMs - projectStartMs); }
            scrubber.max = viewEndMs - viewStartMs;
            updateScrubber();
        }

        function zoomIn() { applyZoom(1); }
        function zoomOut() { applyZoom(-1); }
        function skip(secs) { globalTimeMs = Math.max(projectStartMs, Math.min(projectEndMs, globalTimeMs + (secs * 1000))); applyZoom(0); syncPlayer(); }

        function syncPlayer() {
            const f = projectFiles.find(f => globalTimeMs >= f.start_ms && globalTimeMs < f.end_ms);
            if (!f) return;
            activeFileIdx = projectFiles.indexOf(f);
            document.getElementById('source-label').innerText = f.path.split('/').pop().substring(0,25);
            const offset = (globalTimeMs - f.start_ms) / 1000;
            const url = `/stream/${currentProject}?source_idx=${activeFileIdx}&t=${offset}&speech=${filters.speech}&boost=${filters.boost}&damp=${filters.damp}`;
            player.src = url; player.currentTime = 0; player.play();
            initAudio();
        }

        function seekToTs(ts) { globalTimeMs = parseCompactToMs(ts); applyZoom(0); syncPlayer(); }

        function setLoopStart() { loopStartMs = globalTimeMs; updateLoopUI(); }
        function setLoopEnd() { loopEndMs = globalTimeMs; updateLoopUI(); }
        function clearLoop() { loopStartMs = null; loopEndMs = null; updateLoopUI(); }
        function catchLoop() { if (loopStartMs) { globalTimeMs = loopStartMs; syncPlayer(); } }

        function updateLoopUI() {
            const hl = document.getElementById('loop-highlight');
            if (loopStartMs && loopEndMs) {
                hl.classList.remove('hidden');
                const start = Math.max(0, (loopStartMs - viewStartMs) / (viewEndMs - viewStartMs) * 100);
                const end = Math.min(100, (loopEndMs - viewStartMs) / (viewEndMs - viewStartMs) * 100);
                hl.style.left = start + '%'; hl.style.width = (end - start) + '%';
            } else { hl.classList.add('hidden'); }
        }

        function switchSource() {
            const concurrent = projectFiles.filter(f => globalTimeMs >= f.start_ms && globalTimeMs < f.end_ms);
            if (concurrent.length > 1) {
                let next = (concurrent.indexOf(projectFiles[activeFileIdx]) + 1) % concurrent.length;
                activeFileIdx = projectFiles.indexOf(concurrent[next]);
                syncPlayer();
            }
        }

        async function saveLine() {
            const text = document.getElementById('transcript-input').value; if (!text) return;
            await fetch(`/api/transcript/${currentProject}`, {
                method:'POST', headers:{'Content-Type':'application/json'},
                body: JSON.stringify({text: text, ts: formatCompactTs(globalTimeMs), source_file: projectFiles[activeFileIdx].path.split('/').pop(), username: sessionUser})
            });
            document.getElementById('transcript-input').value = "";
        }

        function dropMarker() { document.getElementById('transcript-input').value = "-- MARKER --"; saveLine(); }

        player.ontimeupdate = () => {
            const activeF = projectFiles[activeFileIdx];
            globalTimeMs = activeF.start_ms + (player.currentTime * 1000);
            updateScrubber();
            if (loopStartMs && loopEndMs && globalTimeMs >= loopEndMs) { globalTimeMs = loopStartMs; syncPlayer(); }
        };

        function updateScrubber() {
            scrubber.value = globalTimeMs - viewStartMs;
            document.getElementById('time-label-current').innerText = formatCompactTs(globalTimeMs).substring(8);
            document.getElementById('time-label-end').innerText = formatCompactTs(viewEndMs).substring(8);
            updateLoopUI();
        }

        scrubber.oninput = () => { globalTimeMs = viewStartMs + parseInt(scrubber.value); syncPlayer(); };

        function connectWS() {
            const prot = location.protocol === 'https:' ? 'wss:' : 'ws:';
            ws = new WebSocket(`${prot}//${location.host}/ws/${currentProject}`);
            ws.onmessage = (e) => {
                const m = JSON.parse(e.data);
                if (m.type === 'full_sync') {
                    document.getElementById('transcript-container').innerHTML = m.lines.map(l => `
                        <div class="line" onclick="seekToTs('${l.ts}')">
                            <div class="ts">${l.ts}</div>
                            <div class="text ${l.text.includes('-- MARKER --') ? 'marker-text' : ''}">${l.text}</div>
                        </div>
                    `).join('');
                }
            };
        }

        loadLobby();
    </script>
</body>
</html>
"""

# --- BACKEND API ---

@app.get("/", response_class=HTMLResponse)
async def get_ui(): return HTML_UI

@app.get("/api/projects")
async def list_projects():
    return {"projects": [{"id": os.path.splitext(f)[0]} for f in glob.glob("*.yaml")]}

@app.post("/api/project/{project_id}/login")
async def project_login(project_id: str, payload: LoginPayload):
    with open(f"{project_id}.yaml", 'r') as f: config = yaml.safe_load(f)
    user = config.get('users', {}).get(payload.username)
    if user and verify_password(user.get('hash', ''), payload.password):
        return {"success": True, "username": payload.username, "perm": user.get('perm', 'EDIT')}
    raise HTTPException(status_code=401)

@app.get("/api/project/{project_id}/config")
async def get_project_config(project_id: str):
    with open(f"{project_id}.yaml", 'r') as f: config = yaml.safe_load(f)
    files = []
    for entry in config.get('files', []):
        if os.path.exists(entry['path']):
            try:
                cmd = ['ffprobe', '-v', 'error', '-show_entries', 'format=duration', '-of', 'default=noprint_wrappers=1:nokey=1', entry['path']]
                out = subprocess.run(cmd, stdout=subprocess.PIPE, text=True).stdout.strip()
                entry['duration'] = float(out) if out else 0
            except: entry['duration'] = 0
            files.append(entry)
    return {"files": files}

@app.get("/stream/{project_id}")
async def stream_media(project_id: str, source_idx: int = 0, t: float = 0, speech: bool = False, boost: bool = False, damp: bool = False):
    """ADVANCED: Hybrid Multi-Channel Forensic Pipeline"""
    with open(f"{project_id}.yaml", 'r') as f: config = yaml.safe_load(f)
    v_files = config.get('files', [])
    if source_idx >= len(v_files): raise HTTPException(status_code=404)
    path = v_files[source_idx]['path']

    filters_list = []
    if speech: filters_list.append("afftdn=nf=-25,highpass=f=200,lowpass=f=3000")
    if boost: filters_list.append("volume=3.5")
    if damp: filters_list.append("acompressor=threshold=-12dB:ratio=10:attack=1:release=50:makeup=2")

    f_args = ["-af", ",".join(filters_list)] if filters_list else []

    # Logic: If using filters, we MUST use MP3 (Stereo only).
    # If NO filters, we use WAV to preserve all channels for the Matrix.
    out_format = 'mp3' if filters_list else 'wav'
    codec = 'libmp3lame' if filters_list else 'pcm_s16le'
    m_type = 'audio/mpeg' if filters_list else 'audio/wav'

    cmd = ['ffmpeg', '-ss', str(t), '-i', path, *f_args, '-f', out_format, '-acodec', codec, '-']
    p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)

    def it():
        try:
            while True:
                c = p.stdout.read(64*1024)
                if not c: break
                yield c
        finally: p.kill()
    return StreamingResponse(it(), media_type=m_type)

@app.post("/api/transcript/{project_id}")
async def save_transcript_line(project_id: str, payload: TranscriptPayload):
    db = f"{project_id}_audit.db"
    with sqlite3.connect(db) as conn:
        c = conn.cursor()
        c.execute("CREATE TABLE IF NOT EXISTS transcript (ts TEXT PRIMARY KEY, text TEXT, source TEXT)")
        col = get_text_column(c)
        c.execute(f"INSERT OR REPLACE INTO transcript (ts, {col}, source) VALUES (?, ?, ?)", (payload.ts, payload.text, payload.source_file))
        conn.commit()
    await manager.broadcast_to_room(project_id, {"type": "full_sync", "lines": get_current_transcript(project_id)})
    return {"status": "success"}

# --- DATABASE WATCHER ---
class ConnectionManager:
    def __init__(self): self.rooms = {}
    async def connect(self, ws, pid): await ws.accept(); self.rooms.setdefault(pid, []).append(ws)
    def disconnect(self, ws, pid): self.rooms[pid].remove(ws)
    async def broadcast_to_room(self, pid, msg):
        for ws in self.rooms.get(pid, []):
            try: await ws.send_json(msg)
            except: pass

manager = ConnectionManager()

def get_current_transcript(pid):
    db, lines = f"{pid}_audit.db", []
    if os.path.exists(db):
        with sqlite3.connect(db) as conn:
            c = conn.cursor()
            col = get_text_column(c)
            c.execute(f"SELECT ts, {col}, source FROM transcript ORDER BY ts ASC")
            for r in c.fetchall(): lines.append({"ts": r[0], "text": r[1], "source": r[2]})
    return lines

@app.websocket("/ws/{pid}")
async def websocket_endpoint(ws: WebSocket, pid: str):
    await manager.connect(ws, pid)
    await ws.send_json({"type": "full_sync", "lines": get_current_transcript(pid)})
    try:
        while True: await ws.receive_text()
    except WebSocketDisconnect: manager.disconnect(ws, pid)

async def watch_all_databases():
    last_mtimes = {}
    while True:
        for db_file in glob.glob("*_audit.db"):
            pid = db_file.replace("_audit.db", "")
            mtime = os.path.getmtime(db_file)
            if mtime > last_mtimes.get(db_file, 0):
                last_mtimes[db_file] = mtime
                await manager.broadcast_to_room(pid, {"type": "full_sync", "lines": get_current_transcript(pid)})
        await asyncio.sleep(1)

if __name__ == "__main__":
    uvicorn.run("server:app", host="0.0.0.0", port=8081, ssl_keyfile="key.pem", ssl_certfile="cert.pem")
