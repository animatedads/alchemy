import os
import argparse
import yaml
import numpy as np
import soundfile as sf
import librosa

from datetime import datetime, timedelta
from scipy.signal import get_window
from scipy.ndimage import uniform_filter1d

# ---------------------------------------------------------------------
# GLOBAL DSP CONSTANTS
# ---------------------------------------------------------------------

SR = 22050
N_FFT = 2048
HOP_LEN = N_FFT // 4

BLOCK_SEC = 8
HOP_SEC = BLOCK_SEC * 0.5

BLOCK_SAMP = int(SR * BLOCK_SEC)
HOP_SAMP = int(SR * HOP_SEC)

MAX_LAG_SEC = 0.2

# ---------------------------------------------------------------------
# YAML FILE TYPE MODES
# ---------------------------------------------------------------------

MODE_TYPES = {

    "plus20": {
        "cam_a": "Enhanced Amp +20dB (Ogg Q10)",
        "cam_b": "FD Feed (Enhanced +20dB)",
        "label": "Enhanced+20dB vs FD+20dB"
    },

    "amp32": {
        "cam_a": "Raw Amp +32dB (Ogg Q10)",
        "cam_b": "FD Feed (Raw Amp +32dB)",
        "label": "Raw+32dB vs FD+32dB"
    },

    "enhanced": {
        "cam_a": "Enhanced (Ogg Q10)",
        "cam_b": "FD Feed (Enhanced)",
        "label": "Enhanced vs FD Enhanced"
    }
}

# ---------------------------------------------------------------------
# YAML LOADER
# ---------------------------------------------------------------------

def load_project(yaml_path, mode):

    with open(yaml_path) as f:
        data = yaml.safe_load(f)

    type_a = MODE_TYPES[mode]["cam_a"]
    type_b = MODE_TYPES[mode]["cam_b"]

    clips_a = []
    clips_b = []

    for entry in data["files"]:

        t = entry.get("type","")
        path = entry["path"]

        start = datetime.strptime(entry["start"],"%Y-%m-%d %H:%M:%S")

        if t == type_a:
            clips_a.append({"path":path,"start":start})

        if t == type_b:
            clips_b.append({"path":path,"start":start})

    clips_a.sort(key=lambda x:x["start"])
    clips_b.sort(key=lambda x:x["start"])

    return clips_a, clips_b


def build_index(clips):

    index=[]

    for i,clip in enumerate(clips):

        start = clip["start"]

        if i+1 < len(clips):
            end = clips[i+1]["start"]
        else:
            end = start + timedelta(hours=2)

        index.append((start,end,clip["path"]))

    return index

# ---------------------------------------------------------------------
# AUDIO BLOCK LOADING
# ---------------------------------------------------------------------

def load_block(path,start_dt,target_dt,duration):

    if not path or not os.path.exists(path):
        return None

    offset = (target_dt-start_dt).total_seconds()

    try:
        y,_ = librosa.load(path,sr=SR,offset=max(0,offset),duration=duration,mono=True)

        if len(y) < 64:
            return None

        return y

    except:
        return None


def pad_or_trim(y,n):

    if len(y)>=n:
        return y[:n]

    return np.pad(y,(0,n-len(y)))


# ---------------------------------------------------------------------
# GCC PHAT ALIGNMENT
# ---------------------------------------------------------------------

def gcc_phat_align(y_a,y_b):

    max_lag = int(MAX_LAG_SEC*SR)

    n=len(y_a)

    nfft = 1<<int(np.ceil(np.log2(2*n-1)))

    Fa=np.fft.rfft(y_a,nfft)
    Fb=np.fft.rfft(y_b,nfft)

    cross=Fa*np.conj(Fb)

    gcc=np.fft.irfft(cross/(np.abs(cross)+1e-9),nfft)

    search=np.concatenate([gcc[-max_lag:],gcc[:max_lag+1]])

    lag=np.argmax(search)-max_lag

    if lag>0:
        y_b=np.concatenate([np.zeros(lag),y_b])[:n]

    elif lag<0:
        y_b=np.concatenate([y_b[-lag:],np.zeros(-lag)])[:n]

    return y_b

# ---------------------------------------------------------------------
# CCTV SPEECH ENHANCEMENT CORE
# ---------------------------------------------------------------------

class NoiseTracker:

    def __init__(self,n_bins):

        self.noise = np.ones(n_bins)*1e-6
        self.alpha = 0.98
        self.beta = 0.8

    def update(self,power):

        self.noise = np.minimum(
            self.alpha*self.noise+(1-self.alpha)*power,
            power*self.beta
        )

        return self.noise


def speech_band_weight(freqs):

    low=120
    high=3800

    rise = 1/(1+np.exp(-(freqs-low)/80))
    fall = 1/(1+np.exp((freqs-high)/500))

    return rise*fall


def log_mmse(S,noise):

    power = np.abs(S)**2

    snr_post = power/(noise+1e-9)

    snr_prio = np.maximum(snr_post-1,0)

    gain = snr_prio/(1+snr_prio)

    gain = np.sqrt(gain)

    return S*gain


def spectral_line_suppress(S):

    mag=np.abs(S)

    mean=np.mean(mag,axis=1,keepdims=True)

    ratio=mag/(mean+1e-9)

    mask=np.clip(ratio,0.2,2)

    return S/mask


def modulation_score(y):

    env=np.abs(y)

    env=uniform_filter1d(env,size=int(SR*0.01))

    mod=np.abs(np.diff(env))

    return np.mean(mod)


def cross_feed_fusion(y_a,y_b):

    score_a=modulation_score(y_a)
    score_b=modulation_score(y_b)

    if score_a>score_b:

        L=y_a
        R=0.6*y_b+0.4*y_a

    else:

        L=0.6*y_a+0.4*y_b
        R=y_b

    return L,R


def harmonic_reinforce(y):

    S=librosa.stft(y,n_fft=N_FFT,hop_length=HOP_LEN)

    H,_=librosa.decompose.hpss(S)

    S_new=0.8*S+0.2*H

    return librosa.istft(S_new,hop_length=HOP_LEN,length=len(y))


class SpeechEnhancer:

    def __init__(self):

        bins=N_FFT//2+1

        self.tracker=NoiseTracker(bins)

        self.freqs=librosa.fft_frequencies(sr=SR,n_fft=N_FFT)

        self.band=speech_band_weight(self.freqs)[:,None]

    def process(self,y):

        S=librosa.stft(y,n_fft=N_FFT,hop_length=HOP_LEN)

        power=np.abs(S)**2

        noise=self.tracker.update(power.mean(axis=1))

        S=log_mmse(S,noise[:,None])

        S*=self.band

        S=spectral_line_suppress(S)

        y=librosa.istft(S,hop_length=HOP_LEN,length=len(y))

        y=harmonic_reinforce(y)

        return np.clip(y,-1,1)

# ---------------------------------------------------------------------
# MAIN PROCESSOR
# ---------------------------------------------------------------------

def process(yaml_path,mode,outfile):

    clips_a,clips_b=load_project(yaml_path,mode)

    index_a=build_index(clips_a)
    index_b=build_index(clips_b)

    start=index_a[0][0]
    end=max(index_a[-1][1],index_b[-1][1])

    enhancer_a=SpeechEnhancer()
    enhancer_b=SpeechEnhancer()

    win=get_window("hann",BLOCK_SAMP)

    ola=np.zeros((BLOCK_SAMP*2,2))

    t=start

    with sf.SoundFile(outfile,"w",samplerate=SR,channels=2) as out:

        while t<end:

            a_start,a_path=None,None
            b_start,b_path=None,None

            for s,e,p in index_a:
                if s<=t<e:
                    a_start,a_path=s,p

            for s,e,p in index_b:
                if s<=t<e:
                    b_start,b_path=s,p

            y_a=load_block(a_path,a_start,t,BLOCK_SEC) if a_path else None
            y_b=load_block(b_path,b_start,t,BLOCK_SEC) if b_path else None

            if y_a is not None:
                y_a=enhancer_a.process(pad_or_trim(y_a,BLOCK_SAMP))

            if y_b is not None:
                y_b=enhancer_b.process(pad_or_trim(y_b,BLOCK_SAMP))

            if y_a is not None and y_b is not None:

                y_b=gcc_phat_align(y_a,y_b)

                L,R=cross_feed_fusion(y_a,y_b)

            elif y_a is not None:

                L=R=y_a

            elif y_b is not None:

                L=R=y_b

            else:

                L=R=np.zeros(BLOCK_SAMP)

            ola[:BLOCK_SAMP,0]+=L*win
            ola[:BLOCK_SAMP,1]+=R*win

            chunk=ola[:HOP_SAMP].copy()

            peak=np.max(np.abs(chunk))

            if peak>0.97:
                chunk*=0.97/peak

            out.write(chunk)

            ola[:-HOP_SAMP]=ola[HOP_SAMP:]
            ola[-HOP_SAMP:]=0

            t+=timedelta(seconds=HOP_SEC)

# ---------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------

if __name__=="__main__":

    parser=argparse.ArgumentParser()

    parser.add_argument("--yaml",required=True)
    parser.add_argument("--mode",required=True,
        choices=["plus20","amp32","enhanced"])
    parser.add_argument("--out",required=True)

    args=parser.parse_args()

    process(args.yaml,args.mode,args.out)
