import os
import shutil
import yaml
from collections import Counter

def fix_errant_files(yaml_path):
    if not os.path.exists(yaml_path):
        print(f"Error: YAML file '{yaml_path}' not found.")
        return

    with open(yaml_path, 'r') as f:
        config = yaml.safe_load(f)

    if 'files' not in config or not config['files']:
        print("Error: No files found in YAML.")
        return

    # 1. Identify the "Majority" Directory
    dirs = [os.path.dirname(f['path']) for f in config['files']]
    counts = Counter(dirs)
    majority_dir = counts.most_common(1)[0][0]

    if not majority_dir:
        # If most files are in the current working directory,
        # we might not want to "move" things there unless specifically told.
        print("Majority of files are in the root directory. No move suggested.")
        return

    print(f"Project Consistency Check for: {yaml_path}")
    print(f"Target Directory (Majority): {majority_dir}/")
    print("-" * 40)

    errant_entries = []
    for entry in config['files']:
        current_dir = os.path.dirname(entry['path'])
        if current_dir != majority_dir:
            errant_entries.append(entry)

    if not errant_entries:
        print("All files are already in the correct directory. Nice!")
        return

    # 2. Propose Moves
    yaml_changed = False
    for entry in errant_entries:
        old_path = entry['path']
        filename = os.path.basename(old_path)
        new_path = os.path.join(majority_dir, filename)

        print(f"\n[ERRANT FILE FOUND]")
        print(f"  Current:  {old_path}")
        print(f"  Proposed: {new_path}")

        choice = input("  Move file and update YAML? [Y/n]: ").strip().lower()

        if choice in ['', 'y', 'yes']:
            if not os.path.exists(old_path):
                print(f"  !! Error: Source file not found at {old_path}. Skipping.")
                continue

            try:
                # Ensure the majority directory actually exists
                if not os.path.exists(majority_dir):
                    os.makedirs(majority_dir)

                shutil.move(old_path, new_path)
                entry['path'] = new_path
                yaml_changed = True
                print(f"  >> Moved successfully.")
            except Exception as e:
                print(f"  !! Failed to move: {e}")
        else:
            print("  >> Skipped.")

    # 3. Finalize YAML
    if yaml_changed:
        with open(yaml_path, 'w') as f:
            yaml.dump(config, f, default_flow_style=False, sort_keys=False)
        print(f"\nUpdated YAML: {yaml_path}")
    else:
        print("\nNo changes made to YAML.")

if __name__ == "__main__":
    import sys
    if len(sys.argv) < 2:
        print("Usage: python file_fixer.py <your_project.yaml>")
    else:
        fix_errant_files(sys.argv[1])
