import os, sys, yaml, curses, sqlite3, librosa, soundfile as sf, numpy as np, requests, json
from datetime import datetime, timedelta
from scipy.ndimage import uniform_filter1d
from difflib import SequenceMatcher

# Known Whisper Hallucinations when fed silence/heavy noise reduction
HALLUCINATIONS = [
    "thank you for watching", "subscribe to my channel", "circlelineartschool",
    "pissedconsumer", "amara.org", "lrcgenerator", "beadaholique", "arf! arf!"
]

class AgenticTrainer:
    def __init__(self, yaml_path):
        self.yaml_path = yaml_path
        self.project_name = os.path.splitext(os.path.basename(yaml_path))[0]
        self.db_path = f"{self.project_name}_audit.db"
        if not os.path.exists(yaml_path): sys.exit(1)
        with open(yaml_path, 'r') as f: self.config = yaml.safe_load(f)
        with open('openai_key.txt', 'r') as k: self.api_key = k.read().strip()
        self.selected_indices = set()
        self.global_best_accuracy = 0.0
        self.global_best_params = {}
        self.file_memory = {}

    def get_manual_lines(self):
        with sqlite3.connect(self.db_path) as conn:
            c = conn.cursor()
            c.execute("PRAGMA table_info(transcript)")
            col = 'text' if 'text' in [i[1] for i in c.fetchall()] else 'content'
            # Ensure lines are strictly chronologically ordered
            return c.execute(f"SELECT ts, {col} FROM transcript WHERE {col} NOT LIKE '-- %' AND {col} != '' ORDER BY ts ASC").fetchall()

    def get_context(self, target_ts):
        """Finds adjacent lines within a +/- 5 second window."""
        lines = self.get_manual_lines()
        target_dt = datetime.strptime(target_ts, '%Y%m%d%H%M%S')
        before, after = None, None

        for i, (ts, text) in enumerate(lines):
            if ts == target_ts:
                # Check previous line
                if i > 0:
                    p_ts, p_txt = lines[i-1]
                    p_dt = datetime.strptime(p_ts, '%Y%m%d%H%M%S')
                    if abs((target_dt - p_dt).total_seconds()) <= 5.0:
                        before = f"[{p_ts}] {p_txt}"
                # Check next line
                if i < len(lines) - 1:
                    n_ts, n_txt = lines[i+1]
                    n_dt = datetime.strptime(n_ts, '%Y%m%d%H%M%S')
                    if abs((n_dt - target_dt).total_seconds()) <= 5.0:
                        after = f"[{n_ts}] {n_txt}"
                break
        return before, after

    def get_dynamic_duration(self, ts, max_duration=8.0):
        with sqlite3.connect(self.db_path) as conn:
            row = conn.cursor().execute("SELECT ts FROM transcript WHERE ts > ? ORDER BY ts ASC LIMIT 1", (ts,)).fetchone()
            if row:
                delta = (datetime.strptime(row[0], '%Y%m%d%H%M%S') - datetime.strptime(ts, '%Y%m%d%H%M%S')).total_seconds()
                return min(max(delta, 1.0), max_duration)
        return max_duration

    def process_variant(self, y, sr, p):
        mag, phase = librosa.magphase(librosa.stft(y))
        mag_c = np.maximum(mag - (np.median(mag, axis=1, keepdims=True) * p.get('noise_floor', 1.5)), mag * p.get('alpha', 0.1))
        y_s = uniform_filter1d(librosa.istft(mag_c * phase), size=max(1, int(p.get('window_size', 5))))
        min_len = min(len(y), len(y_s))
        y_f = (y[:min_len] * p.get('overlay', 0.4)) + (y_s[:min_len] * (1 - p.get('overlay', 0.4)))
        if p.get('pitch_shift', 0.0) != 0.0: y_f = librosa.effects.pitch_shift(y_f, sr=sr, n_steps=p.get('pitch_shift'))
        return librosa.util.normalize(y_f)

    def get_whisper_score(self, y, sr, truth):
        sf.write("train_temp.wav", y, sr)
        with open("train_temp.wav", "rb") as f:
            r = requests.post("https://api.openai.com/v1/audio/transcriptions",
                              headers={"Authorization": f"Bearer {self.api_key}"},
                              data={"model": "whisper-1", "temperature": "0.0"},
                              files={"file": f})
        if r.status_code != 200: return 0.0, "API_ERROR", False
        guess = r.json().get('text', "")
        clean = lambda t: t.split(':', 1)[1].strip() if ':' in t and len(t.split(':', 1)[0]) < 25 else t.strip()

        guess_lower = clean(guess).lower()
        is_hallucination = any(h in guess_lower for h in HALLUCINATIONS)

        return SequenceMatcher(None, clean(truth).lower(), guess_lower).ratio(), clean(guess), is_hallucination

    def ask_llm_optimizer(self, truth, history, filename):
        prompt = f"Target: {truth}\nFile: {filename}\nHistory: {json.dumps(history)}\n"
        prompt += "CRITICAL RULE: If you see 'HALLUCINATION DETECTED' in the history, it means Whisper hallucinated YouTube artifacts because your noise_floor was too high and completely erased the speech. You MUST lower the noise_floor significantly.\n"
        prompt += "Suggest NEXT params (window_size 1-20, noise_floor 0.5-5.0, pitch_shift -4.0-4.0, overlay 0.1-0.9, alpha 0.01-0.3). Return ONLY valid JSON."

        r = requests.post("https://api.openai.com/v1/chat/completions", headers={"Authorization": f"Bearer {self.api_key}"}, json={"model": "gpt-4o", "messages": [{"role": "user", "content": prompt}], "temperature": 0.4})
        try:
            content = r.json()['choices'][0]['message']['content'].strip()
            tick = chr(96)
            return json.loads(content.replace(tick*3 + "json", "").replace(tick*3, "").strip())
        except:
            return {"window_size": 5, "noise_floor": 1.5, "pitch_shift": 0.0, "overlay": 0.4, "alpha": 0.1}

    def select_ui(self, stdscr):
        curses.curs_set(0)
        lines = self.get_manual_lines()
        if not lines: return []
        idx = 0
        while True:
            stdscr.erase()
            max_y, max_x = stdscr.getmaxyx()
            page_size = max(1, max_y - 4)
            start_idx = (idx // page_size) * page_size
            stdscr.addstr(0, 0, f" AGENTIC TRAINING | PAGE {(idx//page_size)+1}/{(len(lines)+page_size-1)//page_size} | {len(self.selected_indices)} SEL ".center(max_x, " "), curses.A_REVERSE)
            for i in range(start_idx, min(start_idx + page_size, len(lines))):
                stdscr.addstr((i - start_idx) + 2, 2, f"{'[X]' if i in self.selected_indices else '[ ]'} [{lines[i][0]}] {lines[i][1][:max_x-25]}", curses.A_REVERSE if i == idx else curses.A_NORMAL)
            stdscr.addstr(max_y - 1, 0, "[UP/DN] Move | [PGUP/PGDN] Page | [SPACE] Toggle | [ENTER] Start | [ESC] Cancel", curses.A_DIM)
            ch = stdscr.getch()
            if ch == curses.KEY_UP: idx = max(0, idx - 1)
            elif ch == curses.KEY_DOWN: idx = min(len(lines) - 1, idx + 1)
            elif ch == curses.KEY_PPAGE: idx = max(0, idx - page_size)
            elif ch == curses.KEY_NPAGE: idx = min(len(lines) - 1, idx + page_size)
            elif ch == ord(' '): self.selected_indices.remove(idx) if idx in self.selected_indices else self.selected_indices.add(idx)
            elif ch in [10, 13, curses.KEY_ENTER]:
                if self.selected_indices: break
            elif ch == 27: return []
        return [lines[i] for i in self.selected_indices]

    def train(self, training_set):
        import warnings
        warnings.filterwarnings('ignore')

        for ts, truth in training_set:
            ctx_before, ctx_after = self.get_context(ts)
            print(f"\n{'='*70}")
            if ctx_before: print(f"Context (Before): {ctx_before}")
            print(f"Target:           [{ts}] '{truth}'")
            if ctx_after:  print(f"Context (After):  {ctx_after}")
            print(f"{'='*70}")

            for y, sr, filename in [(y, sr, os.path.basename(f['path'])) for f in self.config.get('files', []) if os.path.exists(f['path']) and datetime.strptime(f['start'], '%Y-%m-%d %H:%M:%S') <= datetime.strptime(ts, '%Y%m%d%H%M%S') <= datetime.strptime(f['start'], '%Y-%m-%d %H:%M:%S') + timedelta(minutes=60) for y, sr in [librosa.load(f['path'], sr=22050, offset=(datetime.strptime(ts, '%Y%m%d%H%M%S') - datetime.strptime(f['start'], '%Y-%m-%d %H:%M:%S')).total_seconds(), duration=self.get_dynamic_duration(ts))] if len(y) > 0]:
                current = self.file_memory.get(filename, {"window_size": 5, "noise_floor": 1.5, "pitch_shift": 0.0, "overlay": 0.4, "alpha": 0.1})
                history = []
                best_local = 0.0
                print(f"\n>> AI Optimizer focusing on Source: {filename} at {ts}")
                for it in range(5):
                    score, guess, is_halluc = self.get_whisper_score(self.process_variant(y, sr, current), sr, truth)

                    if is_halluc:
                        print(f"   Iter {it+1} | [!] HALLUCINATION DETECTED: AI erased the voice.")
                        history.append({"params": current, "guess": "HALLUCINATION DETECTED. LOWER NOISE FLOOR.", "score": 0.0})
                    else:
                        print(f"   Iter {it+1} | Acc: {score:.2f} | AI: '{guess}' | Params: {current}")
                        history.append({"params": current, "guess": guess, "score": score})

                        if score > best_local:
                            best_local, self.file_memory[filename] = score, current
                            if score > self.global_best_accuracy:
                                self.global_best_accuracy, self.global_best_params = score, {**current, 'best_source_file': filename}

                        if score >= 0.95: break

                    if it < 4: current = self.ask_llm_optimizer(truth, history, filename)

        if self.global_best_params:
            with open(f"{self.project_name}_trained_model.json", 'w') as f: json.dump({'params': self.global_best_params, 'accuracy': self.global_best_accuracy}, f, indent=4)
            print(f"\nSaved! Best Acc: {self.global_best_accuracy:.2f} on {self.global_best_params['best_source_file']}")

if __name__ == "__main__":
    if len(sys.argv) > 1:
        t = AgenticTrainer(sys.argv[1])
        if selected := curses.wrapper(t.select_ui): t.train(selected)
