import re
import yaml
import os
import subprocess
import sys
from datetime import datetime

# Import the existing streaming enhancement logic
try:
    from testaudiostream import enhance_large_audio
except ImportError:
    print("Error: testaudiostream.py must be in the same directory.")
    sys.exit(1)

YAML_FILE = "fcpaphos_project.yaml"
OUTPUT_DIR = "fcpaphos"

raw_mp4s = [
    "11_12_ag_2023Oct10ARef/20231010_093912_tp00006.mp4",
    "11_12_ag_2023Oct10ARef/20231010_101338_tp00025.mp4",
    "11_12_ag_2023Oct10ARef/20231010_104209_tp00026.mp4",
    "11_12_ag_2023Oct10ARef/20231010_111037_tp00027.mp4",
    "11_12_ag_2023Oct10ARef/20231010_111449_tp00007.mp4",
    "11_12_ag_2023Oct10ARef/20231010_113950_tp00028.mp4",
    "11_12_ag_2023Oct10ARef/20231010_120920_tp00029.mp4",
    "11_12_ag_2023Oct10ARef/20231010_123846_tp00030.mp4",
    "11_12_ag_2023Oct10ARef/20231010_125918_tp00008.mp4",
    "11_12_ag_2023Oct10ARef/20231010_130704_tp00031.mp4",
    "11_12_ag_2023Oct10ARef/20231010_133521_tp00032.mp4",
    "11_12_ag_2023Oct10ARef/20231010_140344_tp00033.mp4",
    "11_12_ag_2023Oct10ARef/20231010_143200_tp00034.mp4",
    "11_12_ag_2023Oct10ARef/20231010_144510_tp00009.mp4"
]

def parse_filename(filename):
    """Extracts timestamp, tp identifier, and assigns camera logic."""
    basename = os.path.basename(filename)
    match = re.search(r'(\d{8}_\d{6})_(tp\d+)', basename)
    if not match:
        return None, None, None, None

    ts_raw = match.group(1)
    tp_id = match.group(2)

    # Format to YYYY-MM-DD HH:MM:SS
    dt_str = f"{ts_raw[:4]}-{ts_raw[4:6]}-{ts_raw[6:8]} {ts_raw[9:11]}:{ts_raw[11:13]}:{ts_raw[13:15]}"

    # Assign Camera based on ID
    # tp00006 - tp00009 are FD feeds
    tp_num = int(tp_id.replace("tp", ""))
    if 6 <= tp_num <= 9:
        cam_type = "FD"
    else:
        cam_type = "FC"

    return dt_str, ts_raw, tp_id, cam_type

def process_and_generate_entries():
    entries = []

    if not os.path.exists(OUTPUT_DIR):
        os.makedirs(OUTPUT_DIR)

    for idx, mp4_path in enumerate(raw_mp4s):
        print(f"\n{'='*70}")
        print(f" PROCESSING FILE {idx+1} of {len(raw_mp4s)}")
        print(f" TARGET: {mp4_path}")
        print(f"{'='*70}")

        if not os.path.exists(mp4_path):
            print(f" [!] SKIPPING: File not found -> {mp4_path}")
            continue

        dt_str, ts_raw, tp_id, cam_type = parse_filename(mp4_path)
        if not dt_str:
            print(f" [!] SKIPPING: Unrecognized filename format -> {mp4_path}")
            continue

        base_name = f"{ts_raw}_{tp_id}"

        # Intermediate WAV paths
        raw_amp32_wav = os.path.join(OUTPUT_DIR, f"{base_name}_amp32_TEMP.wav")
        enhanced_wav = os.path.join(OUTPUT_DIR, f"enhanced_{base_name}_TEMP.wav")
        enhanced_plus20_wav = os.path.join(OUTPUT_DIR, f"enhanced_{base_name}_plus20_TEMP.wav")

        # GENERATION PHASE
        # 1. Raw +32dB WAV
        print(f" -> Step 1/3: Applying +32dB Pre-Amp...")
        subprocess.run(['ffmpeg', '-y', '-i', mp4_path, '-af', 'volume=32dB', '-hide_banner', '-loglevel', 'error', '-stats', raw_amp32_wav])

        # 2. Neural Enhancement
        print(f" -> Step 2/3: Neural Streaming Enhancement...")
        enhance_large_audio(raw_amp32_wav, enhanced_wav)

        # 3. Post-Amp +20dB
        print(f" -> Step 3/3: Final +20dB Post-Amp Recovery...")
        subprocess.run(['ffmpeg', '-y', '-i', enhanced_wav, '-af', 'volume=20dB', '-hide_banner', '-loglevel', 'error', '-stats', enhanced_plus20_wav])

        # ARCHIVING PHASE
        print(f"\n -> Phase 2: Archiving Multi-Stage Tracks to Ogg Q10...")
        if cam_type == "FD":
            conversion_map = [
                (mp4_path, f"{base_name}_original.ogg", "FD Feed (Original)"),
                (raw_amp32_wav, f"{base_name}_amp32.ogg", "FD Feed (Raw Amp +32dB)"),
                (enhanced_wav, f"enhanced_{base_name}.ogg", "FD Feed (Enhanced)"),
                (enhanced_plus20_wav, f"enhanced_{base_name}_plus20.ogg", "FD Feed (Enhanced +20dB)")
            ]
        else:
            conversion_map = [
                (mp4_path, f"{base_name}_original.ogg", "Original (Ogg Q10)"),
                (raw_amp32_wav, f"{base_name}_amp32.ogg", "Raw Amp +32dB (Ogg Q10)"),
                (enhanced_wav, f"enhanced_{base_name}.ogg", "Enhanced (Ogg Q10)"),
                (enhanced_plus20_wav, f"enhanced_{base_name}_plus20.ogg", "Enhanced Amp +20dB (Ogg Q10)")
            ]

        for i, (src_path, out_name, label) in enumerate(conversion_map):
            out_path = os.path.join(OUTPUT_DIR, out_name)
            print(f"    [{i+1}/{len(conversion_map)}] Finalizing {label}...")
            # For the original from MP4, we just copy the audio stream if possible, or re-encode if necessary
            # Using -vn to strip video, -c:a libvorbis -q:a 10 for ogg
            subprocess.run(['ffmpeg', '-y', '-i', src_path, '-vn', '-c:a', 'libvorbis', '-q:a', '10', '-hide_banner', '-loglevel', 'error', '-stats', out_path])

            entries.append({
                'path': out_path,
                'start': dt_str,
                'type': label
            })

        # CLEANUP PHASE
        print(f"\n -> Phase 3: Cleanup and Space Recovery...")
        for temp_wav in [raw_amp32_wav, enhanced_wav, enhanced_plus20_wav]:
            if os.path.exists(temp_wav):
                try:
                    os.remove(temp_wav)
                    print(f"    [CLEANED] {os.path.basename(temp_wav)}")
                except:
                    print(f"    [!] Warning: Could not delete {temp_wav}")

    return entries

def append_to_yaml():
    new_entries = process_and_generate_entries()

    if not new_entries:
        print("\n[!] No new entries generated. Check file paths and errors.")
        return

    print(f"\nReading existing {YAML_FILE}...")
    if os.path.exists(YAML_FILE):
        with open(YAML_FILE, 'r') as f:
            config = yaml.safe_load(f) or {}
    else:
        config = {'files': []}

    if 'files' not in config:
        config['files'] = []

    existing_paths = {entry['path'] for entry in config['files']}

    added_count = 0
    for entry in new_entries:
        if entry['path'] not in existing_paths:
            config['files'].append(entry)
            added_count += 1

    # Sort files chronologically for a cleaner YAML
    config['files'].sort(key=lambda x: x.get('start', ''))

    with open(YAML_FILE, 'w') as f:
        yaml.dump(config, f, default_flow_style=False, sort_keys=False)

    print(f"\n{'*'*70}")
    print(f"Successfully generated files and appended {added_count} new track variants to {YAML_FILE}.")
    print(f"{'*'*70}")

if __name__ == "__main__":
    append_to_yaml()
