import os
import sys
import yaml
import curses
import sqlite3
import librosa
import soundfile as sf
import numpy as np
import requests
import json
import traceback
import base64
import io
from datetime import datetime, timedelta
from scipy.ndimage import uniform_filter1d
import scipy.signal as signal
from difflib import SequenceMatcher
import warnings
import inspect

warnings.filterwarnings('ignore')

HALLUCINATIONS = [
    "thank you for watching", "subscribe to my channel", "circlelineartschool",
    "pissedconsumer", "amara.org", "lrcgenerator", "beadaholique", "arf! arf!",
    "субтитры", "dimatorzok"
]

class GeminiCoderTrainer:
    def __init__(self, yaml_path):
        self.yaml_path = yaml_path
        self.project_name = os.path.splitext(os.path.basename(yaml_path))[0]
        self.db_path = f"{self.project_name}_audit.db"
        if not os.path.exists(yaml_path): sys.exit(1)
        with open(yaml_path, 'r') as f: self.config = yaml.safe_load(f)

        try:
            with open('openai_key.txt', 'r') as k: self.openai_key = k.read().strip()
        except:
            print("Error: openai_key.txt missing.")
            sys.exit(1)

        try:
            with open('gemini_key.txt', 'r') as k: self.gemini_key = k.read().strip()
        except:
            print("Error: gemini_key.txt missing.")
            sys.exit(1)

        self.selected_indices = set()
        self.global_best_accuracy = 0.0
        self.global_best_code = ""
        self.global_best_file = ""
        self.file_memory = {}

    def get_manual_lines(self):
        with sqlite3.connect(self.db_path) as conn:
            c = conn.cursor()
            c.execute("PRAGMA table_info(transcript)")
            col = 'text' if 'text' in [i[1] for i in c.fetchall()] else 'content'
            return c.execute(f"SELECT ts, {col} FROM transcript WHERE {col} NOT LIKE '-- %' AND {col} != '' ORDER BY ts ASC").fetchall()

    def get_context(self, target_ts):
        lines = self.get_manual_lines()
        target_dt = datetime.strptime(target_ts, '%Y%m%d%H%M%S')
        before, after = None, None
        for i, (ts, text) in enumerate(lines):
            if ts == target_ts:
                if i > 0 and abs((target_dt - datetime.strptime(lines[i-1][0], '%Y%m%d%H%M%S')).total_seconds()) <= 5.0:
                    before = f"[{lines[i-1][0]}] {lines[i-1][1]}"
                if i < len(lines) - 1 and abs((datetime.strptime(lines[i+1][0], '%Y%m%d%H%M%S') - target_dt).total_seconds()) <= 5.0:
                    after = f"[{lines[i+1][0]}] {lines[i+1][1]}"
                break
        return before, after

    def get_dynamic_duration(self, ts, max_duration=8.0):
        with sqlite3.connect(self.db_path) as conn:
            row = conn.cursor().execute("SELECT ts FROM transcript WHERE ts > ? ORDER BY ts ASC LIMIT 1", (ts,)).fetchone()
            if row: return min(max((datetime.strptime(row[0], '%Y%m%d%H%M%S') - datetime.strptime(ts, '%Y%m%d%H%M%S')).total_seconds(), 1.0), max_duration)
        return max_duration

    def get_whisper_transcription(self, y, sr):
        """OpenAI Whisper Grade."""
        buf = io.BytesIO()
        sf.write(buf, y, sr, format='WAV')
        buf.seek(0)
        try:
            r = requests.post("https://api.openai.com/v1/audio/transcriptions",
                              headers={"Authorization": f"Bearer {self.openai_key}"},
                              data={"model": "whisper-1", "temperature": "0.0"},
                              files={"file": ("audio.wav", buf)})
            return r.json().get('text', "")
        except:
            return ""

    def get_gemini_transcription(self, y, sr):
        """Gemini Multi-modal Grade."""
        buf = io.BytesIO()
        sf.write(buf, y, sr, format='WAV')
        audio_b64 = base64.b64encode(buf.getvalue()).decode('utf-8')

        url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-preview-09-2025:generateContent?key={self.gemini_key}"
        payload = {
            "contents": [{
                "role": "user",
                "parts": [
                    {"text": "Transcribe the audio exactly. If you hear nothing, return an empty string. Ignore background noise. Focus strictly on the human speech."},
                    {"inlineData": {"mimeType": "audio/wav", "data": audio_b64}}
                ]
            }]
        }
        try:
            r = requests.post(url, headers={"Content-Type": "application/json"}, json=payload)
            return r.json()['candidates'][0]['content']['parts'][0]['text'].strip()
        except:
            return ""

    def get_dual_score(self, y, sr, truth):
        whisper_text = self.get_whisper_transcription(y, sr)
        gemini_text = self.get_gemini_transcription(y, sr)

        clean = lambda t: t.split(':', 1)[1].strip() if ':' in t and len(t.split(':', 1)[0]) < 25 else t.strip()
        truth_clean = clean(truth).lower()

        w_guess = clean(whisper_text).lower()
        g_guess = clean(gemini_text).lower()

        is_halluc = any(h in w_guess for h in HALLUCINATIONS)

        w_score = SequenceMatcher(None, truth_clean, w_guess).ratio()
        g_score = SequenceMatcher(None, truth_clean, g_guess).ratio()

        # Blended Consensus Score
        final_score = (w_score * 0.5) + (g_score * 0.5)

        return final_score, whisper_text, gemini_text, is_halluc

    def ask_gemini_coder(self, truth, history, filename):
        prompt = (
            "You are an elite, unconstrained forensic audio engineer and Python DSP developer.\n"
            "Your mission is to aggressively process highly distorted, noisy CCTV/bodycam audio so that transcription AIs can hear it perfectly.\n"
            f"Target human transcription: '{truth}'\n"
            f"Source File: {filename}\n\n"
            "History of attempted Python functions and their resulting Dual-AI consensus scores:\n"
            f"{json.dumps(history, indent=2)}\n\n"
            "CRITICAL RULES:\n"
            "1. RADICALLY change your approach if scores are low. Use radar/sonar/radio interference techniques.\n"
            "2. Access concurrent audio via `def optimize_audio(y, sr, other_tracks):` (other_tracks is a dict of {filename: numpy_array}). Use for noise cancellation/beamforming.\n"
            "3. Use advanced DSP: Butterworth filters, HPSS, spectral gating, time-stretching (0.5x to 1.5x), and multi-channel correlation.\n"
            "4. Return ONLY raw Python code starting with 'def optimize_audio(y, sr, other_tracks):'. No markdown formatting."
        )

        payload = {
            "contents": [{"parts": [{"text": prompt}]}],
            "generationConfig": {"temperature": 0.7}
        }

        url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-preview-09-2025:generateContent?key={self.gemini_key}"
        r = requests.post(url, headers={"Content-Type": "application/json"}, json=payload)

        try:
            content = r.json()['candidates'][0]['content']['parts'][0]['text'].strip()
            tick3 = chr(96) * 3
            if content.startswith(tick3 + "python"): content = content[9:]
            if content.startswith(tick3): content = content[3:]
            if content.endswith(tick3): content = content[:-3]
            return content.strip()
        except:
            return "def optimize_audio(y, sr, other_tracks):\n    import librosa\n    return librosa.util.normalize(y)"

    def execute_generated_code(self, y, sr, other_tracks, code_str):
        local_scope = {}
        try:
            exec(code_str, globals(), local_scope)
            func = local_scope['optimize_audio']
            sig = inspect.signature(func)
            if len(sig.parameters) >= 3:
                y_processed = func(y.copy(), sr, other_tracks)
            else:
                y_processed = func(y.copy(), sr)

            if not isinstance(y_processed, np.ndarray):
                return None, "PYTHON ERROR: Did not return a numpy array."
            if np.isnan(y_processed).any() or np.all(y_processed == 0):
                return None, "PYTHON ERROR: Returned array is empty or contains NaNs."

            return librosa.util.normalize(y_processed), "SUCCESS"
        except Exception as e:
            return None, f"PYTHON ERROR: {traceback.format_exc().splitlines()[-1]}"

    def select_ui(self, stdscr):
        curses.curs_set(0)
        lines = self.get_manual_lines()
        if not lines: return []
        idx = 0
        while True:
            stdscr.erase()
            max_y, max_x = stdscr.getmaxyx()
            page_size = max(1, max_y - 4)
            start_idx = (idx // page_size) * page_size
            stdscr.addstr(0, 0, f" DUAL-AI CODER | PAGE {(idx//page_size)+1}/{(len(lines)+page_size-1)//page_size} | {len(self.selected_indices)} SEL ".center(max_x, " "), curses.A_REVERSE)
            for i in range(start_idx, min(start_idx + page_size, len(lines))):
                stdscr.addstr((i - start_idx) + 2, 2, f"{'[X]' if i in self.selected_indices else '[ ]'} [{lines[i][0]}] {lines[i][1][:max_x-25]}", curses.A_REVERSE if i == idx else curses.A_NORMAL)
            stdscr.addstr(max_y - 1, 0, "[UP/DN] Move | [SPACE] Toggle | [ENTER] Start", curses.A_DIM)
            ch = stdscr.getch()
            if ch == curses.KEY_UP: idx = max(0, idx - 1)
            elif ch == curses.KEY_DOWN: idx = min(len(lines) - 1, idx + 1)
            elif ch == ord(' '): self.selected_indices.remove(idx) if idx in self.selected_indices else self.selected_indices.add(idx)
            elif ch in [10, 13, curses.KEY_ENTER]: break
        return [lines[i] for i in self.selected_indices]

    def train(self, training_set):
        for ts, truth in training_set:
            ctx_before, ctx_after = self.get_context(ts)
            print(f"\n{'='*70}\nTarget: [{ts}] '{truth}'\n{'='*70}")

            target_dt = datetime.strptime(ts, '%Y%m%d%H%M%S')
            duration = self.get_dynamic_duration(ts)
            snippets = []

            for f in self.config.get('files', []):
                if not os.path.exists(f['path']): continue
                try:
                    f_start = datetime.strptime(f['start'], '%Y-%m-%d %H:%M:%S')
                    if f_start <= target_dt <= f_start + timedelta(minutes=60):
                        offset = (target_dt - f_start).total_seconds()
                        y_raw, _ = librosa.load(f['path'], sr=22050, offset=offset, duration=duration)
                        if len(y_raw) > 0: snippets.append((y_raw, 22050, os.path.basename(f['path'])))
                except: pass

            available_tracks = {fname: y for y, sr, fname in snippets}

            for y, sr, filename in snippets:
                other_tracks = {k: v for k, v in available_tracks.items() if k != filename}
                current_code = self.file_memory.get(filename, "def optimize_audio(y, sr, other_tracks):\n    import librosa\n    return librosa.util.normalize(y)")
                history = []
                best_local = 0.0

                print(f"\n>> Training on Source: {filename}")
                for it in range(8):
                    y_proc, status = self.execute_generated_code(y, sr, other_tracks, current_code)
                    if y_proc is None:
                        print(f"   Iter {it+1} | [!] {status}")
                        history.append({"code": current_code, "error": status, "score": 0.0})
                    else:
                        score, w_guess, g_guess, is_halluc = self.get_dual_score(y_proc, sr, truth)
                        print(f"   Iter {it+1} | Consensus: {score:.2f} | W: '{w_guess[:25]}' | G: '{g_guess[:25]}'")

                        history.append({"code": current_code, "whisper": w_guess, "gemini": g_guess, "score": score})
                        if score > best_local:
                            best_local, self.file_memory[filename] = score, current_code
                            if score > self.global_best_accuracy:
                                self.global_best_accuracy, self.global_best_code, self.global_best_file = score, current_code, filename
                        if score >= 0.95: break
                    current_code = self.ask_gemini_coder(truth, history, filename)

        if self.global_best_code:
            with open(f"{self.project_name}_trained_model.json", 'w') as f:
                json.dump({"file": self.global_best_file, "accuracy": self.global_best_accuracy, "python_code": self.global_best_code}, f, indent=4)
            print(f"\nSaved! Winner: {self.global_best_file} (Acc: {self.global_best_accuracy:.2f})")

if __name__ == "__main__":
    if len(sys.argv) > 1:
        t = GeminiCoderTrainer(sys.argv[1])
        if selected := curses.wrapper(t.select_ui): t.train(selected)
