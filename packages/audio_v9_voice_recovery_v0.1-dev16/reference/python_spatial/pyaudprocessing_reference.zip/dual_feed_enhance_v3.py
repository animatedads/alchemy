#!/usr/bin/env python3
"""
dual_feed_enhance_v3.py
=======================
Forensic Audio Enhancement — Dual-Feed Pipeline (v3)
"""

import os
import sys
import argparse
import yaml
import numpy as np
import soundfile as sf
import librosa
from datetime import datetime, timedelta
from scipy.fftpack import fft, ifft

# ---------------------------------------------------------------------------
# CORE TIMELINE ENGINE (YAML Driven)
# ---------------------------------------------------------------------------

def parse_dt(s):
    """Flexible datetime parser for selective ranging."""
    formats = ['%Y-%m-%d %H:%M:%S', '%Y-%m-%d %H:%M', '%Y-%m-%d']
    for fmt in formats:
        try:
            return datetime.strptime(s.strip(), fmt)
        except ValueError:
            continue
    raise ValueError(f"Time data '{s}' does not match recognized formats")

def determine_camera(yaml_type):
    """Reliably determine camera based exclusively on YAML description."""
    if "fd feed" in yaml_type.lower():
        return "cam_b"
    return "cam_a"

def matches_tier(yaml_type, target_tier):
    """Robust string matching to connect CLI args to YAML descriptions."""
    yt = yaml_type.lower()
    tt = target_tier.lower()
    if tt == "amp32": return "+32db" in yt or "amp32" in yt
    if tt == "plus20": return "+20db" in yt or "plus20" in yt
    if tt == "enhanced": return "enhanced" in yt and "+20" not in yt
    if tt == "original": return "original" in yt
    return False

def find_file_for_time(files, target_cam, current_t, target_tier="amp32"):
    """
    Find the active file for a given camera and time.
    Grabs the MOST RECENT file that started before current_t.
    """
    valid_files = []

    for f in files:
        yaml_type = f.get('type', '')
        cam = determine_camera(yaml_type)

        if cam == target_cam and matches_tier(yaml_type, target_tier):
            start = parse_dt(f['start'])
            if start <= current_t:
                valid_files.append((start, f))

    if not valid_files:
        return None

    # Sort by start time descending (most recent first)
    valid_files.sort(key=lambda x: x[0], reverse=True)
    most_recent_start, best_file = valid_files[0]

    # Safety margin: If the most recent file started over 4 hours ago, we are in a dead gap
    if current_t - most_recent_start > timedelta(hours=4):
        return None

    return best_file

def load_audio_segment(path, start_dt, target_t, duration_sec, sr=22050):
    offset = (target_t - start_dt).total_seconds()
    if offset < 0: return None

    try:
        # Check duration to prevent librosa seeking past EOF
        file_dur = librosa.get_duration(path=path)
        if offset >= file_dur: return None

        y, _ = librosa.load(path, sr=sr, offset=offset, duration=duration_sec)

        target_len = int(duration_sec * sr)
        if len(y) < target_len:
            y = np.pad(y, (0, target_len - len(y)))
        return y
    except Exception:
        return None

# ---------------------------------------------------------------------------
# RADAR / SONAR DSP TECHNIQUES
# ---------------------------------------------------------------------------

def gcc_phat_align(sig, refsig, fs=22050, max_tau=0.15):
    """Align sig to refsig using Generalized Cross-Correlation Phase Transform (GCC-PHAT)."""
    n = sig.shape[0] + refsig.shape[0]
    SIG = fft(sig, n=n)
    REFSIG = fft(refsig, n=n)
    R = SIG * np.conj(REFSIG)

    denom = np.maximum(np.abs(R), 1e-6)
    cc = np.real(ifft(R / denom))

    max_shift = int(max_tau * fs)
    cc = np.concatenate((cc[-max_shift:], cc[:max_shift+1]))
    shift = np.argmax(cc) - max_shift

    return np.roll(sig, shift)

def phase_coherence_mask(y_a, y_b, n_fft=2048):
    """
    Phase-coherence Wiener mask (RF interferometry approach).
    Keeps only the frequencies that are phase-aligned across both feeds.
    """
    if len(y_a) < n_fft or len(y_b) < n_fft:
        return y_a

    S_a = librosa.stft(y_a, n_fft=n_fft)
    S_b = librosa.stft(y_b, n_fft=n_fft)

    # Cross-power spectrum
    cps = S_a * np.conj(S_b)
    mag_a, mag_b = np.abs(S_a), np.abs(S_b)

    # Coherence score (0 to 1)
    coherence = np.abs(cps) / (mag_a * mag_b + 1e-8)

    # Apply coherence as a mask to isolate the "beam"
    S_center = S_a * coherence

    # CRITICAL FIX: Pass exactly len(y_a) so ISTFT doesn't truncate samples!
    return librosa.istft(S_center, length=len(y_a))

# ---------------------------------------------------------------------------
# MAIN PROCESSOR
# ---------------------------------------------------------------------------

def run_v3_pipeline(yaml_path, tier, start_time, end_time, out_path):
    with open(yaml_path, 'r') as f:
        config = yaml.safe_load(f)

    sr = 22050
    block_sec = 8.0

    print(f"[*] MVDR Beamformer v3 (YAML Engine)")
    print(f"[*] Processing: {start_time} to {end_time}")
    print(f"[*] Target Tier: '{tier}'")

    # Outputs 3 Channels: Left (Cam A), Right (Cam B), Center (Beam)
    with sf.SoundFile(out_path, mode='w', samplerate=sr, channels=3) as out:
        current_t = start_time
        blocks_dual = 0
        blocks_mono = 0
        blocks_silent = 0

        while current_t < end_time:
            # 1. Dynamically fetch files using the strict YAML metadata
            file_a = find_file_for_time(config['files'], "cam_a", current_t, target_tier=tier)
            file_b = find_file_for_time(config['files'], "cam_b", current_t, target_tier=tier)

            # 2. Load audio windows
            y_a = load_audio_segment(file_a['path'], parse_dt(file_a['start']), current_t, block_sec, sr) if file_a else None
            y_b = load_audio_segment(file_b['path'], parse_dt(file_b['start']), current_t, block_sec, sr) if file_b else None

            # 3. DSP Routing
            if y_a is not None and y_b is not None:
                blocks_dual += 1
                y_a_aligned = gcc_phat_align(y_a, y_b, fs=sr)
                center_beam = phase_coherence_mask(y_a_aligned, y_b)
                chunk = np.vstack((y_a_aligned, y_b, center_beam)).T

            elif y_a is not None:
                blocks_mono += 1
                chunk = np.vstack((y_a, y_a, y_a)).T

            elif y_b is not None:
                blocks_mono += 1
                chunk = np.vstack((y_b, y_b, y_b)).T

            else:
                blocks_silent += 1
                chunk = np.zeros((int(block_sec * sr), 3))

            # 4. Write and advance
            out.write(chunk)
            current_t += timedelta(seconds=block_sec)

            print(f"  Progress: {current_t:%Y-%m-%d %H:%M:%S} | Dual: {blocks_dual} Mono: {blocks_mono} Silent: {blocks_silent}", end="\r")

    print(f"\n\n{'='*60}")
    print(f"  Complete.")
    print(f"  Output      : {out_path}")
    print(f"  Dual blocks : {blocks_dual}")
    print(f"  Mono blocks : {blocks_mono}")
    print(f"  Silent      : {blocks_silent}")
    print(f"{'='*60}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Dual-feed forensic audio enhancement v3 (YAML Engine)")
    parser.add_argument("--yaml", required=True, help="Path to fcpaphos_project.yaml")
    parser.add_argument("--tier", default="amp32", help="Which tier to target (e.g., original, amp32, plus20)")
    parser.add_argument("--start", help="YYYY-MM-DD HH:MM:SS or HH:MM")
    parser.add_argument("--end", help="YYYY-MM-DD HH:MM:SS or HH:MM")
    parser.add_argument("--out", default="master_v3_beam.wav")
    args = parser.parse_args()

    with open(args.yaml, 'r') as f:
        cfg = yaml.safe_load(f)

    all_starts = sorted([parse_dt(f['start']) for f in cfg['files']])

    def handle_time(time_str, default_dt):
        if not time_str: return default_dt
        if "-" not in time_str: return parse_dt(f"2023-10-10 {time_str}")
        return parse_dt(time_str)

    t0 = handle_time(args.start, all_starts[0])
    t1 = handle_time(args.end, all_starts[-1] + timedelta(minutes=32))

    run_v3_pipeline(args.yaml, args.tier, t0, t1, args.out)
