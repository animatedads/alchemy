import os
import json
import yaml
import subprocess
import sys
from datetime import datetime, timedelta

# Import your existing streaming enhancement logic
try:
    from testaudiostream import enhance_large_audio
except ImportError:
    print("Error: testaudiostream.py must be in the same directory.")
    sys.exit(1)

# Configuration
INPUT_DIR = "rehab"
FILELIST = "filelistrehab.txt"
OUTPUT_YAML = "rehab.yaml"
BASE_START_TIME = datetime(2024, 5, 13, 12, 0, 0) # Default guess if no metadata

def get_metadata(filepath):
    """Uses ffprobe to extract duration and creation_time metadata."""
    cmd = [
        'ffprobe', '-v', 'quiet',
        '-select_streams', 'a:0',
        '-show_entries', 'format_tags=creation_time:format=duration',
        '-of', 'json', filepath
    ]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True)
        data = json.loads(result.stdout)
        duration = float(data.get('format', {}).get('duration', 0))
        tags = data.get('format', {}).get('tags', {})
        creation_time = tags.get('creation_time')

        if creation_time:
            # Handle common ISO formats from recorders
            for fmt in ("%Y-%m-%dT%H:%M:%S.%fZ", "%Y-%m-%d %H:%M:%S", "%Y-%m-%dT%H:%M:%SZ"):
                try:
                    return datetime.strptime(creation_time, fmt), duration
                except ValueError:
                    continue
        return None, duration
    except Exception as e:
        print(f"Warning: Could not probe {filepath}: {e}")
        return None, 0

def process_rehab_files():
    print(f"--- Rehab Project Forensic Prepper Engaged ---")

    if not os.path.exists(FILELIST):
        print(f"CRITICAL ERROR: {FILELIST} not found.")
        return

    raw_files = []
    with open(FILELIST, 'r') as f:
        for line in f:
            line = line.strip()
            if not line or not (line.endswith('.mp3') or line.endswith('.wav')):
                continue
            raw_files.append(line)

    total_files = len(raw_files)
    print(f"Detected {total_files} files for processing.")

    project_entries = []
    processed_count = 0
    current_guess_time = BASE_START_TIME

    # Track base filename to group simultaneous feeds (e.g. STE-017 and STE-017(1))
    time_map = {}

    for full_path in raw_files:
        if not os.path.isfile(full_path):
            print(f"SKIPPING: File not found -> {full_path}")
            continue

        processed_count += 1
        fname = os.path.basename(full_path)
        parent_dir = os.path.dirname(full_path)

        print(f"\n{'='*70}")
        print(f" PROCESSING FILE {processed_count} of {total_files}")
        print(f" TARGET: {fname}")
        print(f"{'='*70}")

        # Metadata and Time Handling
        meta_time, duration = get_metadata(full_path)

        # Clean name for grouping (e.g., STE-017(1) -> STE-017)
        base_name_id = fname.split('(')[0].split('.')[0]

        if meta_time:
            timestamp_dt = meta_time
        elif base_name_id in time_map:
            # This is a simultaneous feed (like CamA/CamB or Rec1/Rec2)
            timestamp_dt = time_map[base_name_id]
        else:
            # Guessing: use current_guess_time and update it for the next unique file
            timestamp_dt = current_guess_time
            time_map[base_name_id] = timestamp_dt
            current_guess_time += timedelta(seconds=duration + 1) # 1s gap

        timestamp_str = timestamp_dt.strftime('%Y-%m-%d %H:%M:%S')
        base_name = os.path.splitext(fname)[0]

        # PHASE 1: FORENSIC PIPELINE
        raw_amp32_wav = os.path.join(parent_dir, f"{base_name}_amp32_TEMP.wav")
        print(f" -> Step 1/3: Applying +32dB Pre-Amp...")
        subprocess.run(['ffmpeg', '-y', '-i', full_path, '-af', 'volume=32dB', '-hide_banner', '-loglevel', 'error', '-stats', raw_amp32_wav])

        enhanced_wav = os.path.join(parent_dir, f"enhanced_{base_name}_TEMP.wav")
        print(f" -> Step 2/3: Neural Enhancement (Streaming)...")
        enhance_large_audio(raw_amp32_wav, enhanced_wav)

        enhanced_plus20_wav = os.path.join(parent_dir, f"enhanced_{base_name}_plus20_TEMP.wav")
        print(f" -> Step 3/3: Final +20dB Post-Amp...")
        subprocess.run(['ffmpeg', '-y', '-i', enhanced_wav, '-af', 'volume=20dB', '-hide_banner', '-loglevel', 'error', '-stats', enhanced_plus20_wav])

        # PHASE 2: ARCHIVING (OGG Q10)
        print(f"\n -> Phase 2: Archiving Multi-Stage Tracks...")
        # Labeling for Dual-Feed compatibility (marking as CamA/CamB based on (1) suffix)
        cam_label = "CamB" if "(1)" in fname else "CamA"

        conversion_map = [
            (full_path, f"{base_name}_original.ogg", f"{cam_label} (Original)"),
            (raw_amp32_wav, f"{base_name}_amp32.ogg", f"{cam_label} (Raw Amp +32dB)"),
            (enhanced_wav, f"enhanced_{base_name}.ogg", f"{cam_label} (Enhanced)"),
            (enhanced_plus20_wav, f"enhanced_{base_name}_ampamp.ogg", f"{cam_label} (Enhanced Amp +20dB)")
        ]

        for i, (src_path, out_name, label) in enumerate(conversion_map):
            out_path = os.path.join(parent_dir, out_name)
            print(f"    [{i+1}/{len(conversion_map)}] Archiving {label}...")
            subprocess.run(['ffmpeg', '-y', '-i', src_path, '-c:a', 'libvorbis', '-q:a', '10', '-hide_banner', '-loglevel', 'error', '-stats', out_path])

            project_entries.append({
                'path': out_path,
                'start': timestamp_str,
                'type': label
            })

        # PHASE 3: CLEANUP
        for temp_wav in [raw_amp32_wav, enhanced_wav, enhanced_plus20_wav]:
            if os.path.exists(temp_wav):
                os.remove(temp_wav)

    # OUTPUT YAML
    if project_entries:
        project_config = {'files': project_entries}
        with open(OUTPUT_YAML, 'w') as f:
            yaml.dump(project_config, f, default_flow_style=False, sort_keys=False)
        print(f"\n{'*'*70}")
        print(f" REHAB PROJECT SETUP COMPLETE: {processed_count} files processed.")
        print(f" Project YAML created: {OUTPUT_YAML}")
        print(f"{'*'*70}")

if __name__ == "__main__":
    process_rehab_files()
