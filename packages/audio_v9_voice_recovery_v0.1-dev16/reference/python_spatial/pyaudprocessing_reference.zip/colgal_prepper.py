import os
import sys
import re
import yaml
import subprocess
from datetime import datetime

# Import the existing neural streaming enhancement logic
try:
    from testaudiostream import enhance_large_audio
except ImportError:
    print("[!] Error: testaudiostream.py must be in the same directory to run the neural enhancement.")
    sys.exit(1)

# --- CONFIGURATION ---
SOURCE_DIR = os.path.expanduser("~/blinkdl/blinkvids/")
OUTPUT_DIR = "colgal"
YAML_FILE = "colgal_project.yaml"

# Time boundaries
START_WINDOW = datetime(2026, 5, 15, 12, 0, 0)
END_WINDOW = datetime(2026, 5, 15, 23, 59, 59)

# Filename Regex: Matches '16M1' or '16N4' and the 14-digit timestamp
FILE_REGEX = re.compile(r'(16M1|16N4)\s*-\s*(\d{14})')

def parse_metadata(filename):
    """Extracts Camera ID and Timestamp from the Blink filename."""
    match = FILE_REGEX.search(filename)
    if not match:
        return None, None, None, None

    cam_code = match.group(1)
    ts_raw = match.group(2)

    # Parse to datetime object
    try:
        dt_obj = datetime.strptime(ts_raw, "%Y%m%d%H%M%S")
    except ValueError:
        return None, None, None, None

    dt_str = dt_obj.strftime("%Y-%m-%d %H:%M:%S")

    if cam_code == "16M1":
        cam_id = "Cam A"
    elif cam_code == "16N4":
        cam_id = "Cam B"
    else:
        cam_id = "Unknown"

    return dt_obj, dt_str, cam_id, ts_raw

def scan_and_filter_files():
    """Scans the source directory and filters files matching the exact time window."""
    valid_files = []

    if not os.path.exists(SOURCE_DIR):
        print(f"[!] Source directory {SOURCE_DIR} not found.")
        return valid_files

    for f in sorted(os.listdir(SOURCE_DIR)):
        if not f.lower().endswith(".mp4"):
            continue

        dt_obj, dt_str, cam_id, ts_raw = parse_metadata(f)

        if dt_obj and START_WINDOW <= dt_obj <= END_WINDOW:
            full_path = os.path.join(SOURCE_DIR, f)
            valid_files.append({
                'source_path': full_path,
                'filename': f,
                'cam_id': cam_id,
                'dt_str': dt_str,
                'ts_raw': ts_raw,
                'cam_code': "16M1" if cam_id == "Cam A" else "16N4"
            })

    return valid_files

def run_pipeline():
    print(f"=== COLGAL FORENSIC AUDIO PREPPER ===")
    print(f"Scanning: {SOURCE_DIR}")
    print(f"Window: {START_WINDOW} to {END_WINDOW}\n")

    targets = scan_and_filter_files()
    if not targets:
        print("[!] No files found matching the criteria and time window.")
        return

    print(f"Found {len(targets)} valid media files for processing.")

    if not os.path.exists(OUTPUT_DIR):
        os.makedirs(OUTPUT_DIR)
        print(f"[+] Created project directory: {OUTPUT_DIR}/")

    project_entries = []

    for idx, t in enumerate(targets):
        print(f"\n{'='*70}")
        print(f" PROCESSING FILE {idx+1}/{len(targets)} | {t['cam_id']} | {t['dt_str']}")
        print(f" TARGET: {t['filename']}")
        print(f"{'='*70}")

        base_name = f"{t['ts_raw']}_{t['cam_code']}"

        # Define the exact expected names and labels to check for preprocessed files
        expected_outputs = [
            (f"{base_name}_original.ogg", f"{t['cam_id']} Original (Ogg Q10)"),
            (f"{base_name}_amp32.ogg", f"{t['cam_id']} Raw Amp +32dB (Ogg Q10)"),
            (f"enhanced_{base_name}.ogg", f"{t['cam_id']} Enhanced (Ogg Q10)"),
            (f"enhanced_{base_name}_plus20.ogg", f"{t['cam_id']} Enhanced Amp +20dB (Ogg Q10)")
        ]

        # Check if all output files already exist
        all_exist = all(os.path.exists(os.path.join(OUTPUT_DIR, out_name)) for out_name, _ in expected_outputs)

        if all_exist:
            print(f"    [!] SKIPPING: All preprocessed files already exist for {t['filename']}.")
            for out_name, label in expected_outputs:
                project_entries.append({
                    'path': os.path.join(OUTPUT_DIR, out_name),
                    'start': t['dt_str'],
                    'type': label
                })
            continue

        # Temp WAV paths
        raw_amp32_wav = os.path.join(OUTPUT_DIR, f"{base_name}_amp32_TEMP.wav")
        enhanced_wav = os.path.join(OUTPUT_DIR, f"enhanced_{base_name}_TEMP.wav")
        enhanced_plus20_wav = os.path.join(OUTPUT_DIR, f"enhanced_{base_name}_plus20_TEMP.wav")

        # Stage 1: Raw +32dB WAV
        print(f" -> Step 1/3: Applying +32dB Pre-Amp...")
        result = subprocess.run(['ffmpeg', '-y', '-i', t['source_path'], '-af', 'volume=32dB', '-hide_banner', '-loglevel', 'error', '-stats', raw_amp32_wav])

        # Safety Check: Did FFmpeg actually extract an audio track?
        if result.returncode != 0 or not os.path.exists(raw_amp32_wav) or os.path.getsize(raw_amp32_wav) == 0:
            print(f"    [!] SKIPPING: FFmpeg failed to extract audio. {t['filename']} likely has no audio track.")
            if os.path.exists(raw_amp32_wav):
                try: os.remove(raw_amp32_wav)
                except: pass
            continue

        # Stage 2: Neural Enhancement
        print(f" -> Step 2/3: Neural Streaming Enhancement...")
        enhance_large_audio(raw_amp32_wav, enhanced_wav)

        # Stage 3: Post-Amp +20dB
        print(f" -> Step 3/3: Final +20dB Post-Amp Recovery...")
        subprocess.run(['ffmpeg', '-y', '-i', enhanced_wav, '-af', 'volume=20dB', '-hide_banner', '-loglevel', 'error', '-stats', enhanced_plus20_wav])

        # Stage 4: Ogg Archiving
        print(f"\n -> Phase 2: Archiving Multi-Stage Tracks to Ogg Q10...")

        conversion_map = [
            (t['source_path'], expected_outputs[0][0], expected_outputs[0][1]),
            (raw_amp32_wav, expected_outputs[1][0], expected_outputs[1][1]),
            (enhanced_wav, expected_outputs[2][0], expected_outputs[2][1]),
            (enhanced_plus20_wav, expected_outputs[3][0], expected_outputs[3][1])
        ]

        for i, (src_path, out_name, label) in enumerate(conversion_map):
            out_path = os.path.join(OUTPUT_DIR, out_name)
            print(f"    [{i+1}/{len(conversion_map)}] Finalizing {label}...")

            # Extract audio to high-quality Ogg Vorbis
            subprocess.run(['ffmpeg', '-y', '-i', src_path, '-vn', '-c:a', 'libvorbis', '-q:a', '10', '-hide_banner', '-loglevel', 'error', '-stats', out_path])

            project_entries.append({
                'path': out_path,
                'start': t['dt_str'],
                'type': label
            })

        # Stage 5: Cleanup Temp Files
        print(f"\n -> Phase 3: Cleanup and Space Recovery...")
        for temp_wav in [raw_amp32_wav, enhanced_wav, enhanced_plus20_wav]:
            if os.path.exists(temp_wav):
                try:
                    os.remove(temp_wav)
                except:
                    pass

    # Final YAML Generation
    print(f"\nBuilding YAML Project File...")
    project_entries.sort(key=lambda x: x['start'])

    config = {'files': project_entries}
    with open(YAML_FILE, 'w') as f:
        yaml.dump(config, f, default_flow_style=False, sort_keys=False)

    print(f"\n{'*'*70}")
    print(f"[+] COMPLETE: Processed {len(targets)} videos.")
    print(f"[+] Output Folder: ./{OUTPUT_DIR}/")
    print(f"[+] Generated Project Config: {YAML_FILE}")
    print(f"{'*'*70}")

if __name__ == "__main__":
    run_pipeline()
