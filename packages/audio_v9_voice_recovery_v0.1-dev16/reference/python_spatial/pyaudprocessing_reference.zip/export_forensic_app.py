import os
import sys
import argparse
import yaml
import numpy as np
import soundfile as sf
import librosa
from datetime import datetime, timedelta
from forensic_helper import ForensicHelper as fh

def parse_dt(s):
    return fh.parse_dt(s)

def render_aligned_tracks(yaml_path, start_str, end_str, tier, out_dir):
    os.makedirs(out_dir, exist_ok=True)

    t0 = parse_dt(start_str)
    t1 = parse_dt(end_str)

    if not t0 or not t1:
        print("[!] Error: Invalid start or end timestamp.")
        return

    total_duration_sec = (t1 - t0).total_seconds()
    print(f"=== Aligned Timeline Export Engine ===")
    print(f"Target Window: {t0} -> {t1} ({total_duration_sec:.1f}s)")
    print(f"Target Tier  : {tier}")
    print("-" * 50)

    SR = 22050
    BLOCK_SEC = 8.0
    # Process block-by-block with 0% overlap for clean, simple chronological stitching
    block_samples = int(BLOCK_SEC * SR)

    # Setup output file streams
    out_a_path = os.path.join(out_dir, f"sync_CamA_{tier}.ogg")
    out_b_path = os.path.join(out_dir, f"sync_CamB_{tier}.ogg")

    t = t0
    blocks_processed = 0

    with sf.SoundFile(out_a_path, mode='w', samplerate=SR, channels=1, format='OGG') as out_a, \
         sf.SoundFile(out_b_path, mode='w', samplerate=SR, channels=1, format='OGG') as out_b:

        while t < t1:
            # Calculate remaining time to avoid rendering past the exact end boundary
            remaining_sec = (t1 - t).total_seconds()
            current_block_sec = min(BLOCK_SEC, remaining_sec)
            current_samples = int(current_block_sec * SR)

            # Query all active files for this exact second
            streams = fh.get_active_streams(yaml_path, t.strftime('%Y-%m-%d %H:%M:%S'), tier=tier)

            y_a = np.zeros(current_samples)
            y_b = np.zeros(current_samples)

            active_a = active_b = False

            for s in streams:
                cam = s['cam_id']
                offset = (t - s['start_dt']).total_seconds()

                try:
                    # Load the physical segment corresponding to the current global timestamp
                    y_r, _ = librosa.load(s['path'], sr=SR, offset=offset, duration=current_block_sec)
                    if cam == 'Cam A' and not active_a:
                        y_a[:len(y_r)] = y_r
                        active_a = True
                    elif cam == 'Cam B' and not active_b:
                        y_b[:len(y_r)] = y_r
                        active_b = True
                except Exception:
                    continue

            # If Cam A has no data for this window, fill it with comfort noise
            if active_a:
                out_a.write(y_a)
            else:
                out_a.write(fh.generate_comfort_noise(current_samples, db=-55))

            # If Cam B has no data for this window, fill it with comfort noise
            if active_b:
                out_b.write(y_b)
            else:
                out_b.write(fh.generate_comfort_noise(current_samples, db=-55))

            t += timedelta(seconds=current_block_sec)
            blocks_processed += 1
            if blocks_processed % 5 == 0:
                pct = ( (t - t0).total_seconds() / total_duration_sec ) * 100
                print(f"  [{pct:5.1f}%] {t.strftime('%H:%M:%S')} Rendered", end='\r')

    print(f"\n\n[SUCCESS] Aligned Master Tracks Saved:")
    print(f"  -> Cam A: {out_a_path} (Duration: {total_duration_sec}s)")
    print(f"  -> Cam B: {out_b_path} (Duration: {total_duration_sec}s)")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--yaml", required=True)
    parser.add_argument("--start", required=True, help="YYYY-MM-DD HH:MM:SS")
    parser.add_argument("--end", required=True, help="YYYY-MM-DD HH:MM:SS")
    parser.add_argument("--tier", default="amp32")
    parser.add_argument("--outdir", default="exports")
    args = parser.parse_args()

    render_aligned_tracks(args.yaml, args.start, args.end, args.tier, args.outdir)
