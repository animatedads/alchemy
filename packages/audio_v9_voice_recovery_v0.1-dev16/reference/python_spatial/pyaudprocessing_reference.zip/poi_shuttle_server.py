#!/usr/bin/env python3
"""
POI Shuttle Server - investigative media review UI

Case-neutral FastAPI web UI for indexing evidence media, deriving dates/locations
from configurable YAML rules, manually assigning POIs, excluding unimportant files,
recording candidate number plates, and building simple association links.

This project does not identify real people by name. It creates internal POI labels
and evidence links for analyst review.
"""
from __future__ import annotations

import csv
import html
import io
import json
import mimetypes
import os
import re
import sqlite3
import threading
import time
import hashlib
import base64
import urllib.request
import urllib.error
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

import yaml
from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, HTMLResponse, Response
from pydantic import BaseModel
import uvicorn

APP_TITLE = "POI Shuttle"
BUILD = os.environ.get("POI_BUILD", "internal-2026.05.21.019")
DB_PATH = Path(os.environ.get("POI_DB", "poi_shuttle.db"))
MEDIA_ROOTS = [p for p in os.environ.get("POI_MEDIA_ROOTS", "./media").split(":") if p.strip()]
LOCATION_MAP_PATH = Path(os.environ.get("POI_LOCATION_MAP", "poi_location_map.yaml"))
PORT = int(os.environ.get("POI_PORT", "8081"))
HOST = os.environ.get("POI_HOST", "0.0.0.0")
SSL_KEYFILE = os.environ.get("POI_SSL_KEYFILE", "key.pem")
SSL_CERTFILE = os.environ.get("POI_SSL_CERTFILE", "cert.pem")
# AI provider selection. Use POI_AI_PROVIDER=openai, gemini, deepthink/deepseek, or auto.
# For image geolocation, OpenAI or Gemini are preferred because the agent needs vision.
AI_PROVIDER = os.environ.get("POI_AI_PROVIDER", "auto").strip().lower()
GEMINI_KEY_FILE = os.environ.get("POI_GEMINI_KEY_FILE", "geminiv2_key.txt")
GEMINI_API_KEY = os.environ.get("GEMINI_API_KEY", "")
GEMINI_MODEL = os.environ.get("POI_GEMINI_MODEL", "gemini-2.0-flash")
GEMINI_API_VERSION = os.environ.get("POI_GEMINI_API_VERSION", "v1beta")
OPENAI_KEY_FILE = os.environ.get("POI_OPENAI_KEY_FILE", "openai_key.txt")
OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY", "")
OPENAI_BASE_URL = os.environ.get("POI_OPENAI_BASE_URL", "https://api.openai.com/v1/chat/completions")
OPENAI_MODEL = os.environ.get("POI_OPENAI_MODEL", "gpt-4o-mini")
DEEPTHINK_KEY_FILE = os.environ.get("POI_DEEPTHINK_KEY_FILE", os.environ.get("POI_DEEPSEEK_KEY_FILE", "deepthink_key.txt"))
DEEPTHINK_API_KEY = os.environ.get("DEEPTHINK_API_KEY", os.environ.get("DEEPSEEK_API_KEY", ""))
DEEPTHINK_BASE_URL = os.environ.get("POI_DEEPTHINK_BASE_URL", os.environ.get("POI_DEEPSEEK_BASE_URL", "https://api.deepseek.com/v1/chat/completions"))
DEEPTHINK_MODEL = os.environ.get("POI_DEEPTHINK_MODEL", os.environ.get("POI_DEEPSEEK_MODEL", "deepseek-chat"))
DEEPTHINK_SUPPORTS_IMAGES = os.environ.get("POI_DEEPTHINK_SUPPORTS_IMAGES", "false").strip().lower() in {"1", "true", "yes", "y"}
AI_IMAGE_MAX_DIM = int(os.environ.get("POI_AI_IMAGE_MAX_DIM", "768"))
AI_INLINE_MAX_BYTES = int(os.environ.get("POI_AI_INLINE_MAX_BYTES", str(4 * 1024 * 1024)))

IMAGE_EXTS = {".jpg", ".jpeg", ".png", ".webp", ".bmp", ".tif", ".tiff"}
VIDEO_EXTS = {".mp4", ".m4v", ".mov", ".mkv", ".avi", ".webm"}
AUDIO_EXTS = {".ogg", ".oga", ".wav", ".flac", ".mp3", ".m4a", ".aac"}
MEDIA_EXTS = IMAGE_EXTS | VIDEO_EXTS | AUDIO_EXTS
DB_LOCK = threading.RLock()
SQLITE_TIMEOUT_SEC = float(os.environ.get("POI_SQLITE_TIMEOUT_SEC", "60"))
SQLITE_BUSY_TIMEOUT_MS = int(float(os.environ.get("POI_SQLITE_BUSY_TIMEOUT_SEC", "60")) * 1000)
FACE_WORKER_STARTED = False
FACE_WORKER_LOCK = threading.Lock()
FACE_WORKER_STOP = threading.Event()
FACE_SCAN_SLEEP_SEC = float(os.environ.get("POI_FACE_SCAN_SLEEP_SEC", "0.75"))

SCHEMA = """
CREATE TABLE IF NOT EXISTS media_files (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    path TEXT UNIQUE NOT NULL,
    rel_path TEXT NOT NULL,
    kind TEXT NOT NULL,
    sha1 TEXT,
    file_size INTEGER,
    file_mtime REAL,
    derived_ts TEXT,
    derived_date TEXT,
    location TEXT,
    location_source TEXT,
    excluded INTEGER DEFAULT 0,
    exclude_reason TEXT DEFAULT '',
    importance TEXT DEFAULT 'normal',
    ai_status TEXT DEFAULT 'not_needed',
    notes TEXT DEFAULT '',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS poi_clusters (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    poi_label TEXT UNIQUE NOT NULL,
    status TEXT DEFAULT 'candidate',
    confidence REAL DEFAULT 0.0,
    summary TEXT DEFAULT '',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS sightings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    media_id INTEGER NOT NULL,
    poi_id INTEGER,
    sighting_ts TEXT,
    sighting_date TEXT,
    location TEXT,
    bbox_json TEXT DEFAULT '',
    crop_path TEXT DEFAULT '',
    descriptor_hash TEXT DEFAULT '',
    confidence REAL DEFAULT 0.0,
    review_status TEXT DEFAULT 'unreviewed',
    notes TEXT DEFAULT '',
    FOREIGN KEY(media_id) REFERENCES media_files(id),
    FOREIGN KEY(poi_id) REFERENCES poi_clusters(id)
);
CREATE TABLE IF NOT EXISTS associations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    poi_a INTEGER NOT NULL,
    poi_b INTEGER NOT NULL,
    sighting_date TEXT,
    location TEXT,
    evidence_media_ids TEXT DEFAULT '[]',
    coappearances INTEGER DEFAULT 1,
    confidence REAL DEFAULT 0.0,
    flags TEXT DEFAULT '',
    notes TEXT DEFAULT '',
    UNIQUE(poi_a, poi_b, sighting_date, location)
);
CREATE TABLE IF NOT EXISTS review_queue (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    item_type TEXT NOT NULL,
    item_id INTEGER NOT NULL,
    reason TEXT NOT NULL,
    priority INTEGER DEFAULT 5,
    status TEXT DEFAULT 'queued',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS number_plates (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    media_id INTEGER,
    plate_text TEXT NOT NULL,
    confidence REAL DEFAULT 0.0,
    country_hint TEXT DEFAULT '',
    method TEXT DEFAULT 'manual',
    status TEXT DEFAULT 'candidate',
    notes TEXT DEFAULT '',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    FOREIGN KEY(media_id) REFERENCES media_files(id)
);
CREATE TABLE IF NOT EXISTS ai_geolocation_jobs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    media_id INTEGER NOT NULL,
    job_type TEXT DEFAULT 'single_geolocate',
    status TEXT DEFAULT 'draft',
    prompt TEXT DEFAULT '',
    model TEXT DEFAULT '',
    response_json TEXT DEFAULT '',
    error TEXT DEFAULT '',
    selected_location TEXT DEFAULT '',
    selected_confidence REAL DEFAULT 0.0,
    confirmed INTEGER DEFAULT 0,
    confirmed_at TEXT DEFAULT '',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    FOREIGN KEY(media_id) REFERENCES media_files(id)
);
CREATE TABLE IF NOT EXISTS ai_geolocation_candidates (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    job_id INTEGER NOT NULL,
    media_id INTEGER NOT NULL,
    location TEXT NOT NULL,
    confidence REAL DEFAULT 0.0,
    rationale TEXT DEFAULT '',
    visible_cues TEXT DEFAULT '',
    warnings TEXT DEFAULT '',
    status TEXT DEFAULT 'candidate',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    FOREIGN KEY(job_id) REFERENCES ai_geolocation_jobs(id),
    FOREIGN KEY(media_id) REFERENCES media_files(id)
);
CREATE TABLE IF NOT EXISTS ai_location_windows (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    anchor_media_id INTEGER NOT NULL,
    location TEXT NOT NULL,
    start_ts TEXT,
    end_ts TEXT,
    confidence REAL DEFAULT 0.0,
    sampled_media_ids TEXT DEFAULT '[]',
    rationale TEXT DEFAULT '',
    status TEXT DEFAULT 'proposed',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    FOREIGN KEY(anchor_media_id) REFERENCES media_files(id)
);

CREATE TABLE IF NOT EXISTS face_clusters (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    cluster_label TEXT UNIQUE NOT NULL,
    linked_poi_id INTEGER,
    centroid_json TEXT DEFAULT '[]',
    face_count INTEGER DEFAULT 0,
    confidence REAL DEFAULT 0.0,
    status TEXT DEFAULT 'candidate',
    notes TEXT DEFAULT '',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    FOREIGN KEY(linked_poi_id) REFERENCES poi_clusters(id)
);
CREATE TABLE IF NOT EXISTS face_observations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    media_id INTEGER NOT NULL,
    face_cluster_id INTEGER,
    bbox_json TEXT DEFAULT '',
    crop_path TEXT DEFAULT '',
    embedding_json TEXT DEFAULT '[]',
    detector TEXT DEFAULT 'opencv_haar',
    confidence REAL DEFAULT 0.0,
    review_status TEXT DEFAULT 'candidate',
    notes TEXT DEFAULT '',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    FOREIGN KEY(media_id) REFERENCES media_files(id),
    FOREIGN KEY(face_cluster_id) REFERENCES face_clusters(id)
);
CREATE INDEX IF NOT EXISTS idx_face_obs_media ON face_observations(media_id);
CREATE INDEX IF NOT EXISTS idx_face_obs_cluster ON face_observations(face_cluster_id);
CREATE INDEX IF NOT EXISTS idx_face_clusters_label ON face_clusters(cluster_label);
CREATE TABLE IF NOT EXISTS face_scan_jobs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    media_ids_json TEXT NOT NULL DEFAULT '[]',
    threshold REAL DEFAULT 0.82,
    status TEXT DEFAULT 'queued',
    scanned_images INTEGER DEFAULT 0,
    detected_faces INTEGER DEFAULT 0,
    created_clusters INTEGER DEFAULT 0,
    result_json TEXT DEFAULT '',
    error TEXT DEFAULT '',
    auto_temp_poi INTEGER DEFAULT 0,
    auto_min_dates INTEGER DEFAULT 2,
    created_at TEXT NOT NULL,
    started_at TEXT DEFAULT '',
    finished_at TEXT DEFAULT '',
    updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_face_scan_jobs_status ON face_scan_jobs(status, id);
CREATE INDEX IF NOT EXISTS idx_geo_jobs_media ON ai_geolocation_jobs(media_id);
CREATE INDEX IF NOT EXISTS idx_geo_candidates_media ON ai_geolocation_candidates(media_id);
CREATE INDEX IF NOT EXISTS idx_geo_windows_location ON ai_location_windows(location);
CREATE INDEX IF NOT EXISTS idx_media_date ON media_files(derived_date);
CREATE INDEX IF NOT EXISTS idx_media_location ON media_files(location);
CREATE INDEX IF NOT EXISTS idx_media_excluded ON media_files(excluded);
CREATE INDEX IF NOT EXISTS idx_sightings_poi ON sightings(poi_id);
CREATE INDEX IF NOT EXISTS idx_plates_text ON number_plates(plate_text);
"""

DATE_PATTERNS = [
    re.compile(r"(?P<y>20\d{2})(?P<m>[01]\d)(?P<d>[0-3]\d)[_\- ]?(?P<h>[0-2]\d)(?P<mi>[0-5]\d)(?P<s>[0-5]\d)"),
    re.compile(r"(?P<y>20\d{2})[-_.](?P<m>[01]\d)[-_.](?P<d>[0-3]\d)[_ T-](?P<h>[0-2]\d)[-_.:](?P<mi>[0-5]\d)[-_.:](?P<s>[0-5]\d)"),
    re.compile(r"(?P<y>20\d{2})(?P<m>[01]\d)(?P<d>[0-3]\d)"),
    re.compile(r"(?P<y>20\d{2})[-_.](?P<m>[01]\d)[-_.](?P<d>[0-3]\d)"),
]


def utc_now() -> str:
    return datetime.utcnow().isoformat(timespec="seconds") + "Z"


def connect() -> sqlite3.Connection:
    # The browser, background face worker, AI job updater and media scanner all
    # touch the same SQLite file.  Use a real busy timeout plus WAL so short
    # reads do not cause face-queue writes to fail with "database is locked".
    conn = sqlite3.connect(DB_PATH, timeout=SQLITE_TIMEOUT_SEC)
    conn.row_factory = sqlite3.Row
    try:
        conn.execute(f"PRAGMA busy_timeout={SQLITE_BUSY_TIMEOUT_MS}")
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA synchronous=NORMAL")
    except sqlite3.Error:
        # If SQLite is already busy during startup/open, the caller's retry/error
        # handling will deal with it. Do not hide operational errors later.
        pass
    return conn


def _db_locked_retry(label: str, fn, attempts: int = 10, base_sleep: float = 0.15):
    """Run a small DB write block with retry for transient SQLite locks."""
    last = None
    for attempt in range(attempts):
        try:
            return fn()
        except sqlite3.OperationalError as e:
            if "locked" not in str(e).lower() and "busy" not in str(e).lower():
                raise
            last = e
            time.sleep(base_sleep * (attempt + 1))
    raise HTTPException(status_code=503, detail=f"Database busy while {label}; retry shortly: {last}")


def rows_to_dicts(rows: Iterable[sqlite3.Row]) -> List[Dict[str, Any]]:
    return [dict(r) for r in rows]


def migrate_columns(conn: sqlite3.Connection) -> None:
    existing = {r[1] for r in conn.execute("PRAGMA table_info(media_files)").fetchall()}
    wanted = {
        "excluded": "INTEGER DEFAULT 0",
        "exclude_reason": "TEXT DEFAULT ''",
        "importance": "TEXT DEFAULT 'normal'",
    }
    for col, decl in wanted.items():
        if col not in existing:
            conn.execute(f"ALTER TABLE media_files ADD COLUMN {col} {decl}")

    # Face scanning gained whole-case queued jobs and automatic temporary POI
    # assignment in build .019.  Existing databases need a tiny migration.
    face_job_cols = {r[1] for r in conn.execute("PRAGMA table_info(face_scan_jobs)").fetchall()}
    face_job_wanted = {
        "auto_temp_poi": "INTEGER DEFAULT 0",
        "auto_min_dates": "INTEGER DEFAULT 2",
    }
    for col, decl in face_job_wanted.items():
        if col not in face_job_cols:
            conn.execute(f"ALTER TABLE face_scan_jobs ADD COLUMN {col} {decl}")


def init_db() -> None:
    with DB_LOCK, connect() as conn:
        conn.executescript(SCHEMA)
        migrate_columns(conn)
        conn.commit()
    ensure_location_config_exists()


def ensure_location_config_exists() -> None:
    if LOCATION_MAP_PATH.exists():
        return
    template = {
        "location_schema": "World - Region - Country - City - Area - Site",
        "location_catalog": [],
        "audio_date_locations": {},
        "locations": [],
        "path_hints": [],
    }
    LOCATION_MAP_PATH.write_text(yaml.safe_dump(template, sort_keys=False, allow_unicode=True), encoding="utf-8")


def load_location_config() -> Dict[str, Any]:
    ensure_location_config_exists()
    with open(LOCATION_MAP_PATH, "r", encoding="utf-8") as f:
        cfg = yaml.safe_load(f) or {}
    cfg.setdefault("location_schema", "World - Region - Country - City - Area - Site")
    cfg.setdefault("location_catalog", [])
    cfg.setdefault("audio_date_locations", {})
    cfg.setdefault("locations", [])
    cfg.setdefault("path_hints", [])
    return cfg


def save_location_config(cfg: Dict[str, Any]) -> None:
    clean = {
        "location_schema": str(cfg.get("location_schema") or "World - Region - Country - City - Area - Site"),
        "location_catalog": [str(x).strip() for x in cfg.get("location_catalog", []) if str(x).strip()],
        "audio_date_locations": {str(k).strip(): str(v).strip() for k, v in (cfg.get("audio_date_locations") or {}).items() if str(k).strip() and str(v).strip()},
        "locations": [],
        "path_hints": [],
    }
    for r in cfg.get("locations", []) or []:
        if not isinstance(r, dict):
            continue
        name = str(r.get("name") or "").strip()
        if name:
            clean["locations"].append({"name": name, "start": str(r.get("start") or "").strip(), "end": str(r.get("end") or "").strip(), "source": str(r.get("source") or "location_map").strip()})
    for h in cfg.get("path_hints", []) or []:
        if not isinstance(h, dict):
            continue
        pat = str(h.get("pattern") or "").strip()
        loc = str(h.get("location") or "").strip()
        if pat and loc:
            clean["path_hints"].append({"pattern": pat, "location": loc})
    LOCATION_MAP_PATH.write_text(yaml.safe_dump(clean, sort_keys=False, allow_unicode=True), encoding="utf-8")


def parse_rule_datetime(value: Any) -> Optional[datetime]:
    if value is None:
        return None
    if isinstance(value, datetime):
        return value
    s = str(value).strip()
    if not s:
        return None
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d", "%Y%m%d %H%M%S", "%Y%m%d"):
        try:
            return datetime.strptime(s, fmt)
        except ValueError:
            pass
    try:
        return datetime.fromisoformat(s)
    except ValueError:
        return None


def parse_datetime_from_filename(path: str) -> Tuple[Optional[str], Optional[str], str]:
    name = Path(path).name
    for rx in DATE_PATTERNS:
        m = rx.search(name)
        if not m:
            continue
        gd = m.groupdict()
        try:
            y, mo, d = int(gd["y"]), int(gd["m"]), int(gd["d"])
            h, mi, s = int(gd.get("h") or 0), int(gd.get("mi") or 0), int(gd.get("s") or 0)
            dt = datetime(y, mo, d, h, mi, s)
            return dt.isoformat(sep=" ", timespec="seconds"), dt.date().isoformat(), "filename"
        except ValueError:
            continue
    return None, None, "none"


def derive_location(derived_ts: Optional[str], derived_date: Optional[str], path: str) -> Tuple[str, str]:
    cfg = load_location_config()
    date_map = {str(k): str(v) for k, v in (cfg.get("audio_date_locations") or {}).items()}
    if derived_date and derived_date in date_map:
        return date_map[derived_date], "audio_date_locations"
    dt = parse_rule_datetime(derived_ts) if derived_ts else None
    if dt:
        for r in cfg.get("locations", []) or []:
            if not isinstance(r, dict) or not r.get("name"):
                continue
            start = parse_rule_datetime(r.get("start"))
            end = parse_rule_datetime(r.get("end"))
            if (start is None or dt >= start) and (end is None or dt <= end):
                return str(r["name"]), str(r.get("source") or "location_map")
    for h in cfg.get("path_hints", []) or []:
        try:
            if re.search(str(h.get("pattern") or ""), path, re.I):
                return str(h.get("location") or "Unknown"), "path_hint"
        except re.error:
            continue
    return "Unknown", "unresolved"


def file_kind(path: str) -> str:
    ext = Path(path).suffix.lower()
    if ext in IMAGE_EXTS:
        return "image"
    if ext in VIDEO_EXTS:
        return "video"
    if ext in AUDIO_EXTS:
        return "audio"
    return "other"


def quick_sha1(path: str, limit: int = 2_000_000) -> str:
    h = hashlib.sha1()
    with open(path, "rb") as f:
        rem = limit
        while rem > 0:
            b = f.read(min(65536, rem))
            if not b:
                break
            h.update(b)
            rem -= len(b)
    return h.hexdigest()


def iter_media_files(roots: Iterable[str]) -> Iterable[Path]:
    for root in roots:
        rp = Path(root).expanduser()
        if not rp.exists():
            continue
        if rp.is_file() and rp.suffix.lower() in MEDIA_EXTS:
            yield rp
        elif rp.is_dir():
            for p in rp.rglob("*"):
                if p.is_file() and p.suffix.lower() in MEDIA_EXTS:
                    yield p


def upsert_media(path: Path, root_hint: Optional[Path] = None) -> int:
    abs_path = str(path.resolve())
    rel_path = str(path)
    try:
        if root_hint:
            rel_path = str(path.resolve().relative_to(root_hint.resolve()))
    except Exception:
        pass
    st = path.stat()
    dt_str, d_str, ts_source = parse_datetime_from_filename(path.name)
    location, location_source = derive_location(dt_str, d_str, abs_path)
    ai_status = "queued" if ts_source == "none" or location == "Unknown" else "not_needed"
    try:
        sha1 = quick_sha1(abs_path)
    except Exception:
        sha1 = ""
    with DB_LOCK, connect() as conn:
        now = utc_now()
        conn.execute("""
            INSERT INTO media_files(path, rel_path, kind, sha1, file_size, file_mtime,
                                    derived_ts, derived_date, location, location_source,
                                    ai_status, created_at, updated_at)
            VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)
            ON CONFLICT(path) DO UPDATE SET
                rel_path=excluded.rel_path, kind=excluded.kind, sha1=excluded.sha1,
                file_size=excluded.file_size, file_mtime=excluded.file_mtime,
                derived_ts=excluded.derived_ts, derived_date=excluded.derived_date,
                location=CASE WHEN media_files.location_source='manual_override' THEN media_files.location ELSE excluded.location END,
                location_source=CASE WHEN media_files.location_source='manual_override' THEN media_files.location_source ELSE excluded.location_source END,
                ai_status=excluded.ai_status, updated_at=excluded.updated_at
        """, (abs_path, rel_path, file_kind(abs_path), sha1, st.st_size, st.st_mtime, dt_str, d_str, location, location_source, ai_status, now, now))
        media_id = int(conn.execute("SELECT id FROM media_files WHERE path=?", (abs_path,)).fetchone()["id"])
        if ai_status == "queued":
            queue_review(conn, "media", media_id, f"Needs timestamp/location review: timestamp_source={ts_source}; location={location}")
        conn.commit()
        return media_id


def queue_review(conn: sqlite3.Connection, item_type: str, item_id: int, reason: str, priority: int = 5) -> None:
    row = conn.execute("SELECT id FROM review_queue WHERE item_type=? AND item_id=? AND reason=? AND status IN ('queued','in_progress')", (item_type, item_id, reason)).fetchone()
    if row:
        return
    now = utc_now()
    conn.execute("INSERT INTO review_queue(item_type,item_id,reason,priority,status,created_at,updated_at) VALUES(?,?,?,?,?,?,?)", (item_type, item_id, reason, priority, "queued", now, now))


def scan_media_roots(extra_roots: Optional[List[str]] = None) -> Dict[str, Any]:
    roots = extra_roots or MEDIA_ROOTS
    started = time.time(); count = 0; by_kind: Dict[str, int] = {}
    missing_roots = [r for r in roots if not Path(r).expanduser().exists()]
    for root in roots:
        rootp = Path(root).expanduser()
        for p in iter_media_files([root]):
            upsert_media(p, rootp if rootp.exists() and rootp.is_dir() else None)
            k = file_kind(str(p)); by_kind[k] = by_kind.get(k, 0) + 1; count += 1
    return {"scanned": count, "by_kind": by_kind, "roots": roots, "missing_roots": missing_roots, "seconds": round(time.time()-started, 2)}


def ensure_poi(label: str, confidence: float = 0.0, summary: str = "") -> int:
    with DB_LOCK, connect() as conn:
        now = utc_now()
        conn.execute("INSERT INTO poi_clusters(poi_label, confidence, summary, created_at, updated_at) VALUES(?,?,?,?,?) ON CONFLICT(poi_label) DO UPDATE SET updated_at=excluded.updated_at", (label, confidence, summary, now, now))
        conn.commit()
        return int(conn.execute("SELECT id FROM poi_clusters WHERE poi_label=?", (label,)).fetchone()["id"])


def bootstrap_sightings_from_media() -> Dict[str, Any]:
    poi_id = ensure_poi("UNASSIGNED", 0.0, "Holding cluster for unassigned sightings")
    with DB_LOCK, connect() as conn:
        rows = conn.execute("SELECT * FROM media_files WHERE kind IN ('image','video') AND COALESCE(excluded,0)=0 ORDER BY COALESCE(derived_ts, rel_path)").fetchall()
        created = 0
        for row in rows:
            if conn.execute("SELECT id FROM sightings WHERE media_id=? LIMIT 1", (row["id"],)).fetchone():
                continue
            conn.execute("INSERT INTO sightings(media_id, poi_id, sighting_ts, sighting_date, location, confidence, review_status, notes) VALUES(?,?,?,?,?,?,?,?)", (row["id"], poi_id, row["derived_ts"], row["derived_date"], row["location"], 0.0, "needs_detection", "Placeholder sighting created from media file."))
            queue_review(conn, "sighting", int(row["id"]), "Run person detector / assign POI", priority=4)
            created += 1
        conn.commit()
    return {"created_sightings": created, "visual_media": len(rows)}


def rebuild_associations() -> Dict[str, Any]:
    with DB_LOCK, connect() as conn:
        conn.execute("DELETE FROM associations")
        groups = conn.execute("""
            SELECT s.sighting_date, s.location, GROUP_CONCAT(DISTINCT s.poi_id) AS pois,
                   GROUP_CONCAT(DISTINCT s.media_id) AS media_ids
            FROM sightings s JOIN media_files m ON m.id=s.media_id
            WHERE s.poi_id IS NOT NULL AND COALESCE(m.excluded,0)=0 AND s.poi_id NOT IN (SELECT id FROM poi_clusters WHERE poi_label='UNASSIGNED')
            GROUP BY s.sighting_date, s.location
        """).fetchall()
        created = 0
        for g in groups:
            poi_ids = [int(x) for x in (g["pois"] or "").split(",") if x]
            for i in range(len(poi_ids)):
                for j in range(i+1, len(poi_ids)):
                    a, b = sorted([poi_ids[i], poi_ids[j]])
                    conn.execute("INSERT OR IGNORE INTO associations(poi_a, poi_b, sighting_date, location, evidence_media_ids, coappearances, confidence, flags, notes) VALUES(?,?,?,?,?,?,?,?,?)", (a, b, g["sighting_date"], g["location"], json.dumps((g["media_ids"] or "").split(",")), 1, 0.55, "co_location", "Same date/location association"))
                    created += 1
        conn.commit()
    return {"created_or_seen_links": created}


def rederive_locations() -> Dict[str, Any]:
    changed = 0
    with DB_LOCK, connect() as conn:
        rows = conn.execute("SELECT * FROM media_files").fetchall()
        for r in rows:
            if r["location_source"] == "manual_override":
                continue
            loc, src = derive_location(r["derived_ts"], r["derived_date"], r["path"])
            conn.execute("UPDATE media_files SET location=?, location_source=?, updated_at=? WHERE id=?", (loc, src, utc_now(), r["id"]))
            conn.execute("UPDATE sightings SET location=? WHERE media_id=?", (loc, r["id"]))
            changed += 1
        conn.commit()
    return {"rederived": changed}


def detector_status() -> Dict[str, Any]:
    out = {"opencv": False, "ultralytics": False, "fastreid": False, "dlib_required": False, "notes": ["Face queue uses OpenCV Haar/perceptual clustering only. Do not install dlib/face_recognition in the Python 3.13 server environment."]}
    for name, key in [("cv2", "opencv"), ("ultralytics", "ultralytics"), ("fastreid", "fastreid")]:
        try:
            __import__(name); out[key] = True
        except Exception as e:
            out["notes"].append(f"{key} unavailable: {e}")
    return out



def read_key_from_env_or_file(env_value: str, key_file: str) -> str:
    if (env_value or "").strip():
        return env_value.strip()
    key_path = Path(key_file)
    if key_path.exists():
        return key_path.read_text(encoding="utf-8").strip()
    return ""


def read_gemini_key() -> str:
    return read_key_from_env_or_file(GEMINI_API_KEY, GEMINI_KEY_FILE)


def read_openai_key() -> str:
    return read_key_from_env_or_file(OPENAI_API_KEY, OPENAI_KEY_FILE)


def read_deepthink_key() -> str:
    return read_key_from_env_or_file(DEEPTHINK_API_KEY, DEEPTHINK_KEY_FILE)


def choose_ai_provider(needs_images: bool = False) -> str:
    requested = AI_PROVIDER or "auto"
    aliases = {"deepseek": "deepthink", "deep-think": "deepthink"}
    requested = aliases.get(requested, requested)
    if requested != "auto":
        return requested
    # For geolocation and time-window work, prefer a provider with image support.
    if read_openai_key():
        return "openai"
    if read_gemini_key():
        return "gemini"
    if read_deepthink_key():
        return "deepthink"
    return "none"


def active_ai_model_label(needs_images: bool = False) -> str:
    provider = choose_ai_provider(needs_images=needs_images)
    if provider == "openai":
        return f"openai:{OPENAI_MODEL}"
    if provider == "gemini":
        return f"gemini:{GEMINI_MODEL}"
    if provider == "deepthink":
        return f"deepthink:{DEEPTHINK_MODEL}"
    return "none"


def ai_status() -> Dict[str, Any]:
    provider = choose_ai_provider(needs_images=True)
    openai_key = read_openai_key()
    gemini_key = read_gemini_key()
    deepthink_key = read_deepthink_key()
    vision_ok = provider in {"openai", "gemini"} or (provider == "deepthink" and DEEPTHINK_SUPPORTS_IMAGES)
    return {
        "requested_provider": AI_PROVIDER,
        "provider": provider,
        "enabled": provider != "none" and bool(openai_key or gemini_key or deepthink_key),
        "vision_enabled": bool(vision_ok and provider != "none"),
        "model": active_ai_model_label(needs_images=True),
        "image_max_dim": AI_IMAGE_MAX_DIM,
        "openai": {
            "key_file": OPENAI_KEY_FILE,
            "key_file_exists": Path(OPENAI_KEY_FILE).exists(),
            "configured": bool(openai_key),
            "model": OPENAI_MODEL,
            "base_url": OPENAI_BASE_URL,
        },
        "gemini": {
            "key_file": GEMINI_KEY_FILE,
            "key_file_exists": Path(GEMINI_KEY_FILE).exists(),
            "configured": bool(gemini_key),
            "model": GEMINI_MODEL,
            "api_version": GEMINI_API_VERSION,
        },
        "deepthink": {
            "key_file": DEEPTHINK_KEY_FILE,
            "key_file_exists": Path(DEEPTHINK_KEY_FILE).exists(),
            "configured": bool(deepthink_key),
            "model": DEEPTHINK_MODEL,
            "base_url": DEEPTHINK_BASE_URL,
            "supports_images": DEEPTHINK_SUPPORTS_IMAGES,
        },
    }


def json_from_ai_text(text: str) -> Dict[str, Any]:
    cleaned = (text or "").strip()
    cleaned = re.sub(r"^```(?:json)?\s*", "", cleaned, flags=re.I)
    cleaned = re.sub(r"\s*```$", "", cleaned)
    m = re.search(r"\{.*\}", cleaned, flags=re.S)
    if m:
        cleaned = m.group(0)
    return json.loads(cleaned)


def make_ai_image_part(path: str, max_dim: int = AI_IMAGE_MAX_DIM) -> Dict[str, Any]:
    """Return a downgraded inline_data part. Uses Pillow when available; falls back to raw file if small."""
    p = Path(path)
    mime = mimetypes.guess_type(str(p))[0] or "image/jpeg"
    try:
        from PIL import Image
        with Image.open(p) as im:
            im = im.convert("RGB")
            im.thumbnail((max_dim, max_dim))
            buf = io.BytesIO()
            im.save(buf, format="JPEG", quality=72, optimize=True)
            data = buf.getvalue()
            return {"inline_data": {"mime_type": "image/jpeg", "data": base64.b64encode(data).decode("ascii")}}
    except Exception:
        data = p.read_bytes()
        if len(data) > AI_INLINE_MAX_BYTES:
            raise RuntimeError("Image is too large for inline AI upload and Pillow is unavailable for downscaling. Install pillow or lower the sample.")
        return {"inline_data": {"mime_type": mime, "data": base64.b64encode(data).decode("ascii")}}


def make_contact_sheet_part(rows: List[sqlite3.Row], max_dim: int = AI_IMAGE_MAX_DIM) -> Dict[str, Any]:
    try:
        from PIL import Image, ImageDraw, ImageFont
    except Exception as e:
        raise RuntimeError(f"Pillow is required to create downgraded time-window contact sheets: {e}")
    thumbs = []
    for idx, r in enumerate(rows, start=1):
        try:
            with Image.open(r["path"]) as im:
                im = im.convert("RGB")
                im.thumbnail((240, 180))
                canvas = Image.new("RGB", (260, 220), (20, 23, 28))
                canvas.paste(im, ((260-im.width)//2, 8))
                d = ImageDraw.Draw(canvas)
                label = f"#{idx} {r['derived_ts'] or r['derived_date'] or 'unknown'}"
                d.text((8, 188), label[:34], fill=(255,255,255))
                d.text((8, 204), Path(r['rel_path']).name[:34], fill=(170,180,190))
                thumbs.append(canvas)
        except Exception:
            continue
    if not thumbs:
        raise RuntimeError("No images could be loaded for contact sheet")
    cols = 3
    rows_n = (len(thumbs)+cols-1)//cols
    sheet = Image.new("RGB", (cols*260, rows_n*220), (12,14,18))
    for i, im in enumerate(thumbs):
        sheet.paste(im, ((i%cols)*260, (i//cols)*220))
    buf = io.BytesIO()
    sheet.save(buf, format="JPEG", quality=70, optimize=True)
    return {"inline_data": {"mime_type": "image/jpeg", "data": base64.b64encode(buf.getvalue()).decode("ascii")}}


def openai_image_url_from_part(part: Dict[str, Any]) -> str:
    inline = part.get("inline_data") or {}
    mime = inline.get("mime_type") or "image/jpeg"
    data = inline.get("data") or ""
    if not data:
        raise RuntimeError("AI image part has no inline data")
    return f"data:{mime};base64,{data}"


def openai_compatible_generate_json(prompt: str, image_parts: Optional[List[Dict[str, Any]]] = None, *, provider: str = "openai") -> Dict[str, Any]:
    if provider == "openai":
        key = read_openai_key()
        url = OPENAI_BASE_URL
        model = OPENAI_MODEL
        label = "OpenAI"
        supports_images = True
    else:
        key = read_deepthink_key()
        url = DEEPTHINK_BASE_URL
        model = DEEPTHINK_MODEL
        label = "DeepThink/DeepSeek"
        supports_images = DEEPTHINK_SUPPORTS_IMAGES
    if not key:
        key_file = OPENAI_KEY_FILE if provider == "openai" else DEEPTHINK_KEY_FILE
        raise RuntimeError(f"{label} key not configured. Put a key in {key_file} or set the matching API-key environment variable.")
    if image_parts and not supports_images:
        raise RuntimeError(f"{label} provider is configured but image upload is disabled/not supported. Use POI_AI_PROVIDER=openai for image geolocation, or set POI_DEEPTHINK_SUPPORTS_IMAGES=true only if your endpoint is vision-capable.")

    content: List[Dict[str, Any]] = [{"type": "text", "text": prompt}]
    for part in image_parts or []:
        content.append({"type": "image_url", "image_url": {"url": openai_image_url_from_part(part), "detail": "low"}})
    body = {
        "model": model,
        "messages": [{"role": "user", "content": content}],
        "temperature": 0.1,
        "response_format": {"type": "json_object"},
    }
    data = json.dumps(body).encode("utf-8")
    req = urllib.request.Request(url, data=data, headers={"Content-Type": "application/json", "Authorization": f"Bearer {key}"}, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=180) as resp:
            raw = resp.read().decode("utf-8")
    except urllib.error.HTTPError as e:
        err = e.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"{label} HTTP {e.code}: {err[:1600]}")
    payload = json.loads(raw)
    text = ""
    try:
        text = payload.get("choices", [{}])[0].get("message", {}).get("content", "") or ""
    except Exception:
        pass
    if not text:
        raise RuntimeError(f"{label} returned no message content")
    parsed = json_from_ai_text(text)
    parsed.setdefault("_raw_text", text[:4000])
    return parsed


def gemini_generate_json(prompt: str, image_parts: Optional[List[Dict[str, Any]]] = None) -> Dict[str, Any]:
    key = read_gemini_key()
    if not key:
        raise RuntimeError(f"Gemini key not configured. Put a key in {GEMINI_KEY_FILE} or set GEMINI_API_KEY.")
    url = f"https://generativelanguage.googleapis.com/{GEMINI_API_VERSION}/models/{GEMINI_MODEL}:generateContent?key={key}"
    parts: List[Dict[str, Any]] = [{"text": prompt}]
    if image_parts:
        parts.extend(image_parts)
    body = {
        "contents": [{"role": "user", "parts": parts}],
        "generationConfig": {"temperature": 0.1, "response_mime_type": "application/json"},
    }
    data = json.dumps(body).encode("utf-8")
    req = urllib.request.Request(url, data=data, headers={"Content-Type": "application/json"}, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=120) as resp:
            raw = resp.read().decode("utf-8")
    except urllib.error.HTTPError as e:
        err = e.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"Gemini HTTP {e.code}: {err[:1600]}")
    payload = json.loads(raw)
    text = ""
    try:
        for cand in payload.get("candidates", []):
            for part in cand.get("content", {}).get("parts", []):
                text += part.get("text", "")
    except Exception:
        pass
    if not text:
        raise RuntimeError("Gemini returned no text content")
    parsed = json_from_ai_text(text)
    parsed.setdefault("_raw_text", text[:4000])
    return parsed


def ai_generate_json(prompt: str, image_parts: Optional[List[Dict[str, Any]]] = None) -> Dict[str, Any]:
    provider = choose_ai_provider(needs_images=bool(image_parts))
    if provider == "openai":
        return openai_compatible_generate_json(prompt, image_parts, provider="openai")
    if provider == "gemini":
        return gemini_generate_json(prompt, image_parts)
    if provider == "deepthink":
        return openai_compatible_generate_json(prompt, image_parts, provider="deepthink")
    raise RuntimeError("No AI provider configured. Set POI_AI_PROVIDER=openai and OPENAI_API_KEY/POI_OPENAI_KEY_FILE, or configure Gemini/DeepThink.")


def ai_error_hint(err: str) -> str:
    e = err or ""
    if "API_KEY_SERVICE_BLOCKED" in e or "GenerateContent are blocked" in e:
        return "Gemini key/project is blocked from GenerateContent. Use POI_AI_PROVIDER=openai with your OpenAI key, or fix the Google project/API restrictions."
    if "quota" in e.lower() or "RESOURCE_EXHAUSTED" in e or "429" in e:
        return "The selected AI provider hit quota/rate limits. Switch provider, lower sample count, or wait/retry after the provider's retry window."
    if "401" in e or "invalid_api_key" in e.lower() or "unauthorized" in e.lower():
        return "The selected provider rejected the API key. Check the key file/env var and provider selection."
    if "403" in e or "PERMISSION_DENIED" in e:
        return "The selected provider returned permission denied. Check key restrictions, project billing/terms, model access, and endpoint permissions."
    if "404" in e or "not found" in e.lower():
        return "The selected provider/model/endpoint was not found. Check POI_AI_PROVIDER, model name, and base URL."
    if "image upload is disabled" in e or "not supported" in e:
        return "This agent needs vision. Use POI_AI_PROVIDER=openai for image geolocation, or a confirmed vision-capable OpenAI-compatible endpoint."
    if "key not configured" in e.lower() or "no ai provider" in e.lower():
        return "Configure an AI provider. Recommended: set POI_AI_PROVIDER=openai and put your key in openai_key.txt or OPENAI_API_KEY."
    return "Check the AI job error. The failure has been recorded without changing media records."


def gemini_error_hint(err: str) -> str:
    # Compatibility wrapper for older UI/API naming.
    return ai_error_hint(err)


def candidate_locations_for_prompt() -> str:
    cfg = load_location_config()
    locs = cfg.get("location_catalog") or []
    if not locs:
        return "No catalog locations are configured yet. Return Unknown unless image context is very clear."
    return "\n".join(f"- {x}" for x in locs)


def run_geolocate_agent(media_id: int) -> Dict[str, Any]:
    row = get_media_or_404(media_id)
    if row["kind"] != "image":
        raise HTTPException(status_code=400, detail="AI geolocation currently expects a still image. Extract frames from video first.")
    prompt = f"""
You are a forensic media geolocation triage agent. You must not identify people or infer protected attributes.
Your job is to geolocate the scene using non-person visual evidence: readable signs, building names, roads, rail/tram features, shop signs, landmarks, vehicles, road markings, architecture, and other place cues.

First compare against the case location catalog. If the image clearly shows an out-of-catalog place, do NOT return Unknown merely because it is absent from the catalog. Return a proposed hierarchical location path in the same style as the catalog and mark the warning that it is outside the current catalog.

Known location catalog:
{candidate_locations_for_prompt()}

Media metadata:
- media_id: {row['id']}
- relative_path: {row['rel_path']}
- derived_timestamp: {row['derived_ts'] or 'unknown'}
- current_location: {row['location'] or 'Unknown'}

Return strict JSON only with this schema:
{{
  "media_id": {row['id']},
  "overall_assessment": "short non-identifying scene/location summary",
  "visible_text": "readable location text/signage/landmark text, or empty string",
  "candidates": [
    {{"location": "full catalog path, proposed full path, or Unknown", "confidence": 0.0, "rationale": "why", "visible_cues": "non-person cues including readable text", "warnings": "catalog match / outside catalog / limits"}}
  ],
  "needs_human_confirmation": true
}}
Use confidence 0.0 to 1.0. Prefer catalog locations when they genuinely match. If a landmark/sign clearly identifies a place outside the catalog, return that proposed place rather than Unknown. Only use Unknown when the image lacks enough place cues.
""".strip()
    now = utc_now()
    with DB_LOCK, connect() as conn:
        cur = conn.execute("INSERT INTO ai_geolocation_jobs(media_id, job_type, status, prompt, model, created_at, updated_at) VALUES(?,?,?,?,?,?,?)", (media_id, "single_geolocate", "running", prompt, active_ai_model_label(needs_images=True), now, now))
        job_id = int(cur.lastrowid)
        conn.commit()
    try:
        result = ai_generate_json(prompt, [make_ai_image_part(row["path"])])
        candidates = result.get("candidates") or []
        with DB_LOCK, connect() as conn:
            conn.execute("UPDATE ai_geolocation_jobs SET status='completed', response_json=?, updated_at=? WHERE id=?", (json.dumps(result, ensure_ascii=False), utc_now(), job_id))
            for c in candidates:
                loc = str(c.get("location") or "Unknown")
                conn.execute("INSERT INTO ai_geolocation_candidates(job_id, media_id, location, confidence, rationale, visible_cues, warnings, status, created_at, updated_at) VALUES(?,?,?,?,?,?,?,?,?,?)", (job_id, media_id, loc, float(c.get("confidence") or 0), str(c.get("rationale") or ""), str(c.get("visible_cues") or ""), str(c.get("warnings") or ""), "candidate", utc_now(), utc_now()))
            queue_review(conn, "media", media_id, "AI geolocation candidates need confirmation", priority=2)
            conn.commit()
        return {"job_id": job_id, "media_id": media_id, "result": result}
    except Exception as e:
        # Do not let provider/key/API failures become a FastAPI 500.
        # This keeps the analyst UI alive and records the provider failure
        # against the job so it can be diagnosed from the AI geolocation tab.
        err = str(e)
        with DB_LOCK, connect() as conn:
            conn.execute("UPDATE ai_geolocation_jobs SET status='failed', error=?, updated_at=? WHERE id=?", (err, utc_now(), job_id))
            queue_review(conn, "media", media_id, "AI geolocation failed: " + err[:240], priority=1)
            conn.commit()
        return {
            "ok": False,
            "job_id": job_id,
            "media_id": media_id,
            "error": err,
            "hint": ai_error_hint(err),
            "ai": ai_status(),
        }



def propose_location_window(anchor_media_id: int, location: str, hours_before: float, hours_after: float, sample_limit: int) -> Dict[str, Any]:
    anchor = get_media_or_404(anchor_media_id)
    anchor_dt = parse_rule_datetime(anchor["derived_ts"])
    if not anchor_dt:
        raise HTTPException(status_code=400, detail="Anchor media has no derived timestamp; cannot build +/- window.")
    start_dt = anchor_dt - timedelta(hours=hours_before)
    end_dt = anchor_dt + timedelta(hours=hours_after)
    with DB_LOCK, connect() as conn:
        rows = conn.execute("""
            SELECT * FROM media_files
            WHERE kind='image' AND COALESCE(excluded,0)=0 AND derived_ts IS NOT NULL
              AND derived_ts >= ? AND derived_ts <= ?
            ORDER BY derived_ts
            LIMIT ?
        """, (start_dt.isoformat(sep=" ", timespec="seconds"), end_dt.isoformat(sep=" ", timespec="seconds"), max(1, min(sample_limit, 24)))).fetchall()
    if not rows:
        raise HTTPException(status_code=404, detail="No images found in requested time window")
    listing = "\n".join([f"#{i+1}: media_id={r['id']} ts={r['derived_ts']} file={r['rel_path']} current_location={r['location']}" for i, r in enumerate(rows)])
    prompt = f"""
You are a forensic location-window triage agent. You must not identify people.
A human has selected anchor media #{anchor_media_id} as likely location:
{location}

You are given a downgraded contact sheet of images within a +/- time window.
Decide the likely contiguous time interval during which this same geolocation assignment remains valid.
Use scene cues only: buildings, roads, indoor/outdoor setting, signs, vehicles, lighting, layout, landmarks.

Candidate samples:
{listing}

Return strict JSON only:
{{
  "anchor_media_id": {anchor_media_id},
  "location": "{location}",
  "proposed_start_ts": "YYYY-MM-DD HH:MM:SS or null",
  "proposed_end_ts": "YYYY-MM-DD HH:MM:SS or null",
  "confidence": 0.0,
  "sampled_media_ids": [1,2,3],
  "rationale": "why this interval seems valid",
  "boundary_notes": "what appears to change before/after",
  "needs_human_confirmation": true
}}
Only include sampled media IDs from the list above.
""".strip()
    result = ai_generate_json(prompt, [make_contact_sheet_part(rows)])
    s_ts = result.get("proposed_start_ts")
    e_ts = result.get("proposed_end_ts")
    sampled = result.get("sampled_media_ids") or [int(r["id"]) for r in rows]
    now = utc_now()
    with DB_LOCK, connect() as conn:
        cur = conn.execute("INSERT INTO ai_location_windows(anchor_media_id, location, start_ts, end_ts, confidence, sampled_media_ids, rationale, status, created_at, updated_at) VALUES(?,?,?,?,?,?,?,?,?,?)", (anchor_media_id, location, s_ts, e_ts, float(result.get("confidence") or 0), json.dumps(sampled), str(result.get("rationale") or ""), "proposed", now, now))
        win_id = int(cur.lastrowid)
        queue_review(conn, "location_window", win_id, "AI proposed geolocation time window needs confirmation", priority=2)
        conn.commit()
    return {"window_id": win_id, "result": result}


def apply_location_window(window_id: int) -> Dict[str, Any]:
    with DB_LOCK, connect() as conn:
        w = conn.execute("SELECT * FROM ai_location_windows WHERE id=?", (window_id,)).fetchone()
    if not w:
        raise HTTPException(status_code=404, detail="window proposal not found")
    if not w["start_ts"] or not w["end_ts"]:
        raise HTTPException(status_code=400, detail="window proposal has no start/end")
    cfg = load_location_config()
    cfg.setdefault("locations", [])
    cfg["locations"].append({"name": w["location"], "start": w["start_ts"], "end": w["end_ts"], "source": f"ai_window_confirmed:{window_id}"})
    if w["location"] not in (cfg.get("location_catalog") or []):
        cfg.setdefault("location_catalog", []).append(w["location"])
    save_location_config(cfg)
    rd = rederive_locations()
    with DB_LOCK, connect() as conn:
        conn.execute("UPDATE ai_location_windows SET status='confirmed', updated_at=? WHERE id=?", (utc_now(), window_id))
        conn.commit()
    return {"applied": True, "window_id": window_id, "location_map": str(LOCATION_MAP_PATH), **rd}



def _cosine_similarity(a: List[float], b: List[float]) -> float:
    if not a or not b or len(a) != len(b):
        return 0.0
    dot = sum(x*y for x, y in zip(a, b))
    na = sum(x*x for x in a) ** 0.5
    nb = sum(y*y for y in b) ** 0.5
    if na <= 1e-9 or nb <= 1e-9:
        return 0.0
    return dot / (na * nb)


def _blend_centroid(old: List[float], new: List[float], old_count: int) -> List[float]:
    if not old or len(old) != len(new):
        return new
    n = max(0, int(old_count))
    return [((old[i] * n) + new[i]) / (n + 1) for i in range(len(new))]


def _face_embedding_from_crop(crop: Any) -> List[float]:
    import cv2
    gray = cv2.cvtColor(crop, cv2.COLOR_BGR2GRAY) if len(crop.shape) == 3 else crop
    small = cv2.resize(gray, (32, 32), interpolation=cv2.INTER_AREA)
    vals = [float(x) / 255.0 for x in small.flatten().tolist()]
    mean = sum(vals) / len(vals)
    vals = [v - mean for v in vals]
    norm = sum(v*v for v in vals) ** 0.5
    if norm > 1e-9:
        vals = [v / norm for v in vals]
    return vals


def _next_face_cluster_label(conn: sqlite3.Connection) -> str:
    row = conn.execute("SELECT COUNT(*) AS c FROM face_clusters").fetchone()
    return f"FACE-{int(row['c'])+1:04d}"


def _assign_face_cluster(conn: sqlite3.Connection, embedding: List[float], threshold: float) -> Tuple[int, float, bool]:
    rows = conn.execute("SELECT * FROM face_clusters WHERE status!='rejected'").fetchall()
    best_id = None
    best_sim = -1.0
    best_count = 0
    best_centroid: List[float] = []
    for r in rows:
        try:
            c = json.loads(r["centroid_json"] or "[]")
        except Exception:
            c = []
        sim = _cosine_similarity(embedding, c)
        if sim > best_sim:
            best_sim = sim; best_id = int(r["id"]); best_count = int(r["face_count"] or 0); best_centroid = c
    now = utc_now()
    if best_id is not None and best_sim >= threshold:
        new_centroid = _blend_centroid(best_centroid, embedding, best_count)
        conn.execute("UPDATE face_clusters SET centroid_json=?, face_count=face_count+1, confidence=MAX(confidence,?), updated_at=? WHERE id=?", (json.dumps(new_centroid), float(best_sim), now, best_id))
        return best_id, float(best_sim), False
    label = _next_face_cluster_label(conn)
    cur = conn.execute("INSERT INTO face_clusters(cluster_label, centroid_json, face_count, confidence, status, notes, created_at, updated_at) VALUES(?,?,?,?,?,?,?,?)", (label, json.dumps(embedding), 1, 0.0, "candidate", "Auto-created from face scan. Internal cluster only; not a real-world identity.", now, now))
    return int(cur.lastrowid), 0.0, True


def _update_face_job_progress(job_id: Optional[int], scanned_delta: int = 0, faces_delta: int = 0, clusters_delta: int = 0, status_note: str = "") -> None:
    """Small best-effort progress update for the queued face worker.

    This is intentionally tiny and separate from the image processing work so the
    browser can see progress while OpenCV is scanning.  Failures here should not
    kill the face scan itself.
    """
    if not job_id:
        return
    try:
        now = utc_now()
        with DB_LOCK, connect() as conn:
            if status_note:
                conn.execute(
                    """
                    UPDATE face_scan_jobs
                    SET scanned_images=scanned_images+?, detected_faces=detected_faces+?, created_clusters=created_clusters+?,
                        error=?, updated_at=?
                    WHERE id=?
                    """,
                    (int(scanned_delta), int(faces_delta), int(clusters_delta), status_note[:1800], now, int(job_id)),
                )
            else:
                conn.execute(
                    """
                    UPDATE face_scan_jobs
                    SET scanned_images=scanned_images+?, detected_faces=detected_faces+?, created_clusters=created_clusters+?,
                        updated_at=?
                    WHERE id=?
                    """,
                    (int(scanned_delta), int(faces_delta), int(clusters_delta), now, int(job_id)),
                )
            conn.commit()
    except Exception as e:
        print(f"[poi-shuttle] face job progress update failed: {e}")


def scan_faces_for_media(media_ids: List[int], threshold: float = 0.82, job_id: Optional[int] = None) -> Dict[str, Any]:
    """Detect faces and cluster them as internal FACE-* references only.

    This deliberately does not identify people by name. It finds face-like crops,
    stores evidence crops, and groups similar observations for analyst review.

    Important implementation detail: never hold DB_LOCK while OpenCV is reading
    or scanning images.  The worker updates face_scan_jobs after each image so the
    UI does not sit at "running / scanned 0" until the whole batch finishes.
    """
    try:
        import cv2
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"OpenCV/cv2 unavailable for face scanning: {e}")

    crop_dir = Path(os.environ.get("POI_FACE_CROP_DIR", "poi_face_crops"))
    crop_dir.mkdir(parents=True, exist_ok=True)
    cascade_path = cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
    cascade = cv2.CascadeClassifier(cascade_path)
    if cascade.empty():
        raise HTTPException(status_code=500, detail="OpenCV Haar face cascade could not be loaded")

    # Fetch the media rows up front, then release SQLite before doing image work.
    rows: List[sqlite3.Row] = []
    missing: List[int] = []
    with DB_LOCK, connect() as conn:
        for mid in media_ids:
            row = conn.execute("SELECT * FROM media_files WHERE id=?", (int(mid),)).fetchone()
            if row:
                rows.append(row)
            else:
                missing.append(int(mid))

    scanned = detected = created_clusters = 0
    errors: List[str] = []
    for mid in missing:
        errors.append(f"media #{mid} not found")
        _update_face_job_progress(job_id, 0, 0, 0, f"media #{mid} not found")

    # Ensure the holding POI once, outside any long scan transaction.
    unassigned_poi_id = ensure_poi("UNASSIGNED", 0.0, "Holding cluster for unassigned sightings")

    for row in rows:
        mid = int(row["id"])
        if row["kind"] != "image":
            with DB_LOCK, connect() as conn:
                queue_review(conn, "media", mid, "Face scan requested but media is not a still image; extract video frames first", priority=3)
                conn.commit()
            _update_face_job_progress(job_id, 0, 0, 0, f"media #{mid}: skipped non-image")
            continue

        path = str(row["path"])
        _update_face_job_progress(job_id, 0, 0, 0, f"scanning media #{mid}: {Path(path).name}")
        try:
            img = cv2.imread(path)
            if img is None:
                errors.append(f"media #{mid}: could not read image")
                _update_face_job_progress(job_id, 1, 0, 0, f"media #{mid}: could not read image")
                scanned += 1
                continue

            # Downscale very large images for the detector; keep bbox scaled back
            # to original coordinates for crop/evidence storage.
            max_dim = int(os.environ.get("POI_FACE_DETECT_MAX_DIM", "1600"))
            scale = 1.0
            detect_img = img
            h0, w0 = img.shape[:2]
            if max(h0, w0) > max_dim:
                scale = max_dim / float(max(h0, w0))
                detect_img = cv2.resize(img, (max(1, int(w0 * scale)), max(1, int(h0 * scale))))

            gray = cv2.cvtColor(detect_img, cv2.COLOR_BGR2GRAY)
            faces = cascade.detectMultiScale(gray, scaleFactor=1.08, minNeighbors=5, minSize=(32, 32))
            scanned += 1
            face_count_this_image = 0
            clusters_this_image = 0

            if len(faces) == 0:
                with DB_LOCK, connect() as conn:
                    queue_review(conn, "media", mid, "Face scan found no frontal faces", priority=5)
                    conn.commit()
                _update_face_job_progress(job_id, 1, 0, 0, f"media #{mid}: no frontal faces")
                continue

            for idx, (x, y, w, h) in enumerate(faces):
                # Convert detector coordinates back to original image coordinates.
                if scale != 1.0:
                    x = int(x / scale); y = int(y / scale); w = int(w / scale); h = int(h / scale)
                mx, my = int(w * 0.18), int(h * 0.22)
                x1, y1 = max(0, x-mx), max(0, y-my)
                x2, y2 = min(img.shape[1], x+w+mx), min(img.shape[0], y+h+my)
                crop = img[y1:y2, x1:x2]
                if crop.size == 0:
                    continue
                emb = _face_embedding_from_crop(crop)

                with DB_LOCK, connect() as conn:
                    cluster_id, sim, is_new = _assign_face_cluster(conn, emb, threshold)
                    if is_new:
                        created_clusters += 1
                        clusters_this_image += 1
                    crop_name = f"media_{mid}_face_{int(time.time()*1000)}_{idx}.jpg"
                    crop_path = crop_dir / crop_name
                    cv2.imwrite(str(crop_path), crop)
                    now = utc_now()
                    cur = conn.execute(
                        "INSERT INTO face_observations(media_id, face_cluster_id, bbox_json, crop_path, embedding_json, detector, confidence, review_status, notes, created_at, updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
                        (mid, cluster_id, json.dumps({"x": int(x1), "y": int(y1), "w": int(x2-x1), "h": int(y2-y1)}), str(crop_path), json.dumps(emb), "opencv_haar_32x32_perceptual", float(max(0.0, sim)), "candidate", "Auto-detected face crop; confirm manually before relying on link.", now, now),
                    )
                    face_id = int(cur.lastrowid)
                    if not conn.execute("SELECT id FROM sightings WHERE media_id=? LIMIT 1", (mid,)).fetchone():
                        conn.execute(
                            "INSERT INTO sightings(media_id, poi_id, sighting_ts, sighting_date, location, bbox_json, crop_path, descriptor_hash, confidence, review_status, notes) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
                            (mid, unassigned_poi_id, row["derived_ts"], row["derived_date"], row["location"], json.dumps({"face_observation_id": face_id, "x": int(x1), "y": int(y1), "w": int(x2-x1), "h": int(y2-y1)}), str(crop_path), f"face_obs:{face_id}", 0.25, "face_candidate", "Placeholder sighting created from face scan."),
                        )
                    queue_review(conn, "face", face_id, "Review face cluster and link to POI if appropriate", priority=2)
                    conn.commit()
                detected += 1
                face_count_this_image += 1

            _update_face_job_progress(job_id, 1, face_count_this_image, clusters_this_image, f"media #{mid}: {face_count_this_image} candidate face(s)")
        except Exception as e:
            err = f"media #{mid}: {e}"
            errors.append(err)
            _update_face_job_progress(job_id, 1, 0, 0, err)
            scanned += 1

    return {"scanned_images": scanned, "detected_faces": detected, "created_clusters": created_clusters, "threshold": threshold, "errors": errors}




def auto_assign_cross_date_face_pois(min_dates: int = 2) -> Dict[str, Any]:
    """Create temporary POIs for internal face clusters seen on different dates.

    This is deliberately conservative and review-grade: it does not identify a
    real person by name.  It says only that an internal face cluster appears in
    images from multiple dates and therefore deserves a temporary POI label for
    timeline/link analysis.
    """
    min_dates = max(2, int(min_dates or 2))
    assigned: List[Dict[str, Any]] = []
    with DB_LOCK, connect() as conn:
        clusters = conn.execute(
            """
            SELECT fc.id, fc.cluster_label,
                   COUNT(fo.id) AS face_observations,
                   COUNT(DISTINCT fo.media_id) AS media_count,
                   COUNT(DISTINCT m.derived_date) AS date_count,
                   MIN(m.derived_ts) AS first_seen,
                   MAX(m.derived_ts) AS last_seen,
                   GROUP_CONCAT(DISTINCT m.derived_date) AS dates,
                   GROUP_CONCAT(DISTINCT m.location) AS locations
            FROM face_clusters fc
            JOIN face_observations fo ON fo.face_cluster_id=fc.id
            JOIN media_files m ON m.id=fo.media_id
            WHERE fc.linked_poi_id IS NULL
              AND fc.status!='rejected'
              AND COALESCE(m.excluded,0)=0
              AND COALESCE(m.derived_date,'')!=''
            GROUP BY fc.id
            HAVING date_count >= ?
            ORDER BY date_count DESC, media_count DESC, fc.id ASC
            """,
            (min_dates,),
        ).fetchall()

    for c in clusters:
        label = f"TEMP-{c['cluster_label']}"
        summary = (
            f"Automatic temporary POI from {c['cluster_label']}: internal face cluster "
            f"seen across {int(c['date_count'] or 0)} different dates and "
            f"{int(c['media_count'] or 0)} media files. Requires analyst confirmation."
        )
        poi_id = ensure_poi(label, 0.50, summary)
        touched = link_face_cluster_to_poi(int(c['id']), label).get("sightings_touched", 0)
        with DB_LOCK, connect() as conn:
            conn.execute(
                "UPDATE poi_clusters SET status='temporary_auto', confidence=MAX(confidence,0.50), summary=?, updated_at=? WHERE id=?",
                (summary, utc_now(), poi_id),
            )
            conn.execute(
                "UPDATE face_clusters SET status='auto_temp_poi', notes=COALESCE(notes,'') || char(10) || ? WHERE id=?",
                ("Auto-linked to temporary POI because cluster appears on multiple dates.", int(c['id'])),
            )
            queue_review(conn, "poi", poi_id, f"Review automatic temporary POI {label} created from cross-date face cluster", priority=1)
            conn.commit()
        assigned.append({
            "cluster_id": int(c["id"]),
            "cluster_label": c["cluster_label"],
            "poi_id": poi_id,
            "poi_label": label,
            "date_count": int(c["date_count"] or 0),
            "media_count": int(c["media_count"] or 0),
            "dates": c["dates"],
            "locations": c["locations"],
            "sightings_touched": touched,
        })

    if assigned:
        try:
            rebuild_associations()
        except Exception as e:
            print(f"[poi-shuttle] rebuild associations after auto temporary POIs failed: {e}")
    return {"assigned_temp_pois": len(assigned), "items": assigned, "min_dates": min_dates}


def enqueue_face_scan(media_ids: List[int], threshold: float = 0.82, auto_temp_poi: bool = False, auto_min_dates: int = 2) -> Dict[str, Any]:
    clean_ids = []
    seen = set()
    for mid in media_ids or []:
        try:
            imid = int(mid)
        except Exception:
            continue
        if imid > 0 and imid not in seen:
            clean_ids.append(imid)
            seen.add(imid)
    if not clean_ids:
        raise HTTPException(status_code=400, detail="media_ids is required")
    threshold = max(0.1, min(0.99, float(threshold or 0.82)))
    now = utc_now()

    def _write_job():
        with DB_LOCK, connect() as conn:
            cur = conn.execute(
                "INSERT INTO face_scan_jobs(media_ids_json, threshold, status, auto_temp_poi, auto_min_dates, created_at, updated_at) VALUES(?,?,?,?,?,?,?)",
                (json.dumps(clean_ids), threshold, "queued", 1 if auto_temp_poi else 0, max(2, int(auto_min_dates or 2)), now, now),
            )
            job_id = int(cur.lastrowid)
            # Keep this transaction deliberately tiny.  The background worker may
            # be scanning thousands of images, so queue creation must not wait on
            # review-row housekeeping.
            conn.commit()
            return job_id

    job_id = _db_locked_retry("queueing face scan", _write_job)

    # Best-effort review hints, intentionally separate from the queue transaction.
    def _write_review_hints():
        with DB_LOCK, connect() as conn:
            for mid in clean_ids[:50]:
                queue_review(conn, "media", mid, f"Queued for face detection job #{job_id}", priority=4)
            conn.commit()

    try:
        _db_locked_retry("adding face queue review hints", _write_review_hints, attempts=3, base_sleep=0.1)
    except Exception:
        pass
    return {"queued": True, "job_id": job_id, "media_count": len(clean_ids), "threshold": threshold, "status": "queued", "auto_temp_poi": bool(auto_temp_poi), "auto_min_dates": max(2, int(auto_min_dates or 2))}


def _next_face_scan_job() -> Optional[sqlite3.Row]:
    with DB_LOCK, connect() as conn:
        row = conn.execute("SELECT * FROM face_scan_jobs WHERE status='queued' ORDER BY id ASC LIMIT 1").fetchone()
        if not row:
            return None
        now = utc_now()
        conn.execute("UPDATE face_scan_jobs SET status='running', started_at=?, updated_at=? WHERE id=?", (now, now, int(row["id"])))
        conn.commit()
        return conn.execute("SELECT * FROM face_scan_jobs WHERE id=?", (int(row["id"]),)).fetchone()


def process_face_scan_job(job: sqlite3.Row) -> Dict[str, Any]:
    job_id = int(job["id"])
    try:
        media_ids = json.loads(job["media_ids_json"] or "[]")
        if not isinstance(media_ids, list):
            media_ids = []
    except Exception:
        media_ids = []
    try:
        result = scan_faces_for_media([int(x) for x in media_ids], float(job["threshold"] or 0.82), job_id=job_id)
        if int(job["auto_temp_poi"] or 0):
            try:
                result["auto_temp_poi"] = auto_assign_cross_date_face_pois(int(job["auto_min_dates"] or 2))
            except Exception as e:
                result["auto_temp_poi_error"] = str(e)
        now = utc_now()
        with DB_LOCK, connect() as conn:
            conn.execute(
                """
                UPDATE face_scan_jobs
                SET status='done', scanned_images=?, detected_faces=?, created_clusters=?, result_json=?, error='', finished_at=?, updated_at=?
                WHERE id=?
                """,
                (
                    int(result.get("scanned_images") or 0),
                    int(result.get("detected_faces") or 0),
                    int(result.get("created_clusters") or 0),
                    json.dumps(result),
                    now,
                    now,
                    job_id,
                ),
            )
            conn.commit()
        return result
    except Exception as e:
        now = utc_now()
        err = str(e)
        with DB_LOCK, connect() as conn:
            conn.execute("UPDATE face_scan_jobs SET status='failed', error=?, finished_at=?, updated_at=? WHERE id=?", (err[:2000], now, now, job_id))
            conn.commit()
        return {"error": err, "job_id": job_id}


def face_scan_worker_loop() -> None:
    print("[poi-shuttle] face scan queue worker started")
    while not FACE_WORKER_STOP.is_set():
        try:
            job = _next_face_scan_job()
            if job is None:
                FACE_WORKER_STOP.wait(FACE_SCAN_SLEEP_SEC)
                continue
            print(f"[poi-shuttle] face scan job #{int(job['id'])} running")
            result = process_face_scan_job(job)
            print(f"[poi-shuttle] face scan job #{int(job['id'])} finished: {result}")
        except Exception as e:
            print(f"[poi-shuttle] face scan worker error: {e}")
            FACE_WORKER_STOP.wait(2.0)


def start_face_scan_worker() -> None:
    global FACE_WORKER_STARTED
    with FACE_WORKER_LOCK:
        if FACE_WORKER_STARTED:
            return
        FACE_WORKER_STARTED = True
        t = threading.Thread(target=face_scan_worker_loop, name="poi-face-scan-worker", daemon=True)
        t.start()


def get_faces_summary() -> Dict[str, Any]:
    with DB_LOCK, connect() as conn:
        clusters = conn.execute("""
            SELECT fc.*, p.poi_label,
                   COUNT(fo.id) AS observations,
                   COUNT(DISTINCT fo.media_id) AS media_count,
                   MIN(m.derived_ts) AS first_seen,
                   MAX(m.derived_ts) AS last_seen,
                   GROUP_CONCAT(DISTINCT m.location) AS locations
            FROM face_clusters fc
            LEFT JOIN poi_clusters p ON p.id=fc.linked_poi_id
            LEFT JOIN face_observations fo ON fo.face_cluster_id=fc.id
            LEFT JOIN media_files m ON m.id=fo.media_id
            GROUP BY fc.id ORDER BY fc.id DESC
        """).fetchall()
        faces = conn.execute("""
            SELECT fo.*, fc.cluster_label, fc.linked_poi_id, p.poi_label,
                   m.rel_path, m.derived_ts, m.derived_date, m.location, m.kind
            FROM face_observations fo
            LEFT JOIN face_clusters fc ON fc.id=fo.face_cluster_id
            LEFT JOIN poi_clusters p ON p.id=fc.linked_poi_id
            LEFT JOIN media_files m ON m.id=fo.media_id
            ORDER BY fo.id DESC LIMIT 500
        """).fetchall()
        jobs = conn.execute("SELECT * FROM face_scan_jobs ORDER BY id DESC LIMIT 100").fetchall()
    return {"clusters": rows_to_dicts(clusters), "faces": rows_to_dicts(faces), "jobs": rows_to_dicts(jobs)}


def link_face_cluster_to_poi(cluster_id: int, poi_label: str) -> Dict[str, Any]:
    poi_label = (poi_label or "").strip()
    if not poi_label:
        raise HTTPException(status_code=400, detail="poi_label is required")
    poi_id = ensure_poi(poi_label, 0.55, "POI linked from internal face cluster")
    with DB_LOCK, connect() as conn:
        fc = conn.execute("SELECT * FROM face_clusters WHERE id=?", (cluster_id,)).fetchone()
        if not fc:
            raise HTTPException(status_code=404, detail="face cluster not found")
        conn.execute("UPDATE face_clusters SET linked_poi_id=?, status='linked_to_poi', updated_at=? WHERE id=?", (poi_id, utc_now(), cluster_id))
        rows = conn.execute("SELECT fo.*, m.derived_ts, m.derived_date, m.location FROM face_observations fo JOIN media_files m ON m.id=fo.media_id WHERE fo.face_cluster_id=?", (cluster_id,)).fetchall()
        updated = 0
        for r in rows:
            # Assign all existing sightings on the same media to the chosen POI. This is reviewable, not definitive.
            cur = conn.execute("UPDATE sightings SET poi_id=?, review_status='face_cluster_assigned', confidence=MAX(confidence,0.55), notes=COALESCE(notes,'') || char(10) || ? WHERE media_id=?", (poi_id, f"Linked from {fc['cluster_label']} by analyst.", r["media_id"]))
            if cur.rowcount == 0:
                conn.execute("INSERT INTO sightings(media_id, poi_id, sighting_ts, sighting_date, location, bbox_json, crop_path, descriptor_hash, confidence, review_status, notes) VALUES(?,?,?,?,?,?,?,?,?,?,?)", (r["media_id"], poi_id, r["derived_ts"], r["derived_date"], r["location"], r["bbox_json"], r["crop_path"], f"face_cluster:{cluster_id}", 0.55, "face_cluster_assigned", f"Linked from {fc['cluster_label']} by analyst."))
            updated += 1
        conn.commit()
    return {"cluster_id": cluster_id, "poi_id": poi_id, "poi_label": poi_label, "sightings_touched": updated}

def get_media_or_404(media_id: int) -> sqlite3.Row:
    with DB_LOCK, connect() as conn:
        row = conn.execute("SELECT * FROM media_files WHERE id=?", (media_id,)).fetchone()
    if not row:
        raise HTTPException(status_code=404, detail="media not found")
    return row


class ScanPayload(BaseModel):
    roots: Optional[List[str]] = None

class CreatePOIPayload(BaseModel):
    label: str
    sighting_ids: List[int] = []
    confidence: float = 0.55
    summary: str = ""

class ExcludePayload(BaseModel):
    media_ids: List[int]
    excluded: bool = True
    reason: str = ""

class MediaUpdatePayload(BaseModel):
    media_ids: Optional[List[int]] = None
    location: Optional[str] = None
    notes: Optional[str] = None
    importance: Optional[str] = None

class PlatePayload(BaseModel):
    media_id: Optional[int] = None
    plate_text: str
    confidence: float = 0.0
    country_hint: str = ""
    method: str = "manual"
    status: str = "candidate"
    notes: str = ""

class PlateScanPayload(BaseModel):
    media_ids: List[int]

class AssignSightingsPayload(BaseModel):
    poi_id: int
    sighting_ids: List[int]

class LocationConfigPayload(BaseModel):
    config: Dict[str, Any]
    rederive: bool = False

class AIGeolocatePayload(BaseModel):
    media_id: int

class AIGeolocateConfirmPayload(BaseModel):
    media_id: int
    job_id: Optional[int] = None
    location: str
    confidence: float = 0.0
    notes: str = ""
    add_to_catalog: bool = True

class AIWindowPayload(BaseModel):
    anchor_media_id: int
    location: str
    hours_before: float = 3.0
    hours_after: float = 3.0
    sample_limit: int = 12

class AIWindowApplyPayload(BaseModel):
    window_id: int

class FaceScanPayload(BaseModel):
    media_ids: List[int]
    threshold: float = 0.82
    auto_temp_poi: bool = False
    auto_min_dates: int = 2

class FaceScanAllPayload(BaseModel):
    threshold: float = 0.82
    include_excluded: bool = False
    auto_temp_poi: bool = True
    auto_min_dates: int = 2
    limit: Optional[int] = None

class FaceClusterLinkPayload(BaseModel):
    poi_label: str


app = FastAPI(title=APP_TITLE)
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])


def reset_stale_face_jobs() -> None:
    """Recover jobs left in running state by a prior crash/restart.

    SQLite has no worker heartbeat, so a job marked running with no live Python
    worker can otherwise sit forever.  On startup we safely requeue it.
    """
    try:
        now = utc_now()
        with DB_LOCK, connect() as conn:
            conn.execute(
                """
                UPDATE face_scan_jobs
                SET status='queued', error='requeued after server restart/stale running state', updated_at=?
                WHERE status='running'
                """,
                (now,),
            )
            conn.commit()
    except Exception as e:
        print(f"[poi-shuttle] stale face job reset failed: {e}")

@app.on_event("startup")
def startup() -> None:
    init_db()
    reset_stale_face_jobs()
    start_face_scan_worker()
    print(f"[poi-shuttle] build {BUILD}")

@app.get("/", response_class=HTMLResponse)
def ui() -> str:
    return HTML_UI

@app.get("/api/status")
def api_status() -> Dict[str, Any]:
    return {"app": APP_TITLE, "build": BUILD, "db": str(DB_PATH), "media_roots": MEDIA_ROOTS, "location_map": str(LOCATION_MAP_PATH), "location_map_exists": LOCATION_MAP_PATH.exists(), "detectors": detector_status(), "ai": ai_status(), "ssl": {"keyfile": SSL_KEYFILE, "certfile": SSL_CERTFILE, "enabled_if_files_exist": Path(SSL_KEYFILE).exists() and Path(SSL_CERTFILE).exists()}}

@app.post("/api/scan")
def api_scan(payload: ScanPayload) -> Dict[str, Any]:
    return scan_media_roots(payload.roots)

@app.get("/api/media")
def api_media(kind: Optional[str] = None, search: str = "", show_excluded: bool = False, offset: int = 0, limit: int = 80) -> Dict[str, Any]:
    where: List[str] = [] ; params: List[Any] = []
    if kind and kind != "all":
        if kind == "visual":
            where.append("kind IN ('image','video')")
        else:
            where.append("kind=?"); params.append(kind)
    if not show_excluded:
        where.append("COALESCE(excluded,0)=0")
    if search.strip():
        q = f"%{search.strip()}%"
        where.append("(rel_path LIKE ? OR location LIKE ? OR derived_date LIKE ? OR notes LIKE ?)")
        params.extend([q,q,q,q])
    sql_where = (" WHERE " + " AND ".join(where)) if where else ""
    limit = max(1, min(500, int(limit or 80))); offset = max(0, int(offset or 0))
    with DB_LOCK, connect() as conn:
        total = int(conn.execute("SELECT COUNT(*) AS c FROM media_files" + sql_where, params).fetchone()["c"])
        rows = conn.execute("SELECT * FROM media_files" + sql_where + " ORDER BY COALESCE(derived_ts, rel_path) LIMIT ? OFFSET ?", params + [limit, offset]).fetchall()
    return {"media": rows_to_dicts(rows), "total": total, "offset": offset, "limit": limit}

@app.post("/api/media/exclude")
def api_media_exclude(payload: ExcludePayload) -> Dict[str, Any]:
    with DB_LOCK, connect() as conn:
        for mid in payload.media_ids:
            conn.execute("UPDATE media_files SET excluded=?, exclude_reason=?, importance=?, updated_at=? WHERE id=?", (1 if payload.excluded else 0, payload.reason if payload.excluded else "", "excluded" if payload.excluded else "normal", utc_now(), mid))
        conn.commit()
    return {"updated": len(payload.media_ids), "excluded": payload.excluded}

@app.post("/api/media/update")
def api_media_update(payload: MediaUpdatePayload) -> Dict[str, Any]:
    ids = payload.media_ids or []
    if not ids:
        return {"updated": 0}
    with DB_LOCK, connect() as conn:
        for mid in ids:
            if payload.location is not None:
                conn.execute("UPDATE media_files SET location=?, location_source='manual_override', updated_at=? WHERE id=?", (payload.location, utc_now(), mid))
                conn.execute("UPDATE sightings SET location=? WHERE media_id=?", (payload.location, mid))
            if payload.notes is not None:
                conn.execute("UPDATE media_files SET notes=?, updated_at=? WHERE id=?", (payload.notes, utc_now(), mid))
            if payload.importance is not None:
                conn.execute("UPDATE media_files SET importance=?, updated_at=? WHERE id=?", (payload.importance, utc_now(), mid))
        conn.commit()
    return {"updated": len(ids)}

@app.get("/api/media/{media_id}/file")
def api_media_file(media_id: int):
    row = get_media_or_404(media_id); path = row["path"]
    if not Path(path).exists():
        raise HTTPException(status_code=404, detail="file missing on disk")
    return FileResponse(path, media_type=mimetypes.guess_type(path)[0] or "application/octet-stream", filename=Path(path).name)

@app.get("/api/media/{media_id}/thumb")
def api_media_thumb(media_id: int):
    row = get_media_or_404(media_id)
    if row["kind"] == "image" and Path(row["path"]).exists():
        return FileResponse(row["path"])
    label = html.escape(row["kind"].upper())
    name = html.escape(Path(row["rel_path"]).name)
    svg = f'<svg xmlns="http://www.w3.org/2000/svg" width="640" height="380"><rect width="100%" height="100%" fill="#1b1f27"/><text x="50%" y="45%" fill="#00ffcc" font-family="monospace" font-size="34" text-anchor="middle">{label}</text><text x="50%" y="60%" fill="#aaa" font-family="monospace" font-size="15" text-anchor="middle">{name}</text></svg>'
    return Response(svg, media_type="image/svg+xml")

@app.post("/api/bootstrap-sightings")
def api_bootstrap_sightings() -> Dict[str, Any]:
    return bootstrap_sightings_from_media()

@app.post("/api/rebuild-associations")
def api_rebuild_associations() -> Dict[str, Any]:
    return rebuild_associations()

@app.post("/api/ai/triage")
def api_ai_triage(limit: int = 25) -> Dict[str, Any]:
    return {"processed": 0, "limit": limit, "ai": ai_status(), "note": "Use AI geolocate on selected media; automatic batch triage remains deliberately manual-gated."}

@app.get("/api/ai/selftest")
def api_ai_selftest() -> Dict[str, Any]:
    prompt = 'Return strict JSON only: {"ok": true, "message": "ai provider reachable"}'
    try:
        result = ai_generate_json(prompt, [])
        return {"ok": True, "result": result, "ai": ai_status()}
    except Exception as e:
        err = str(e)
        return {"ok": False, "error": err, "hint": ai_error_hint(err), "ai": ai_status()}

@app.get("/api/ai/gemini/selftest")
def api_ai_gemini_selftest() -> Dict[str, Any]:
    # Backwards-compatible route name; now tests whichever POI_AI_PROVIDER selects.
    return api_ai_selftest()

@app.post("/api/ai/geolocate")
def api_ai_geolocate(payload: AIGeolocatePayload) -> Dict[str, Any]:
    return run_geolocate_agent(payload.media_id)

@app.post("/api/ai/geolocate/confirm")
def api_ai_geolocate_confirm(payload: AIGeolocateConfirmPayload) -> Dict[str, Any]:
    location_added = False
    clean_loc = str(payload.location or "").strip()
    if payload.add_to_catalog and clean_loc and clean_loc.lower() != "unknown":
        cfg = load_location_config()
        catalog = cfg.setdefault("location_catalog", [])
        if clean_loc not in catalog:
            catalog.append(clean_loc)
            save_location_config(cfg)
            location_added = True
    with DB_LOCK, connect() as conn:
        conn.execute("UPDATE media_files SET location=?, location_source='ai_confirmed', notes=CASE WHEN ?!='' THEN COALESCE(notes,'') || char(10) || ? ELSE notes END, updated_at=? WHERE id=?", (clean_loc, payload.notes, payload.notes, utc_now(), payload.media_id))
        conn.execute("UPDATE sightings SET location=?, confidence=MAX(confidence, ?), notes=CASE WHEN ?!='' THEN COALESCE(notes,'') || char(10) || ? ELSE notes END WHERE media_id=?", (clean_loc, payload.confidence, payload.notes, payload.notes, payload.media_id))
        if payload.job_id:
            conn.execute("UPDATE ai_geolocation_jobs SET selected_location=?, selected_confidence=?, confirmed=1, confirmed_at=?, status='confirmed', updated_at=? WHERE id=?", (clean_loc, payload.confidence, utc_now(), utc_now(), payload.job_id))
            conn.execute("UPDATE ai_geolocation_candidates SET status=CASE WHEN location=? THEN 'confirmed' ELSE 'rejected' END, updated_at=? WHERE job_id=?", (clean_loc, utc_now(), payload.job_id))
        queue_review(conn, "media", payload.media_id, "AI geolocation confirmed; consider deriving surrounding time window", priority=3)
        conn.commit()
    return {"confirmed": True, "media_id": payload.media_id, "location": clean_loc, "location_added_to_catalog": location_added}

@app.get("/api/ai/geolocate/jobs")
def api_ai_geolocate_jobs(media_id: Optional[int] = None) -> Dict[str, Any]:
    params: List[Any] = []
    where = ""
    if media_id is not None:
        where = " WHERE j.media_id=?"; params.append(media_id)
    with DB_LOCK, connect() as conn:
        jobs = conn.execute("SELECT j.*, m.rel_path, m.derived_ts FROM ai_geolocation_jobs j JOIN media_files m ON m.id=j.media_id" + where + " ORDER BY j.id DESC LIMIT 100", params).fetchall()
        cands = conn.execute("SELECT c.*, j.media_id FROM ai_geolocation_candidates c JOIN ai_geolocation_jobs j ON j.id=c.job_id ORDER BY c.id DESC LIMIT 300").fetchall()
        wins = conn.execute("SELECT w.*, m.rel_path FROM ai_location_windows w JOIN media_files m ON m.id=w.anchor_media_id ORDER BY w.id DESC LIMIT 100").fetchall()
    return {"jobs": rows_to_dicts(jobs), "candidates": rows_to_dicts(cands), "windows": rows_to_dicts(wins)}

@app.post("/api/ai/geolocate/window")
def api_ai_geolocate_window(payload: AIWindowPayload) -> Dict[str, Any]:
    try:
        return propose_location_window(payload.anchor_media_id, payload.location, payload.hours_before, payload.hours_after, payload.sample_limit)
    except HTTPException:
        raise
    except Exception as e:
        err = str(e)
        return {"ok": False, "error": err, "hint": ai_error_hint(err), "ai": ai_status()}

@app.post("/api/ai/geolocate/window/apply")
def api_ai_geolocate_window_apply(payload: AIWindowApplyPayload) -> Dict[str, Any]:
    return apply_location_window(payload.window_id)

@app.get("/api/sightings")
def api_sightings(poi_id: Optional[int] = None) -> Dict[str, Any]:
    where: List[str] = ["COALESCE(m.excluded,0)=0"] ; params: List[Any] = []
    if poi_id is not None:
        where.append("s.poi_id=?"); params.append(poi_id)
    sql = """
        SELECT s.*, m.rel_path, m.kind, m.path, p.poi_label
        FROM sightings s JOIN media_files m ON m.id=s.media_id
        LEFT JOIN poi_clusters p ON p.id=s.poi_id
    """ + " WHERE " + " AND ".join(where) + " ORDER BY COALESCE(s.sighting_ts, m.derived_ts, m.rel_path)"
    with DB_LOCK, connect() as conn:
        rows = conn.execute(sql, params).fetchall()
    return {"sightings": rows_to_dicts(rows)}

@app.get("/api/pois")
def api_pois() -> Dict[str, Any]:
    with DB_LOCK, connect() as conn:
        rows = conn.execute("""
            SELECT p.*, COUNT(s.id) AS sightings, COUNT(DISTINCT s.location) AS locations,
                   MIN(s.sighting_ts) AS first_seen, MAX(s.sighting_ts) AS last_seen
            FROM poi_clusters p LEFT JOIN sightings s ON s.poi_id=p.id
            GROUP BY p.id ORDER BY p.poi_label
        """).fetchall()
    return {"pois": rows_to_dicts(rows)}

@app.post("/api/pois")
def api_create_poi(payload: CreatePOIPayload) -> Dict[str, Any]:
    poi_id = ensure_poi(payload.label, payload.confidence, payload.summary)
    if payload.sighting_ids:
        with DB_LOCK, connect() as conn:
            conn.executemany("UPDATE sightings SET poi_id=?, review_status='assigned', confidence=? WHERE id=?", [(poi_id, payload.confidence, sid) for sid in payload.sighting_ids])
            conn.commit()
    return {"poi_id": poi_id, "label": payload.label}

@app.post("/api/sightings/assign")
def api_assign_sightings(payload: AssignSightingsPayload) -> Dict[str, Any]:
    with DB_LOCK, connect() as conn:
        conn.executemany("UPDATE sightings SET poi_id=?, review_status='assigned' WHERE id=?", [(payload.poi_id, sid) for sid in payload.sighting_ids])
        conn.commit()
    return {"assigned": len(payload.sighting_ids)}

@app.get("/api/associations")
def api_associations() -> Dict[str, Any]:
    with DB_LOCK, connect() as conn:
        rows = conn.execute("""
            SELECT a.*, pa.poi_label AS poi_a_label, pb.poi_label AS poi_b_label
            FROM associations a JOIN poi_clusters pa ON pa.id=a.poi_a JOIN poi_clusters pb ON pb.id=a.poi_b
            ORDER BY a.sighting_date, a.location, a.confidence DESC
        """).fetchall()
    return {"associations": rows_to_dicts(rows)}

@app.get("/api/graph")
def api_graph() -> Dict[str, Any]:
    with DB_LOCK, connect() as conn:
        nodes = conn.execute("SELECT p.id, p.poi_label AS label, COUNT(s.id) AS sightings FROM poi_clusters p LEFT JOIN sightings s ON s.poi_id=p.id WHERE p.poi_label!='UNASSIGNED' GROUP BY p.id").fetchall()
        edges = conn.execute("SELECT poi_a AS source, poi_b AS target, confidence, flags, sighting_date, location FROM associations").fetchall()
    return {"nodes": rows_to_dicts(nodes), "edges": rows_to_dicts(edges)}

@app.get("/api/review-queue")
def api_review_queue() -> Dict[str, Any]:
    with DB_LOCK, connect() as conn:
        rows = conn.execute("SELECT * FROM review_queue ORDER BY priority ASC, id ASC LIMIT 200").fetchall()
    return {"queue": rows_to_dicts(rows)}

@app.get("/api/location-summary")
def api_location_summary() -> Dict[str, Any]:
    with DB_LOCK, connect() as conn:
        rows = conn.execute("""
            SELECT derived_date, location, location_source, COUNT(*) AS files,
                   SUM(CASE WHEN kind='audio' THEN 1 ELSE 0 END) AS audio_files,
                   SUM(CASE WHEN kind='image' THEN 1 ELSE 0 END) AS image_files,
                   SUM(CASE WHEN kind='video' THEN 1 ELSE 0 END) AS video_files
            FROM media_files WHERE COALESCE(excluded,0)=0
            GROUP BY derived_date, location, location_source ORDER BY derived_date, location
        """).fetchall()
    return {"locations": rows_to_dicts(rows)}

@app.get("/api/locations/config")
def api_locations_config() -> Dict[str, Any]:
    return {"config": load_location_config()}

@app.post("/api/locations/config")
def api_locations_config_save(payload: LocationConfigPayload) -> Dict[str, Any]:
    save_location_config(payload.config)
    result = {"saved": True, "path": str(LOCATION_MAP_PATH)}
    if payload.rederive:
        result.update(rederive_locations())
    return result

@app.post("/api/locations/rederive")
def api_locations_rederive() -> Dict[str, Any]:
    return rederive_locations()

@app.get("/api/plates")
def api_plates() -> Dict[str, Any]:
    with DB_LOCK, connect() as conn:
        rows = conn.execute("""
            SELECT np.*, m.rel_path, m.derived_ts, m.location
            FROM number_plates np LEFT JOIN media_files m ON m.id=np.media_id
            ORDER BY np.created_at DESC, np.id DESC
        """).fetchall()
    return {"plates": rows_to_dicts(rows)}

@app.post("/api/plates")
def api_plate_add(payload: PlatePayload) -> Dict[str, Any]:
    with DB_LOCK, connect() as conn:
        now = utc_now()
        cur = conn.execute("INSERT INTO number_plates(media_id, plate_text, confidence, country_hint, method, status, notes, created_at, updated_at) VALUES(?,?,?,?,?,?,?,?,?)", (payload.media_id, payload.plate_text.strip().upper(), payload.confidence, payload.country_hint, payload.method, payload.status, payload.notes, now, now))
        conn.commit()
    return {"plate_id": cur.lastrowid}

@app.post("/api/plates/scan")
def api_plates_scan(payload: PlateScanPayload) -> Dict[str, Any]:
    # Conservative scaffold. OCR/ANPR workers can populate number_plates later.
    with DB_LOCK, connect() as conn:
        for mid in payload.media_ids:
            queue_review(conn, "media", mid, "Candidate number plate scan requested", priority=3)
        conn.commit()
    return {"queued": len(payload.media_ids), "note": "ANPR request queued. Add OCR worker for automated extraction; manual plate entry is available now."}


@app.get("/api/faces")
def api_faces() -> Dict[str, Any]:
    return get_faces_summary()

@app.post("/api/faces/scan")
def api_faces_scan(payload: FaceScanPayload) -> Dict[str, Any]:
    return enqueue_face_scan(payload.media_ids, payload.threshold, payload.auto_temp_poi, payload.auto_min_dates)

@app.post("/api/faces/scan-all-images")
def api_faces_scan_all_images(payload: FaceScanAllPayload) -> Dict[str, Any]:
    where = ["kind='image'"]
    params: List[Any] = []
    if not payload.include_excluded:
        where.append("COALESCE(excluded,0)=0")
    sql = "SELECT id FROM media_files WHERE " + " AND ".join(where) + " ORDER BY COALESCE(derived_ts, rel_path), id"
    if payload.limit and int(payload.limit) > 0:
        sql += " LIMIT ?"
        params.append(int(payload.limit))
    with DB_LOCK, connect() as conn:
        ids = [int(r["id"]) for r in conn.execute(sql, params).fetchall()]
    if not ids:
        raise HTTPException(status_code=400, detail="No image media files found. Run Scan media first.")
    result = enqueue_face_scan(ids, payload.threshold, payload.auto_temp_poi, payload.auto_min_dates)
    result.update({"selected_images": len(ids), "include_excluded": bool(payload.include_excluded), "endpoint": "/api/faces/scan-all-images"})
    return result

@app.post("/api/faces/auto-temp-pois")
def api_faces_auto_temp_pois(min_dates: int = 2) -> Dict[str, Any]:
    return auto_assign_cross_date_face_pois(min_dates)

@app.post("/api/faces/scan-now")
def api_faces_scan_now(payload: FaceScanPayload) -> Dict[str, Any]:
    # Manual/debug route only. The UI uses /api/faces/scan so large batches never block the browser.
    return scan_faces_for_media(payload.media_ids, payload.threshold)

@app.post("/api/faces/clusters/{cluster_id}/link-poi")
def api_face_cluster_link_poi(cluster_id: int, payload: FaceClusterLinkPayload) -> Dict[str, Any]:
    return link_face_cluster_to_poi(cluster_id, payload.poi_label)

@app.get("/api/faces/{face_id}/crop")
def api_face_crop(face_id: int):
    with DB_LOCK, connect() as conn:
        row = conn.execute("SELECT * FROM face_observations WHERE id=?", (face_id,)).fetchone()
    if not row:
        raise HTTPException(status_code=404, detail="face observation not found")
    path = Path(row["crop_path"] or "")
    if not path.exists():
        raise HTTPException(status_code=404, detail="face crop missing on disk")
    return FileResponse(str(path), media_type="image/jpeg", filename=path.name)

@app.get("/api/export/sightings.csv")
def api_export_sightings_csv():
    with DB_LOCK, connect() as conn:
        rows = conn.execute("""
            SELECT s.id, p.poi_label, s.sighting_ts, s.sighting_date, s.location,
                   s.confidence, s.review_status, m.rel_path, s.notes
            FROM sightings s JOIN media_files m ON m.id=s.media_id LEFT JOIN poi_clusters p ON p.id=s.poi_id
            WHERE COALESCE(m.excluded,0)=0 ORDER BY s.sighting_date, s.sighting_ts
        """).fetchall()
    buf = io.StringIO(); w = csv.writer(buf)
    w.writerow(["sighting_id", "poi", "timestamp", "date", "location", "confidence", "review_status", "media", "notes"])
    for r in rows:
        w.writerow([r[k] for k in r.keys()])
    return Response(buf.getvalue(), media_type="text/csv", headers={"Content-Disposition": "attachment; filename=poi_sightings.csv"})

HTML_UI = r'''
<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><title>POI Shuttle</title><meta name="viewport" content="width=device-width, initial-scale=1">
<style>
:root{--bg:#101114;--panel:#181b20;--line:#2a2f38;--text:#f2f4f8;--muted:#9aa6b2;--accent:#00ffcc;--warn:#ffaa00;--bad:#ff5c77;--good:#35d07f}*{box-sizing:border-box}body{margin:0;font-family:system-ui,-apple-system,Segoe UI,sans-serif;background:var(--bg);color:var(--text);height:100vh;overflow:hidden}header{height:42px;display:flex;align-items:center;justify-content:space-between;padding:0 14px;background:#15171b;border-bottom:1px solid var(--line)}header h1{font-size:17px;margin:0}.build{font-size:12px;color:var(--warn);margin-left:10px}button,input,select,textarea{font:inherit}button{background:#242a33;border:1px solid #3a424f;color:var(--text);border-radius:9px;padding:7px 10px;cursor:pointer}button.primary{background:#007d6b;border-color:#00d6b6}button.warn{background:#6f4d00;border-color:#d89a00}button.bad{background:#60202a;border-color:#a03a4a}input,select,textarea{background:#0b0d10;color:var(--text);border:1px solid #333b47;border-radius:8px;padding:7px;width:100%}.layout{display:grid;grid-template-columns:310px minmax(620px,1fr) 360px;gap:12px;height:calc(100vh - 42px);padding:12px}.panel{background:var(--panel);border:1px solid var(--line);border-radius:14px;padding:12px;overflow:auto}.main{overflow:auto}.card{background:#151922;border:1px solid #2c3340;border-radius:12px;padding:12px;margin-bottom:10px}.small{color:var(--muted);font-size:12px}.statgrid{display:grid;grid-template-columns:1fr 1fr;gap:10px}.stat{background:#0f1319;border:1px solid #2b3340;border-radius:9px;padding:10px}.stat b{font-size:21px;color:var(--accent);display:block}.tabs{display:flex;gap:7px;margin-bottom:10px;flex-wrap:wrap}.tab.on{border-color:var(--accent);color:var(--accent)}.toolbar{display:grid;grid-template-columns:1fr 130px 120px 120px;gap:8px;margin-bottom:10px}.media-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(250px,1fr));gap:12px}.media{position:relative;background:#151922;border:1px solid #2c3340;border-radius:12px;overflow:hidden;cursor:pointer}.media.selected{outline:3px solid var(--accent)}.media.excluded{opacity:.48}.media img{width:100%;height:190px;object-fit:cover;background:#0b0d10;display:block}.media .body{padding:10px}.media .check{position:absolute;top:8px;left:8px;width:24px;height:24px;z-index:5}.badge{display:inline-block;border:1px solid #465061;border-radius:999px;padding:2px 7px;margin:3px 2px;font-size:12px;color:#b8c2ce}.badge.good{border-color:#00aa88;color:#35d07f}.badge.warn{border-color:#d89a00;color:#ffaa00}.badge.bad{border-color:#a03a4a;color:#ff5c77}table{width:100%;border-collapse:collapse}td,th{border-bottom:1px solid #2b3340;padding:7px;text-align:left;font-size:13px}th{color:#b8c2ce}.rowgrid{display:grid;grid-template-columns:1fr 1fr 70px;gap:8px;margin-bottom:6px}.rowgrid4{display:grid;grid-template-columns:1fr 1fr 1fr 70px;gap:8px;margin-bottom:6px}.pager{display:flex;gap:8px;align-items:center;justify-content:space-between;margin:10px 0}.mono{font-family:ui-monospace,SFMono-Regular,Menlo,monospace;white-space:pre-wrap}@media(max-width:1100px){.layout{grid-template-columns:280px 1fr}.rightpanel{display:none}.toolbar{grid-template-columns:1fr 1fr}.media-grid{grid-template-columns:repeat(auto-fill,minmax(220px,1fr))}}

.poi-linker{display:grid;grid-template-columns:minmax(160px,1fr) minmax(180px,1fr) auto;gap:6px;align-items:center}.poi-linker select,.poi-linker input{background:#0b0f14;color:#e6edf3;border:1px solid #303946;border-radius:8px;padding:8px}.poi-linker button{white-space:nowrap}
</style></head><body>
<header><h1>POI Shuttle <span class="small">— evidence links, not identity claims</span><span id="build" class="build"></span></h1><div><button onclick="refreshAll()">Refresh</button> <button onclick="location.href='/api/export/sightings.csv'">Export CSV</button></div></header>
<div class="layout"><aside class="panel"><h3>Case index</h3><div id="status"></div><br><button class="primary" onclick="scan()">Scan media</button> <button onclick="bootstrap()">Bootstrap sightings</button> <button onclick="rebuild()">Rebuild links</button> <button class="warn" onclick="triage()">AI triage</button><hr><h3>Create / assign POI</h3><input id="newPoiLabel" placeholder="POI-001 or descriptive label"><br><br><button class="primary" onclick="createPoi()">Assign selected sightings</button><div id="pois"></div></aside>
<main class="panel main"><div class="tabs"><button class="tab on" id="tab-media" onclick="setView('media')">Media</button><button class="tab" id="tab-sightings" onclick="setView('sightings')">Sightings</button><button class="tab" id="tab-graph" onclick="setView('graph')">Association graph</button><button class="tab" id="tab-locations" onclick="setView('locations')">Locations</button><button class="tab" id="tab-plates" onclick="setView('plates')">Number plates</button><button class="tab" id="tab-faces" onclick="setView('faces')">Face clusters</button><button class="tab" id="tab-ai_geo" onclick="setView('ai_geo')">AI geolocation</button></div><div id="view"></div></main>
<aside class="panel rightpanel"><h3>Review queue</h3><div id="queue"></div><hr><h3>Selected</h3><div class="small">Selected media: <span id="selectedMediaCount">0</span></div><div class="small">Selected sightings: <span id="selectedCount">0</span></div><pre id="selectedData" class="card mono">None</pre></aside></div>
<script>
let state={status:null,media:[],mediaTotal:0,mediaOffset:0,mediaLimit:80,mediaKind:'visual',mediaSearch:'',showExcluded:false,pois:[],sightings:[],associations:[],graph:null,queue:[],locations:[],locConfig:null,plates:[],faces:{clusters:[],faces:[]},aiGeo:{jobs:[],candidates:[],windows:[]},view:'media',selectedSightings:new Set(),selectedMedia:new Set()};
async function api(url,opts={}){const r=await fetch(url,opts);if(!r.ok)throw new Error(await r.text());return await r.json()}function esc(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}function fmt(s){return s?esc(s):'<span class="small">unknown</span>'}
async function loadMedia(){const p=new URLSearchParams({kind:state.mediaKind,search:state.mediaSearch,show_excluded:state.showExcluded,offset:state.mediaOffset,limit:state.mediaLimit});const d=await api('/api/media?'+p);state.media=d.media;state.mediaTotal=d.total;state.mediaOffset=d.offset;state.mediaLimit=d.limit}
async function refreshAll(){state.status=await api('/api/status');document.getElementById('build').textContent='build '+state.status.build;await loadMedia();state.pois=(await api('/api/pois')).pois;state.sightings=(await api('/api/sightings')).sightings;state.associations=(await api('/api/associations')).associations;state.graph=await api('/api/graph');state.queue=(await api('/api/review-queue')).queue;state.locations=(await api('/api/location-summary')).locations;state.locConfig=(await api('/api/locations/config')).config;state.plates=(await api('/api/plates')).plates;state.faces=await api('/api/faces');state.aiGeo=await api('/api/ai/geolocate/jobs');renderAll()}
function renderAll(){renderStatus();renderPois();renderQueue();renderSelected();renderView()}function renderStatus(){const s=state.status,visual=state.mediaTotal;document.getElementById('status').innerHTML=`<div class="statgrid"><div class="stat"><b>${state.mediaTotal}</b><span class="small">filtered media</span></div><div class="stat"><b>${visual}</b><span class="small">current view</span></div><div class="stat"><b>${state.sightings.length}</b><span class="small">sightings</span></div><div class="stat"><b>${state.associations.length}</b><span class="small">links</span></div></div><br><span class="small">Roots: ${esc((s.media_roots||[]).join(' | '))}</span><br><span class="small">Location map: ${esc(s.location_map)} ${s.location_map_exists?'✅':'⚠️'}</span><br><span class="small">Detector packages: OpenCV=${s.detectors.opencv}, YOLO=${s.detectors.ultralytics}, FastReID=${s.detectors.fastreid}, dlib_required=${s.detectors.dlib_required}</span>`}
function renderPois(){let h='<table><tr><th>POI</th><th>Sightings</th><th>Locs</th></tr>';for(const p of state.pois)h+=`<tr onclick="filterPoi(${p.id})"><td>${esc(p.poi_label)}</td><td>${p.sightings}</td><td>${p.locations}</td></tr>`;document.getElementById('pois').innerHTML=h+'</table>'}function renderQueue(){document.getElementById('queue').innerHTML=state.queue.length?('<table>'+state.queue.slice(0,80).map(q=>`<tr><td>${esc(q.item_type)} #${q.item_id}</td><td>${esc(q.reason)}</td></tr>`).join('')+'</table>'):'<span class="small">Nothing queued.</span>'}
function jsq(s){return JSON.stringify(String(s??''))}
function renderSelected(){document.getElementById('selectedMediaCount').textContent=state.selectedMedia.size;document.getElementById('selectedCount').textContent=state.selectedSightings.size;document.getElementById('selectedData').textContent=JSON.stringify({media:[...state.selectedMedia].slice(0,100),sightings:[...state.selectedSightings].slice(0,100)},null,2)}
function setView(v){state.view=v;document.querySelectorAll('.tab').forEach(t=>t.classList.remove('on'));document.getElementById('tab-'+v).classList.add('on');renderView()}function renderView(){if(state.view==='media')renderMedia();if(state.view==='sightings')renderSightings();if(state.view==='graph')renderGraph();if(state.view==='locations')renderLocations();if(state.view==='plates')renderPlates();if(state.view==='faces')renderFaces();if(state.view==='ai_geo')renderAIGeo()}
function mediaToolbar(){return `<div class="toolbar"><input id="mediaSearch" placeholder="filter filename/date/location" value="${esc(state.mediaSearch)}" onkeydown="if(event.key==='Enter')applyMediaFilters()"><select id="mediaKind"><option value="visual">visual</option><option value="image">images</option><option value="video">videos</option><option value="audio">audio</option><option value="all">all</option></select><select id="showExcluded"><option value="false">hide excluded</option><option value="true">show excluded</option></select><button onclick="applyMediaFilters()">Apply</button></div><div class="card"><button onclick="selectPageMedia()">Select page</button> <button onclick="clearMediaSelection()">Clear selection</button> <button class="bad" onclick="excludeSelected(true)">Exclude selected</button> <button onclick="excludeSelected(false)">Restore selected</button> <button onclick="setSelectedLocation()">Set location</button> <button class="warn" onclick="scanSelectedPlates()">Scan selected for plates</button> <button class="warn" onclick="scanSelectedFaces()">Queue selected for faces</button> <button class="primary" onclick="aiGeolocateSelected()">AI geolocate selected</button></div>`}
function renderMedia(){let h=mediaToolbar();h+=`<div class="pager"><button onclick="prevPage()">Prev</button><span class="small">Showing ${state.mediaOffset+1}-${Math.min(state.mediaOffset+state.media.length,state.mediaTotal)} of ${state.mediaTotal}</span><button onclick="nextPage()">Next</button></div><div class="media-grid">`;for(const m of state.media){const sel=state.selectedMedia.has(m.id);const bad=m.location==='Unknown'||!m.derived_ts;h+=`<div class="media ${sel?'selected':''} ${m.excluded?'excluded':''}" onclick="toggleMedia(${m.id})"><input class="check" type="checkbox" ${sel?'checked':''} onclick="event.stopPropagation();toggleMedia(${m.id})"><img src="/api/media/${m.id}/thumb" loading="lazy"><div class="body"><b>#${m.id} ${esc(m.rel_path.split('/').pop())}</b><br><span class="badge">${esc(m.kind)}</span><span class="badge ${bad?'warn':'good'}">${esc(m.location||'Unknown')}</span><span class="badge">${esc(m.derived_date||'no date')}</span>${m.excluded?'<span class="badge bad">excluded</span>':''}<br><span class="small">${esc(m.rel_path)}</span></div></div>`}document.getElementById('view').innerHTML=h+'</div>';document.getElementById('mediaKind').value=state.mediaKind;document.getElementById('showExcluded').value=String(state.showExcluded)}
async function applyMediaFilters(){state.mediaSearch=document.getElementById('mediaSearch').value;state.mediaKind=document.getElementById('mediaKind').value;state.showExcluded=document.getElementById('showExcluded').value==='true';state.mediaOffset=0;await loadMedia();renderAll()}function nextPage(){state.mediaOffset=Math.min(Math.max(0,state.mediaTotal-state.mediaLimit),state.mediaOffset+state.mediaLimit);loadMedia().then(renderAll)}function prevPage(){state.mediaOffset=Math.max(0,state.mediaOffset-state.mediaLimit);loadMedia().then(renderAll)}function toggleMedia(id){state.selectedMedia.has(id)?state.selectedMedia.delete(id):state.selectedMedia.add(id);renderSelected();renderMedia()}function selectPageMedia(){state.media.forEach(m=>state.selectedMedia.add(m.id));renderSelected();renderMedia()}function clearMediaSelection(){state.selectedMedia.clear();renderSelected();renderMedia()}
async function excludeSelected(x){const reason=x?(prompt('Reason for exclusion','unimportant')||'unimportant'):'';await api('/api/media/exclude',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({media_ids:[...state.selectedMedia],excluded:x,reason})});await refreshAll()}async function setSelectedLocation(){const cfg=state.locConfig||{};const loc=prompt('Set selected media location', (cfg.location_catalog||[])[0]||'');if(!loc)return;await api('/api/media/update',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({media_ids:[...state.selectedMedia],location:loc})});await refreshAll()}async function scanSelectedPlates(){alert(JSON.stringify(await api('/api/plates/scan',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({media_ids:[...state.selectedMedia]})}),null,2));await refreshAll()}
function toggleSighting(id){state.selectedSightings.has(id)?state.selectedSightings.delete(id):state.selectedSightings.add(id);renderSelected();renderSightings()}function renderSightings(rows=state.sightings){let h='<table><tr><th></th><th>POI</th><th>Time</th><th>Location</th><th>Media</th><th>Status</th></tr>';for(const s of rows)h+=`<tr><td><input type="checkbox" ${state.selectedSightings.has(s.id)?'checked':''} onclick="toggleSighting(${s.id})"></td><td>${esc(s.poi_label||'UNASSIGNED')}</td><td>${fmt(s.sighting_ts)}</td><td>${esc(s.location||'Unknown')}</td><td><a href="/api/media/${s.media_id}/file" target="_blank">${esc(s.rel_path)}</a></td><td>${esc(s.review_status)}</td></tr>`;document.getElementById('view').innerHTML=h+'</table>'}
function cfgRows(arr,cls,fields){return (arr||[]).map((r,i)=>`<div class="${cls}" data-i="${i}">${fields.map(f=>`<input data-f="${f}" value="${esc(typeof r==='string'?r:(r[f]||''))}">`).join('')}<button onclick="this.parentElement.remove()">Del</button></div>`).join('')}function renderLocations(){const c=state.locConfig||{};let h='<div class="card"><h2>Editable location config</h2><span class="small">Stored in poi_location_map.yaml. No case locations are hard-coded in Python.</span></div>';h+=`<h3>Catalog</h3><div id="catRows">${cfgRows(c.location_catalog||[],'rowgrid',['value'])}</div><button onclick="addCat()">Add catalog row</button><h3>Date map</h3><div id="dateRows">${Object.entries(c.audio_date_locations||{}).map(([k,v])=>`<div class="rowgrid"><input data-f="date" value="${esc(k)}"><input data-f="location" value="${esc(v)}"><button onclick="this.parentElement.remove()">Del</button></div>`).join('')}</div><button onclick="addDateRow()">Add date map</button><h3>Window rules</h3><div id="winRows">${cfgRows(c.locations||[],'rowgrid4',['name','start','end'])}</div><button onclick="addWin()">Add window</button><h3>Path hints</h3><div id="hintRows">${cfgRows(c.path_hints||[],'rowgrid',['pattern','location'])}</div><button onclick="addHint()">Add path hint</button><br><br><button class="primary" onclick="saveLoc(false)">Save only</button> <button class="warn" onclick="saveLoc(true)">Save + rederive</button><h3>Current derived summary</h3><table><tr><th>Date</th><th>Location</th><th>Source</th><th>Files</th></tr>`;for(const l of state.locations)h+=`<tr><td>${fmt(l.derived_date)}</td><td>${esc(l.location)}</td><td>${esc(l.location_source)}</td><td>${l.files}</td></tr>`;document.getElementById('view').innerHTML=h+'</table>'}
function addCat(){document.getElementById('catRows').insertAdjacentHTML('beforeend','<div class="rowgrid"><input data-f="value" placeholder="World - Region - Country - City - Area - Site"><span></span><button onclick="this.parentElement.remove()">Del</button></div>')}function addDateRow(){document.getElementById('dateRows').insertAdjacentHTML('beforeend','<div class="rowgrid"><input data-f="date" placeholder="YYYY-MM-DD"><input data-f="location" placeholder="World - ..."><button onclick="this.parentElement.remove()">Del</button></div>')}function addWin(){document.getElementById('winRows').insertAdjacentHTML('beforeend','<div class="rowgrid4"><input data-f="name" placeholder="World - ..."><input data-f="start" placeholder="YYYY-MM-DD HH:MM:SS"><input data-f="end" placeholder="YYYY-MM-DD HH:MM:SS"><button onclick="this.parentElement.remove()">Del</button></div>')}function addHint(){document.getElementById('hintRows').insertAdjacentHTML('beforeend','<div class="rowgrid"><input data-f="pattern" placeholder="regex"><input data-f="location" placeholder="World - ..."><button onclick="this.parentElement.remove()">Del</button></div>')}
async function saveLoc(rederive){const cfg={location_schema:'World - Region - Country - City - Area - Site',location_catalog:[],audio_date_locations:{},locations:[],path_hints:[]};document.querySelectorAll('#catRows input').forEach(i=>{if(i.value.trim())cfg.location_catalog.push(i.value.trim())});document.querySelectorAll('#dateRows .rowgrid').forEach(r=>{const d=r.querySelector('[data-f="date"]').value.trim(),l=r.querySelector('[data-f="location"]').value.trim();if(d&&l)cfg.audio_date_locations[d]=l});document.querySelectorAll('#winRows .rowgrid4').forEach(r=>{const name=r.querySelector('[data-f="name"]').value.trim();if(name)cfg.locations.push({name,start:r.querySelector('[data-f="start"]').value.trim(),end:r.querySelector('[data-f="end"]').value.trim(),source:'location_map'})});document.querySelectorAll('#hintRows .rowgrid').forEach(r=>{const pattern=r.querySelector('[data-f="pattern"]').value.trim(),location=r.querySelector('[data-f="location"]').value.trim();if(pattern&&location)cfg.path_hints.push({pattern,location})});alert(JSON.stringify(await api('/api/locations/config',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({config:cfg,rederive})}),null,2));await refreshAll()}
function renderGraph(){let h='<table><tr><th>A</th><th>B</th><th>Date</th><th>Location</th><th>Flags</th><th>Conf.</th></tr>';for(const e of state.associations)h+=`<tr><td>${esc(e.poi_a_label)}</td><td>${esc(e.poi_b_label)}</td><td>${fmt(e.sighting_date)}</td><td>${esc(e.location)}</td><td>${esc(e.flags)}</td><td>${e.confidence}</td></tr>`;document.getElementById('view').innerHTML=h+'</table>'}
function renderPlates(){let h='<div class="card"><h2>Number plates</h2><input id="plateText" placeholder="plate text"><br><br><button onclick="addPlate()">Add manual plate</button></div><table><tr><th>Plate</th><th>Conf</th><th>Method</th><th>Status</th><th>Media</th><th>Location</th></tr>';for(const p of state.plates)h+=`<tr><td>${esc(p.plate_text)}</td><td>${p.confidence}</td><td>${esc(p.method)}</td><td>${esc(p.status)}</td><td>${esc(p.rel_path||'')}</td><td>${esc(p.location||'')}</td></tr>`;document.getElementById('view').innerHTML=h+'</table>'}async function addPlate(){const t=document.getElementById('plateText').value.trim();if(!t)return;await api('/api/plates',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({plate_text:t,method:'manual',status:'candidate'})});await refreshAll()}

async function scanSelectedFaces(){
  if(!state.selectedMedia.size)return alert('Select images to queue for face detection first.');
  const threshold=parseFloat(prompt('Face cluster similarity threshold. Higher = stricter. Suggested 0.82','0.82')||'0.82');
  try{
    const r=await api('/api/faces/scan',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({media_ids:[...state.selectedMedia],threshold})});
    alert('Face detection queued as job #'+r.job_id+' for '+r.media_count+' media files. You can keep using the UI while the worker processes it.');
    await refreshAll();setView('faces');
  }catch(e){alert('Face queue failed: '+e.message)}
}
function facePoiValue(clusterId){
  const sel=document.getElementById('facePoiSelect_'+clusterId);
  const custom=document.getElementById('facePoiCustom_'+clusterId);
  const customVal=(custom&&custom.value||'').trim();
  if(customVal)return customVal;
  return sel ? (sel.value||'').trim() : '';
}
async function linkFaceCluster(clusterId, seedLabel){
  let label=facePoiValue(clusterId);
  if(!label){
    label=prompt('No POI selected. Enter a new POI label for this internal face cluster:', seedLabel||('POI-FACE-'+clusterId));
  }
  label=(label||'').trim();
  if(!label){alert('Select an existing POI or type a new POI label first.');return;}
  try{
    const r=await api('/api/faces/clusters/'+clusterId+'/link-poi',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({poi_label:label})});
    alert('Linked '+label+'; sightings touched: '+r.sightings_touched);
    await refreshAll();setView('faces');
  }catch(e){alert('Link failed: '+e.message)}
}
function facePoiControls(clusterId, currentLabel, seedLabel){
  const pois=(state.pois||[]).filter(p=>p.poi_label && p.poi_label!=='UNASSIGNED');
  let opts='<option value="">-- select existing POI --</option>';
  for(const p of pois){
    const lab=String(p.poi_label||'');
    opts+=`<option value="${esc(lab)}" ${lab===currentLabel?'selected':''}>${esc(lab)} (${p.sightings||0})</option>`;
  }
  const placeholder=seedLabel||('POI-FACE-'+clusterId);
  return `<div class="poi-linker"><select id="facePoiSelect_${clusterId}">${opts}</select><input id="facePoiCustom_${clusterId}" placeholder="new POI label, e.g. ${esc(placeholder)}"><button class="primary" onclick="linkFaceCluster(${clusterId},${jsq(placeholder)})">Link</button></div>`;
}
function renderFaces(){
  let h='<div class="card"><h2>Face clusters</h2><p class="small">Face detection is queued. The UI submits a job, the background worker processes images one by one, and observations appear here when complete. This is internal grouping only; it does not identify real people by name.</p><button class="warn" onclick="scanSelectedFaces()">Queue selected media for face detection</button> <button onclick="refreshAll()">Refresh queue</button></div>';
  h+='<h3>Face detection queue</h3><table><tr><th>Job</th><th>Status</th><th>Media</th><th>Scanned</th><th>Faces</th><th>Clusters</th><th>Error</th><th>Created</th><th>Finished</th></tr>';
  for(const j of (state.faces.jobs||[])){
    let mediaCount=0;try{mediaCount=JSON.parse(j.media_ids_json||'[]').length}catch(e){}
    h+=`<tr><td>#${j.id}</td><td>${esc(j.status)}</td><td>${mediaCount}</td><td>${j.scanned_images||0}</td><td>${j.detected_faces||0}</td><td>${j.created_clusters||0}</td><td>${esc(j.error||'')}</td><td>${fmt(j.created_at)}</td><td>${fmt(j.finished_at)}</td></tr>`
  }
  h+='</table>';
  h+='<h3>Internal clusters</h3><table><tr><th>Cluster</th><th>Linked POI</th><th>Faces</th><th>Media</th><th>First</th><th>Last</th><th>Locations</th><th>Action</th></tr>';
  for(const c of (state.faces.clusters||[])){
    h+=`<tr><td>${esc(c.cluster_label)}</td><td>${esc(c.poi_label||'')}</td><td>${c.observations||0}</td><td>${c.media_count||0}</td><td>${fmt(c.first_seen)}</td><td>${fmt(c.last_seen)}</td><td>${esc(c.locations||'')}</td><td>${facePoiControls(c.id,c.poi_label||'',c.cluster_label)}</td></tr>`
  }
  h+='</table><h3>Recent face observations</h3><div class="media-grid">';
  for(const f of (state.faces.faces||[])){
    h+=`<div class="media"><img src="/api/faces/${f.id}/crop" loading="lazy"><div class="body"><b>#${f.id} ${esc(f.cluster_label||'FACE')}</b><br><span class="badge">media #${f.media_id}</span><span class="badge">${esc(f.location||'Unknown')}</span><span class="badge">${esc(f.derived_date||'no date')}</span><br><span class="small">${esc(f.rel_path||'')}</span><br><span class="small">status=${esc(f.review_status)} conf=${Number(f.confidence||0).toFixed(3)}</span></div></div>`
  }
  h+='</div>';
  document.getElementById('view').innerHTML=h;
}


function selectedOneMedia(){const a=[...state.selectedMedia];if(a.length!==1){alert('Select exactly one image/media file for this AI agent step.');return null}return a[0]}
function aiMsg(msg,bad=false){const el=document.getElementById('aiActionStatus');if(el){el.className='card mono '+(bad?'bad':'');el.textContent=msg}else{console.log(msg)}}
async function aiGeolocateSelected(){
  const id=selectedOneMedia();if(!id)return;
  setView('ai_geo');
  document.getElementById('view').innerHTML='<div class="card"><h2>AI geolocation agent</h2><pre id="aiActionStatus" class="card mono">Running AI geolocation on media #'+id+' ...</pre></div>';
  try{
    const r=await api('/api/ai/geolocate',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({media_id:id})});
    if(r.ok===false){aiMsg('AI geolocation failed but was recorded as job #'+r.job_id+'\n\n'+r.error+'\n\nHint: '+(r.hint||''),true)}
    else{aiMsg('AI geolocation completed. Refreshing candidate table...\n\n'+JSON.stringify(r,null,2))}
  }catch(e){aiMsg('AI geolocation request failed: '+e.message,true)}
  await refreshAll();setView('ai_geo')
}
async function confirmGeo(jobId,mediaId,loc,conf){
  const notes='AI geolocation confirmed by analyst from UI';
  aiMsg('Confirming media #'+mediaId+' as '+loc+' ...');
  try{
    const r=await api('/api/ai/geolocate/confirm',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({job_id:jobId,media_id:mediaId,location:loc,confidence:Number(conf||0),notes,add_to_catalog:true})});
    await refreshAll();setView('ai_geo');aiMsg('CONFIRMED\n'+JSON.stringify(r,null,2));
  }catch(e){aiMsg('Confirm failed: '+e.message,true)}
}
async function confirmCustomGeo(jobId,mediaId,seedLoc=''){
  const cfg=state.locConfig||{};
  const suggestion=seedLoc&&seedLoc!=='Unknown'?seedLoc:((cfg.location_catalog||[])[0]||'World - EU - Romania - Bucharest - Gara de Nord');
  const loc=prompt('Confirmed hierarchical location path', suggestion);if(!loc)return;
  const conf=parseFloat(prompt('Confirmation confidence 0.0 to 1.0','0.95')||'0.95');
  const notes='Manual/custom geolocation confirmation from UI';
  aiMsg('Confirming custom location for media #'+mediaId+' ...');
  try{
    const r=await api('/api/ai/geolocate/confirm',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({job_id:jobId,media_id:mediaId,location:loc,confidence:conf,notes,add_to_catalog:true})});
    await refreshAll();setView('ai_geo');aiMsg('CUSTOM LOCATION CONFIRMED\n'+JSON.stringify(r,null,2));
  }catch(e){aiMsg('Confirm custom failed: '+e.message,true)}
}
async function proposeGeoWindow(mediaId,loc){
  const hb=parseFloat((document.getElementById('geoHoursBefore')||{}).value||'3');
  const ha=parseFloat((document.getElementById('geoHoursAfter')||{}).value||'3');
  const lim=parseInt((document.getElementById('geoSampleLimit')||{}).value||'12');
  aiMsg('Building downgraded contact sheet and asking AI for time window...\nmedia #'+mediaId+'\nlocation: '+loc+'\nwindow: -'+hb+'h +'+ha+'h, samples '+lim);
  try{
    const r=await api('/api/ai/geolocate/window',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({anchor_media_id:mediaId,location:loc,hours_before:hb,hours_after:ha,sample_limit:lim})});
    await refreshAll();setView('ai_geo');aiMsg('WINDOW PROPOSAL RESULT\n'+JSON.stringify(r,null,2));
  }catch(e){aiMsg('AI window proposal failed: '+e.message,true)}
}
async function applyGeoWindow(winId){
  if(!confirm('Apply this AI proposed window into poi_location_map.yaml and rederive media locations?'))return;
  aiMsg('Applying proposed window #'+winId+' into YAML and rederiving media locations...');
  try{
    const r=await api('/api/ai/geolocate/window/apply',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({window_id:winId})});
    await refreshAll();setView('ai_geo');aiMsg('WINDOW APPLIED\n'+JSON.stringify(r,null,2));
  }catch(e){aiMsg('Apply window failed: '+e.message,true)}
}
async function aiProviderSelfTest(){try{aiMsg('Testing active AI provider...');const r=await api('/api/ai/selftest');aiMsg('AI SELF-TEST\n'+JSON.stringify(r,null,2));await refreshAll();setView('ai_geo')}catch(e){aiMsg('AI provider self-test failed: '+e.message,true)}}
function renderAIGeo(){
  let h='<div class="card"><h2>AI geolocation agent</h2><p class="small">Workflow: select exactly one image in Media → AI geolocate selected → confirm one candidate → ask AI to test downgraded images around the timestamp → apply confirmed time window into the YAML location map.</p>';
  h+=`<p class="small">AI enabled: ${state.status.ai&&state.status.ai.enabled?'yes':'no'} | provider: ${esc(state.status.ai?state.status.ai.provider:'')} | model: ${esc(state.status.ai?state.status.ai.model:'')} | vision: ${state.status.ai&&state.status.ai.vision_enabled?'yes':'no'}</p>`;
  h+='<div class="rowgrid4"><div><label class="small">Hours before</label><input id="geoHoursBefore" value="3"></div><div><label class="small">Hours after</label><input id="geoHoursAfter" value="3"></div><div><label class="small">Sample limit</label><input id="geoSampleLimit" value="12"></div><div style="padding-top:19px"><button onclick="aiProviderSelfTest()">Self-test</button></div></div>';
  h+='<button class="primary" onclick="aiGeolocateSelected()">Run on selected media</button><pre id="aiActionStatus" class="card mono">Ready. Select one image in Media, then run geolocation. Confirm and time-window actions will report here.</pre></div>';
  h+='<h3>Candidate geolocations</h3><table><tr><th>Job</th><th>Media</th><th>Candidate location</th><th>Conf.</th><th>Rationale</th><th>Action</th></tr>';
  for(const c of state.aiGeo.candidates||[]){
    h+=`<tr><td>#${c.job_id}</td><td>#${c.media_id}</td><td>${esc(c.location)}</td><td>${c.confidence}</td><td>${esc(c.rationale)}<br><span class="small">${esc(c.visible_cues||'')}</span></td><td><button class="primary" onclick="confirmGeo(${c.job_id},${c.media_id},${jsq(c.location)},${Number(c.confidence||0)})">Confirm</button> <button onclick="confirmCustomGeo(${c.job_id},${c.media_id},${jsq(c.location)})">Confirm custom</button> <button class="warn" onclick="proposeGeoWindow(${c.media_id},${jsq(c.location)})">Find time window</button></td></tr>`
  }
  h+='</table><h3>Proposed geolocation windows</h3><table><tr><th>ID</th><th>Anchor</th><th>Location</th><th>Start</th><th>End</th><th>Conf.</th><th>Status</th><th>Action</th></tr>';
  for(const w of state.aiGeo.windows||[]){h+=`<tr><td>#${w.id}</td><td>#${w.anchor_media_id}</td><td>${esc(w.location)}</td><td>${fmt(w.start_ts)}</td><td>${fmt(w.end_ts)}</td><td>${w.confidence}</td><td>${esc(w.status)}</td><td>${w.status==='proposed'?`<button class="warn" onclick="applyGeoWindow(${w.id})">Apply to YAML</button>`:''}</td></tr>`}
  h+='</table><h3>Recent jobs</h3><table><tr><th>ID</th><th>Media</th><th>Status</th><th>Error</th></tr>';
  for(const j of state.aiGeo.jobs||[]){h+=`<tr><td>#${j.id}</td><td>#${j.media_id} ${esc(j.rel_path||'')}</td><td>${esc(j.status)}</td><td>${esc(j.error||'')}</td></tr>`}
  document.getElementById('view').innerHTML=h+'</table>'
}

async function scan(){const roots=prompt('Optional roots, colon separated. Leave blank for POI_MEDIA_ROOTS.','');const body=roots?{roots:roots.split(':').map(s=>s.trim()).filter(Boolean)}:{};alert(JSON.stringify(await api('/api/scan',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)}),null,2));await refreshAll()}async function bootstrap(){alert(JSON.stringify(await api('/api/bootstrap-sightings',{method:'POST'}),null,2));await refreshAll()}async function rebuild(){alert(JSON.stringify(await api('/api/rebuild-associations',{method:'POST'}),null,2));await refreshAll()}async function triage(){alert(JSON.stringify(await api('/api/ai/triage',{method:'POST'}),null,2));await refreshAll()}async function createPoi(){const label=document.getElementById('newPoiLabel').value.trim();if(!label)return alert('Enter POI label');await api('/api/pois',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({label,sighting_ids:[...state.selectedSightings],confidence:0.55})});state.selectedSightings.clear();document.getElementById('newPoiLabel').value='';await refreshAll()}function filterPoi(id){setView('sightings');renderSightings(state.sightings.filter(s=>s.poi_id===id))}
refreshAll().catch(e=>{document.getElementById('status').textContent=e.message;console.error(e)});
</script></body></html>
'''

def main() -> None:
    init_db()
    reset_stale_face_jobs()
    start_face_scan_worker()
    ssl_kwargs: Dict[str, Any] = {}
    if Path(SSL_KEYFILE).exists() and Path(SSL_CERTFILE).exists():
        ssl_kwargs = {"ssl_keyfile": SSL_KEYFILE, "ssl_certfile": SSL_CERTFILE}
        print(f"[poi-shuttle] SSL enabled with {SSL_CERTFILE} / {SSL_KEYFILE}")
    else:
        print("[poi-shuttle] SSL key/cert not found; running HTTP")
    print(f"[poi-shuttle] build {BUILD}")
    print(f"[poi-shuttle] media roots: {MEDIA_ROOTS}")
    print(f"[poi-shuttle] location map: {LOCATION_MAP_PATH} exists={LOCATION_MAP_PATH.exists()}")
    uvicorn.run(app, host=HOST, port=PORT, **ssl_kwargs)

if __name__ == "__main__":
    main()
