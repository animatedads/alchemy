import soundfile as sf
import numpy as np
from scipy.signal import butter, lfilter, iirnotch
from datetime import datetime

def butter_lowpass(cutoff, fs, order=5):
    nyq = 0.5 * fs
    normal_cutoff = cutoff / nyq
    b, a = butter(order, normal_cutoff, btype='low', analog=False)
    return b, a

def butter_highpass(cutoff, fs, order=5):
    nyq = 0.5 * fs
    normal_cutoff = cutoff / nyq
    b, a = butter(order, normal_cutoff, btype='high', analog=False)
    return b, a

def apply_filter(data, b, a):
    return lfilter(b, a, data)

def stream_aligned(path, file_start, trial_start, trial_end, sr=22050, block_sec=10.0):
    import soundfile as sf
    import numpy as np
    from datetime import datetime
    fmt = "%Y-%m-%d %H:%M:%S"
    f_st = datetime.strptime(file_start, fmt)
    t_st = datetime.strptime(trial_start, fmt)
    t_en = datetime.strptime(trial_end, fmt)

    trial_dur = (t_en - t_st).total_seconds()
    delta = (f_st - t_st).total_seconds()

    total_samples = int(trial_dur * sr)
    block_samples = int(block_sec * sr)

    pad_front = int(max(0, delta) * sr)
    offset_frames = int(max(0, -delta) * sr)

    try:
        f = sf.SoundFile(path)
        f.seek(offset_frames)
    except:
        f = None

    samples_yielded = 0
    while samples_yielded < total_samples:
        chunk_size = min(block_samples, total_samples - samples_yielded)
        block = np.zeros(chunk_size, dtype=np.float32)

        write_start = 0
        if samples_yielded < pad_front:
            pad_amt = min(chunk_size, pad_front - samples_yielded)
            write_start += pad_amt

        if write_start < chunk_size and f is not None:
            read_amt = chunk_size - write_start
            try:
                data = f.read(read_amt, dtype='float32', fill_value=0.0)
                if data.ndim > 1: data = data.mean(axis=1)
                block[write_start:write_start+len(data)] = data
            except:
                pass

        yield block
        samples_yielded += chunk_size

    if f: f.close()

# Define trial window
trial_start = "2023-10-10 04:01:01"
trial_end = "2023-10-10 04:11:01"
sr = 22050

# Create generators for each stream
gen_a6 = stream_aligned('fcpaphos/enhanced_20231010_041038_tp00014_plus20.ogg', '2023-10-10 04:10:38', trial_start, trial_end, sr)
gen_b8 = stream_aligned('fcpaphos/enhanced_20231010_033544_tp00003_plus20.ogg', '2023-10-10 03:35:44', trial_start, trial_end, sr)

# Filter coefficients for Stream 6 (Cam A)
b_lp6, a_lp6 = butter_lowpass(4000, sr)
b_hp6, a_hp6 = butter_highpass(20, sr)
b_notch1000, a_notch1000 = iirnotch(1000, 30, sr)
b_notch2000, a_notch2000 = iirnotch(2000, 30, sr)

# Filter coefficients for Stream 8 (Cam B)
b_lp8, a_lp8 = butter_lowpass(8000, sr)
b_hp8, a_hp8 = butter_highpass(20, sr)

# Open output file
with sf.SoundFile('trial_mix_plus20_20231010_040101_to_041101.ogg', 'w', samplerate=sr, channels=2) as out_f:
    for block_a, block_b in zip(gen_a6, gen_b8):
        # Apply filters to Cam A (Stream 6)
        block_a = apply_filter(block_a, b_lp6, a_lp6)
        block_a = apply_filter(block_a, b_hp6, a_hp6)
        block_a = apply_filter(block_a, b_notch1000, a_notch1000)
        block_a = apply_filter(block_a, b_notch2000, a_notch2000)

        # Apply filters to Cam B (Stream 8)
        block_b = apply_filter(block_b, b_lp8, a_lp8)
        block_b = apply_filter(block_b, b_hp8, a_hp8)

        # Create stereo block
        stereo_block = np.zeros((len(block_a), 2), dtype=np.float32)
        stereo_block[:, 0] = block_a  # Left channel (Cam A)
        stereo_block[:, 1] = block_b  # Right channel (Cam B)

        # Normalize the stereo block
        max_val = np.max(np.abs(stereo_block))
        if max_val > 0:
            stereo_block /= max_val

        # Write to output file
        out_f.write(stereo_block)