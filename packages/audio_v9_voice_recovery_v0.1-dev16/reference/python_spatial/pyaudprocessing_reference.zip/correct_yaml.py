#!/usr/bin/env python3
"""
correct_yaml.py
================================================================================
Forensic Camera Alignment Correction Script
================================================================================
Concurrently probes raw MP4 footage files from Front Camera (fc) and Front Door (fd)
directories, extracts physical hardware fingerprints via FFmpeg/ffprobe, and uses
these characteristics to verify and correct misaligned camera tags inside your YAML.

Features:
  - Concurrent ffprobe calls for fast bulk database processing.
  - Multi-layered classification architecture (hardware signature, folder, heuristics).
  - Preserves processing labels (Original, Enhanced, Amp levels) while swapping Cam tags.
  - Supports --dry-run to audit modifications before writing to YAML.
"""

import os
import re
import sys
import json
import yaml
import argparse
import subprocess
import concurrent.futures
from collections import Counter

# Standard forensic suffixes and prefixes to clean filenames down to core IDs
FORENSIC_PREFIXES = ["enhanced_"]
FORENSIC_SUFFIXES = [
    "_original.ogg",
    "_amp32.ogg",
    "_plus20.ogg",
    "_ampamp.ogg",
    ".ogg",
    ".mp4"
]

def extract_core_identifier(filename):
    """Strips all forensic prepended or appended tags to find the raw root name."""
    core = filename
    for prefix in FORENSIC_PREFIXES:
        if core.lower().startswith(prefix.lower()):
            core = core[len(prefix):]

    # Repeatedly strip suffixes to handle multiple layers (e.g. .mp4.ogg)
    changed = True
    while changed:
        changed = False
        for suffix in FORENSIC_SUFFIXES:
            if core.lower().endswith(suffix.lower()):
                core = core[:-len(suffix)]
                changed = True
    return core

def get_hardware_signature(filepath):
    """Runs ffprobe on a file and extracts key stream parameters as a signature."""
    try:
        cmd = [
            'ffprobe', '-v', 'quiet',
            '-show_format', '-show_streams',
            '-of', 'json', filepath
        ]
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=5)
        if result.returncode != 0:
            return None

        data = json.loads(result.stdout)
        fmt = data.get('format', {})
        fmt_tags = fmt.get('tags', {})

        sig = {
            "format_name": fmt.get("format_name"),
            "major_brand": fmt_tags.get("major_brand") or fmt_tags.get("encoder"),
            "streams": []
        }

        for stream in data.get('streams', []):
            st_type = stream.get('codec_type')
            st_sig = {
                "type": st_type,
                "codec": stream.get("codec_name"),
                "handler": stream.get("tags", {}).get("handler_name")
            }
            if st_type == 'video':
                st_sig["resolution"] = f"{stream.get('width')}x{stream.get('height')}"
                st_sig["fps"] = stream.get("r_frame_rate")
            elif st_type == 'audio':
                st_sig["sample_rate"] = stream.get("sample_rate")
                st_sig["channels"] = stream.get("channels")
            sig["streams"].append(st_sig)
        return sig
    except Exception:
        return None

def serialize_signature(sig):
    """Serializes a physical signature dict into a standardized string comparison key."""
    if not sig: return "Unknown / Unreadable"
    parts = []
    if sig.get("format_name"):
        parts.append(f"Format: {sig['format_name'].upper()}")
    if sig.get("major_brand"):
        parts.append(f"Brand: {sig['major_brand']}")

    for idx, s in enumerate(sig.get("streams", [])):
        t = s.get("type", "unknown").upper()
        codec = s.get("codec", "unknown")
        handler = s.get("handler")
        handler_str = f" ({handler})" if handler else ""

        if t == "VIDEO":
            res = s.get("resolution", "Unknown")
            fps = s.get("fps", "Unknown")
            parts.append(f"Stream {idx} [Video: {codec} | {res} | {fps}fps{handler_str}]")
        elif t == "AUDIO":
            sr = s.get("sample_rate", "Unknown")
            ch = s.get("channels", "Unknown")
            parts.append(f"Stream {idx} [Audio: {codec} | {sr}Hz | {ch}ch{handler_str}]")
    return " | ".join(parts)

def scan_raw_folder_worker(file_path, folder_cam):
    """Worker task to probe a single file."""
    sig = get_hardware_signature(file_path)
    return {
        "path": file_path,
        "filename": os.path.basename(file_path),
        "basename": os.path.splitext(os.path.basename(file_path))[0],
        "folder_cam": folder_cam,
        "signature_raw": sig,
        "signature_str": serialize_signature(sig)
    }

def scan_raw_folders(fc_dir, fd_dir, workers=16):
    """Scans and probes raw folders concurrently."""
    print(f"[*] Scanning physical directories (fc: '{fc_dir}', fd: '{fd_dir}')...")
    targets = []

    # Index mvl/fc (Cam A)
    if os.path.exists(fc_dir):
        for root, _, files in os.walk(fc_dir):
            for f in files:
                if f.lower().endswith(".mp4"):
                    targets.append((os.path.join(root, f), "Cam A"))

    # Index mvl/fd (Cam B)
    if os.path.exists(fd_dir):
        for root, _, files in os.walk(fd_dir):
            for f in files:
                if f.lower().endswith(".mp4"):
                    targets.append((os.path.join(root, f), "Cam B"))

    if not targets:
        print("[!] Warning: No raw .mp4 files found in the provided directories!")
        return []

    print(f"[*] Probing physical attributes of {len(targets)} files using {workers} concurrent workers...")
    raw_files_metadata = []

    with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as executor:
        futures = {executor.submit(scan_raw_folder_worker, path, cam): path for path, cam in targets}
        for idx, future in enumerate(concurrent.futures.as_completed(futures)):
            res = future.result()
            raw_files_metadata.append(res)
            # Print elegant inline progress
            sys.stdout.write(f"  Probed {idx+1}/{len(targets)} raw files...\r")
            sys.stdout.flush()
    print("\n[*] Probing completed.")
    return raw_files_metadata

def correct_type_label(current_type, correct_cam):
    """Corrects the camera label prefix in the YAML entry type while preserving tier details."""
    if not current_type:
        return f"{correct_cam} (Original)"

    current_low = current_type.lower()
    current_cam_parsed = "Cam A" if "cam a" in current_low or "cama" in current_low else "Cam B" if "cam b" in current_low or "camb" in current_low else None

    if current_cam_parsed == correct_cam:
        return current_type # Assignment matches

    if current_cam_parsed == "Cam A":
        return re.sub(r'(?i)cam\s*a', correct_cam, current_type)
    elif current_cam_parsed == "Cam B":
        return re.sub(r'(?i)cam\s*b', correct_cam, current_type)
    else:
        # If there's no camera label, prepend the correct one
        return f"{correct_cam} ({current_type})"

def main():
    parser = argparse.ArgumentParser(description="Forensic YAML Camera Alignment Fixer")
    parser.add_argument("--yaml", required=True, help="Path to project YAML to correct")
    parser.add_argument("--fc", default="mvl/fc", help="Path to raw Cam A (Front Camera) directory")
    parser.add_argument("--fd", default="mvl/fd", help="Path to raw Cam B (Front Door/Secondary) directory")
    parser.add_argument("--dry-run", action="store_true", help="Audit anomalies and show changes without saving")
    parser.add_argument("--workers", type=int, default=16, help="Number of concurrent probing workers")
    args = parser.parse_args()

    if not os.path.exists(args.yaml):
        print(f"Error: YAML project configuration '{args.yaml}' not found.")
        sys.exit(1)

    # 1. Probe all raw files concurrently
    raw_metadata = scan_raw_folders(args.fc, args.fd, workers=args.workers)

    # 2. Establish physical hardware baselines using majority rules
    fc_sigs = [f['signature_str'] for f in raw_metadata if f['folder_cam'] == 'Cam A' and f['signature_raw']]
    fd_sigs = [f['signature_str'] for f in raw_metadata if f['folder_cam'] == 'Cam B' and f['signature_raw']]

    dom_fc = Counter(fc_sigs).most_common(1)[0][0] if fc_sigs else "No signatures collected"
    dom_fd = Counter(fd_sigs).most_common(1)[0][0] if fd_sigs else "No signatures collected"

    print("\n=== Established Physical Camera Signatures ===")
    print(f"Cam A Dominant (mvl/fc):")
    print(f"  --> {dom_fc}")
    print(f"Cam B Dominant (mvl/fd):")
    print(f"  --> {dom_fd}")
    print("-" * 110)

    # 3. Process the YAML file
    with open(args.yaml, 'r') as f:
        config = yaml.safe_load(f) or {}

    entries = config.get('files', [])
    if not entries:
        print("[!] No entries found in the YAML project configuration.")
        sys.exit(0)

    print(f"\n[*] Auditing {len(entries)} file entries against raw metadata...")
    corrections_made = 0
    missing_sources = 0
    perfect_matches = 0

    # Index raw_metadata for faster substring matching
    for idx, entry in enumerate(entries):
        path = entry.get('path', '')
        current_type = entry.get('type', '')

        if not path:
            continue

        filename = os.path.basename(path)
        core_id = extract_core_identifier(filename)

        # Determine current camera classification in YAML
        yaml_cam_label = "Cam B" if "cam b" in current_type.lower() else "Cam A"

        # Find matching raw physical source
        matched_raw = None
        for r in raw_metadata:
            # Match exact core_id, substring in basename, or reverse substring
            if r['basename'] == core_id or core_id in r['basename'] or r['basename'] in core_id:
                matched_raw = r
                break

        correct_cam = None
        match_type_desc = ""

        if matched_raw:
            sig = matched_raw['signature_str']
            # Determine camera assignment by checking physical signature or folder membership
            if sig == dom_fc:
                correct_cam = "Cam A"
                match_type_desc = "Physical Signature (Cam A Match)"
            elif sig == dom_fd:
                correct_cam = "Cam B"
                match_type_desc = "Physical Signature (Cam B Match)"
            else:
                # Fallback to physical location (directory found)
                correct_cam = matched_raw['folder_cam']
                match_type_desc = f"Folder Membership (Found in {correct_cam})"
        else:
            # Absolute fallback if raw MP4 is offline: check default heuristics on filename
            fallback_cam = "Cam B" if 'tp00024' in filename.lower() or '(1)' in filename.lower() else "Cam A"
            correct_cam = fallback_cam
            match_type_desc = "Heuristic Fallback (Offline Source)"
            missing_sources += 1

        # Check for camera assignment mismatch
        if yaml_cam_label != correct_cam:
            new_type = correct_type_label(current_type, correct_cam)
            print(f"\n [CORRECTION ALERT] Mismatch detected for file: {filename}")
            print(f"   Current Labeled Type : '{current_type}'")
            print(f"   Correct Camera Type  : '{new_type}'")
            print(f"   Audit Validation     : {match_type_desc}")
            if matched_raw:
                print(f"   Matched Raw File     : {matched_raw['folder_cam']}/{matched_raw['filename']}")

            entry['type'] = new_type
            corrections_made += 1
        else:
            perfect_matches += 1

    print("\n" + "=" * 110)
    print("=== Alignment Correction Summary ===")
    print(f" Total Checked Entries : {len(entries)}")
    print(f" Unchanged / Correct   : {perfect_matches}")
    print(f" Corrected Entries     : {corrections_made}")
    print(f" Offline / Unresolved  : {missing_sources}")
    print("-" * 110)

    if corrections_made > 0:
        if args.dry_run:
            print("\n[DRY RUN] Corrected configuration not saved. Run without --dry-run to commit changes.")
        else:
            with open(args.yaml, 'w') as f:
                yaml.dump(config, f, default_flow_style=False, sort_keys=False)
            print(f"\n[SUCCESS] Successfully corrected {corrections_made} alignment errors inside {args.yaml}!")
    else:
        print("\n[OK] No misalignments found. All physical properties align perfectly with your YAML project configurations.")

if __name__ == "__main__":
    main()
