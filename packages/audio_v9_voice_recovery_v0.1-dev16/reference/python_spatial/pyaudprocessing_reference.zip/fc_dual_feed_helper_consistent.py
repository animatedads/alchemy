#!/usr/bin/env python3
"""
fc_dual_feed_helper_consistent.py
=================================
Helper-consistent compatibility edition of fc_dual_feed.py.

Purpose:
- Keep the original FC DSP chain intact: adaptive denoise, GCC-PHAT,
  phase-coherence Wiener, MVDR, CLEAN, and persistence gate.
- Replace the project-specific clip lists, estimated end-times, and direct YAML
  type matching with forensic_helper.py stream discovery and block loading.
- Preserve the original --mode behaviour while also accepting --tier.
"""

import os
import argparse
import yaml
import numpy as np
import soundfile as sf
import librosa
from datetime import datetime, timedelta
from scipy.signal import get_window
from scipy.ndimage import uniform_filter1d

from forensic_helper import ForensicHelper as fh

# ---------------------------------------------------------------------------
# DSP CONSTANTS
# ---------------------------------------------------------------------------
SR         = 22050
N_FFT      = 2048
HOP_LEN    = N_FFT // 4      # 512 samples
BLOCK_SEC  = 8
HOP_SEC    = BLOCK_SEC * 0.5
BLOCK_SAMP = int(BLOCK_SEC * SR)
HOP_SAMP   = int(HOP_SEC  * SR)
PERSIST_N  = 3
CLEAN_ITER = 5
CLEAN_GAIN = 0.12
MAX_LAG_SEC= 0.20            # 200 ms — generous for long-form clips with drift
NOISE_PCT  = 8

# ---------------------------------------------------------------------------
# FILE-TYPE SELECTORS per mode
# ---------------------------------------------------------------------------
# Maps --mode to the YAML type strings used for each camera
MODE_TYPES = {
    "plus20": {
        "cam_a": "Enhanced Amp +20dB (Ogg Q10)",
        "cam_b": "FD Feed (Enhanced +20dB)",
        "label": "Enhanced+20dB vs FD+20dB",
    },
    "amp32": {
        "cam_a": "Raw Amp +32dB (Ogg Q10)",
        "cam_b": "FD Feed (Raw Amp +32dB)",
        "label": "Raw+32dB vs FD+32dB",
    },
}

# ---------------------------------------------------------------------------
# YAML LOADER — builds two sorted clip lists from the project file
# ---------------------------------------------------------------------------

def load_project(yaml_path, mode):
    with open(yaml_path) as f:
        data = yaml.safe_load(f)

    type_a = MODE_TYPES[mode]["cam_a"]
    type_b = MODE_TYPES[mode]["cam_b"]

    clips_a = []
    clips_b = []

    for entry in data["files"]:
        t    = entry.get("type", "")
        path = entry["path"]
        start_str = entry["start"]
        try:
            start_dt = datetime.strptime(start_str, "%Y-%m-%d %H:%M:%S")
        except ValueError:
            continue

        if t == type_a:
            clips_a.append({"path": path, "start": start_dt})
        elif t == type_b:
            clips_b.append({"path": path, "start": start_dt})

    clips_a.sort(key=lambda x: x["start"])
    clips_b.sort(key=lambda x: x["start"])

    print(f"  Camera A clips ({type_a}): {len(clips_a)}")
    print(f"  Camera B clips ({type_b}): {len(clips_b)}")

    return clips_a, clips_b


def build_index(clips):
    """Return list of (start_dt, end_dt, path).
    End is estimated from the next clip's start (or +2h for the final clip)."""
    index = []
    for i, clip in enumerate(clips):
        start = clip["start"]
        if i + 1 < len(clips):
            # Use next clip start as end — accurate for both ~32min and ~100min clips
            end = clips[i + 1]["start"]
        else:
            end = start + timedelta(hours=2, minutes=30)  # safe tail for last clip
        index.append((start, end, clip["path"]))
    return index


# ---------------------------------------------------------------------------
# STREAMING BLOCK LOADER
# ---------------------------------------------------------------------------

def load_block(path, file_start, target_dt, duration_sec):
    """Stream-load `duration_sec` from `path` at the position corresponding
    to `target_dt`. Returns None on any failure (missing file, EOF, etc.)."""
    if not path or not os.path.exists(path):
        return None
    offset = max(0.0, (target_dt - file_start).total_seconds())
    try:
        y, _ = librosa.load(path, sr=SR, offset=offset,
                            duration=duration_sec, mono=True)
        return y if len(y) > 64 else None
    except Exception:
        return None


def find_clip(index, t):
    """Return (file_start, path) for the clip whose window contains t."""
    for (start, end, path) in index:
        if start <= t < end:
            return start, path
    return None, None


def pad_or_trim(y, n):
    if len(y) >= n:
        return y[:n].copy()
    return np.pad(y, (0, n - len(y)))


def safe(y):
    return np.nan_to_num(y, nan=0.0, posinf=0.0, neginf=0.0)


# ---------------------------------------------------------------------------
# ADAPTIVE SPECTRAL FLOOR
# ---------------------------------------------------------------------------

def adaptive_denoise(y):
    """Per-block noise floor from lowest-energy STFT frames → gentle
    spectral subtraction.  Tracks actual noise character of each block
    rather than cutting a fixed frequency shelf."""
    y = safe(y)
    S = librosa.stft(y, n_fft=N_FFT, hop_length=HOP_LEN)
    mag, phase = librosa.magphase(S)
    rms = librosa.feature.rms(S=mag)[0]
    thresh = np.percentile(rms, NOISE_PCT)
    idx = np.where(rms <= thresh)[0]
    floor = (mag[:, idx].mean(axis=1, keepdims=True) if len(idx)
             else np.median(mag, axis=1, keepdims=True) * 0.25)
    mag_clean = np.maximum(mag - floor * 1.2, mag * 0.08)
    return safe(librosa.istft(mag_clean * phase, hop_length=HOP_LEN, length=len(y)))


# ---------------------------------------------------------------------------
# TECHNIQUE 1 — GCC-PHAT ALIGNMENT  (radar TDOA)
# ---------------------------------------------------------------------------

def gcc_phat_align(y_a, y_b):
    """GCC-PHAT: frequency-domain phase-transform TDOA.
    Whitens the cross-spectrum so only inter-channel phase drives the lag
    estimate.  Particularly important for amp32 mode where no prior sync
    has been applied and the two cameras may have drifted."""
    max_lag = int(MAX_LAG_SEC * SR)
    n = len(y_a)
    nfft = 1 << int(np.ceil(np.log2(2 * n - 1)))
    Fa = np.fft.rfft(safe(y_a), n=nfft)
    Fb = np.fft.rfft(safe(y_b), n=nfft)
    cross = Fa * np.conj(Fb)
    gcc   = np.fft.irfft(cross / (np.abs(cross) + 1e-10), n=nfft)
    search = np.concatenate([gcc[-max_lag:], gcc[:max_lag + 1]])
    lag    = int(np.argmax(search)) - max_lag
    if lag > 0:
        aligned = np.concatenate([np.zeros(lag), y_b])[:n]
    elif lag < 0:
        aligned = np.concatenate([y_b[-lag:], np.zeros(-lag)])[:n]
    else:
        aligned = y_b[:n]
    return safe(aligned)


# ---------------------------------------------------------------------------
# TECHNIQUE 2 — PHASE-COHERENCE WIENER MASK  (RF interferometry)
# ---------------------------------------------------------------------------

def phase_coherence_wiener(y_a, y_b):
    """Complex inter-channel coherence Wiener mask.
    Requires phase agreement between channels (not just equal magnitude),
    the way RF interferometry gates correlated signals from noise."""
    n  = len(y_a)
    Sa = librosa.stft(safe(y_a), n_fft=N_FFT, hop_length=HOP_LEN)
    Sb = librosa.stft(safe(y_b), n_fft=N_FFT, hop_length=HOP_LEN)

    cross_r = uniform_filter1d((Sa * np.conj(Sb)).real, size=5, axis=1)
    cross_i = uniform_filter1d((Sa * np.conj(Sb)).imag, size=5, axis=1)
    cross   = cross_r + 1j * cross_i
    pow_a   = uniform_filter1d(np.abs(Sa) ** 2, size=5, axis=1)
    pow_b   = uniform_filter1d(np.abs(Sb) ** 2, size=5, axis=1)

    coh = np.abs(cross) / (np.sqrt(np.abs(pow_a * pow_b)) + 1e-10)
    G   = coh ** 2 / (coh ** 2 + (1.0 - coh ** 2) / 8.0)
    G   = np.clip(safe(G), 0.06, 1.0)

    a_out = safe(librosa.istft(Sa * G, hop_length=HOP_LEN, length=n))
    b_out = safe(librosa.istft(Sb * G, hop_length=HOP_LEN, length=n))
    return a_out, b_out


# ---------------------------------------------------------------------------
# TECHNIQUE 3 — MVDR BEAMFORMING  (sonar adaptive array)
# ---------------------------------------------------------------------------

def mvdr_beamform(y_a, y_b):
    """2-element MVDR: per-bin adaptive weights minimise total output power
    while preserving coherent arrivals (voices).  Spatially nulls sources
    that differ between the two feeds."""
    n  = len(y_a)
    Sa = librosa.stft(safe(y_a), n_fft=N_FFT, hop_length=HOP_LEN)
    Sb = librosa.stft(safe(y_b), n_fft=N_FFT, hop_length=HOP_LEN)
    n_freq, n_frames = Sa.shape
    X    = np.stack([Sa, Sb], axis=0)
    R    = np.einsum('ift,jft->fij', X, X.conj()) / n_frames
    d    = np.array([1.0, 1.0], dtype=complex) / np.sqrt(2)
    eye2 = np.eye(2, dtype=complex)
    out  = np.zeros_like(Sa)

    for k in range(n_freq):
        diag = 1e-4 * (np.abs(R[k, 0, 0]) + np.abs(R[k, 1, 1])) / 2
        Rk   = R[k] + eye2 * diag
        try:
            Rinv = np.linalg.inv(Rk)
        except np.linalg.LinAlgError:
            out[k] = Sa[k]
            continue
        Rinv_d = Rinv @ d
        w = Rinv_d / (d.conj() @ Rinv_d + 1e-10)
        out[k] = w.conj() @ X[:, k, :]

    return safe(librosa.istft(out, hop_length=HOP_LEN, length=n))


# ---------------------------------------------------------------------------
# TECHNIQUE 4 — CLEAN DECONVOLUTION  (radio astronomy, Hogbom 1974)
# ---------------------------------------------------------------------------

def clean_deconvolve(y):
    """Iterative removal of dominant spectral lines (HVAC hum, electrical
    buzz, engine drone) without touching the broadband voice signal."""
    y = safe(y)
    S = librosa.stft(y, n_fft=N_FFT, hop_length=HOP_LEN)
    mag, phase = librosa.magphase(S)
    dirty    = mag.mean(axis=1)
    residual = dirty.copy()
    removed  = np.zeros_like(dirty)
    bins     = np.arange(len(dirty))

    for _ in range(CLEAN_ITER):
        peak_idx = int(np.argmax(residual))
        peak_val = residual[peak_idx]
        if peak_val < 1e-8:
            break
        beam      = peak_val * np.exp(-0.5 * ((bins - peak_idx) / 2.5) ** 2)
        residual -= CLEAN_GAIN * beam
        residual  = np.maximum(residual, 0.0)
        removed  += CLEAN_GAIN * beam

    suppression = np.clip(1.0 - removed / (dirty + 1e-10), 0.05, 1.0)
    mag_clean   = mag * suppression[:, np.newaxis]
    return safe(librosa.istft(mag_clean * phase, hop_length=HOP_LEN, length=len(y)))


# ---------------------------------------------------------------------------
# TECHNIQUE 5 — TEMPORAL PERSISTENCE GATE  (radar dwell time)
# ---------------------------------------------------------------------------

class PersistenceGate:
    """Ring buffer of N spectral magnitude frames.  A bin must be energetic
    across ALL N consecutive windows to pass.  Clicks, slams, radio bleed
    have zero persistence; voiced speech persists for hundreds of ms."""

    def __init__(self):
        n_bins = N_FFT // 2 + 1
        self.buf = [np.zeros(n_bins) for _ in range(PERSIST_N)]
        self.ptr = 0

    def gate(self, y):
        S = librosa.stft(safe(y), n_fft=N_FFT, hop_length=HOP_LEN)
        mag, phase = librosa.magphase(S)
        mean_mag = mag.mean(axis=1)
        self.buf[self.ptr] = mean_mag
        self.ptr = (self.ptr + 1) % PERSIST_N
        persist = np.min(np.vstack(self.buf), axis=0)
        mask = np.clip(persist / (mean_mag + 1e-10), 0.0, 1.0)
        return safe(librosa.istft(mag * mask[:, np.newaxis] * phase,
                                  hop_length=HOP_LEN, length=len(y)))



# ---------------------------------------------------------------------------
# HELPER-CONSISTENT PLUMBING
# ---------------------------------------------------------------------------

def parse_time_arg(value, default_dt):
    if not value:
        return default_dt
    value = str(value).strip()
    if "-" in value:
        dt = fh.parse_dt(value)
    else:
        parts = value.split(":")
        if len(parts) == 2:
            value = value + ":00"
        dt = fh.parse_dt(f"{default_dt.strftime('%Y-%m-%d')} {value}")
    if not dt:
        raise ValueError(f"Cannot parse time: {value!r}")
    return dt


def tier_matches(label, path, tier):
    blob = f"{label or ''} {path or ''}".lower()
    tier = (tier or "").lower()
    if tier == "amp32":
        return "+32db" in blob or "amp32" in blob or "raw amp +32" in blob
    if tier == "plus20":
        return "+20db" in blob or "+20" in blob or "plus20" in blob or "ampamp" in blob
    if tier == "enhanced":
        return "enhanced" in blob and "+20" not in blob and "plus20" not in blob
    if tier == "original":
        return "original" in blob
    return tier in blob


def load_project_streams(yaml_path, tier):
    raw_streams = fh.get_active_streams(yaml_path, datetime.min, datetime.max)
    streams = []
    for s in raw_streams:
        label = s.get("filter") or s.get("type") or ""
        path = s.get("path", "")
        if tier_matches(label, path, tier):
            streams.append(s)
    streams.sort(key=lambda s: (s.get("start_dt"), s.get("cam_id"), s.get("path")))
    return streams


def get_stream_for_time(streams, cam_id, t):
    candidates = [s for s in streams if s.get("cam_id") == cam_id and s.get("start_dt") <= t < s.get("end_dt")]
    if not candidates:
        return None
    return max(candidates, key=lambda s: s.get("start_dt"))


def read_block(stream_info, t, duration_sec=BLOCK_SEC):
    if not stream_info:
        return None
    y = fh.read_stream_block(stream_info, t, duration_sec, SR)
    if y is None or not np.any(y):
        return None
    return pad_or_trim(safe(y), BLOCK_SAMP)


def ensure_output_dir(path):
    d = os.path.dirname(os.path.abspath(path))
    if d:
        os.makedirs(d, exist_ok=True)


def safe_soundfile_format(out_path):
    fmt = "OGG" if out_path.lower().endswith(".ogg") else None
    subtype = "VORBIS" if fmt == "OGG" else None
    return fmt, subtype


def register_output(yaml_path, output_path, start_dt, label):
    with open(yaml_path, "r") as f:
        cfg = yaml.safe_load(f) or {}
    cfg.setdefault("files", [])
    entry = {
        "path": output_path,
        "start": start_dt.strftime("%Y-%m-%d %H:%M:%S"),
        "type": label,
    }
    updated = False
    for existing in cfg["files"]:
        if os.path.normpath(existing.get("path", "")) == os.path.normpath(output_path):
            existing.update(entry)
            updated = True
            break
    if not updated:
        cfg["files"].append(entry)
    cfg["files"].sort(key=lambda x: x.get("start", ""))
    with open(yaml_path, "w") as f:
        yaml.dump(cfg, f, default_flow_style=False, sort_keys=False)


# ---------------------------------------------------------------------------
# MAIN PROCESSING LOOP — helper-consistent wrapper, original DSP chain retained
# ---------------------------------------------------------------------------

def process(yaml_path, mode="amp32", output_path=None, date_start=None, date_end=None, tier=None):
    tier = tier or mode
    label = MODE_TYPES.get(mode, {}).get("label", tier)
    output_path = output_path or f"fc_paphos_{tier}.ogg"

    print("=" * 64)
    print(f"  FC Paphos Dual-Feed Enhancement — Helper Consistent")
    print(f"  Mode/Tier : {tier}  ({label})")
    print(f"  YAML      : {yaml_path}")
    print(f"  Output    : {output_path}")
    print("=" * 64)

    streams = load_project_streams(yaml_path, tier)
    if not streams:
        raise SystemExit(f"[!] No streams found for tier/mode {tier!r} in {yaml_path}")

    t_global_start = min(s["start_dt"] for s in streams)
    t_global_end = max(s["end_dt"] for s in streams)
    t_start = date_start or t_global_start
    t_end = date_end or t_global_end
    total_sec = max(1.0, (t_end - t_start).total_seconds())

    cams = {"Cam A": 0, "Cam B": 0}
    for s in streams:
        if s.get("cam_id") in cams:
            cams[s.get("cam_id")] += 1

    print(f"\n  Streams      : Cam A={cams['Cam A']}  Cam B={cams['Cam B']}  total={len(streams)}")
    print(f"  Full timeline: {t_global_start:%Y-%m-%d %H:%M}  →  {t_global_end:%Y-%m-%d %H:%M}")
    print(f"  Processing  : {t_start:%Y-%m-%d %H:%M}  →  {t_end:%Y-%m-%d %H:%M}")
    print(f"  (~{total_sec/3600:.1f} hours)\n")

    ensure_output_dir(output_path)
    fmt, subtype = safe_soundfile_format(output_path)

    gate_a = PersistenceGate()
    gate_b = PersistenceGate()
    win = get_window("hann", BLOCK_SAMP).astype(np.float32)
    ola = np.zeros((BLOCK_SAMP * 2, 2), dtype=np.float32)

    t = t_start
    blocks_done = blocks_dual = blocks_mono = blocks_silent = 0
    last_a_path = last_b_path = None

    with sf.SoundFile(output_path, mode="w", samplerate=SR, channels=2, format=fmt, subtype=subtype) as out_f:
        while t < t_end:
            stream_a = get_stream_for_time(streams, "Cam A", t)
            stream_b = get_stream_for_time(streams, "Cam B", t)
            a_path = stream_a.get("path") if stream_a else None
            b_path = stream_b.get("path") if stream_b else None

            if a_path != last_a_path:
                print(f"\n  [{t:%Y-%m-%d %H:%M:%S}]  Cam A → {os.path.basename(a_path) if a_path else '(no coverage)'}")
                last_a_path = a_path
            if b_path != last_b_path:
                print(f"\n  [{t:%Y-%m-%d %H:%M:%S}]  Cam B → {os.path.basename(b_path) if b_path else '(no coverage)'}")
                last_b_path = b_path

            y_a = read_block(stream_a, t, BLOCK_SEC)
            y_b = read_block(stream_b, t, BLOCK_SEC)

            if y_a is not None:
                y_a = adaptive_denoise(y_a)
            if y_b is not None:
                y_b = adaptive_denoise(y_b)

            if y_a is not None and y_b is not None:
                blocks_dual += 1
                y_b = gcc_phat_align(y_a, y_b)
                y_a, y_b = phase_coherence_wiener(y_a, y_b)
                y_beam = mvdr_beamform(y_a, y_b)
                y_a = clean_deconvolve(gate_a.gate(y_a))
                y_b = clean_deconvolve(gate_b.gate(y_b))
                y_beam = clean_deconvolve(y_beam)
                L = np.clip(0.6 * y_a + 0.4 * y_beam, -1.0, 1.0)
                R = np.clip(0.6 * y_b + 0.4 * y_beam, -1.0, 1.0)
            elif y_a is not None:
                blocks_mono += 1
                mono = clean_deconvolve(gate_a.gate(y_a))
                L = R = np.clip(mono, -1.0, 1.0)
            elif y_b is not None:
                blocks_mono += 1
                mono = clean_deconvolve(gate_b.gate(y_b))
                L = R = np.clip(mono, -1.0, 1.0)
            else:
                blocks_silent += 1
                L = R = np.zeros(BLOCK_SAMP, dtype=np.float32)

            ola[:BLOCK_SAMP, 0] += (pad_or_trim(L, BLOCK_SAMP) * win).astype(np.float32)
            ola[:BLOCK_SAMP, 1] += (pad_or_trim(R, BLOCK_SAMP) * win).astype(np.float32)

            chunk = ola[:HOP_SAMP, :].copy()
            peak = np.max(np.abs(chunk))
            if peak > 0.97:
                chunk *= 0.97 / peak
            out_f.write(chunk)

            ola[:-HOP_SAMP] = ola[HOP_SAMP:]
            ola[-HOP_SAMP:] = 0.0

            blocks_done += 1
            t += timedelta(seconds=HOP_SEC)
            if blocks_done % 50 == 0:
                elapsed = (t - t_start).total_seconds()
                pct = min(100.0, 100.0 * elapsed / total_sec)
                mode_str = "DUAL" if (y_a is not None and y_b is not None) else "mono"
                print(f"  [{pct:5.1f}%]  {t:%Y-%m-%d %H:%M}  dual={blocks_dual}  mono={blocks_mono}  silent={blocks_silent}  [{mode_str}]", end="\r")

    print(f"\n\n{'='*64}")
    print(f"  Complete  —  {output_path}")
    print(f"  Mode/Tier   : {tier}")
    print(f"  Dual blocks : {blocks_dual}  ({blocks_dual * HOP_SEC / 3600:.1f}h dual-feed processed)")
    print(f"  Mono blocks : {blocks_mono}  ({blocks_mono * HOP_SEC / 3600:.1f}h single-feed)")
    print(f"  Silent      : {blocks_silent}")
    print(f"  Total       : {blocks_done}  ({blocks_done * HOP_SEC / 3600:.1f}h output)")
    print(f"{'='*64}\n")

    register_output(yaml_path, output_path, t_start, f"Coverage - FC Dual Feed Helper Consistent ({tier})")
    print(f"[*] YAML registered: {output_path}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="FC Paphos dual-feed forensic audio enhancement — helper consistent")
    parser.add_argument("--yaml", required=True, help="Path to project YAML")
    parser.add_argument("--mode", default=None, choices=["plus20", "amp32"], help="Original FC mode name")
    parser.add_argument("--tier", default=None, help="Helper tier override: original, amp32, enhanced, plus20")
    parser.add_argument("--out", default=None, help="Output filename")
    parser.add_argument("--start", default=None, help="YYYY-MM-DD, YYYY-MM-DD HH:MM[:SS], or HH:MM[:SS]")
    parser.add_argument("--end", default=None, help="YYYY-MM-DD, YYYY-MM-DD HH:MM[:SS], or HH:MM[:SS]")
    args = parser.parse_args()

    tier = args.tier or args.mode or "amp32"
    mode = args.mode or (tier if tier in MODE_TYPES else "amp32")
    streams_for_defaults = load_project_streams(args.yaml, tier)
    if not streams_for_defaults:
        raise SystemExit(f"[!] No streams found for tier/mode {tier!r}")
    default_start = min(s["start_dt"] for s in streams_for_defaults)
    default_end = max(s["end_dt"] for s in streams_for_defaults)
    t0 = parse_time_arg(args.start, default_start) if args.start else None
    t1 = parse_time_arg(args.end, default_start) if args.end else None
    out = args.out or f"fc_paphos_{tier}_helper_consistent.ogg"
    process(args.yaml, mode=mode, output_path=out, date_start=t0, date_end=t1, tier=tier)
