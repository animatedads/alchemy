"""
dual_feed_enhance_v8.py
=======================
Forensic Audio Enhancement — V8 Standardized Parallel Pipeline
(Upgraded: AI Time-Dependent Filtering via ForensicHelper Router)

Techniques:
1. Multi-Processed Segments: Parallel 5-minute window processing.
2. Adaptive Noise Atlas (ANA): 15-minute TOD binning.
3. AI Transient Mapping: Consults AI models to surgically notch anomalies.
4. Total Abstraction: Relies entirely on forensic_helper.py for architecture.
"""

import os
import json
import csv
import numpy as np
import soundfile as sf
import librosa
import pickle
import re
import warnings
import concurrent.futures
from datetime import datetime, timedelta
from scipy import signal
from scipy.signal import correlate, get_window
from forensic_helper import ForensicHelper as fh, PipelineQueue

# --- SUPPRESS DEPRECATION & BACKEND WARNINGS ---
warnings.filterwarnings('ignore', category=UserWarning, module='librosa')
warnings.filterwarnings('ignore', category=FutureWarning, module='librosa')

# --- CONFIGURATION ---
SR            = 22050
BLOCK_SEC     = 8.0
HOP_FRAC      = 0.5
N_FFT         = 2048
HOP_LENGTH    = N_FFT // 4
BIN_SIZE_MIN  = 15
N_BINS        = (24 * 60) // BIN_SIZE_MIN
SEGMENT_MIN   = 5

def sanitize(y):
    return np.nan_to_num(y, nan=0.0, posinf=0.0, neginf=0.0)

# --- SOURCE SELECTION / AUDIT HELPERS ---

GENERATED_KEYWORDS = [
    "generated", "trial_mix", "dual_feed", "coverage", "joined",
    "beam", "fused", "sync_", "master", "v7", "v8", "v9",
    "scene", "dfe8", "v9_scene"
]

def stream_haystack(s):
    return " ".join(str(s.get(k, "")) for k in ("filter", "type", "path", "label")).lower()

def is_generated_stream(s):
    hay = stream_haystack(s)
    return any(k in hay for k in GENERATED_KEYWORDS)

def is_bad_duplicate_timestamp_path(path):
    base = os.path.basename(str(path))
    return re.search(r'(20\d{6}_\d{6})_\1', base) is not None

def matches_tier_stream(s, tier):
    hay = stream_haystack(s)
    tl = str(tier or "").lower()
    if tl == "amp32":
        return ("amp32" in hay) or ("+32db" in hay) or ("raw amp" in hay)
    if tl == "plus20":
        return ("plus20" in hay) or ("+20db" in hay) or ("+20" in hay)
    if tl == "enhanced":
        return ("enhanced" in hay) and ("plus20" not in hay) and ("+20" not in hay)
    if tl == "original":
        return "original" in hay
    return tl in hay

def source_priority(s):
    hay = stream_haystack(s)
    path = s.get("path", "")
    penalty = 0
    if is_generated_stream(s):
        penalty += 1000
    if is_bad_duplicate_timestamp_path(path):
        penalty += 500
    if "enhanced" in hay and "raw amp" not in hay:
        penalty += 50
    if "original" in hay:
        penalty += 20
    return penalty

def choose_active_stream(streams, cam_id, t):
    candidates = [
        st for st in streams
        if st.get("cam_id") == cam_id and st["start_dt"] <= t < st["end_dt"]
    ]
    if not candidates:
        return None
    candidates.sort(key=lambda st: (source_priority(st), -st["start_dt"].timestamp(), str(st.get("path", ""))))
    return candidates[0]

# --- V8 CORE: EIGEN-NOISE PROJECTION ---

@fh.time_operation
def eigen_noise_projection(Sa, Sb, debug=False):
    n_freq, n_frames = Sa.shape
    clean_a = np.zeros_like(Sa)
    clean_b = np.zeros_like(Sb)

    for f in range(n_freq):
        X_f = np.vstack([Sa[f, :], Sb[f, :]])
        R_f = (X_f @ np.conj(X_f.T)) / n_frames
        R_f += np.eye(2) * 1e-7
        try:
            eigvals, eigvecs = np.linalg.eigh(R_f)
            noise_vec = eigvecs[:, -1:]
            P = np.eye(2) - (noise_vec @ np.conj(noise_vec.T))
            X_clean_f = P @ X_f
            clean_a[f, :] = X_clean_f[0]
            clean_b[f, :] = X_clean_f[1]
        except:
            clean_a[f, :] = Sa[f, :]
            clean_b[f, :] = Sb[f, :]
    return clean_a, clean_b

# --- V8 CORE: NOISE ATLAS & TRANSIENT TRACKING ---

class NoiseAtlas:
    def __init__(self, project_id):
        self.project_id = project_id
        self.atlas_path = f"{project_id}_v8_atlas.pkl"
        self.mag_sum = [np.zeros((N_FFT // 2) + 1) for _ in range(N_BINS)]
        self.counts = [0 for _ in range(N_BINS)]
        self.transient_events = []
        if os.path.exists(self.atlas_path):
            self.load()

    def merge_results(self, other_mag_sum, other_counts, transient_events):
        for i in range(N_BINS):
            self.mag_sum[i] += other_mag_sum[i]
            self.counts[i] += other_counts[i]
        self.transient_events.extend(transient_events)

    def get_noise_floor(self, dt):
        bin_id = int(((dt.hour * 3600) + (dt.minute * 60) + dt.second) // (BIN_SIZE_MIN * 60))
        if self.counts[bin_id] < 1: return None
        return self.mag_sum[bin_id] / self.counts[bin_id]

    def save(self):
        with open(self.atlas_path, 'wb') as f:
            pickle.dump({'mag_sum': self.mag_sum, 'counts': self.counts, 'events': self.transient_events}, f)

    def load(self):
        with open(self.atlas_path, 'rb') as f:
            data = pickle.load(f)
            self.mag_sum = data['mag_sum']
            self.counts = data['counts']
            self.transient_events = data.get('events', [])

# --- UTILITIES ---

def cross_ambiguity_align(y_a, y_b, max_delay_sec=0.2):
    y_a, y_b = sanitize(y_a), sanitize(y_b)
    max_lags = int(max_delay_sec * SR)
    corr = correlate(y_a, y_b, mode='full')
    lags = np.arange(-len(y_a) + 1, len(y_b))
    mask = (lags >= -max_lags) & (lags <= max_lags)
    if not np.any(mask): return y_b
    best_lag = lags[mask][np.argmax(np.abs(corr[mask]))]
    if best_lag > 0: return np.pad(y_b, (best_lag, 0))[:len(y_b)]
    elif best_lag < 0: return np.concatenate([y_b[-best_lag:], np.zeros(-best_lag)])[:len(y_b)]
    return y_b

def _iter_dynamic_filter_rules(filter_map):
    """
    Normalise dynamic filter JSON into (timestamp, rule) pairs.

    V8 originally expected:
        {"YYYY-mm-dd HH:MM:SS": {"action": "notch", "freq_hz": 2500}}

    forensic_helper can also leave a raw anomaly/event list when AI consultation
    fails, for example:
        [{"time": "...", "hz": 2500, "mag_ratio": 8.2}, ...]

    Raw event lists are not executable filters unless they contain an action,
    so this function safely skips non-filter events instead of crashing.
    """
    if not filter_map:
        return []

    # Expected format.
    if isinstance(filter_map, dict):
        return list(filter_map.items())

    # Tolerate list format. Only entries with a usable action are executable.
    if isinstance(filter_map, list):
        rules = []
        for item in filter_map:
            if not isinstance(item, dict):
                continue
            ts = item.get("time") or item.get("ts") or item.get("timestamp")
            action = item.get("action")
            if not ts or not action:
                continue

            rule = dict(item)
            # Some raw anomaly logs use "hz" instead of "freq_hz".
            if "freq_hz" not in rule and "hz" in rule:
                rule["freq_hz"] = rule.get("hz")
            rules.append((ts, rule))
        return rules

    return []


def apply_dynamic_filters(y, current_dt, filter_map):
    """Applies temporary AI-prescribed filters based on the time window."""
    if not filter_map:
        return y

    rules = _iter_dynamic_filter_rules(filter_map)
    if not rules:
        return y

    y_filtered = y.copy()
    nyquist = SR / 2.0
    filters_applied = 0
    max_filters_per_block = 4

    for ts_str, rule in rules:
        if filters_applied >= max_filters_per_block:
            break
        if not isinstance(rule, dict):
            continue

        try:
            rule_dt = datetime.strptime(str(ts_str), '%Y-%m-%d %H:%M:%S')
        except Exception:
            continue

        # Activate filter within +/- 4 seconds of the anomaly.
        if abs((current_dt - rule_dt).total_seconds()) >= 4.0:
            continue

        try:
            action = str(rule.get('action', '')).lower().strip()
            freq = rule.get('freq_hz')
            freq = float(freq) if freq is not None else None

            if action == 'notch' and freq is not None:
                # Keep filters within sane audio bounds.
                if not (50.0 < freq < nyquist - 100.0):
                    continue
                q = float(rule.get('q', 30))
                q = min(80.0, max(10.0, q))
                b, a = signal.iirnotch(freq, q, SR)
                y_filtered = signal.lfilter(b, a, y_filtered)
                filters_applied += 1

            elif action == 'highpass' and freq is not None:
                if not (20.0 <= freq <= 500.0):
                    continue
                b, a = signal.butter(4, freq / nyquist, btype='high')
                y_filtered = signal.lfilter(b, a, y_filtered)
                filters_applied += 1

        except Exception:
            continue

    return sanitize(y_filtered)

# --- WORKER FUNCTION ---

def process_segment(seg_info):
    """Parallel Worker: Handles Training (Sensing) or Masking (Enhancement)."""
    pid = seg_info['pid']
    t_start = seg_info['t_start']
    t_end = seg_info['t_end']
    streams = seg_info['streams']
    output_path = seg_info['temp_path']
    seg_idx = seg_info.get('idx', -1)
    train_mode = seg_info.get('train_mode', False)
    debug = seg_info.get('debug', False)

    mag_sum = [np.zeros((N_FFT // 2) + 1) for _ in range(N_BINS)]
    counts = [0 for _ in range(N_BINS)]
    transient_events = []

    nonzero_blocks = 0
    silent_blocks = 0
    dual_blocks = 0
    mono_a_blocks = 0
    mono_b_blocks = 0
    error_blocks = 0
    first_a_path = ""
    first_b_path = ""
    last_a_path = ""
    last_b_path = ""

    atlas = NoiseAtlas(pid) if not train_mode else None

    filter_map = {}
    if not train_mode:
        map_path = f"{pid}_dynamic_filters.json"
        if os.path.exists(map_path):
            try:
                with open(map_path, 'r') as f: filter_map = json.load(f)
            except: pass

    hop_sec = BLOCK_SEC * HOP_FRAC
    block_samples = int(BLOCK_SEC * SR)
    hop_samples = int(hop_sec * SR)

    ola_buf = np.zeros(block_samples * 2)
    win = get_window('hann', block_samples)
    t = t_start

    freqs = librosa.fft_frequencies(sr=SR, n_fft=N_FFT)

    out_f = None
    if not train_mode:
        out_f = sf.SoundFile(output_path, mode='w', samplerate=SR, channels=1, format='WAV')

    try:
        while t < t_end:
            active_a = choose_active_stream(streams, 'Cam A', t)
            active_b = choose_active_stream(streams, 'Cam B', t)

            if active_a:
                last_a_path = active_a.get('path', '')
                if not first_a_path:
                    first_a_path = last_a_path
            if active_b:
                last_b_path = active_b.get('path', '')
                if not first_b_path:
                    first_b_path = last_b_path

            # Stream Abstraction via updated helper method
            y_a = fh.read_stream_block(active_a, t, BLOCK_SEC, SR)
            y_b = fh.read_stream_block(active_b, t, BLOCK_SEC, SR)

            has_a = bool(np.any(y_a))
            has_b = bool(np.any(y_b))

            if has_a or has_b:
                nonzero_blocks += 1
                if has_a and has_b:
                    dual_blocks += 1
                elif has_a:
                    mono_a_blocks += 1
                elif has_b:
                    mono_b_blocks += 1

                if train_mode:
                    # 1. Sense the noise floor and build the Atlas
                    if np.any(y_a):
                        S = np.abs(librosa.stft(sanitize(y_a), n_fft=N_FFT, hop_length=HOP_LENGTH))
                        median_floor = np.median(S, axis=1)

                        bin_id = int(((t.hour * 3600) + (t.minute * 60) + t.second) // (BIN_SIZE_MIN * 60))
                        mag_sum[bin_id] += median_floor
                        counts[bin_id] += 1

                        # 2. Transient Detection Logic (Detect 5x magnitude anomalies)
                        frame_max = np.max(S, axis=1)
                        anomaly_idx = np.where(frame_max > (median_floor * 4.0))[0]
                        for idx in anomaly_idx:
                            hz = freqs[idx]
                            if hz > 150: # Avoid deep sub rumbles for this detection
                                ratio = frame_max[idx] / (median_floor[idx] + 1e-6)
                                if ratio > 5.0:
                                    transient_events.append({
                                        "time": t.strftime('%Y-%m-%d %H:%M:%S'),
                                        "hz": float(hz),
                                        "mag_ratio": float(ratio)
                                    })
                                    break # Only log the single most intense event per block
                else:
                    # Active Enhancement Mode
                    # Apply pre-calculated AI dynamic filters for anomalies
                    y_a_filt = apply_dynamic_filters(y_a, t, filter_map)
                    y_b_filt = apply_dynamic_filters(y_b, t, filter_map)

                    y_b_aligned = cross_ambiguity_align(y_a_filt, y_b_filt)

                    Sa = librosa.stft(y_a_filt, n_fft=N_FFT, hop_length=HOP_LENGTH)
                    Sb = librosa.stft(y_b_aligned, n_fft=N_FFT, hop_length=HOP_LENGTH)

                    Sa_clean, _ = eigen_noise_projection(Sa, Sb, debug=debug)

                    # Target stationary baseline noise recorded during training
                    floor = atlas.get_noise_floor(t)
                    if floor is not None:
                        mag = np.abs(Sa_clean)
                        mask = np.maximum(0, mag - (floor[:, None] * 1.5)) / (mag + 1e-10)
                        Sa_clean *= mask

                    y_out = librosa.istft(Sa_clean, hop_length=HOP_LENGTH, length=block_samples)
                    ola_buf[:block_samples] += sanitize(y_out * win)
                    out_f.write(librosa.util.normalize(ola_buf[:hop_samples]))

                    ola_buf[:block_samples] = ola_buf[hop_samples:hop_samples+block_samples]
                    ola_buf[block_samples:] = 0
            elif not train_mode:
                silent_blocks += 1
                out_f.write(fh.generate_comfort_noise(hop_samples, db=-55))

            t += timedelta(seconds=hop_sec)
    finally:
        if out_f: out_f.close()

    stats = {
        'idx': seg_idx,
        'path': output_path,
        'start': t_start.strftime('%Y-%m-%d %H:%M:%S'),
        'end': t_end.strftime('%Y-%m-%d %H:%M:%S'),
        'nonzero_blocks': nonzero_blocks,
        'silent_blocks': silent_blocks,
        'dual_blocks': dual_blocks,
        'mono_a_blocks': mono_a_blocks,
        'mono_b_blocks': mono_b_blocks,
        'error_blocks': error_blocks,
        'first_a_path': first_a_path,
        'last_a_path': last_a_path,
        'first_b_path': first_b_path,
        'last_b_path': last_b_path,
    }

    if train_mode:
        return {'mag_sum': mag_sum, 'counts': counts, 'events': transient_events, 'stats': stats}
    return stats

# --- MAIN ENGINE ---

def process_v8_parallel(args):
    pid = os.path.splitext(os.path.basename(args.yaml))[0]

    # 1. Ask ForensicHelper for ALL streams in the project, then select only
    # physical source streams for the requested tier. Generated/derived masters
    # are excluded by default because they can overlap raw clips and silently
    # win the old "last matching stream" selection logic.
    raw_streams = fh.get_active_streams(args.yaml, datetime.min, datetime.max, max_assumed_hours=96)

    include_generated = bool(getattr(args, 'include_generated', False))
    streams = []
    excluded_generated = 0
    excluded_dup_ts = 0
    for st in raw_streams:
        if not matches_tier_stream(st, args.tier):
            continue
        if is_bad_duplicate_timestamp_path(st.get('path', '')):
            excluded_dup_ts += 1
            continue
        if is_generated_stream(st) and not include_generated:
            excluded_generated += 1
            continue
        streams.append(st)

    streams.sort(key=lambda st: (st.get('cam_id', ''), st['start_dt'], source_priority(st), str(st.get('path', ''))))

    print(f"[*] Source selection: {len(raw_streams)} raw candidates, {len(streams)} usable tier streams")
    print(f"[*] Excluded generated/derived: {excluded_generated} | duplicate timestamp paths: {excluded_dup_ts}")
    if include_generated:
        print("[!] --include-generated is active: derived masters may be used as sources.")

    if not streams:
        print(f"[!] Error: No streams found matching tier '{args.tier}' in {args.yaml}")
        return

    starts = sorted([s['start_dt'] for s in streams])

    def handle_time(time_str, default_dt):
        if not time_str: return default_dt
        if "-" in time_str: return fh.parse_dt(time_str)
        target_date = starts[0].strftime("%Y-%m-%d") if starts else "1970-01-01"
        return fh.parse_dt(f"{target_date} {time_str}:00")

    # 2. Bound the processing window
    t0 = handle_time(args.start, starts[0])
    last_stream = max(streams, key=lambda x: x['end_dt'])
    t1 = handle_time(args.end, last_stream['end_dt'])

    queue = PipelineQueue(debug=args.debug)
    temp_dir = f"temp_{pid}"
    os.makedirs(temp_dir, exist_ok=True)

    segments = []
    curr_t = t0
    seg_idx = 0
    while curr_t < t1:
        next_t = min(curr_t + timedelta(minutes=SEGMENT_MIN), t1)
        segments.append({
            'idx': seg_idx,
            'pid': pid,
            't_start': curr_t,
            't_end': next_t,
            'streams': streams,
            'tier': args.tier,
            'train_mode': args.train,
            'debug': args.debug,
            'temp_path': os.path.join(temp_dir, f"seg_{seg_idx:04d}.wav")
        })
        curr_t = next_t
        seg_idx += 1

    queue.total_tasks = len(segments)
    n_workers = args.workers if args.workers else max(1, (os.cpu_count() or 2) - 1)

    print(f"=== V8 High-Performance Parallel Engine ===")
    print(f"Project: {pid} | Tier: {args.tier} | Mode: {'TRAINING' if args.train else 'ENHANCEMENT'}")
    print(f"Workers: {n_workers} | Segments: {len(segments)}")

    queue.log_action(f"Initialized Pipeline with {n_workers} workers.")

    global_atlas = NoiseAtlas(pid) if args.train else None
    processed_files = []
    segment_stats = []

    with concurrent.futures.ProcessPoolExecutor(max_workers=n_workers) as executor:
        futures = {executor.submit(process_segment, seg): seg for seg in segments}
        for future in concurrent.futures.as_completed(futures):
            seg = futures[future]
            try:
                res = future.result()
            except Exception as e:
                queue.completed_tasks += 1
                print(f"\n[!] Segment failed {seg['t_start']} -> {seg['t_end']}: {e}")
                if args.train:
                    queue.progress("Sensing")
                    continue

                # Enhancement mode fallback: write a correctly sized comfort-noise
                # segment so the final stitch preserves the absolute timeline.
                fallback_path = seg['temp_path']
                seg_seconds = max(0.0, (seg['t_end'] - seg['t_start']).total_seconds())
                seg_samples = int(seg_seconds * SR)
                try:
                    sf.write(fallback_path, fh.generate_comfort_noise(seg_samples, db=-55), SR, format='WAV')
                    fallback_stats = {
                        'idx': seg.get('idx', -1),
                        'path': fallback_path,
                        'start': seg['t_start'].strftime('%Y-%m-%d %H:%M:%S'),
                        'end': seg['t_end'].strftime('%Y-%m-%d %H:%M:%S'),
                        'nonzero_blocks': 0,
                        'silent_blocks': int(max(1, seg_seconds // (BLOCK_SEC * HOP_FRAC))),
                        'dual_blocks': 0,
                        'mono_a_blocks': 0,
                        'mono_b_blocks': 0,
                        'error_blocks': 1,
                        'first_a_path': '',
                        'last_a_path': '',
                        'first_b_path': '',
                        'last_b_path': '',
                        'failed': str(e),
                    }
                    processed_files.append(fallback_path)
                    segment_stats.append(fallback_stats)
                    queue.progress("Enhancing")
                    queue.log_action(f"Fallback Segment: {os.path.basename(fallback_path)}")
                except Exception as fallback_error:
                    print(f"[!] Could not create fallback segment {fallback_path}: {fallback_error}")
                continue

            queue.completed_tasks += 1
            if args.train:
                global_atlas.merge_results(res['mag_sum'], res['counts'], res.get('events', []))
                if isinstance(res, dict) and res.get('stats'):
                    segment_stats.append(res['stats'])
                queue.progress("Sensing")
            else:
                if isinstance(res, dict):
                    processed_files.append(res['path'])
                    segment_stats.append(res)
                    log_path = res['path']
                else:
                    processed_files.append(res)
                    log_path = res
                queue.progress("Enhancing")
                queue.log_action(f"Saved Segment: {os.path.basename(log_path)}")

    if args.train:
        # Phase 2: Route Anomalies through the Universal ForensicHelper AI Router
        sorted_events = sorted(global_atlas.transient_events, key=lambda x: x['mag_ratio'], reverse=True)
        if hasattr(args, 'ai_consult') and args.ai_consult:
            # Passes right into the centralized Router
            fh.consult_ai_for_filters(sorted_events, pid, provider=args.ai_provider)

        global_atlas.save()
        print(f"\n[*] Parallel Training Complete. Noise Atlas saved to {global_atlas.atlas_path}")
        try: os.rmdir(temp_dir)
        except: pass
        return

    # Explicit chronological assembly. Do not rely on worker completion order.
    if segment_stats:
        segment_stats.sort(key=lambda r: int(r.get('idx', 10**9)))
        processed_files = [r['path'] for r in segment_stats if r.get('path') and os.path.exists(r.get('path'))]
    else:
        processed_files = sorted(processed_files)

    # Segment activity report for diagnosing silent tails / wrong source selection.
    audit_csv = f"{pid}_v8_segment_activity.csv"
    if segment_stats:
        fieldnames = [
            'idx', 'start', 'end', 'path',
            'nonzero_blocks', 'silent_blocks', 'dual_blocks',
            'mono_a_blocks', 'mono_b_blocks', 'error_blocks',
            'first_a_path', 'last_a_path', 'first_b_path', 'last_b_path',
            'failed'
        ]
        with open(audit_csv, 'w', newline='') as f:
            w = csv.DictWriter(f, fieldnames=fieldnames, extrasaction='ignore')
            w.writeheader()
            for row in segment_stats:
                w.writerow(row)
        print(f"\n[*] Segment activity audit: {audit_csv}")

    # Atomic Stitching with ForensicHelper
    print(f"\n[*] Utilizing ForensicHelper for continuous timeline stitching...")
    out_file = args.out if args.out else f"{pid}_master_v8_parallel.ogg"

    success = fh.stitch_segments(processed_files, out_file, debug=args.debug)

    if success:
        # Cleanup
        for p in processed_files:
            if p and os.path.exists(p): os.remove(p)
        try: os.rmdir(temp_dir)
        except: pass
        print(f"=== SUCCESS ===\nV8 Master: {out_file}")

if __name__ == "__main__":
    parser = fh.get_standard_parser("V8 Forensic Parallel Enhancer")
    # Dynamically inject training & AI arguments gracefully
    if not any(a.option_strings and '--train' in a.option_strings for a in parser._actions):
        parser.add_argument("--train", action="store_true", help="Builds noise atlas and logs transients.")
    if not any(a.option_strings and '--ai-consult' in a.option_strings for a in parser._actions):
        parser.add_argument("--ai-consult", action="store_true", help="Send detected anomalies to AI for dynamic filter mapping.")
        parser.add_argument("--ai-provider", default="gemini", choices=["gemini", "openai", "deepthought"], help="Select AI Engine for analysis")
    if not any(a.option_strings and '--include-generated' in a.option_strings for a in parser._actions):
        parser.add_argument("--include-generated", action="store_true", help="Allow generated/derived masters as source streams. Default is to exclude them.")
    args = parser.parse_args()
    process_v8_parallel(args)

