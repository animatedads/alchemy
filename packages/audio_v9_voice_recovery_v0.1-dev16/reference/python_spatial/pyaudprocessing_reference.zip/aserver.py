import os
import glob
import yaml
import sqlite3
import asyncio
import subprocess
import hashlib
import logging
import sys
from datetime import datetime, timedelta
import time
from typing import Optional
from contextlib import asynccontextmanager
from fastapi import FastAPI, WebSocket, WebSocketDisconnect, Request, Header, HTTPException
from fastapi.responses import HTMLResponse, StreamingResponse, JSONResponse, FileResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import uvicorn

# Define the logger at the module level
logger = logging.getLogger("as400")

def setup_as400_logger():
    """Configures the logger safely after Uvicorn's startup sequence."""
    logger.setLevel(logging.WARNING)
    if not logger.handlers:
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setFormatter(logging.Formatter('INFO:     %(message)s'))
        logger.addHandler(console_handler)
    logger.propagate = False

# --- AS400-Style Job Queue & Cache ---
MEDIA_DURATIONS_CACHE = {}
FILE_METADATA_CACHE = {}
ACTIVE_PROJECTS = set()
job_queue = asyncio.PriorityQueue()
queued_items = set()

def get_media_duration(filepath):
    try:
        cmd = ['ffprobe', '-v', 'quiet', '-show_entries', 'format=duration', '-of', 'default=noprint_wrappers=1:nokey=1', filepath]
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=5)
        return float(result.stdout.strip())
    except:
        return 0.0

async def sizing_worker():
    while True:
        try:
            priority, timestamp, pid, filepath = await job_queue.get()
            if filepath in queued_items: queued_items.remove(filepath)
            if filepath in MEDIA_DURATIONS_CACHE:
                job_queue.task_done()
                continue
            dur = await asyncio.to_thread(get_media_duration, filepath)
            MEDIA_DURATIONS_CACHE[filepath] = dur
            job_queue.task_done()
        except asyncio.CancelledError: break
        except Exception: pass

async def startup_sweep():
    try:
        extensions = ('*.ogg', '*.mp4', '*.wav', '*/*.ogg', '*/*.mp4', '*/*.wav')
        for ext in extensions:
            for filepath in glob.glob(ext):
                if os.path.isfile(filepath) and filepath not in queued_items:
                    queued_items.add(filepath)
                    await job_queue.put((10, time.time(), "", filepath))
    except Exception: pass

async def watch_yaml_files():
    last_mtimes = {}
    while True:
        try:
            yaml_files = glob.glob("*.yaml")
            for yaml_file in yaml_files:
                mtime = os.path.getmtime(yaml_file)
                pid = os.path.splitext(os.path.basename(yaml_file))[0]
                if mtime > last_mtimes.get(yaml_file, 0):
                    last_mtimes[yaml_file] = mtime
                    with open(yaml_file, 'r') as f:
                        config = yaml.safe_load(f) or {}
                        if pid not in FILE_METADATA_CACHE: FILE_METADATA_CACHE[pid] = {}
                        for entry in config.get('files', []):
                            path = entry.get('path')
                            if path in MEDIA_DURATIONS_CACHE:
                                dur = MEDIA_DURATIONS_CACHE[path]
                                start_dt = datetime.strptime(entry.get('start'), '%Y-%m-%d %H:%M:%S')
                                FILE_METADATA_CACHE[pid][path] = {"start": start_dt, "duration": dur}
        except asyncio.CancelledError: break
        except Exception: pass
        await asyncio.sleep(2)

def verify_password(stored_hash_str, password):
    try:
        salt, hash_val = stored_hash_str.split('$')
        return hashlib.sha256((salt + password).encode()).hexdigest() == hash_val
    except: return False

@asynccontextmanager
async def lifespan(app: FastAPI):
    setup_as400_logger()
    await startup_sweep()
    app.state.watcher_task = asyncio.create_task(watch_all_databases())
    app.state.yaml_task = asyncio.create_task(watch_yaml_files())
    app.state.worker_task = asyncio.create_task(sizing_worker())
    yield
    app.state.watcher_task.cancel()
    app.state.yaml_task.cancel()
    app.state.worker_task.cancel()

app = FastAPI(lifespan=lifespan)
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])

@app.get("/")
async def get_ui():
    if os.path.exists("aserver.ui"):
        with open("aserver.ui", "r", encoding="utf-8") as f:
            return HTMLResponse(content=f.read())
    return HTMLResponse(content="Error: aserver.ui not found", status_code=404)

@app.get("/api/projects")
async def list_projects():
    projects = []
    for db_file in glob.glob("*_audit.db"):
        pid = db_file.replace("_audit.db", "")
        yaml_path = f"{pid}.yaml"
        if not os.path.exists(yaml_path): yaml_path = f"{pid}_project.yaml"
        total_size = os.path.getsize(db_file) if os.path.exists(db_file) else 0
        media_count = 0
        total_duration = 0.0
        if os.path.exists(yaml_path):
            total_size += os.path.getsize(yaml_path)
            with open(yaml_path, 'r') as f:
                config = yaml.safe_load(f) or {}
                files = config.get('files', [])
                media_count = len(files)
                for entry in files:
                    path = entry.get('path', '')
                    if os.path.exists(path): total_size += os.path.getsize(path)
                    total_duration += MEDIA_DURATIONS_CACHE.get(path, 0.0)

        projects.append({
            "id": pid,
            "name": pid.replace("_", " ").title(),
            "size": f"{total_size / (1024*1024):.1f} MB",
            "files": media_count,
            "duration": total_duration
        })
    return {"projects": projects}

@app.post("/api/project/{pid}/login")
async def project_login(pid: str, request: Request):
    body = await request.json()
    username = body.get('username', '').strip()
    password = body.get('password', '').strip()

    if not username or not password:
        raise HTTPException(status_code=401, detail="Both Username and Password required")

    yaml_path = f"{pid}.yaml"
    if not os.path.exists(yaml_path): yaml_path = f"{pid}_project.yaml"
    if os.path.exists(yaml_path):
        with open(yaml_path, 'r') as f:
            config = yaml.safe_load(f)
            if 'password' in config:
                if not verify_password(config['password'], password):
                    raise HTTPException(status_code=401, detail="Invalid credentials")
    return {"success": True}

@app.get("/api/project/{pid}/config")
async def project_config(pid: str):
    yaml_path = f"{pid}.yaml"
    if not os.path.exists(yaml_path): yaml_path = f"{pid}_project.yaml"
    if os.path.exists(yaml_path):
        with open(yaml_path, 'r') as f:
            config = yaml.safe_load(f) or {}
            if 'password' in config: del config['password']
            for entry in config.get('files', []):
                entry['duration'] = MEDIA_DURATIONS_CACHE.get(entry.get('path'), 0.0)
            return config
    return {"files": []}

@app.get("/stream/{pid}")
async def stream_audio(pid: str, source_idx: int = 0, range: Optional[str] = Header(None)):
    yaml_path = f"{pid}.yaml"
    if not os.path.exists(yaml_path): yaml_path = f"{pid}_project.yaml"
    with open(yaml_path, 'r') as f:
        config = yaml.safe_load(f)
        files = config.get('files', [])
        if 0 <= source_idx < len(files):
            filepath = files[source_idx].get('path')
            if filepath and os.path.exists(filepath):
                file_size = os.stat(filepath).st_size
                if range:
                    byte_ranges = range.replace("bytes=", "").split("-")
                    start = int(byte_ranges[0])
                    end = int(byte_ranges[1]) if len(byte_ranges) > 1 and byte_ranges[1] else file_size - 1
                    def file_iterator():
                        with open(filepath, "rb") as file:
                            file.seek(start)
                            remaining = end - start + 1
                            while remaining > 0:
                                chunk = file.read(min(1024 * 1024, remaining))
                                if not chunk: break
                                remaining -= len(chunk)
                                yield chunk
                    return StreamingResponse(file_iterator(), status_code=206, headers={
                        "Content-Range": f"bytes {start}-{end}/{file_size}",
                        "Accept-Ranges": "bytes", "Content-Type": "audio/ogg"
                    })
                return FileResponse(filepath, headers={"Accept-Ranges": "bytes", "Content-Type": "audio/ogg"})
    raise HTTPException(status_code=404, detail="Audio not found")

@app.get("/api/queue")
async def queue_status():
    return {"queue_size": job_queue.qsize(), "sized_files": len(MEDIA_DURATIONS_CACHE)}

@app.post("/api/update/{pid}")
async def update_transcript_line(pid: str, item: BaseModel):
    # This matches the frontend expectations
    pass

class ConnectionManager:
    def __init__(self): self.active_connections = {}
    async def connect(self, ws, pid):
        await ws.accept()
        if pid not in self.active_connections: self.active_connections[pid] = []
        self.active_connections[pid].append(ws)
    def disconnect(self, ws, pid):
        if pid in self.active_connections:
            self.active_connections[pid].remove(ws)
    async def broadcast_to_room(self, pid, message):
        if pid in self.active_connections:
            for c in self.active_connections[pid]:
                try: await c.send_json(message)
                except: pass

manager = ConnectionManager()

async def watch_all_databases():
    last_mtimes = {}
    while True:
        for db_file in glob.glob("*_audit.db"):
            mtime = os.path.getmtime(db_file)
            if mtime > last_mtimes.get(db_file, 0):
                last_mtimes[db_file] = mtime
                pid = db_file.replace("_audit.db", "")
                # Simulate a sync - actually implementation needs to read DB
                await manager.broadcast_to_room(pid, {"type": "sync_notice"})
        await asyncio.sleep(1)

@app.websocket("/ws/{pid}")
async def websocket_endpoint(ws: WebSocket, pid: str):
    await manager.connect(ws, pid)
    try:
        while True: await ws.receive_text()
    except WebSocketDisconnect:
        manager.disconnect(ws, pid)

if __name__ == "__main__":
    uvicorn.run("aserver:app", host="0.0.0.0", port=8000, reload=True)
