import os
import shutil
import yaml
import argparse

def move_project_files(yaml_path, target_base_dir):
    # 1. Load the YAML
    if not os.path.exists(yaml_path):
        print(f"Error: YAML file '{yaml_path}' not found.")
        return

    with open(yaml_path, 'r') as f:
        config = yaml.safe_load(f)

    if 'files' not in config:
        print("Error: No 'files' section found in YAML.")
        return

    # Create target directory if it doesn't exist
    if not os.path.exists(target_base_dir):
        os.makedirs(target_base_dir)
        print(f"Created target directory: {target_base_dir}")

    moved_count = 0
    missing_count = 0

    # 2. Iterate and Move
    for entry in config['files']:
        old_path = entry['path']

        # Determine the filename
        file_name = os.path.basename(old_path)
        new_path = os.path.join(target_base_dir, file_name)

        if os.path.exists(old_path):
            print(f"Moving: {file_name} ...", end="\r")
            try:
                # Use shutil.move (Location X -> Location Y)
                shutil.move(old_path, new_path)

                # 3. Amend the YAML entry in memory
                entry['path'] = new_path
                moved_count += 1
            except Exception as e:
                print(f"\nFailed to move {file_name}: {e}")
        else:
            print(f"\nWarning: File not found at {old_path}. Skipping.")
            missing_count += 1

    # 4. Save the amended YAML
    with open(yaml_path, 'w') as f:
        yaml.dump(config, f, default_flow_style=False, sort_keys=False)

    print(f"\n\nProcessing Complete:")
    print(f"- Files successfully moved: {moved_count}")
    print(f"- Files missing/skipped: {missing_count}")
    print(f"- YAML updated: {yaml_path}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Move project files and update YAML config.")
    parser.add_argument("yaml", help="Path to the project YAML file (e.g., fcpaphos_project.yaml)")
    parser.add_argument("target", help="Target location (e.g., D:/Archived_Cases/fcpaphos/)")

    args = parser.parse_args()
    move_project_files(args.yaml, args.target)
