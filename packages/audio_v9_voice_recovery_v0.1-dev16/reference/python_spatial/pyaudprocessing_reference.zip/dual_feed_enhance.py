"""
dual_feed_enhance.py
====================
Forensic Audio Enhancement — Dual-Feed Pipeline (V2.4: Selection Monitor & Filter Patch)
- Selection Monitor: Logs real-time source file transitions to the terminal.
- Spectrogram Patch: 8th-order Butterworth Low-Pass Filter (4kHz) to kill high-frequency wall.
- Priority Patch: Prefers 'amp' (+32dB raw) over 'ampamp' (+20dB enhanced) to avoid clipping.
- Stability: Fixed istft length consistency and NaN/Inf sanitization for large files.
"""

import os
import sys
import argparse
import yaml
import numpy as np
import soundfile as sf
import librosa
from datetime import datetime, timedelta
from scipy.signal import correlate, get_window, butter, lfilter
from scipy.ndimage import uniform_filter1d

# --------------------------------------------------------------------------
# CONFIGURATION
# --------------------------------------------------------------------------
SR            = 22050          # Unified sample rate for forensic processing
BLOCK_SEC     = 8              # Processing window (seconds)
HOP_FRAC      = 0.5            # 50% overlap for smooth OLA reconstruction
N_FFT         = 2048
HOP_LENGTH    = N_FFT // 4
CUTOFF_HZ     = 4000           # High-frequency noise wall removal point

# --------------------------------------------------------------------------
# FORENSIC STABILITY & FILTERING UTILS
# --------------------------------------------------------------------------

def sanitize(y):
    """Deep sanitization: converts NaNs and Infs to silent samples."""
    return np.nan_to_num(y, nan=0.0, posinf=0.0, neginf=0.0)

def forensic_lowpass_filter(y, cutoff=4000, sr=22050, order=8):
    """
    Surgical brickwall filter to remove the high-frequency 'screaming' noise
    identified in the spectrogram analysis.
    """
    nyq = 0.5 * sr
    normal_cutoff = cutoff / nyq
    b, a = butter(order, normal_cutoff, btype='low', analog=False)
    # Applying filter and re-sanitizing output
    return sanitize(lfilter(b, a, y))

# --------------------------------------------------------------------------
# RADAR/SONAR/ASTRONOMY DSP MODULES
# --------------------------------------------------------------------------

def cross_ambiguity_align(y_a, y_b, max_delay_sec=0.2):
    """Aligns two audio streams using Radar-derived Cross-Ambiguity logic."""
    y_a, y_b = sanitize(y_a), sanitize(y_b)
    max_lags = int(max_delay_sec * SR)
    # Correlation in time domain to detect micro-second phase shifts
    corr = correlate(y_a, y_b, mode='full')
    lags = np.arange(-len(y_a) + 1, len(y_b))

    # Search within the specified forensic delay window
    mask = (lags >= -max_lags) & (lags <= max_lags)
    if not np.any(mask): return y_b

    best_lag = lags[mask][np.argmax(np.abs(corr[mask]))]

    if best_lag > 0:
        return np.pad(y_b, (best_lag, 0))[:len(y_b)]
    elif best_lag < 0:
        return np.concatenate([y_b[-best_lag:], np.zeros(-best_lag)])[:len(y_b)]
    return y_b

def mvdr_beamform(y_a, y_b):
    """Sonar-style MVDR Beamforming to steer a null toward noise sources."""
    target_len = len(y_a)
    y_a, y_b = sanitize(y_a), sanitize(y_b)

    S_a = librosa.stft(y_a, n_fft=N_FFT, hop_length=HOP_LENGTH)
    S_b = librosa.stft(y_b, n_fft=N_FFT, hop_length=HOP_LENGTH)

    X = np.stack([S_a, S_b], axis=0) # Dual-element virtual sensor array
    # Compute Spatial Covariance Matrix
    R = np.einsum('ift,jft->fij', X, X.conj()) / X.shape[2]

    h = np.array([1.0, 1.0]) # Steering vector for coherent voice
    y_out = np.zeros_like(S_a)

    with np.errstate(divide='ignore', invalid='ignore'):
        for f in range(R.shape[0]):
            try:
                # Numerical stability: Regularized pseudo-inverse
                R_inv = np.linalg.pinv(R[f] + np.eye(2)*1e-6)
                denominator = h.conj() @ R_inv @ h
                w = (R_inv @ h) / (denominator + 1e-10)
                y_out[f, :] = w.conj() @ X[:, f, :]
            except:
                y_out[f, :] = S_a[f, :]

    # istft 'length' argument is critical for maintaining OLA alignment
    return sanitize(librosa.istft(y_out, hop_length=HOP_LENGTH, length=target_len))

def clean_deconvolve(y_primary, y_reference, iterations=5):
    """Radio Astronomy CLEAN: surgically peels away interference patterns."""
    p, r = sanitize(y_primary), sanitize(y_reference)
    gain = 0.5
    for _ in range(iterations):
        if np.sum(r**2) < 1e-10: break
        corr = correlate(p, r, mode='same')
        idx = np.argmax(np.abs(corr))
        scale = corr[idx] / (np.sum(r**2) + 1e-10)

        # Subtraction in time domain
        shift = idx - (len(p) // 2)
        r_shifted = np.roll(r, shift) * scale * gain
        p = p - r_shifted

    return sanitize(p)

def phase_coherence_mask(y_a, y_b):
    """Analyzes inter-channel phase synchronization to identify human speech."""
    target_len = len(y_a)
    S_a = librosa.stft(sanitize(y_a), n_fft=N_FFT, hop_length=HOP_LENGTH)
    S_b = librosa.stft(sanitize(y_b), n_fft=N_FFT, hop_length=HOP_LENGTH)

    mag_a, mag_b = np.abs(S_a), np.abs(S_b)
    cross = S_a * S_b.conj()

    with np.errstate(divide='ignore', invalid='ignore'):
        power_a = uniform_filter1d(mag_a**2, size=5, axis=1)
        power_b = uniform_filter1d(mag_b**2, size=5, axis=1)
        # Numerical protection: abs() inside sqrt avoids negative roots
        coh = np.abs(cross) / (np.sqrt(np.abs(power_a * power_b)) + 1e-10)
        mask = np.clip(np.nan_to_num(coh), 0.1, 1.0)

    return sanitize(librosa.istft(S_a * mask, hop_length=HOP_LENGTH, length=target_len))

# --------------------------------------------------------------------------
# TIMELINE & SOURCE PREFERENCE
# --------------------------------------------------------------------------

def score_source_type(label):
    """
    Priority scoring logic:
    - 'amp' (+32dB raw) is preferred (100)
    - 'enhanced' is medium (50)
    - 'ampamp' is penalized (5) due to reported harmonic distortion
    - 'original' is backup (10)
    """
    l = str(label).lower()
    if 'ampamp' in l:    return 5
    if 'amp' in l:       return 100
    if 'enhanced' in l:  return 50
    return 10

def load_timeline(yaml_path):
    with open(yaml_path, 'r') as f:
        config = yaml.safe_load(f)

    raw_entries = config.get('files', [])
    streams = {}

    for entry in raw_entries:
        path = entry['path']
        label = entry.get('type', '')
        start_ts = entry['start']

        # Categorize by Cam (Simplified CamA / CamB logic)
        cam_id = 'B' if 'CamB' in label or '(1)' in path else 'A'

        try:
            dt = datetime.strptime(start_ts, '%Y-%m-%d %H:%M:%S')
            if dt not in streams: streams[dt] = {'A': [], 'B': []}
            entry['priority'] = score_source_type(label)
            streams[dt][cam_id].append(entry)
        except:
            continue

    # Sort files by priority at each timestamp
    for dt in streams:
        streams[dt]['A'].sort(key=lambda x: x['priority'], reverse=True)
        streams[dt]['B'].sort(key=lambda x: x['priority'], reverse=True)

    return streams, sorted(streams.keys())

# --------------------------------------------------------------------------
# MAIN PROCESSING LOOP
# --------------------------------------------------------------------------

def process(yaml_path, output_path):
    streams, times = load_timeline(yaml_path)
    if not times: return

    t_start = times[0]
    # Estimate total duration
    t_end = times[-1] + timedelta(hours=1)
    total_sec = (t_end - t_start).total_seconds()

    print(f"=== Dual-Feed Forensic Master v2.4 ===")
    print(f"Selection Monitor: ACTIVE")
    print(f"Forensic Filter  : 8th Order LPF @ {CUTOFF_HZ}Hz")

    hop_sec = BLOCK_SEC * HOP_FRAC
    hop_samples, block_samples = int(hop_sec * SR), int(BLOCK_SEC * SR)
    ola_buf = np.zeros(block_samples * 2)
    win = get_window('hann', block_samples)

    t = t_start
    last_a_path = last_b_path = None
    blocks_processed = 0

    with sf.SoundFile(output_path, mode='w', samplerate=SR, channels=1) as out_f:
        while t < t_end:
            y_a, y_b = np.zeros(block_samples), np.zeros(block_samples)
            active_a = active_b = None

            # Fetch candidates covering current timestamp
            for ts in times:
                if ts <= t < ts + timedelta(hours=1):
                    if streams[ts]['A']: active_a = streams[ts]['A'][0]
                    if streams[ts]['B']: active_b = streams[ts]['B'][0]

            # SELECTION MONITOR: Real-time source visibility
            if active_a and active_a['path'] != last_a_path:
                print(f"\n[{t:%H:%M:%S}] CamA switch -> {os.path.basename(active_a['path'])} (Prio: {active_a['priority']})")
                last_a_path = active_a['path']
            if active_b and active_b['path'] != last_b_path:
                print(f"\n[{t:%H:%M:%S}] CamB switch -> {os.path.basename(active_b['path'])} (Prio: {active_b['priority']})")
                last_b_path = active_b['path']

            # Load and Apply Low-Pass Filtering immediately
            if active_a:
                offset = (t - datetime.strptime(active_a['start'], '%Y-%m-%d %H:%M:%S')).total_seconds()
                try:
                    y_r, _ = librosa.load(active_a['path'], sr=SR, offset=offset, duration=BLOCK_SEC)
                    y_a[:len(y_r)] = forensic_lowpass_filter(y_r)
                except: pass

            if active_b:
                offset = (t - datetime.strptime(active_b['start'], '%Y-%m-%d %H:%M:%S')).total_seconds()
                try:
                    y_r, _ = librosa.load(active_b['path'], sr=SR, offset=offset, duration=BLOCK_SEC)
                    y_b[:len(y_r)] = forensic_lowpass_filter(y_r)
                except: pass

            # Forensic DSP Chain
            if np.any(y_a) or np.any(y_b):
                y_b_aligned = cross_ambiguity_align(y_a, y_b)
                y_beam = mvdr_beamform(y_a, y_b_aligned)
                y_clean = clean_deconvolve(y_beam, y_b_aligned)
                y_final = phase_coherence_mask(y_clean, y_b_aligned)
                ola_buf[:block_samples] += sanitize(y_final * win)

            # Write reconstruction to disk
            out_f.write(librosa.util.normalize(ola_buf[:hop_samples]))

            # Overlap-Add Shift
            ola_buf[:block_samples] = ola_buf[hop_samples:hop_samples+block_samples]
            ola_buf[block_samples:] = 0

            blocks_processed += 1
            t += timedelta(seconds=hop_sec)

            if blocks_processed % 10 == 0:
                elapsed = (t - t_start).total_seconds()
                pct = min(100.0, 100 * elapsed / total_sec)
                print(f"  [{pct:5.1f}%] {t:%H:%M:%S} blocks={blocks_processed}", end='\r')

    print(f"\n\n=== Process Complete ===\nOutput: {output_path}")

    # Register generated master back into the project YAML
    try:
        with open(yaml_path, 'r') as f: config = yaml.safe_load(f)
        new_entry = {
            'path': output_path,
            'start': t_start.strftime('%Y-%m-%d %H:%M:%S'),
            'type': 'Dual-Feed Filtered Master'
        }
        exists = False
        if 'files' in config:
            for entry in config['files']:
                if entry.get('path') == output_path:
                    entry['start'] = new_entry['start']; entry['type'] = new_entry['type']
                    exists = True; break
        else: config['files'] = []
        if not exists: config['files'].append(new_entry)
        with open(yaml_path, 'w') as f: yaml.dump(config, f, default_flow_style=False, sort_keys=False)
        print(f"Successfully updated YAML project file: {yaml_path}")
    except Exception as e:
        print(f"Error registering master in YAML: {e}")

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--config', default='rehab.yaml')
    parser.add_argument('--out', default='rehab_dual_master.ogg')
    args = parser.parse_args()
    if os.path.exists(args.config):
        process(args.config, args.out)
