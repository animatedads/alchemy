#!/usr/bin/env python3

import yaml
import subprocess
import json
import os
from datetime import datetime

OPENAI_KEY_FILE = "openai_key.txt"


class Track:

    def __init__(self, path, start, type_):
        self.path = path
        self.start = datetime.strptime(start, "%Y-%m-%d %H:%M:%S")
        self.type = type_

        self.camera = self.detect_camera()
        self.metrics = {}
        self.score = 0

    def detect_camera(self):

        t = self.type.lower()
        p = self.path.lower()

        if "(a)" in t:
            return "A"

        if "(b)" in t:
            return "B"

        if "_tp0000" in p:
            return "A"

        if "_tp0002" in p or "_tp0003" in p:
            return "B"

        if "raw_sync_a_b" in p:
            return "AB"

        return "?"



def load_tracks(yaml_file):

    with open(yaml_file) as f:
        data = yaml.safe_load(f)

    tracks = []

    for f in data["files"]:

        path = f["path"]

        if not os.path.exists(path):
            continue

        if not path.endswith((".ogg",".wav",".flac")):
            continue

        tracks.append(
            Track(path, f["start"], f["type"])
        )

    return tracks


def audio_metrics(path):

    cmd = [
        "ffmpeg",
        "-i", path,
        "-af", "volumedetect",
        "-f", "null",
        "-"
    ]

    p = subprocess.run(
        cmd,
        stderr=subprocess.PIPE,
        stdout=subprocess.PIPE,
        text=True
    )

    out = p.stderr

    peak = -100
    mean = -100

    for line in out.splitlines():

        if "max_volume:" in line:
            peak = float(line.split("max_volume:")[1].split(" dB")[0])

        if "mean_volume:" in line:
            mean = float(line.split("mean_volume:")[1].split(" dB")[0])

    return {
        "peak": peak,
        "mean": mean
    }


def score_track(track):

    m = track.metrics

    score = 0

    score += max(0, 60 + m["peak"])
    score += max(0, 40 + m["mean"])

    p = track.path.lower()

    if "ampamp" in p:
        score += 30

    elif "amp" in p:
        score += 20

    if "enhanced" in p:
        score += 15

    if "denoised" in track.type.lower():
        score += 20

    if "dual_master" in p:
        score -= 200

    if "ai master" in track.type.lower():
        score -= 200

    return score


def analyse_tracks(tracks):

    print("[forge] analysing audio behaviour")

    for t in tracks:

        t.metrics = audio_metrics(t.path)

        t.score = score_track(t)

        print(
            t.path,
            "camera:", t.camera,
            "peak:", t.metrics["peak"],
            "mean:", t.metrics["mean"],
            "score:", t.score
        )


def build_segments(tracks):

    times = set()

    for t in tracks:
        times.add(t.start)

    return sorted(times)


def choose_best(candidates):

    candidates.sort(key=lambda x: x.score, reverse=True)

    return candidates[0]


def build_plan(tracks):

    segments = build_segments(tracks)

    plan = []

    for t in segments:

        window = []

        for tr in tracks:
            if tr.start == t:
                window.append(tr)

        if not window:
            continue

        best = choose_best(window)

        plan.append(best)

    return plan


def print_plan(plan):

    print("\n[forge] final coverage plan\n")

    for p in plan:

        print(
            p.start,
            "camera:", p.camera,
            "score:", p.score,
            p.path
        )


def main():

    import sys

    if len(sys.argv) < 2:
        print("usage: forge_track_plan.py project.yaml")
        return

    yaml_file = sys.argv[1]

    tracks = load_tracks(yaml_file)

    print("[forge] loaded", len(tracks), "audio tracks")

    analyse_tracks(tracks)

    plan = build_plan(tracks)

    print_plan(plan)


if __name__ == "__main__":
    main()
