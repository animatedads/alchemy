import os, sys, yaml, json, librosa, numpy as np, soundfile as sf
from datetime import datetime
from scipy.ndimage import uniform_filter1d
import warnings

# Suppress librosa/PySoundFile warnings from flooding the terminal
warnings.filterwarnings('ignore')

def compile_master_track(yaml_path):
    if not os.path.exists(yaml_path):
        print(f"Error: Project file '{yaml_path}' not found.")
        return

    project_name = os.path.splitext(os.path.basename(yaml_path))[0]
    model_path = f"{project_name}_trained_model.json"

    if not os.path.exists(model_path):
        print(f"Error: Trained model '{model_path}' not found. Run the AI Trainer first.")
        return

    # 1. Load Configurations
    with open(yaml_path, 'r') as f: config = yaml.safe_load(f)
    with open(model_path, 'r') as f:
        ai_model = json.load(f)
        params = ai_model.get('params', {})

    print(f"--- Compiling AI Master Track for {project_name} ---")
    print(f"Optimal Weights -> Window: {params.get('window_size', 5)}, Noise: {params.get('noise_floor', 1.5)}x, Pitch: {params.get('pitch_shift', 0.0)}, Overlay: {params.get('overlay', 0.4)}")

    # 2. Map the Chronological Timeline
    timeline = []
    for entry in config.get('files', []):
        entry_type = entry.get('type', '')
        if 'Original' in entry_type or 'Raw' in entry_type or entry_type == '':
            if 'Amp' not in entry_type and 'Enhanced' not in entry_type:
                try:
                    dt = datetime.strptime(entry['start'], '%Y-%m-%d %H:%M:%S')
                    timeline.append({'path': entry['path'], 'start': dt})
                except:
                    pass

    if not timeline:
        print("Error: No valid source files found in YAML.")
        return

    timeline.sort(key=lambda x: x['start'])
    master_out_path = f"{project_name}_AI_Master.ogg"
    global_start_time = timeline[0]['start']

    # Grab the true native sample rate from the first file to prevent slow-down bugs
    try: native_sample_rate = sf.info(timeline[0]['path']).samplerate
    except: native_sample_rate = 44100

    print(f"\nInitializing Master Output: {master_out_path} at {native_sample_rate}Hz")

    # 3. Stream and Splice
    with sf.SoundFile(master_out_path, mode='w', samplerate=native_sample_rate, channels=1) as out_f:
        for i, current_file in enumerate(timeline):
            filepath = current_file['path']
            if not os.path.exists(filepath): continue

            try: file_duration = sf.info(filepath).duration
            except: file_duration = 1724.0

            if i + 1 < len(timeline):
                next_start = timeline[i+1]['start']
                process_duration = min(file_duration, (next_start - current_file['start']).total_seconds())
            else:
                process_duration = file_duration

            if process_duration <= 0: continue

            print(f"\n>> Splicing Source: {os.path.basename(filepath)} (Active: {process_duration/60:.1f}m)")
            print("   Calibrating room acoustics...")

            # Dynamic Noise Floor calibration for THIS specific file segment
            y_sample, _ = librosa.load(filepath, sr=native_sample_rate, duration=min(60, process_duration))
            mag_sample, _ = librosa.magphase(librosa.stft(y_sample))
            noise_mask = np.median(mag_sample, axis=1, keepdims=True)
            del y_sample, mag_sample

            # Stream Processing (Block-by-Block)
            block_samples = int(30 * native_sample_rate)
            total_samples = int(process_duration * native_sample_rate)
            samples_processed = 0

            for block in sf.blocks(filepath, blocksize=block_samples):
                if samples_processed >= total_samples: break

                # Trim the final block exactly to the camera switch marker
                if samples_processed + len(block) > total_samples:
                    block = block[:total_samples - samples_processed]

                if len(block.shape) > 1: block = librosa.to_mono(block.T)

                # --- APPLY AI EVOLVED PARAMETERS ---
                mag, phase = librosa.magphase(librosa.stft(block))
                mag_c = np.maximum(mag - (noise_mask * params.get('noise_floor', 1.5)), mag * params.get('alpha', 0.1))
                y_c = librosa.istft(mag_c * phase)
                y_s = uniform_filter1d(y_c, size=max(1, int(params.get('window_size', 5))))

                min_len = min(len(block), len(y_s))
                overlay = params.get('overlay', 0.4)
                y_f = (block[:min_len] * overlay) + (y_s[:min_len] * (1 - overlay))

                # --- APPLY AI PITCH SHIFT ---
                pitch = params.get('pitch_shift', 0.0)
                if pitch != 0.0:
                    y_f = librosa.effects.pitch_shift(y_f, sr=native_sample_rate, n_steps=pitch)

                # Block-level normalization
                out_f.write(librosa.util.normalize(y_f))
                samples_processed += len(block)
                print(f"   Streaming: {samples_processed/native_sample_rate/60:.1f}m / {process_duration/60:.1f}m...", end='\r')

    # 4. Update the YAML Configuration
    print(f"\n\n--- Updating Project Configuration ---")
    track_exists = False
    for entry in config.get('files', []):
        if entry.get('type', '') == 'AI Optimized Master':
            entry['path'] = master_out_path
            entry['start'] = global_start_time.strftime('%Y-%m-%d %H:%M:%S')
            track_exists = True
            break

    if not track_exists:
        config.setdefault('files', []).append({
            'path': master_out_path,
            'start': global_start_time.strftime('%Y-%m-%d %H:%M:%S'),
            'type': 'AI Optimized Master'
        })

    with open(yaml_path, 'w') as f: yaml.dump(config, f, default_flow_style=False, sort_keys=False)
    print(f"Mission Complete. '{master_out_path}' is ready for review.")

if __name__ == "__main__":
    if len(sys.argv) < 2: print("Usage: python compile_ai_track.py <project.yaml>")
    else: compile_master_track(sys.argv[1])
