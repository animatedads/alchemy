import numpy as np
import librosa
import soundfile as sf
from scipy.ndimage import uniform_filter1d
import os

def enhance_large_audio(input_file, output_file, block_size_sec=60, moving_avg_window=5, overlay_ratio=0.4):
    """
    Modified forensic process to handle large (2h+) files using block-based streaming.
    """
    # 1. Inspect file metadata
    info = sf.info(input_file)
    sr = info.samplerate
    # We'll process in 60-second blocks to balance speed and memory
    block_samples = int(block_size_sec * sr)

    print(f"--- Forensic Processing Started: {input_file} ---")
    print(f"Total Duration: {info.duration/3600:.2f} hours")

    # 2. STEP 1: Representative Noise Estimation (The "Guessing" Part)
    # Instead of scanning 2 hours (which takes too long), we sample a 2-minute
    # portion from the start to create a global spectral noise mask.
    print("Phase 1: Estimating noise floor from initial sample...")
    sample_dur = min(120, info.duration)
    y_sample, _ = librosa.load(input_file, sr=sr, duration=sample_dur)

    stft_sample = librosa.stft(y_sample)
    mag_sample, _ = librosa.magphase(stft_sample)
    rms_sample = librosa.feature.rms(S=mag_sample)[0]

    noise_threshold_val = np.percentile(rms_sample, 10)
    noise_frames = np.where(rms_sample <= noise_threshold_val)[0]

    if len(noise_frames) > 0:
        noise_mask = mag_sample[:, noise_frames].mean(axis=1, keepdims=True)
    else:
        noise_mask = np.median(mag_sample, axis=1, keepdims=True)

    # Cleanup memory from phase 1
    del y_sample, stft_sample, mag_sample

    # 3. STEP 2: Block-based Streaming
    print(f"Phase 2: Streaming audio in {block_size_sec}s blocks...")

    # Create output file handle
    # We output as mono to keep the process consistent with CCTV forensic standards
    with sf.SoundFile(output_file, mode='w', samplerate=sr, channels=1) as out_f:
        # Use sf.blocks to read without loading the whole file
        for block in sf.blocks(input_file, blocksize=block_samples):

            # Ensure block is mono
            if len(block.shape) > 1:
                block = librosa.to_mono(block.T)

            # --- AUDIO PROCESS (Identical to your original testaudio.py) ---
            stft = librosa.stft(block)
            magnitude, phase = librosa.magphase(stft)

            # Spectral subtraction (with 10% floor)
            magnitude_clean = np.maximum(magnitude - (noise_mask * 1.5), magnitude * 0.1)
            y_spectral = librosa.istft(magnitude_clean * phase)

            # Temporal smoothing (Radar-style integration)
            y_smoothed = uniform_filter1d(y_spectral, size=moving_avg_window)

            # Parallel Overlay
            min_len = min(len(block), len(y_smoothed))
            y_final = (block[:min_len] * overlay_ratio) + (y_smoothed[:min_len] * (1 - overlay_ratio))

            # Normalization (Per block to avoid clipping)
            y_final = librosa.util.normalize(y_final)

            # Write block to disk
            out_f.write(y_final)

            # Simple progress tracker
            print(f"  Processed block {out_f.tell()/sr/60:.1f} minutes...", end='\r')

    print(f"\n--- Process Complete: {output_file} ---")

if __name__ == "__main__":
    # Update these filenames as needed
    IN_FILE = "20231010_125918_tp00008amp.ogg"
    OUT_FILE = "enhanced_evidence_20231010_125918_tp00008amp.wav"

    if os.path.exists(IN_FILE):
        enhance_large_audio(IN_FILE, OUT_FILE)
    else:
        print(f"Error: {IN_FILE} not found.")
