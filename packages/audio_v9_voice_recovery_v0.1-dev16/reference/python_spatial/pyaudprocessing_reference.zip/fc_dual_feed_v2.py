import os
import argparse
import yaml
import numpy as np
import soundfile as sf
import librosa
from datetime import datetime, timedelta
from scipy.fftpack import fft, ifft

# ---------------------------------------------------------------------
# DSP HELPERS
# ---------------------------------------------------------------------

class SpectralEnhancer:
    def __init__(self, sr, n_fft=2048):
        self.sr = sr
        self.n_fft = n_fft
        self.noise_thresh = 0.02

    def process(self, y):
        if y is None or len(y) < self.n_fft: return y
        S = librosa.stft(y, n_fft=self.n_fft)
        S_abs = np.abs(S)
        S_phase = np.angle(S)

        # Estimate noise from lowest 10% energy frames
        noise_mu = np.mean(np.sort(S_abs, axis=1)[:, :max(1, int(S.shape[1]*0.1))], axis=1, keepdims=True)

        S_clean = np.maximum(S_abs - 2.0 * noise_mu, self.noise_thresh * S_abs)
        return librosa.istft(S_clean * np.exp(1j * S_phase))

def gcc_phat_align(sig, refsig, fs=22050, max_tau=0.15):
    """Align sig to refsig using GCC-PHAT."""
    n = sig.shape[0] + refsig.shape[0]
    SIG = fft(sig, n=n)
    REFSIG = fft(refsig, n=n)
    R = SIG * np.conj(REFSIG)

    # GCC-PHAT math
    denom = np.maximum(np.abs(R), 1e-6)
    cc = np.real(ifft(R / denom))

    max_shift = int(max_tau * fs)
    # Center the cross-correlation
    cc = np.concatenate((cc[-max_shift:], cc[:max_shift+1]))
    shift = np.argmax(cc) - max_shift

    return np.roll(sig, shift)

# ---------------------------------------------------------------------
# CORE TIMELINE ENGINE
# ---------------------------------------------------------------------

def parse_dt(s):
    """Flexible datetime parsing for YYYY-MM-DD HH:MM:SS, HH:MM, or Date-only."""
    formats = ['%Y-%m-%d %H:%M:%S', '%Y-%m-%d %H:%M', '%Y-%m-%d']
    for fmt in formats:
        try:
            return datetime.strptime(s.strip(), fmt)
        except ValueError:
            continue
    raise ValueError(f"Time data '{s}' does not match recognized formats (YYYY-MM-DD HH:MM:SS, HH:MM, or Date)")

def find_file_for_time(files, target_type, t):
    for f in files:
        if f.get('type') == target_type:
            start = parse_dt(f['start'])
            # Most clips are 32m or 70m. 4 hours is a safe overlap search window.
            if start <= t < (start + timedelta(hours=4)):
                return f
    return None

def load_audio_segment(path, start_dt, target_t, duration_sec, sr=22050):
    offset = (target_t - start_dt).total_seconds()
    if offset < 0: return None

    try:
        # Check duration with librosa to avoid seeking past EOF
        file_dur = librosa.get_duration(path=path)
        if offset >= file_dur: return None

        y, _ = librosa.load(path, sr=sr, offset=offset, duration=duration_sec)

        target_len = int(duration_sec * sr)
        if len(y) < target_len:
            y = np.pad(y, (0, target_len - len(y)))
        return y
    except Exception:
        return None

# ---------------------------------------------------------------------
# MAIN PROCESSOR
# ---------------------------------------------------------------------

def run_pipeline(yaml_path, mode, start_time, end_time, out_path):
    with open(yaml_path, 'r') as f:
        config = yaml.safe_load(f)

    modes = {
        "plus20": ("Enhanced Amp +20dB (Ogg Q10)", "FD Feed (Enhanced +20dB)"),
        "amp32": ("Raw Amp +32dB (Ogg Q10)", "FD Feed (Raw Amp +32dB)"),
        "enhanced": ("Enhanced (Ogg Q10)", "FD Feed (Enhanced)")
    }
    type_a, type_b = modes[mode]

    sr = 22050
    block_sec = 8.0
    enhancer = SpectralEnhancer(sr)

    print(f"[*] Processing: {start_time} to {end_time}")
    print(f"[*] Mode: {mode}")

    with sf.SoundFile(out_path, mode='w', samplerate=sr, channels=2) as out:
        current_t = start_time
        while current_t < end_time:
            file_a = find_file_for_time(config['files'], type_a, current_t)
            file_b = find_file_for_time(config['files'], type_b, current_t)

            y_a = load_audio_segment(file_a['path'], parse_dt(file_a['start']), current_t, block_sec, sr) if file_a else None
            y_b = load_audio_segment(file_b['path'], parse_dt(file_b['start']), current_t, block_sec, sr) if file_b else None

            # Logic for Dual vs Mono vs Silence
            if y_a is not None and y_b is not None:
                # Denoise -> Align -> Combine
                y_a_clean = enhancer.process(y_a)
                y_b_clean = enhancer.process(y_b)
                y_a_aligned = gcc_phat_align(y_a_clean, y_b_clean, fs=sr)
                chunk = np.vstack((y_a_aligned, y_b_clean)).T

            elif y_a is not None:
                y_a_clean = enhancer.process(y_a)
                chunk = np.vstack((y_a_clean, y_a_clean)).T

            elif y_b is not None:
                y_b_clean = enhancer.process(y_b)
                chunk = np.vstack((y_b_clean, y_b_clean)).T

            else:
                chunk = np.zeros((int(block_sec * sr), 2))

            out.write(chunk)
            current_t += timedelta(seconds=block_sec)
            print(f" Progress: {current_t}", end="\r")

    print(f"\n[!] Complete: {out_path}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--yaml", required=True)
    parser.add_argument("--mode", required=True, choices=["plus20", "amp32", "enhanced"])
    parser.add_argument("--start", help="YYYY-MM-DD HH:MM:SS or YYYY-MM-DD HH:MM")
    parser.add_argument("--end", help="YYYY-MM-DD HH:MM:SS or YYYY-MM-DD HH:MM")
    parser.add_argument("--out", default="fc_enhanced_output.wav")
    args = parser.parse_args()

    with open(args.yaml, 'r') as f:
        cfg = yaml.safe_load(f)

    all_starts = sorted([parse_dt(f['start']) for f in cfg['files']])
    t0 = parse_dt(args.start) if args.start else all_starts[0]
    t1 = parse_dt(args.end) if args.end else (all_starts[-1] + timedelta(minutes=32))

    run_pipeline(args.yaml, args.mode, t0, t1, args.out)
