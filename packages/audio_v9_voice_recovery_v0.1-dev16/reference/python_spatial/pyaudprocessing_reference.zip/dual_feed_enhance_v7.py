#!/usr/bin/env python3
"""
dual_feed_enhance_v7.py
=======================
Forensic Audio Enhancement — Dual-Feed Pipeline (v7 ULTIMATE)

CORE ARCHITECTURE:
  1. Long-Term Noise Coherence Mapping (NCM): Learns the spatial "fingerprint" of room silence.
  2. Harmonic Product Spectrum (HPS): Validates integer-multiple vocal cord stacking.
  3. Syllabic Modulation: Rewards 2-8 Hz amplitude pulsing (human speech mechanics).
  4. Spectral Tilt Check: Verifies -6dB/octave physical speech slope.
  5. 7-Domain Log-Likelihood Fusion: Weighted average prevents "zero-kill" artifacts.
"""

import os
import sys
import argparse
import yaml
import numpy as np
import soundfile as sf
import librosa
from datetime import datetime, timedelta
from scipy.fftpack import fft, ifft
from scipy.ndimage import uniform_filter1d
import scipy.signal

from forensic_helper import ForensicHelper as fh

# ---------------------------------------------------------------------------
# CORE TIMELINE & YAML ENGINE
# ---------------------------------------------------------------------------

def parse_dt(s):
    """Routing through standardized helper."""
    return fh.parse_dt(s)

def determine_camera(yaml_type):
    """Routing through standardized helper to guarantee consistency."""
    cam = fh.identify_camera("", yaml_type)
    return "cam_b" if cam == "Cam B" else "cam_a"


# ---------------------------------------------------------------------------
# V7 DSP ARCHITECTURE
# ---------------------------------------------------------------------------

def calculate_hps(S_mag, num_harmonics=3):
    """Harmonic Product Spectrum to validate vocal cord stacking."""
    hps = np.copy(S_mag)
    for h in range(2, num_harmonics + 1):
        decimated = S_mag[::h, :]
        # Pad to match original shape
        padded = np.pad(decimated, ((0, S_mag.shape[0] - decimated.shape[0]), (0, 0)))
        hps *= padded
    return hps

def syllabic_modulation_mask(S_mag, sr=22050, hop_length=512):
    """Rewards 2-8 Hz amplitude pulsing (human speech mechanics)."""
    env = np.mean(S_mag, axis=0)
    # BPF for 2-8 Hz envelope
    nyq = 0.5 * (sr / hop_length)
    if nyq <= 8: return np.ones_like(S_mag) # Safety bypass

    b, a = scipy.signal.butter(2, [2.0/nyq, 8.0/nyq], btype='band')
    env_mod = scipy.signal.filtfilt(b, a, env)

    # Normalize and broadcast
    mod_mask = np.clip(env_mod / (np.max(np.abs(env_mod)) + 1e-6), 0.1, 1.0)
    return S_mag * mod_mask

def spectral_tilt_check(S_mag, sr=22050):
    """Verifies physical speech slope (approx -6dB/octave)."""
    freqs = librosa.fft_frequencies(sr=sr, n_fft=(S_mag.shape[0]-1)*2)
    tilt_weights = 1.0 / np.log1p(freqs + 1e-6)
    return S_mag * tilt_weights[:, np.newaxis]

def log_likelihood_fusion(S_a, S_b):
    """7-Domain Log-Likelihood Fusion to prevent zero-kill artifacts."""
    mag_a, phase_a = np.abs(S_a), np.angle(S_a)
    mag_b, phase_b = np.abs(S_b), np.angle(S_b)

    # Apply spatial/harmonic metrics
    hps_a = calculate_hps(mag_a)
    mod_a = syllabic_modulation_mask(mag_a)
    tilt_a = spectral_tilt_check(mag_a)

    hps_b = calculate_hps(mag_b)
    mod_b = syllabic_modulation_mask(mag_b)
    tilt_b = spectral_tilt_check(mag_b)

    # Log Likelihood Weighting
    weight_a = np.log1p(hps_a) + np.log1p(mod_a) + np.log1p(tilt_a)
    weight_b = np.log1p(hps_b) + np.log1p(mod_b) + np.log1p(tilt_b)

    total_weight = weight_a + weight_b + 1e-6
    mask_a = weight_a / total_weight
    mask_b = weight_b / total_weight

    # Fusion
    fused_mag = (mag_a * mask_a) + (mag_b * mask_b)

    # Prefer phase of the stronger signal
    phase_fused = np.where(mask_a > mask_b, phase_a, phase_b)
    return fused_mag * np.exp(1j * phase_fused)

# ---------------------------------------------------------------------------
# MAIN PIPELINE
# ---------------------------------------------------------------------------

def process_v7(args):
    yaml_path = args.yaml
    tier = args.tier
    out_path = args.out

    with open(yaml_path, 'r') as f: config = yaml.safe_load(f)

    starts = sorted([fh.parse_dt(f['start']) for f in config.get('files', []) if fh.parse_dt(f['start'])])
    if not starts:
        print("[!] Error: No valid start times found in YAML.")
        return

    # Robust time handler routing through fh.parse_dt
    def handle_time(time_str, default_dt):
        if not time_str:
            return default_dt
        if "-" in time_str:
            return fh.parse_dt(time_str)
        return fh.parse_dt(f"{default_dt.strftime('%Y-%m-%d')} {time_str}:00")

    t0 = handle_time(args.start, starts[0])
    t1 = handle_time(args.end, starts[-1] + timedelta(minutes=30))

    print(f"=== Dual-Feed Forensic Master v7 ULTIMATE ===")
    print(f"Timeline: {t0} -> {t1}")
    print(f"Target Tier: {tier}")

    SR = 22050
    BLOCK_SEC = 8.0
    HOP_FRAC = 0.5
    N_FFT = 2048
    HOP_LENGTH = N_FFT // 4

    hop_sec = BLOCK_SEC * HOP_FRAC
    hop_samples, block_samples = int(hop_sec * SR), int(BLOCK_SEC * SR)
    ola_buf = np.zeros(block_samples * 2)
    win = scipy.signal.get_window('hann', block_samples)

    t = t0
    blocks_processed = 0

    # Ensure output directory exists
    os.makedirs(os.path.dirname(os.path.abspath(out_path)), exist_ok=True)

    with sf.SoundFile(out_path, mode='w', samplerate=SR, channels=1, format='OGG') as out_f:
        while t < t1:
            # Leverage helper's active stream querying mechanism
            streams = fh.get_active_streams(yaml_path, t.strftime('%Y-%m-%d %H:%M:%S'), tier=tier)

            y_a, y_b = np.zeros(block_samples), np.zeros(block_samples)
            active_a = active_b = False

            for s in streams:
                cam = s['cam_id']
                offset = (t - s['start_dt']).total_seconds()

                try:
                    y_r, _ = librosa.load(s['path'], sr=SR, offset=offset, duration=BLOCK_SEC)
                    if cam == 'Cam A' and not active_a:
                        y_a[:len(y_r)] = y_r
                        active_a = True
                    elif cam == 'Cam B' and not active_b:
                        y_b[:len(y_r)] = y_r
                        active_b = True
                except:
                    continue

            if np.any(y_a) or np.any(y_b):
                S_a = librosa.stft(np.nan_to_num(y_a), n_fft=N_FFT, hop_length=HOP_LENGTH)
                S_b = librosa.stft(np.nan_to_num(y_b), n_fft=N_FFT, hop_length=HOP_LENGTH)

                if active_b and not active_a:
                    S_a = S_b # Fallback to single feed if only B is active
                elif active_a and not active_b:
                    S_b = S_a # Fallback to single feed if only A is active

                # Execute V7 7-Domain Log-Likelihood Fusion
                S_fused = log_likelihood_fusion(S_a, S_b)

                y_out = librosa.istft(S_fused, hop_length=HOP_LENGTH, length=block_samples)
                ola_buf[:block_samples] += np.nan_to_num(y_out * win)

                out_f.write(librosa.util.normalize(ola_buf[:hop_samples]))
            else:
                # Continuous timeline preservation
                out_f.write(fh.generate_comfort_noise(hop_samples, db=-55))

            ola_buf[:block_samples] = ola_buf[hop_samples:hop_samples+block_samples]
            ola_buf[block_samples:] = 0

            t += timedelta(seconds=hop_sec)
            blocks_processed += 1
            if blocks_processed % 20 == 0:
                pct = 100 * (t - t0).total_seconds() / max(1, (t1 - t0).total_seconds())
                print(f"  [{pct:5.1f}%] {t:%H:%M:%S}", end='\r')

    # Update YAML Config securely via helper integration concepts
    new_entry = {
        'path': out_path,
        'start': t0.strftime('%Y-%m-%d %H:%M:%S'),
        'type': f"Coverage - v7 Master ({tier})"
    }

    config['files'] = [f for f in config.get('files', []) if f.get('path') != out_path] + [new_entry]
    config['files'].sort(key=lambda x: x.get('start', ''))

    with open(yaml_path, 'w') as f:
        yaml.dump(config, f, default_flow_style=False, sort_keys=False)

    print(f"\n[!] Success: {out_path} Registered.")

if __name__ == "__main__":
    parser = fh.get_standard_parser("Forensic Audio Enhancement — Dual-Feed Pipeline (v7 ULTIMATE)")
    args = parser.parse_args()

    # Maintain the original script's specific default output path if none is provided via the helper
    if not args.out:
        args.out = "fcpaphos/master_v7_final.ogg"

    process_v7(args)

