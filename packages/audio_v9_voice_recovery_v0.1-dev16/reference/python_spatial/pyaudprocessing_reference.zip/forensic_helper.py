import os
import sys
import time
import yaml
import shutil
import logging
import argparse
import re
import warnings
import subprocess
import threading
import hashlib
import concurrent.futures
import numpy as np
from collections import Counter
from datetime import datetime, timedelta
from functools import wraps

try:
    import soundfile as sf
    import librosa
except ImportError:
    sf = None
    librosa = None

# Standardize Logging
logging.basicConfig(level=logging.INFO, format='%(levelname)s: %(message)s')
logger = logging.getLogger("forensic")

class ForensicHelper:
    """
    Standardizes Forensic Audio Operations:
    - Camera ID logic
    - Time Parsing & Metadata Extraction
    - Timeline Querying & Stream Abstraction
    - Continuity Analysis
    - Raw Media Ingestion (Parallel Pipeline Standard)
    - Project Tidying & Directory Standardization (File Fixer Logic)
    - FFmpeg Stitching & Smart Bitrate Extraction
    - Timeline Consistency & Cam Assignment Checking
    - GMT/Local Offset Mapping & Auto-detection
    - Multi-stream Hardware Signature Fingerprinting & Discrepancy Auditing (Direct Folders & YAMLs)
    """

    _yaml_lock = threading.Lock()

    @staticmethod
    def identify_camera(path, label=""):
        """Universal Camera ID Logic: Relies strictly on YAML metadata consistency."""
        l = str(label).lower()
        if 'cam b' in l or 'camb' in l or 'fd feed' in l: return 'Cam B'
        if 'cam a' in l or 'cama' in l: return 'Cam A'
        p = str(path).lower()
        return 'Cam B' if '(1)' in p else 'Cam A'

    @staticmethod
    def get_majority_directory(yaml_path):
        """Identifies the primary project directory based on existing file locations."""
        if not os.path.exists(yaml_path):
            return os.path.dirname(os.path.abspath(yaml_path)) or '.'

        with open(yaml_path, 'r') as f:
            config = yaml.safe_load(f) or {}

        dirs = [os.path.dirname(entry.get('path', '')) for entry in config.get('files', []) if entry.get('path')]
        if not dirs:
            return os.path.dirname(os.path.abspath(yaml_path)) or '.'

        counts = Counter(dirs)
        majority_dir = counts.most_common(1)[0][0]

        return majority_dir if majority_dir else (os.path.dirname(os.path.abspath(yaml_path)) or '.')


    @staticmethod
    def _get_api_key(provider="gemini"):
        """Retrieves the API key for the requested AI provider."""
        key_file = f"{provider}_key.txt"
        if provider == "openai":
            key_file = "openai_key.txt"
        elif provider == "deepthought":
            key_file = "deepthought_key.txt"

        try:
            with open(key_file, "r") as f:
                return f.read().strip()
        except:
            print(f"    [!] Warning: Missing API key file: {key_file}")
            return ""

    @staticmethod
    def consult_ai(prompt, provider="gemini", image_b64=None, audio_b64=None, json_mode=False):
        """
        Universal AI router supporting Gemini, OpenAI (ChatGPT), and DeepThought.
        Handles formatting, payload structures, and exponential backoff.
        """
        import requests
        import json
        import time

        api_key = ForensicHelper._get_api_key(provider)
        if not api_key:
            return None

        for attempt in range(5):
            try:
                if provider == "gemini":
                    url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-preview-09-2025:generateContent?key={api_key}"
                    parts = [{"text": prompt}]
                    if image_b64:
                        parts.append({"inlineData": {"mimeType": "image/png", "data": image_b64}})
                    if audio_b64:
                        parts.append({"inlineData": {"mimeType": "audio/wav", "data": audio_b64}})

                    payload = {"contents": [{"role": "user", "parts": parts}]}
                    if json_mode:
                        payload["generationConfig"] = {"responseMimeType": "application/json"}

                    r = requests.post(url, json=payload, timeout=45)
                    res = r.json()
                    if 'error' in res: raise Exception(res['error'].get('message', 'API Error'))

                    text = res['candidates'][0]['content']['parts'][0]['text']
                    if json_mode:
                        text = text.replace("```json", "").replace("```", "").strip()
                        return json.loads(text)
                    return text

                elif provider == "openai":
                    url = "https://api.openai.com/v1/chat/completions"
                    headers = {"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"}

                    content = [{"type": "text", "text": prompt}]
                    if image_b64:
                        content.append({"type": "image_url", "image_url": {"url": f"data:image/png;base64,{image_b64}"}})

                    payload = {
                        "model": "gpt-4o",
                        "messages": [{"role": "user", "content": content}],
                        "temperature": 0.2
                    }
                    if json_mode:
                        payload["response_format"] = {"type": "json_object"}

                    r = requests.post(url, headers=headers, json=payload, timeout=45)
                    res = r.json()
                    if 'error' in res: raise Exception(res['error'].get('message', 'API Error'))

                    text = res['choices'][0]['message']['content']
                    if json_mode:
                        return json.loads(text)
                    return text

                elif provider == "deepthought":
                    # Drop-in compatible structure for DeepThought/DeepSeek standard REST endpoints
                    url = "https://api.deepthought.ai/v1/chat/completions"
                    headers = {"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"}

                    payload = {
                        "model": "deepthought-core",
                        "messages": [{"role": "user", "content": prompt}],
                        "temperature": 0.1
                    }

                    r = requests.post(url, headers=headers, json=payload, timeout=45)
                    res = r.json()
                    if 'error' in res: raise Exception(res['error'].get('message', 'API Error'))

                    text = res['choices'][0]['message']['content']
                    if json_mode:
                        text = text.replace("```json", "").replace("```", "").strip()
                        return json.loads(text)
                    return text

            except Exception as e:
                if attempt == 4:
                    print(f"    [!] {provider.upper()} API Error: {e}")
                    return None
                time.sleep(2 ** attempt)

    @staticmethod
    def consult_ai_for_filters(events, project_id, provider="gemini"):
        """Sends collected peak noise events to AI to build a time-dependent filter map."""
        import json
        map_file = f"{project_id}_dynamic_filters.json"
        if not events: return

        print(f"\n[*] Sending {len(events)} acoustic anomalies to {provider.upper()} for classification...")

        condensed_log = []
        for e in events[:100]:
            condensed_log.append(f"Time: {e['time']}, PeakHz: {e['hz']:.1f}, MagnitudeRatio: {e['mag_ratio']:.1f}x")

        prompt = (
            "You are an AI Forensic Audio Filter Specialist. I have detected unusual spectral anomalies (transients) "
            "during a surveillance recording. Below is the event log (Time, Peak Freq in Hz, Magnitude Ratio over noise floor).\n\n"
            "Characteristics:\n- Alarms/Sirens: Tonal, narrow peaks (usually 1000Hz - 4000Hz).\n"
            "- Cars/Engines: Broadband low-frequency rumble (usually < 250Hz).\n"
            "- Cats/Animals: Harmonic sweeps (usually 500Hz - 1500Hz).\n\n"
            "TASK: Analyze the log and map them to targeted filters. Return ONLY a valid JSON dictionary where the keys are the exact timestamps, "
            "and the values are objects specifying the filter. Example format:\n"
            "{\n"
            "  \"2023-10-10 10:11:34\": {\"type\": \"alarm\", \"action\": \"notch\", \"freq_hz\": 2500, \"q\": 30},\n"
            "  \"2023-10-10 10:12:05\": {\"type\": \"car\", \"action\": \"highpass\", \"freq_hz\": 200}\n"
            "}\n\nEvent Log:\n" + "\n".join(condensed_log)
        )

        filter_map = ForensicHelper.consult_ai(prompt, provider=provider, json_mode=True)
        if filter_map:
            with open(map_file, 'w') as f:
                json.dump(filter_map, f, indent=4)
            print(f"    [+] {provider.upper()} Filter Map generated: {len(filter_map)} dynamic rules created.")
        else:
            print("    [!] Saving raw event log instead due to API failure.")
            with open(map_file, 'w') as f: json.dump(events, f, indent=4)

    @staticmethod
    def analyze_spectral_map(filename, label, img_b64, audio_b64=None, provider="openai"):
        """Sends visual acoustic data to AI to generate enhancement strategies."""
        prompt = (
            f"You are an Elite Forensic Audio Engineer. I have provided a Spectral Map (Spectrogram) "
            f"for the audio file '{filename}' (Type: {label}).\n\n"
            "TASK:\n"
            "1. Inspect the Spectrogram for constant frequency interference (whines/walls at 4kHz+).\n"
            "2. Identify visual signs of harmonic distortion or digital aliasing.\n"
            "3. Estimate the noise floor intensity and general clarity.\n\n"
            "OUTPUT JSON ONLY:\n"
            "{\n"
            "  'noise_floor_db': float,\n"
            "  'low_pass_cutoff': int,\n"
            "  'high_pass_cutoff': int,\n"
            "  'notch_filters': [int, int],\n"
            "  'explanation': 'Detailed summary of detected artifacts'\n"
            "}"
        )
        return ForensicHelper.consult_ai(prompt, provider=provider, image_b64=img_b64, audio_b64=audio_b64, json_mode=True)

    @staticmethod
    def generate_dsp_code(truth, history, filename, provider="gemini"):
        """Requests custom Python DSP processing code based on historical iterations."""
        import json
        prompt = (
            f"Elite Forensic DSP. Target: '{truth}'. File: {filename}. History: {json.dumps(history)}. "
            "Use Radar/Sonar math. Output ONLY Python: def optimize_audio(y, sr, other_tracks):"
        )
        code = ForensicHelper.consult_ai(prompt, provider=provider, json_mode=False)
        if code:
            for t in [chr(96)*3+"python", chr(96)*3]: code = code.replace(t, "")
            return code.strip()
        return "def optimize_audio(y, sr, other_tracks):\n    import librosa\n    return librosa.util.normalize(y)"

        """Identifies the primary project directory based on existing file locations."""
        if not os.path.exists(yaml_path):
            return os.path.dirname(os.path.abspath(yaml_path)) or '.'

        with open(yaml_path, 'r') as f:
            config = yaml.safe_load(f) or {}

        dirs = [os.path.dirname(entry.get('path', '')) for entry in config.get('files', []) if entry.get('path')]
        if not dirs:
            return os.path.dirname(os.path.abspath(yaml_path)) or '.'

        counts = Counter(dirs)
        majority_dir = counts.most_common(1)[0][0]

        return majority_dir if majority_dir else (os.path.dirname(os.path.abspath(yaml_path)) or '.')

    @staticmethod
    def parse_dt(s):
        """Extremely forgiving standardized datetime parser."""
        if not s: return None
        if isinstance(s, datetime): return s
        for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M", "%Y-%m-%d", "%Y%m%d%H%M%S", "%Y%m%d %H:%M"):
            try: return datetime.strptime(s, fmt)
            except ValueError: continue
        return None

    @staticmethod
    def extract_time_from_filename(filename):
        """Parses and returns a datetime object from filename if standard timestamps exist."""
        import re
        match_sep = re.search(r'(20\d{2})(\d{2})(\d{2})_(\d{2})(\d{2})(\d{2})', filename)
        match_flat = re.search(r'(20\d{2})(\d{2})(\d{2})(\d{2})(\d{2})(\d{2})', filename)
        if match_sep:
            y, m, d, hh, mm, ss = match_sep.groups()
            try: return datetime(int(y), int(m), int(d), int(hh), int(mm), int(ss))
            except ValueError: pass
        if match_flat:
            y, m, d, hh, mm, ss = match_flat.groups()
            try: return datetime(int(y), int(m), int(d), int(hh), int(mm), int(ss))
            except ValueError: pass
        return None

    @staticmethod
    def get_media_creation_time(filepath):
        """Extracts creation_time metadata from media files using ffprobe."""
        import json
        if not os.path.exists(filepath): return None
        try:
            cmd = [
                'ffprobe', '-v', 'quiet',
                '-select_streams', 'a:0',
                '-show_entries', 'format_tags=creation_time',
                '-of', 'json', filepath
            ]
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=5)
            data = json.loads(result.stdout)
            c_time = data.get('format', {}).get('tags', {}).get('creation_time')
            if c_time:
                for fmt in ("%Y-%m-%dT%H:%M:%S.%fZ", "%Y-%m-%d %H:%M:%S", "%Y-%m-%dT%H:%M:%SZ"):
                    try: return datetime.strptime(c_time, fmt)
                    except ValueError: continue
            return None
        except:
            return None

    @staticmethod
    def get_hardware_signature(filepath):
        """Queries the internal stream characteristics and container tags of a file to build a physical fingerprint."""
        import json
        if not os.path.exists(filepath): return None
        try:
            cmd = [
                'ffprobe', '-v', 'quiet',
                '-show_format', '-show_streams',
                '-of', 'json', filepath
            ]
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=5)
            data = json.loads(result.stdout)

            fmt = data.get('format', {})
            fmt_tags = fmt.get('tags', {})

            sig = {
                "format_name": fmt.get("format_name"),
                "major_brand": fmt_tags.get("major_brand") or fmt_tags.get("encoder"),
                "streams": []
            }

            for stream in data.get('streams', []):
                st_type = stream.get('codec_type')
                st_sig = {
                    "type": st_type,
                    "codec": stream.get("codec_name"),
                    "handler": stream.get("tags", {}).get("handler_name")
                }
                if st_type == 'video':
                    st_sig["resolution"] = f"{stream.get('width')}x{stream.get('height')}"
                    st_sig["fps"] = stream.get("r_frame_rate")
                elif st_type == 'audio':
                    st_sig["sample_rate"] = stream.get("sample_rate")
                    st_sig["channels"] = stream.get("channels")

                sig["streams"].append(st_sig)
            return sig
        except Exception as e:
            logger.debug(f"Failed to generate hardware signature for {filepath}: {e}")
            return None

    @staticmethod
    def serialize_signature(sig):
        """Converts a signature dict to a clean, readable string representation."""
        if not sig: return "Unknown / Unreadable"
        parts = []
        if sig.get("format_name"):
            parts.append(f"Format: {sig['format_name'].upper()}")
        if sig.get("major_brand"):
            parts.append(f"Brand: {sig['major_brand']}")

        for idx, s in enumerate(sig.get("streams", [])):
            t = s.get("type", "unknown").upper()
            codec = s.get("codec", "unknown")
            handler = s.get("handler")
            handler_str = f" ({handler})" if handler else ""

            if t == "VIDEO":
                res = s.get("resolution", "Unknown")
                fps = s.get("fps", "Unknown")
                parts.append(f"Stream {idx} [Video: {codec} | {res} | {fps}fps{handler_str}]")
            elif t == "AUDIO":
                sr = s.get("sample_rate", "Unknown")
                ch = s.get("channels", "Unknown")
                parts.append(f"Stream {idx} [Audio: {codec} | {sr}Hz | {ch}ch{handler_str}]")
        return " | ".join(parts)

    @staticmethod
    def verify_camera_hardware(yaml_path=None, folder_path=None):
        """
        Extracts internal ffprobe stream characteristics for all tracked or raw files.
        Detects mismatching container variables or codecs to flag camera classification errors.
        Supports checking a project YAML file or directly scanning a folder of raw source files.
        """
        files_to_check = []
        source_desc = ""

        if folder_path:
            if not os.path.exists(folder_path) or not os.path.isdir(folder_path):
                logger.error(f"[VERIFY] Folder not found or invalid: {folder_path}")
                return False
            source_desc = f"Raw Folder: {folder_path}"
            # Scan directory for typical media formats
            media_exts = {'.mp4', '.m4v', '.mov', '.avi', '.mkv', '.wav', '.ogg', '.webm', '.3gp'}
            for root, _, files in os.walk(folder_path):
                for f in files:
                    ext = os.path.splitext(f)[1].lower()
                    if ext in media_exts:
                        files_to_check.append({
                            'path': os.path.join(root, f),
                            'label': '' # No YAML label available for direct scans
                        })
        elif yaml_path:
            if not os.path.exists(yaml_path):
                logger.error(f"[VERIFY] YAML not found: {yaml_path}")
                return False
            source_desc = f"Project YAML: {yaml_path}"
            with open(yaml_path, 'r') as f:
                config = yaml.safe_load(f) or {}
            for entry in config.get('files', []):
                path = entry.get('path', '')
                label = entry.get('type', '')
                if path:
                    files_to_check.append({
                        'path': path,
                        'label': label
                    })
        else:
            logger.error("[VERIFY] You must specify either a YAML path or a Folder path.")
            return False

        if not files_to_check:
            print(f"[VERIFY] No files found to verify for source: {source_desc}")
            return False

        print(f"\n=== FFmpeg Internal Hardware Signature Scan & Audit ===")
        print(f"Source: {source_desc}")
        print("-" * 110)

        raw_files = []
        missing_files = []
        special_keywords = ['master', 'trial_mix', 'dual_feed', 'coverage', 'joined', 'beam', 'fused', 'sync_']

        for file_info in files_to_check:
            path = file_info['path']
            label = file_info['label']

            p_low = path.lower()
            l_low = label.lower()
            is_generated = any(kw in p_low or kw in l_low for kw in special_keywords)
            if is_generated:
                continue # Focus audit on raw original camera tracks

            if not os.path.exists(path):
                missing_files.append(path)
                continue

            cam_assigned = ForensicHelper.identify_camera(path, label)
            sig = ForensicHelper.get_hardware_signature(path)

            if sig:
                raw_files.append({
                    'path': path,
                    'filename': os.path.basename(path),
                    'assigned_cam': cam_assigned,
                    'signature_raw': sig,
                    'signature_str': ForensicHelper.serialize_signature(sig)
                })

        if not raw_files:
            print("[!] No physical original feeds were readable for hardware scanning.")
            if missing_files:
                print(f"[!] Note: {len(missing_files)} files were listed but are offline/missing.")
            return True

        # Group signatures by assigned Camera ID
        cam_groups = {}
        for f in raw_files:
            cam_groups.setdefault(f['assigned_cam'], []).append(f)

        hardware_standards = {}
        discrepancies_found = 0

        # Establish dominant hardware standard signatures per camera
        for cam, files in cam_groups.items():
            sig_counts = Counter([f['signature_str'] for f in files])
            dominant_sig, count = sig_counts.most_common(1)[0]
            hardware_standards[cam] = dominant_sig

            print(f"\n* Camera Focus: {cam}")
            print(f"  Established Dominant Signature Profile ({count}/{len(files)} files):")
            print(f"    --> {dominant_sig}")

        # Scan for internal anomalies
        print("\n" + "-" * 110)
        print("--- Hardware Signature Discrepancy Report ---")

        for f in raw_files:
            cam = f['assigned_cam']
            standard_sig = hardware_standards.get(cam)
            actual_sig = f['signature_str']

            if not standard_sig:
                continue

            if actual_sig != standard_sig:
                # Find if this file matches the hardware signature of the OTHER camera
                cross_over_match = None
                for other_cam, other_sig in hardware_standards.items():
                    if other_cam != cam and actual_sig == other_sig:
                        cross_over_match = other_cam
                        break

                print(f"\n [ALERT] Physical Stream Mismatch Detected!")
                print(f"   File            : {f['filename']}")
                print(f"   Labeled Location: {cam}")
                print(f"   Actual Streams  : {actual_sig}")

                if cross_over_match:
                    print(f"   Forensic Audit  : This file matches the exact physical hardware profile of {cross_over_match}!")
                    print(f"   Resolution      : Strong indication of a mislabeled file. Reassign to {cross_over_match}.")
                else:
                    print(f"   Forensic Audit  : Unique hardware signature anomaly. This file does not match either camera standard.")
                    print(f"   Expected        : {standard_sig}")
                discrepancies_found += 1

        if discrepancies_found == 0:
            print("\n [OK] Hardware Integrity Confirmed: All physical stream patterns match their expected camera profile.")
        else:
            print(f"\n [WARNING] Hardware Audit finished with {discrepancies_found} anomalous files flagged.")

        if missing_files:
            print(f"\n Note: {len(missing_files)} original files are registered but currently offline.")
        print("==============================================================================================================\n")
        return True

    @staticmethod
    def detect_gmt_offset(dir_path):
        """
        Scans a directory for companion media files that contain BOTH a filename
        timestamp (local time) and internal MP4 metadata creation_time (GMT).
        Calculates and returns the rounded standard timezone offset (timedelta)
        to safely adjust ingested metadata files that lack filename timestamps.
        """
        if not dir_path or not os.path.exists(dir_path) or not os.path.isdir(dir_path):
            return timedelta(0)

        offsets = []
        try:
            for f in os.listdir(dir_path):
                filepath = os.path.join(dir_path, f)
                if not os.path.isfile(filepath):
                    continue

                local_dt = ForensicHelper.extract_time_from_filename(f)
                if not local_dt:
                    continue

                utc_dt = ForensicHelper.get_media_creation_time(filepath)
                if not utc_dt:
                    continue

                diff_sec = (local_dt - utc_dt).total_seconds()
                # Round offset to standard 30-minute block boundaries to clear write latencies
                rounded_sec = int(round(diff_sec / 1800.0) * 1800)
                offsets.append(rounded_sec)
        except Exception as e:
            logger.debug(f"Error scanning directory for GMT offsets: {e}")

        if not offsets:
            logger.debug("[INGEST] No cross-reference files found in directory. Defaulting to 0 GMT offset.")
            return timedelta(0)

        # Apply majority voting to clear sporadic single-file write anomalies
        most_common_sec = Counter(offsets).most_common(1)[0][0]
        detected_offset = timedelta(seconds=most_common_sec)
        logger.info(f"[INGEST] Auto-detected GMT Offset: {most_common_sec / 3600.0:+.1f} hours ({detected_offset}) based on directory cross-referencing.")
        return detected_offset

    @staticmethod
    def get_file_hash(filepath):
        """Calculates MD5 hash of a file for duplicate detection."""
        if not os.path.exists(filepath): return None
        hasher = hashlib.md5()
        try:
            with open(filepath, 'rb') as f:
                for chunk in iter(lambda: f.read(65536), b''):
                    hasher.update(chunk)
            return hasher.hexdigest()
        except:
            return None

    @staticmethod
    def get_file_duration(path):
        """Attempts to get exact file duration. Fallbacks to 3600.0 (1 hour) if unreadable or highly corrupt."""
        if not os.path.exists(path):
            return 3600.0

        dur = None
        if sf is not None:
            try:
                with sf.SoundFile(path) as f:
                    dur = f.frames / f.samplerate
            except:
                pass

        # Validate duration limit to prevent giant uninitialized memory values (e.g. Unix Timestamp representations)
        if dur is None or dur <= 0 or dur > 259200.0: # Cap raw physical segments at 72 hours max
            try:
                cmd = ['ffprobe', '-v', 'quiet', '-show_entries', 'format=duration', '-of', 'default=noprint_wrappers=1:nokey=1', path]
                result = subprocess.run(cmd, capture_output=True, text=True, timeout=5)
                dur = float(result.stdout.strip())
            except:
                pass

        if dur is None or np.isnan(dur) or dur <= 0 or dur > 259200.0:
            return 3600.0

        return dur

    @staticmethod
    def get_active_streams(yaml_path, target_time, end_time=None, max_assumed_hours=4, tier=None):
        """Fetches all streams overlapping a specific time or time range without duplications."""
        if not os.path.exists(yaml_path):
            logger.error(f"[QUERY] YAML not found: {yaml_path}")
            return []

        with open(yaml_path, 'r') as f:
            config = yaml.safe_load(f) or {}

        t_start = ForensicHelper.parse_dt(target_time)
        t_end = ForensicHelper.parse_dt(end_time) if end_time else t_start

        if not t_start:
            logger.error("[QUERY] Invalid target time provided.")
            return []

        active_streams = []
        seen_paths = set()

        for entry in config.get('files', []):
            path = entry.get('path', '')
            label = entry.get('type', 'Unknown Filter')
            f_start_str = entry.get('start', '')

            if not path or path in seen_paths:
                continue

            if tier and not ForensicHelper.tier_matches(entry, tier):
                continue

            f_start = ForensicHelper.parse_dt(f_start_str)
            if not f_start: continue


            is_generated = any(
                kw in (path.lower() + " " + label.lower())
                for kw in ["master", "trial_mix", "dual_feed", "coverage", "joined", "beam", "fused", "sync_", "generated"]
            )

            rough_hours = 72 if is_generated else max_assumed_hours
            rough_f_end = f_start + timedelta(hours=rough_hours)

            if f_start <= t_end and rough_f_end >= t_start:
                dur_sec = ForensicHelper.get_file_duration(path)
                f_end = f_start + timedelta(seconds=dur_sec)

                if f_start <= t_end and f_end >= t_start:
                    seen_paths.add(path)
                    cam_id = ForensicHelper.identify_camera(path, label)
                    active_streams.append({
                        'cam_id': cam_id,
                        'filter': label,
                        'path': path,
                        'start_dt': f_start,
                        'end_dt': f_end,
                        'duration_sec': dur_sec
                    })

        active_streams.sort(key=lambda x: (x['cam_id'], x['start_dt']))
        return active_streams

    @staticmethod
    def get_continuous_blocks(yaml_path, target_start, target_end=None, max_gap_sec=2.0, tier=None):
        """Analyzes active streams and groups them into continuous blocks per camera."""
        streams = ForensicHelper.get_active_streams(yaml_path, target_start, target_end, tier=tier)

        cams = {}
        for s in streams:
            cams.setdefault(s['cam_id'], []).append(s)

        blocks = []
        for cam, cam_streams in cams.items():
            cam_streams.sort(key=lambda x: x['start_dt'])

            current_block = []
            block_start = None
            block_end = None

            for s in cam_streams:
                if not current_block:
                    current_block.append(s)
                    block_start = s['start_dt']
                    block_end = s['end_dt']
                else:
                    if s['start_dt'] <= block_end + timedelta(seconds=max_gap_sec):
                        current_block.append(s)
                        block_end = max(block_end, s['end_dt'])
                    else:
                        blocks.append({
                            'cam_id': cam,
                            'start_dt': block_start,
                            'end_dt': block_end,
                            'duration_sec': (block_end - block_start).total_seconds(),
                            'streams': current_block
                        })
                        current_block = [s]
                        block_start = s['start_dt']
                        block_end = s['end_dt']

            if current_block:
                blocks.append({
                    'cam_id': cam,
                    'start_dt': block_start,
                    'end_dt': block_end,
                    'duration_sec': (block_end - block_start).total_seconds(),
                    'streams': current_block
                })

        blocks.sort(key=lambda x: x['start_dt'])
        return blocks

    @staticmethod
    def read_stream_block(stream_info, t_current, block_sec, sr=22050):
        if not stream_info or librosa is None:
            return np.zeros(int(block_sec * sr), dtype=np.float32)

        path = stream_info.get('path')
        start_dt = stream_info.get('start_dt')
        target_len = int(block_sec * sr)

        if not path or not start_dt:
            return np.zeros(target_len, dtype=np.float32)

        offset = (t_current - start_dt).total_seconds()

        try:
            y, _ = librosa.load(path, sr=sr, offset=offset, duration=block_sec)
            if len(y) < target_len:
                y = np.pad(y, (0, target_len - len(y)))
            return y[:target_len]
        except Exception as e:
            logger.debug(f"Stream read error for {path}: {e}")
            return np.zeros(target_len, dtype=np.float32)

    @staticmethod
    def print_active_streams(yaml_path, target_time, end_time=None):
        streams = ForensicHelper.get_active_streams(yaml_path, target_time, end_time)

        range_str = f"Time: {target_time}"
        if end_time: range_str += f" to {end_time}"

        print(f"\n=== Active Streams [{range_str}] ===")
        if not streams:
            print(" No active streams found in this window.")
            return

        print(f" {'CAM ID':<10} | {'FILTER / TIER':<32} | {'START TIME':<20} | {'FILE'}")
        print("-" * 110)
        for s in streams:
            fname = os.path.basename(s['path'])
            start_str = s['start_dt'].strftime('%Y-%m-%d %H:%M:%S')
            print(f" {s['cam_id']:<10} | {s['filter']:<32} | {start_str:<20} | {fname}")
        print("-" * 110)
        print(f" Total Active Streams: {len(streams)}\n")

    @staticmethod
    def print_continuous_blocks(blocks):
        print(f"\n=== Continuous Stream Blocks Breakdown ===")
        if not blocks:
            print(" No blocks found.")
            return

        for i, block in enumerate(blocks):
            cam = block['cam_id']
            dur = block['duration_sec']
            st = block['start_dt'].strftime('%Y-%m-%d %H:%M:%S')
            et = block['end_dt'].strftime('%Y-%m-%d %H:%M:%S')
            num_files = len(block['streams'])

            print(f"\n[Block {i+1}] {cam} | Total Duration: {dur:.1f}s")
            print(f"  Timeline: {st} -> {et}")
            print(f"  Composition ({num_files} Physical Files):")
            for j, s in enumerate(block['streams']):
                f_name = os.path.basename(s['path'])
                f_st = s['start_dt'].strftime('%H:%M:%S')
                f_et = s['end_dt'].strftime('%H:%M:%S')
                f_dur = s['duration_sec']
                print(f"    {j+1:02d}. {f_st} -> {f_et} ({f_dur:>7.1f}s) | {f_name}")
        print("==========================================")

    @staticmethod
    def tidy_project(yaml_path):
        """Scans the YAML project, standardizes labels/filenames, and enforces correct directory targeting."""
        if not os.path.exists(yaml_path):
            logger.error(f"[TIDY] YAML not found: {yaml_path}")
            return False

        with open(yaml_path, 'r') as f:
            config = yaml.safe_load(f) or {}

        if 'files' not in config:
            logger.info("[TIDY] No 'files' array found in YAML.")
            return False

        majority_dir = ForensicHelper.get_majority_directory(yaml_path)

        print(f"\n=== Forensic Project Tidy Up Pipeline ===")
        print(f"Target Project : {yaml_path}")
        print(f"Target Majority: {majority_dir}/")
        print("-" * 45)

        changes_made = 0
        missing_files = 0
        valid_files = []
        seen_yaml_paths = set()

        for entry in config['files']:
            old_path = entry.get('path', '')
            old_label = entry.get('type', '')

            if not old_path:
                continue

            p_low = old_path.lower()
            l_low = old_label.lower()

            special_keywords = ['master', 'trial_mix', 'dual_feed', 'coverage', 'joined', 'beam', 'fused', 'sync_']
            if any(kw in p_low or kw in l_low for kw in special_keywords):
                if os.path.exists(old_path):
                    if old_path in seen_yaml_paths:
                        changes_made += 1
                        continue
                    if '(Generated)' not in old_label:
                        new_label = f"{old_label} (Generated)" if old_label else "Generated Track"
                        entry['type'] = new_label
                        changes_made += 1
                    valid_files.append(entry)
                    seen_yaml_paths.add(old_path)
                else:
                    missing_files += 1
                    changes_made += 1
                continue

            cam_id = ForensicHelper.identify_camera(old_path, old_label)

            fname = os.path.basename(old_path)
            fname_no_ext = fname[:-4] if fname.lower().endswith(".ogg") else os.path.splitext(fname)[0]

            # Dynamic tier detection. Preserve custom gain tiers such as amp24 / plus12.
            plus_match = re.search(r'_(plus\d+(?:p\d+)?|minus\d+(?:p\d+)?)\.ogg$', fname.lower())
            raw_amp_match = re.search(r'_(amp\d+(?:p\d+)?|ampminus\d+(?:p\d+)?)\.ogg$', fname.lower())

            is_enhanced_amp = bool(plus_match) or "enhanced amp" in l_low or "_ampamp" in p_low
            is_raw_amp = bool(raw_amp_match) or "raw amp" in l_low
            is_original = fname.lower().endswith("_original.ogg") or "original" in l_low
            is_enhanced = ("enhanced" in p_low or "enhanced" in l_low) and not is_enhanced_amp

            # Remove known tier suffixes to recover core name.
            core_name = fname_no_ext
            if core_name.startswith("enhanced_"):
                core_name = core_name[len("enhanced_"):]
            core_name = re.sub(r'_(original|amp\d+(?:p\d+)?|ampminus\d+(?:p\d+)?|plus\d+(?:p\d+)?|minus\d+(?:p\d+)?|ampamp)$', '', core_name, flags=re.I)

            tier_name = ""
            if is_enhanced_amp:
                tier_name = plus_match.group(1) if plus_match else "plus20"
                gain_part = tier_name.replace("plus", "").replace("minus", "-").replace("p", ".")
                new_fname = f"enhanced_{core_name}_{tier_name}.ogg"
                new_label = f"{cam_id} (Enhanced Amp {gain_part}dB)"
            elif is_enhanced:
                tier_name = "enhanced"
                new_fname = f"enhanced_{core_name}.ogg"
                new_label = f"{cam_id} (Enhanced)"
            elif is_raw_amp:
                tier_name = raw_amp_match.group(1) if raw_amp_match else "amp32"
                gain_part = tier_name.replace("ampminus", "-").replace("amp", "").replace("p", ".")
                new_fname = f"{core_name}_{tier_name}.ogg"
                new_label = f"{cam_id} (Raw Amp {gain_part}dB)"
            else:
                tier_name = "original"
                new_fname = f"{core_name}_original.ogg"
                new_label = f"{cam_id} (Original)"

            new_path = os.path.join(majority_dir, new_fname)

            if new_path in seen_yaml_paths:
                changes_made += 1
                continue

            file_exists = False
            if old_path != new_path:
                if os.path.exists(old_path):
                    try:
                        os.makedirs(majority_dir, exist_ok=True)
                        shutil.move(old_path, new_path)
                        entry['path'] = new_path
                        changes_made += 1
                        file_exists = True
                    except:
                        pass
                elif os.path.exists(new_path):
                    entry['path'] = new_path
                    changes_made += 1
                    file_exists = True
                else:
                    missing_files += 1
                    changes_made += 1
            else:
                if os.path.exists(old_path):
                    file_exists = True
                else:
                    missing_files += 1
                    changes_made += 1

            if file_exists:
                if old_label != new_label:
                    entry['type'] = new_label
                    changes_made += 1
                if entry.get('tier') != tier_name:
                    entry['tier'] = tier_name
                    changes_made += 1
                valid_files.append(entry)
                seen_yaml_paths.add(new_path)

        if changes_made > 0:
            config['files'] = valid_files
            with open(yaml_path, 'w') as f:
                yaml.dump(config, f, default_flow_style=False, sort_keys=False)
            print(f"[SUCCESS] Applied {changes_made} standardizations to project files.")
        else:
            print("[OK] Project is already tidy and standardized.")

        return True

    @staticmethod
    def find_duration_modes(durations, rel_tol=0.10, min_count=5, min_pct=0.005):
        """
        Groups segment durations into discrete standard settings/modes (adaptive 1D clustering)
        to robustly handle camera setting changes over time.
        """
        if not durations:
            return []
        durs = np.sort(durations)
        clusters = []

        # Simple leader-based 1D clustering
        for d in durs:
            placed = False
            for c in clusters:
                rep = c['rep']
                if abs(d - rep) / rep <= rel_tol:
                    c['values'].append(d)
                    c['rep'] = np.median(c['values'])
                    placed = True
                    break
            if not placed:
                clusters.append({'rep': d, 'values': [d]})

        modes = []
        total = len(durations)
        for c in clusters:
            val_arr = np.array(c['values'])
            median_val = np.median(val_arr)
            count = len(val_arr)
            pct = count / total
            # A cluster is treated as a valid standard setting mode if it meets
            # minimum counting or percentage thresholds.
            if count >= min_count or pct >= min_pct or total < min_count:
                modes.append({
                    'median': median_val,
                    'count': count,
                    'pct': pct,
                    'min': np.min(val_arr),
                    'max': np.max(val_arr)
                })

        # Sort modes by support frequency (count) descending
        modes.sort(key=lambda x: x['count'], reverse=True)
        return modes

    @staticmethod
    def check_consistency(yaml_path):
        """
        Dynamically analyzes segment file lengths (durations) per logical camera
        assignment to identify cross-assigned feeds, unflagged master audio compilations,
        and missing media references. Supports adaptive multi-modal settings over time.
        """
        if not os.path.exists(yaml_path):
            logger.error(f"[CHECK] YAML not found: {yaml_path}")
            return False

        with open(yaml_path, 'r') as f:
            config = yaml.safe_load(f) or {}

        entries = config.get('files', [])
        if not entries:
            print("[CHECK] No active files tracked in project configuration.")
            return False

        print(f"\n=== Forensic Camera Assignment & Segment Length Consistency Check ===")
        print(f"Project File: {yaml_path}")
        print("-" * 88)

        raw_files = []
        generated_files = []
        missing_files = []

        special_keywords = ['master', 'trial_mix', 'dual_feed', 'coverage', 'joined', 'beam', 'fused', 'sync_']

        for entry in entries:
            path = entry.get('path', '')
            label = entry.get('type', '')

            if not path:
                continue

            p_low = path.lower()
            l_low = label.lower()

            if not os.path.exists(path):
                missing_files.append(entry)
                continue

            dur = ForensicHelper.get_file_duration(path)
            cam_assigned = ForensicHelper.identify_camera(path, label)

            # Smart classification: If a file has an incredibly long duration (> 3.3 hours / 12000s),
            # it is automatically categorized as an exported master/processed track rather than raw footage.
            is_generated = any(kw in p_low or kw in l_low for kw in special_keywords) or (dur > 12000.0)

            info = {
                'path': path,
                'filename': os.path.basename(path),
                'label': label,
                'duration': dur,
                'cam_assigned': cam_assigned,
                'entry': entry
            }

            if is_generated:
                generated_files.append(info)
            else:
                raw_files.append(info)

        if not raw_files:
            print("[!] Empty Raw Dataset: No physical feeds available for analysis.")
            if missing_files:
                print(f"[!] Note: {len(missing_files)} elements are registered but missing.")
            return True

        # Map out duration list per camera
        cam_durations = {}
        for f in raw_files:
            cam_durations.setdefault(f['cam_assigned'], []).append(f['duration'])

        # Calculate standard normal (median) segment length modes for each camera
        cam_modes = {}
        print("\n--- Camera Segment Length Fingerprint Standards ---")
        for cam, durs in cam_durations.items():
            if not durs: continue
            modes = ForensicHelper.find_duration_modes(durs)
            cam_modes[cam] = modes
            print(f" * {cam:10} | Found {len(modes)} Valid Standard Segment Setting(s):")
            for idx, m in enumerate(modes):
                med = m['median']
                print(f"     - Mode {idx+1}: {med:8.1f}s (~{med/60:.1f} minutes) | Support: {m['count']} files ({m['pct']*100:.1f}%)")

        # Audit feeds for crossovers or generated edits masquerading as raw segments
        anomalies_found = 0
        print("\n--- Consistency Audit Report ---")

        for f in raw_files:
            assigned = f['cam_assigned']
            dur = f['duration']
            fname = f['filename']

            # Find closest standard mode in assigned camera
            modes = cam_modes.get(assigned, [])
            if not modes:
                continue

            best_match_dev = None
            best_mode = None
            for m in modes:
                dev = abs(dur - m['median']) / m['median']
                if best_match_dev is None or dev < best_match_dev:
                    best_match_dev = dev
                    best_mode = m

            # Check if duration meets any valid assigned mode within 15% tolerance
            is_consistent = (best_match_dev is not None and best_match_dev <= 0.15)

            if is_consistent:
                # Legitimate segment that matches an active setting profile
                continue

            possible_mismatch = False
            suspected_cam = None
            matched_other_median = None

            # 1. Cross-compare with other camera modes to find potential mix-ups
            for other_cam, other_modes in cam_modes.items():
                if other_cam == assigned:
                    continue
                for m_other in other_modes:
                    dev_other = abs(dur - m_other['median']) / m_other['median']
                    if dev_other < 0.05:
                        possible_mismatch = True
                        suspected_cam = other_cam
                        matched_other_median = m_other['median']
                        break
                if possible_mismatch:
                    break

            if possible_mismatch:
                print(f" [WARNING] Potential Mislabeled Camera Assignment:")
                print(f"   File       : {fname}")
                print(f"   Assigned To: {assigned}")
                print(f"   Duration   : {dur:.1f}s")
                print(f"   Anomaly    : Length matches standard segment setting of {suspected_cam} ({matched_other_median:.1f}s)!")
                print(f"   Resolution : Believe this file actually belongs to {suspected_cam}.")
                print("-" * 88)
                anomalies_found += 1
            else:
                # 2. Check for extreme outlier within assigned camera
                max_mode_val = max(m['median'] for m in modes)
                min_mode_val = min(m['median'] for m in modes)

                if dur > max_mode_val * 2.0:
                    print(f" [NOTICE] Suspected Generated Track (Labeled as Raw Feed):")
                    print(f"   File       : {fname}")
                    print(f"   Assigned To: {assigned}")
                    print(f"   Duration   : {dur:.1f}s")
                    print(f"   Anomaly    : Unusually long segment (~{dur/max_mode_val:.1f}x maximum normal size of {max_mode_val:.1f}s). Likely pre-joined or exported master.")
                    print("-" * 88)
                    anomalies_found += 1
                elif dur < min_mode_val * 0.2:
                    print(f" [INFO] Shorter Segment Interval Detected:")
                    print(f"   File       : {fname}")
                    print(f"   Assigned To: {assigned}")
                    print(f"   Duration   : {dur:.1f}s (Closest standard setting size is {best_mode['median']:.1f}s)")
                    print(f"   Anomaly    : Abruptly short duration. Indicates crash, manual cut, or snippet.")
                    print("-" * 88)

        if generated_files:
            print("\n--- Standardized Generated Media Tracks ---")
            for f in generated_files:
                print(f" * [GENERATED] {f['cam_assigned']} | {f['duration']:.1f}s | {f['filename']} ({f['label']})")

        if missing_files:
            print("\n--- Missing / Offline Media Tracks (Cannot Check) ---")
            for f in missing_files:
                print(f" [!] Offline: {os.path.basename(f['path'])} ({f.get('type', 'Unknown Type')})")

        print("\n=== Timeline Verification Summary ===")
        print(f" Total Track Count   : {len(raw_files) + len(generated_files) + len(missing_files)}")
        print(f" Valid Raw Feeds     : {len(raw_files)}")
        print(f" Master/Generated    : {len(generated_files)}")
        print(f" Offline/Missing     : {len(missing_files)}")
        print(f" Anomalies Flagged   : {anomalies_found}")
        print("========================================================================\n")
        return True

    @staticmethod
    def _format_gain_db(value):
        """Return an FFmpeg-safe dB gain string, e.g. 32 -> 32dB, 20.5 -> 20.5dB."""
        try:
            v = float(value)
        except Exception:
            v = 0.0
        if abs(v - int(v)) < 1e-9:
            return f"{int(v)}dB"
        return f"{v:g}dB"

    @staticmethod
    def _gain_filename_tag(value, prefix="amp"):
        """Return a filesystem-safe gain tag, e.g. 32 -> amp32, 20.5 -> plus20p5, -3 -> ampminus3."""
        try:
            v = float(value)
        except Exception:
            v = 0.0

        if prefix == "plus":
            base = "plus" if v >= 0 else "minus"
        else:
            base = "amp" if v >= 0 else "ampminus"

        val = abs(v)
        if abs(val - int(val)) < 1e-9:
            sval = str(int(val))
        else:
            sval = f"{val:g}".replace(".", "p")
        return f"{base}{sval}"

    @staticmethod
    def tier_matches(entry, tier=None):
        """
        Dynamic tier matcher.

        Supports historic tiers:
            original, amp32, enhanced, plus20

        Also supports custom ingest gains:
            amp24, amp18, plus12, plus6, ampminus3, minus6

        The ingest pipeline now writes an explicit YAML 'tier' field. Older YAMLs
        without that field still match using path and type/label text.
        """
        if not tier:
            return True

        t = str(tier).strip().lower()
        if not t:
            return True

        path = str(entry.get("path", "")).lower()
        label = str(entry.get("type", entry.get("label", ""))).lower()
        explicit = str(entry.get("tier", "")).lower()
        hay = f"{explicit} {label} {path}"

        if t in hay:
            return True

        # Friendly aliases.
        if t in {"orig", "original", "raw_original"}:
            return explicit == "original" or "original" in hay

        if t in {"enh", "enhanced"}:
            # Enhanced, but not enhanced amplified/recovered tier.
            return explicit == "enhanced" or ("enhanced" in hay and "plus" not in hay and "enhanced amp" not in hay)

        if t in {"raw", "rawamp", "raw_amp"}:
            return explicit.startswith("amp") or "raw amp" in hay or re.search(r"_amp(?:minus)?\d", path) is not None

        if t in {"enhanced_amp", "enhancedamp", "plus"}:
            return explicit.startswith("plus") or explicit.startswith("minus") or "enhanced amp" in hay or re.search(r"_(?:plus|minus)\d", path) is not None

        # Normalize "24" to amp24 for convenience.
        if re.fullmatch(r"-?\d+(?:\.\d+)?", t):
            val = float(t)
            tag = ForensicHelper._gain_filename_tag(val, prefix="amp")
            return tag in hay

        # Normalize "+12", "12db", "+12db" to plus12 or amp12 depending on context.
        db_match = re.fullmatch(r"\+?(-?\d+(?:\.\d+)?)db", t)
        if db_match:
            val = float(db_match.group(1))
            raw_tag = ForensicHelper._gain_filename_tag(val, prefix="amp")
            plus_tag = ForensicHelper._gain_filename_tag(val, prefix="plus")
            return raw_tag in hay or plus_tag in hay

        return False


    @staticmethod
    def _file_creation_datetime(path):
        """
        Best-effort file/media creation datetime.

        Priority:
          1. ffprobe tags: creation_time / date / encoded_date
          2. OS birth time, where Python exposes it
          3. file modification time fallback

        Linux ctime is deliberately avoided because it is metadata-change time,
        not creation time.
        """
        import os
        import subprocess
        from datetime import datetime

        path = os.path.expanduser(str(path))

        # Media metadata, if present.
        try:
            cmd = [
                "ffprobe", "-v", "error",
                "-show_entries", "format_tags=creation_time,date,encoded_date",
                "-of", "default=noprint_wrappers=1",
                path
            ]
            res = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=10)
            if res.returncode == 0:
                for line in (res.stdout or "").splitlines():
                    if "=" not in line:
                        continue
                    _key, val = line.split("=", 1)
                    val = val.strip()
                    if not val:
                        continue

                    candidates = [
                        val.replace("Z", "+00:00"),
                        val.replace("UTC ", "").replace("Z", "+00:00"),
                    ]
                    for cand in candidates:
                        try:
                            dt = datetime.fromisoformat(cand)
                            if dt.tzinfo is not None:
                                dt = dt.astimezone().replace(tzinfo=None)
                            if dt.year > 1990:
                                return dt
                        except Exception:
                            pass

                        for fmt in ("%Y-%m-%d %H:%M:%S", "%Y:%m:%d %H:%M:%S", "%Y-%m-%dT%H:%M:%S"):
                            try:
                                dt = datetime.strptime(cand[:19], fmt)
                                if dt.year > 1990:
                                    return dt
                            except Exception:
                                pass
        except Exception:
            pass

        # OS creation/birth time, where available.
        try:
            st = os.stat(path)
            birth = getattr(st, "st_birthtime", None)
            if birth:
                return datetime.fromtimestamp(birth)
        except Exception:
            pass

        # Practical fallback: file modification time.
        try:
            return datetime.fromtimestamp(os.path.getmtime(path))
        except Exception:
            return None


    @staticmethod
    def _directory_date_datetime(path, fallback_time=None):
        """
        Extract a date from the containing directory path.

        Handles examples such as:
            /home/hc3/Downloads/import/2024 10 10 a/REC-005.WAV
            /home/hc3/Downloads/import/2024-10-10/REC-005.WAV
            /home/hc3/Downloads/import/20241010/REC-005.WAV

        If fallback_time is supplied, its time-of-day is kept. This lets a
        bogus 1980-01-01 12:58:24 become 2024-10-10 12:58:24.
        """
        import os
        import re
        from datetime import datetime

        d = os.path.abspath(os.path.dirname(os.path.expanduser(str(path))))
        parts = []
        while True:
            head, tail = os.path.split(d)
            if tail:
                parts.append(tail)
            if not head or head == d:
                break
            d = head
            if len(parts) >= 8:
                break

        candidates = []
        for p in parts:
            candidates.append(p)
            candidates.append(p.replace("_", " ").replace("-", " ").replace(".", " "))

        for text in candidates:
            # 2024 10 10, 2024 10 10 a, 2024-10-10, 2024_10_10
            m = re.search(r'\b(20\d{2}|19\d{2})[\s._-]+(\d{1,2})[\s._-]+(\d{1,2})\b', text)
            if m:
                y, mo, da = map(int, m.groups())
                try:
                    if fallback_time:
                        return datetime(y, mo, da, fallback_time.hour, fallback_time.minute, fallback_time.second)
                    return datetime(y, mo, da, 0, 0, 0)
                except Exception:
                    pass

            # 20241010
            m = re.search(r'\b(20\d{2}|19\d{2})(\d{2})(\d{2})\b', text)
            if m:
                y, mo, da = map(int, m.groups())
                try:
                    if fallback_time:
                        return datetime(y, mo, da, fallback_time.hour, fallback_time.minute, fallback_time.second)
                    return datetime(y, mo, da, 0, 0, 0)
                except Exception:
                    pass

        return None



    @staticmethod
    def ingest_raw_media(source_path, yaml_path, start_time_str="auto", cam_id="Cam A", out_dir=None, silent=False, raw_amp_db=32.0, enhanced_amp_db=20.0):
        """Processes a raw media file (MP4/WAV) through the neural pipeline and archives to Ogg.

        raw_amp_db controls the pre-enhancement amplification applied to the original extraction.
        enhanced_amp_db controls the post-enhancement recovery amplification.
        Defaults preserve historic behaviour: raw +32dB and enhanced +20dB.
        """
        def safe_print(msg):
            if not silent:
                print(msg)

        safe_print(f"\n=== Forensic Raw Media Ingestion Pipeline ===")
        safe_print(f" Source : {source_path}")
        safe_print(f" Project: {yaml_path}")
        safe_print(f" Camera : {cam_id}")
        safe_print(f"{'-'*45}")

        if not os.path.exists(source_path):
            logger.error(f"[INGEST] Source file not found: {source_path}")
            return False

        # Parse timestamp first to generate paths for duplicate checking
        if not start_time_str or str(start_time_str).lower() == "auto":
            fname = os.path.basename(source_path)
            start_dt = ForensicHelper.extract_time_from_filename(fname)

            if not start_dt:
                # Use internal metadata adjusted by the GMT offset calculated from directory companions
                raw_utc_dt = ForensicHelper.get_media_creation_time(source_path)
                if raw_utc_dt:
                    source_dir = os.path.dirname(os.path.abspath(source_path)) or "."
                    offset = ForensicHelper.detect_gmt_offset(source_dir)
                    start_dt = raw_utc_dt + offset

                    if int(start_dt.year) == 1980:
                        dir_dt = ForensicHelper._directory_date_datetime(source_path, fallback_time=start_dt)
                        if dir_dt:
                            start_dt = dir_dt
                            logger.info(f"[INGEST] Media timestamp was 1980 placeholder. Using directory date with file time: {start_dt.strftime('%Y-%m-%d %H:%M:%S')} ({source_path})")
                        else:
                            logger.info(f"[INGEST] Extracted internal GMT creation time {raw_utc_dt.strftime('%Y-%m-%d %H:%M:%S')}. Applied GMT Offset {offset} -> Local time: {start_dt.strftime('%Y-%m-%d %H:%M:%S')}")
                    else:
                        logger.info(f"[INGEST] Extracted internal GMT creation time {raw_utc_dt.strftime('%Y-%m-%d %H:%M:%S')}. Applied GMT Offset {offset} -> Local time: {start_dt.strftime('%Y-%m-%d %H:%M:%S')}")

                if not start_dt:
                    file_dt = ForensicHelper._file_creation_datetime(source_path)
                    if file_dt and int(file_dt.year) == 1980:
                        dir_dt = ForensicHelper._directory_date_datetime(source_path, fallback_time=file_dt)
                        if dir_dt:
                            start_dt = dir_dt
                            logger.info(f"[INGEST] File timestamp was 1980 placeholder. Using directory date with file time: {start_dt.strftime('%Y-%m-%d %H:%M:%S')} ({source_path})")
                        else:
                            start_dt = file_dt
                            logger.info(f"[INGEST] Using file/media creation timestamp as start time: {start_dt.strftime('%Y-%m-%d %H:%M:%S')} ({source_path})")
                    elif file_dt:
                        start_dt = file_dt
                        logger.info(f"[INGEST] Using file/media creation timestamp as start time: {start_dt.strftime('%Y-%m-%d %H:%M:%S')} ({source_path})")
                    else:
                        dir_dt = ForensicHelper._directory_date_datetime(source_path)
                        if dir_dt:
                            start_dt = dir_dt
                            logger.info(f"[INGEST] Using directory date as start time: {start_dt.strftime('%Y-%m-%d %H:%M:%S')} ({source_path})")
                        else:
                            logger.error(f"[INGEST] Could not auto-detect start time from {source_path}.")
                            logger.error("[INGEST] No filename timestamp, internal media creation_time, OS birth time, file mtime, or directory date was usable.")
                            return False
        else:
            start_dt = ForensicHelper.parse_dt(start_time_str)
            if not start_dt:
                logger.error(f"[INGEST] Invalid start time format: {start_time_str}")
                return False

        if not out_dir:
            out_dir = ForensicHelper.get_majority_directory(yaml_path)

        base_name = os.path.splitext(os.path.basename(source_path))[0]
        safe_time = start_dt.strftime("%Y%m%d_%H%M%S")

        # Deduplication of double-timestamp prefixes in the workspace
        if base_name.startswith(safe_time):
            prefix = base_name
        else:
            prefix = f"{safe_time}_{base_name}"

        raw_amp_db = float(raw_amp_db)
        enhanced_amp_db = float(enhanced_amp_db)
        raw_amp_label = ForensicHelper._format_gain_db(raw_amp_db)
        enhanced_amp_label = ForensicHelper._format_gain_db(enhanced_amp_db)
        raw_amp_tag = ForensicHelper._gain_filename_tag(raw_amp_db, prefix="amp")
        enhanced_amp_tag = ForensicHelper._gain_filename_tag(enhanced_amp_db, prefix="plus")

        # -------------------------------------------------------------
        # DUPLICATE PROTECTION: Only ingest if not already in YAML
        # -------------------------------------------------------------
        if os.path.exists(yaml_path):
            with ForensicHelper._yaml_lock:
                try:
                    with open(yaml_path, 'r') as f:
                        config = yaml.safe_load(f) or {}
                except:
                    config = {}

            existing_paths = {entry.get('path', '') for entry in config.get('files', [])}
            expected_paths = [
                os.path.join(out_dir, f"{prefix}_original.ogg"),
                os.path.join(out_dir, f"{prefix}_{raw_amp_tag}.ogg"),
                os.path.join(out_dir, f"enhanced_{prefix}.ogg"),
                os.path.join(out_dir, f"enhanced_{prefix}_{enhanced_amp_tag}.ogg")
            ]
            standard_existing_paths = {os.path.normpath(p) for p in existing_paths if p}
            standard_expected_paths = [os.path.normpath(p) for p in expected_paths]

            if any(p in standard_existing_paths for p in standard_expected_paths):
                logger.info(f"[INGEST] Skipping '{source_path}' - already ingested.")
                return True

        # -------------------------------------------------------------
        # Proceed with Ingestion
        # -------------------------------------------------------------
        try:
            from testaudiostream import enhance_large_audio
        except ImportError:
            logger.error("[INGEST] Missing testaudiostream.py for neural enhancement. Aborting.")
            return False

        os.makedirs(out_dir, exist_ok=True)

        raw_amp_wav = os.path.join(out_dir, f"{prefix}_{raw_amp_tag}_TEMP.wav")
        enhanced_wav = os.path.join(out_dir, f"enhanced_{prefix}_TEMP.wav")
        enhanced_plus_wav = os.path.join(out_dir, f"enhanced_{prefix}_{enhanced_amp_tag}_TEMP.wav")

        logger.info(f"[INGEST] Audio Extraction & {raw_amp_label} Pre-Amp...")
        res = subprocess.run(['ffmpeg', '-y', '-i', source_path, '-af', f'volume={raw_amp_label}', '-hide_banner', '-loglevel', 'error', '-stats', raw_amp_wav])

        if res.returncode != 0 or not os.path.exists(raw_amp_wav) or os.path.getsize(raw_amp_wav) == 0:
            logger.error(f"[INGEST] Failed to extract audio.")
            if os.path.exists(raw_amp_wav): os.remove(raw_amp_wav)
            return False

        logger.info(f"[INGEST] Neural Streaming Enhancement...")
        enhance_large_audio(raw_amp_wav, enhanced_wav)

        logger.info(f"[INGEST] Final {enhanced_amp_label} Post-Amp Recovery...")
        subprocess.run(['ffmpeg', '-y', '-i', enhanced_wav, '-af', f'volume={enhanced_amp_label}', '-hide_banner', '-loglevel', 'error', '-stats', enhanced_plus_wav])

        conversion_map = [
            (source_path, f"{prefix}_original.ogg", f"{cam_id} (Original)"),
            (raw_amp_wav, f"{prefix}_{raw_amp_tag}.ogg", f"{cam_id} (Raw Amp {raw_amp_label})"),
            (enhanced_wav, f"enhanced_{prefix}.ogg", f"{cam_id} (Enhanced)"),
            (enhanced_plus_wav, f"enhanced_{prefix}_{enhanced_amp_tag}.ogg", f"{cam_id} (Enhanced Amp {enhanced_amp_label})")
        ]

        new_entries = []
        for src, out_name, label in conversion_map:
            out_path = os.path.join(out_dir, out_name)
            subprocess.run(['ffmpeg', '-y', '-i', src, '-vn', '-c:a', 'libvorbis', '-q:a', '10', '-hide_banner', '-loglevel', 'error', out_path])
            # Dynamic tier names feed downstream tools and --tier selection.
            if out_name.endswith("_original.ogg"):
                tier_name = "original"
            elif out_name == f"{prefix}_{raw_amp_tag}.ogg":
                tier_name = raw_amp_tag
            elif out_name == f"enhanced_{prefix}.ogg":
                tier_name = "enhanced"
            elif out_name == f"enhanced_{prefix}_{enhanced_amp_tag}.ogg":
                tier_name = enhanced_amp_tag
            else:
                tier_name = ""

            new_entries.append({
                'path': out_path,
                'start': start_dt.strftime('%Y-%m-%d %H:%M:%S'),
                'type': label,
                'tier': tier_name
            })

        for tmp in [raw_amp_wav, enhanced_wav, enhanced_plus_wav]:
            if os.path.exists(tmp): os.remove(tmp)

        with ForensicHelper._yaml_lock:
            config = {'files': []}
            if os.path.exists(yaml_path):
                with open(yaml_path, 'r') as f:
                    config = yaml.safe_load(f) or {'files': []}
            config['files'].extend(new_entries)
            config['files'].sort(key=lambda x: x.get('start', ''))
            with open(yaml_path, 'w') as f:
                yaml.dump(config, f, default_flow_style=False, sort_keys=False)

        logger.info(f"[INGEST] Success! Finalized Ogg streams generated for {os.path.basename(source_path)}.")
        return True

    @staticmethod
    def generate_comfort_noise(num_samples, db=-55):
        amplitude = 10 ** (db / 20.0)
        noise = np.random.normal(0, amplitude / 3.0, num_samples)
        return np.clip(noise, -amplitude, amplitude)

    @staticmethod
    def export_streams_at_bitrate(streams, output_path, bitrate="128k", debug=False):
        if not streams:
            logger.error("[EXPORT] No streams provided.")
            return False

        temp_dir = os.path.dirname(os.path.abspath(output_path))
        if temp_dir and not os.path.exists(temp_dir):
            os.makedirs(temp_dir, exist_ok=True)

        list_path = os.path.join(temp_dir, f"temp_export_list_{int(time.time())}.txt")

        with open(list_path, 'w') as f:
            for s in streams:
                p = s.get('path')
                if p and os.path.exists(p):
                    f.write(f"file '{os.path.abspath(p)}'\n")

        sample_rate = '44100'
        channels = '2'
        try:
            br_val = int(bitrate.lower().replace('k', '').replace('bps', '').strip())
            if br_val <= 16:
                sample_rate = '8000'
                channels = '1'
            elif br_val <= 32:
                sample_rate = '16000'
                channels = '1'
        except:
            pass

        if output_path.lower().endswith('.ogg'):
            cmd = ['ffmpeg', '-y', '-f', 'concat', '-safe', '0', '-i', list_path, '-c:a', 'libvorbis', '-b:a', bitrate, '-ar', sample_rate, '-ac', channels, output_path]
        else:
            cmd = ['ffmpeg', '-y', '-f', 'concat', '-safe', '0', '-i', list_path, '-b:a', bitrate, '-ar', sample_rate, '-ac', channels, output_path]

        result = subprocess.run(cmd, capture_output=True, text=True)
        if os.path.exists(list_path): os.remove(list_path)

        if result.returncode != 0:
            logger.error(f"[EXPORT] FFmpeg Error: {result.stderr}")
            return False
        return True

    @staticmethod
    def stitch_segments(file_paths, output_path, debug=False):
        """Stitches multiple chronological chunk files together cleanly using FFmpeg."""
        if not file_paths:
            logger.error("[STITCH] No segments to stitch.")
            return False

        sorted_files = sorted(file_paths)
        temp_dir = os.path.dirname(os.path.abspath(output_path))
        if temp_dir and not os.path.exists(temp_dir):
            os.makedirs(temp_dir, exist_ok=True)

        list_path = os.path.join(temp_dir, f"temp_stitch_list_{int(time.time())}.txt")

        try:
            with open(list_path, 'w') as f:
                for p in sorted_files:
                    if p and os.path.exists(p):
                        f.write(f"file '{os.path.abspath(p)}'\n")

            if output_path.lower().endswith('.ogg'):
                cmd = ['ffmpeg', '-y', '-f', 'concat', '-safe', '0', '-i', list_path, '-c:a', 'libvorbis', '-q:a', '10', '-hide_banner', '-loglevel', 'error', output_path]
            else:
                cmd = ['ffmpeg', '-y', '-f', 'concat', '-safe', '0', '-i', list_path, '-c', 'copy', '-hide_banner', '-loglevel', 'error', output_path]

            res = subprocess.run(cmd, capture_output=True, text=True)
            if os.path.exists(list_path): os.remove(list_path)

            return res.returncode == 0
        except Exception as e:
            logger.error(f"[STITCH] Stitch Exception: {e}")
            if os.path.exists(list_path): os.remove(list_path)
            return False

    @staticmethod
    def time_operation(func):
        """Decorator to log execution time of DSP/Pipeline operations."""
        @wraps(func)
        def wrapper(*args, **kwargs):
            debug = kwargs.get('debug', False) or (hasattr(args[0], 'debug') and args[0].debug) if args else False
            start = time.perf_counter()
            result = func(*args, **kwargs)
            end = time.perf_counter()
            if debug: logger.info(f"[DEBUG] {func.__name__} completed in {end-start:.4f}s")
            return result
        return wrapper

    @staticmethod
    def get_standard_parser(description="Forensic Audio Tool"):
        parser = argparse.ArgumentParser(description=description)
        parser.add_argument("--yaml", help="Project YAML configuration (Optional for direct folder hardware verification)")
        parser.add_argument("--tier", default="amp32", help="Audio processing tier. Supports original, enhanced, amp32, plus20, and custom tiers such as amp24 or plus12.")
        parser.add_argument("--start", help="HH:MM, Full Timestamp, or None")
        parser.add_argument("--end", help="HH:MM or Full Timestamp")
        parser.add_argument("--out", help="Output filename")
        parser.add_argument("--train", action="store_true", help="Run in training/sensing mode")
        parser.add_argument("--debug", action="store_true", help="Enable verbose timing and queue details")
        parser.add_argument("--workers", type=int, help="Override concurrent process count")

        # Ingestion, Tidying, Checking & Verification Arguments
        parser.add_argument("--ingest", help="Path, directory, comma-list, or glob pattern of raw media files to process. Example: --ingest 'mvl/fc/*tp*'")
        parser.add_argument("--cam", default="Cam A", help="Camera Label for the ingested file")
        parser.add_argument("--raw-amp-db", type=float, default=32.0, help="Pre-enhancement amplification applied to original extraction. Default: 32")
        parser.add_argument("--enhanced-amp-db", type=float, default=20.0, help="Post-enhancement amplification applied to enhanced audio. Default: 20")
        parser.add_argument("--tidy", action="store_true", help="Standardize project YAML labels")
        parser.add_argument("--check", action="store_true", help="Verify timeline segment consistency & camera mappings.")
        parser.add_argument("--verify-hardware", action="store_true", help="Verify internal stream characteristics via FFmpeg to audit A/B classifications.")
        parser.add_argument("--folder", help="Direct path to a folder of raw MP4 files to audit using physical stream parameters.")
        return parser

class PipelineQueue:
    """Manages forensic task segments with debug transparency and concurrent progress monitoring."""
    def __init__(self, max_workers=2, total_tasks=0, debug=False):
        self.debug = debug
        self.total_tasks = total_tasks
        self.completed_tasks = 0
        self.max_workers = max_workers
        self._lock = threading.Lock()

    def log_action(self, msg):
        if self.debug:
            logger.info(f"[QUEUE] {msg}")

    def progress(self, msg="Processing"):
        with self._lock:
            pct = (self.completed_tasks / self.total_tasks) * 100 if self.total_tasks > 0 else 0
            sys.stdout.write(f"  [{pct:5.1f}%] {msg} ({self.completed_tasks}/{self.total_tasks})\r")
            sys.stdout.flush()

    def increment(self, msg="Processing"):
        with self._lock:
            self.completed_tasks += 1
        self.progress(msg)


if __name__ == "__main__":
    parser = ForensicHelper.get_standard_parser("Forensic Helper CLI Tool")
    parser.add_argument("--query", help="Target time to query active streams")
    args = parser.parse_args()

    if args.check:
        if not args.yaml:
            print("Error: --yaml is required for --check operations.")
            sys.exit(1)
        ForensicHelper.check_consistency(args.yaml)
    elif args.verify_hardware:
        if args.folder:
            ForensicHelper.verify_camera_hardware(folder_path=args.folder)
        elif args.yaml:
            ForensicHelper.verify_camera_hardware(yaml_path=args.yaml)
        else:
            print("Error: You must provide either --folder <path> or --yaml <path> to run hardware verification.")
            sys.exit(1)
    elif args.tidy:
        if not args.yaml:
            print("Error: --yaml is required for --tidy operations.")
            sys.exit(1)
        ForensicHelper.tidy_project(args.yaml)
    elif args.ingest:
        if not args.yaml:
            print("Error: --yaml is required for --ingest operations.")
            sys.exit(1)

        import glob

        media_exts = (
            ".mp4", ".m4v", ".mov", ".avi", ".mkv",
            ".wav", ".ogg", ".flac", ".webm", ".3gp", ".aac", ".m4a"
        )

        def is_media_file(path):
            return os.path.isfile(path) and os.path.splitext(path)[1].lower() in media_exts

        def expand_ingest_targets(spec):
            """
            Expands --ingest into a deterministic list of media files.

            Supports:
              --ingest video.mp4
              --ingest folder/
              --ingest 'folder/*tp*'
              --ingest 'a.mp4,b.wav,c.ogg'

            Quoted globs are intentionally supported here because quoted shell
            globs arrive in Python literally and otherwise fail os.path.exists().
            """
            targets = []

            if not spec:
                return targets

            # Comma list may itself contain globs or directories.
            if ',' in spec:
                for part in spec.split(','):
                    targets.extend(expand_ingest_targets(part.strip()))
                return targets

            # Directory: scan direct children for supported media files.
            if os.path.isdir(spec):
                for name in os.listdir(spec):
                    path = os.path.join(spec, name)
                    if is_media_file(path):
                        targets.append(path)
                return targets

            # Glob pattern: support quoted or unquoted patterns.
            if glob.has_magic(spec):
                for path in glob.glob(spec):
                    if is_media_file(path):
                        targets.append(path)
                return targets

            # Single file path.
            if is_media_file(spec):
                targets.append(spec)
            else:
                targets.append(spec)

            return targets

        ingest_targets = sorted(set(expand_ingest_targets(args.ingest)))

        if not ingest_targets:
            print(f"[!] No ingest targets matched: {args.ingest}")
            print("    Supported media extensions:", ", ".join(media_exts))
            sys.exit(1)

        print(f"[*] Ingest target count: {len(ingest_targets)}")

        if len(ingest_targets) > 1:
            max_workers = args.workers if args.workers else min(4, os.cpu_count() or 2)
            queue = PipelineQueue(max_workers=max_workers, total_tasks=len(ingest_targets), debug=args.debug)
            print(f"\n[*] Initiating Parallel Ingestion with {max_workers} worker threads...")

            def worker_task(target):
                try:
                    # IMPORTANT: use keyword arguments here. The function signature is:
                    # ingest_raw_media(source_path, yaml_path, start_time_str="auto", cam_id="Cam A", out_dir=None, silent=False)
                    # Passing args.cam positionally would incorrectly bind it as out_dir.
                    return ForensicHelper.ingest_raw_media(
                        target,
                        args.yaml,
                        start_time_str=args.start,
                        cam_id=args.cam,
                        silent=True,
                        raw_amp_db=args.raw_amp_db,
                        enhanced_amp_db=args.enhanced_amp_db
                    )
                except Exception as e:
                    logger.error(f"Error ingesting {target}: {e}")
                    return False
                finally:
                    queue.increment("Bulk Ingesting")

            with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
                results = list(executor.map(worker_task, ingest_targets))

            ok = sum(1 for r in results if r)
            failed = len(results) - ok
            print(f"\n[*] Bulk Ingestion completed. Success: {ok} | Failed: {failed}")
            if failed:
                sys.exit(1)
        else:
            ForensicHelper.ingest_raw_media(
                ingest_targets[0],
                args.yaml,
                start_time_str=args.start,
                cam_id=args.cam,
                raw_amp_db=args.raw_amp_db,
                enhanced_amp_db=args.enhanced_amp_db
            )
    elif args.query:
        if not args.yaml:
            print("Error: --yaml is required for --query operations.")
            sys.exit(1)
        ForensicHelper.print_active_streams(args.yaml, args.query, args.end)
    else:
        print("\nCommands:")
        print("  Check Mappings: python forensic_helper.py --check --yaml project.yaml")
        print("  Verify Folder:  python forensic_helper.py --verify-hardware --folder /path/to/mp4s")
        print("  Verify YAML:    python forensic_helper.py --verify-hardware --yaml project.yaml")
        print("  Tidy Project:   python forensic_helper.py --tidy --yaml project.yaml")
        print("  Ingest Media:   python forensic_helper.py --ingest video.mp4 --yaml project.yaml --cam 'Cam A'")
        print("  Custom Gains:   python forensic_helper.py --ingest video.mp4 --yaml project.yaml --raw-amp-db 24 --enhanced-amp-db 12")
        print("  Query Timeline: python forensic_helper.py --query '2023-10-10 15:00' --yaml project.yaml\n")
