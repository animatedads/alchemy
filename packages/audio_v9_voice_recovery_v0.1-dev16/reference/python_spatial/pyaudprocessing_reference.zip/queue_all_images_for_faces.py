#!/usr/bin/env python3
"""Queue every indexed image in POI Shuttle for face detection.

This is a tiny command-line client.  It does not scan folders itself; it calls
POI Shuttle's API endpoint so the server owns the queue, SQLite state, and
background worker.

Example:
  python queue_all_images_for_faces.py --url https://127.0.0.1:8081 --insecure
  python queue_all_images_for_faces.py --url https://127.0.0.1:8081 --threshold 0.82 --min-dates 2
"""
import argparse
import json
import ssl
import sys
import urllib.error
import urllib.request


def main() -> int:
    ap = argparse.ArgumentParser(description="Queue all POI Shuttle image media for face detection")
    ap.add_argument("--url", default="https://127.0.0.1:8081", help="POI Shuttle base URL")
    ap.add_argument("--threshold", type=float, default=0.82, help="Face-cluster similarity threshold")
    ap.add_argument("--include-excluded", action="store_true", help="Also queue media marked excluded")
    ap.add_argument("--no-auto-temp-poi", action="store_true", help="Disable automatic temporary POI assignment")
    ap.add_argument("--min-dates", type=int, default=2, help="Minimum distinct dates before a face cluster becomes a temporary POI")
    ap.add_argument("--limit", type=int, default=None, help="Queue at most this many images for a test run")
    ap.add_argument("--insecure", action="store_true", help="Disable TLS verification for local self-signed certs")
    args = ap.parse_args()

    payload = {
        "threshold": args.threshold,
        "include_excluded": bool(args.include_excluded),
        "auto_temp_poi": not args.no_auto_temp_poi,
        "auto_min_dates": max(2, int(args.min_dates or 2)),
        "limit": args.limit,
    }
    data = json.dumps(payload).encode("utf-8")
    endpoint = args.url.rstrip("/") + "/api/faces/scan-all-images"
    req = urllib.request.Request(endpoint, data=data, headers={"Content-Type": "application/json"}, method="POST")
    ctx = ssl._create_unverified_context() if args.insecure else None
    try:
        with urllib.request.urlopen(req, timeout=120, context=ctx) as resp:
            body = resp.read().decode("utf-8", errors="replace")
            print(body)
            parsed = json.loads(body)
            print(f"Queued job #{parsed.get('job_id')} for {parsed.get('selected_images', parsed.get('media_count'))} images")
            if parsed.get("auto_temp_poi"):
                print(f"Automatic temporary POI assignment enabled for face clusters seen on >= {parsed.get('auto_min_dates')} dates")
            return 0
    except urllib.error.HTTPError as e:
        print(f"HTTP {e.code}: {e.read().decode('utf-8', errors='replace')}", file=sys.stderr)
        return 2
    except Exception as e:
        print(f"ERROR: {e}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
