# ooRexx Job-to-Node Allocator v0.2

Authority-constrained placement for deciding where a job may and can execute.

## Core rule

Hard eligibility is evaluated before optimisation. Security, legal, access,
runtime, software, architecture and mandatory resource constraints are never
soft scores and cannot be outweighed by idle CPU, free storage, cost or speed.

## v0.2

v0.2 preserves the v0.1 API concepts and adds:

- external hard-constraint assessors for Security/Permissions/Legal Effect adapters;
- ranked admission after eligibility and scoring;
- fallback to the next eligible node when authoritative admission/reservation fails;
- WLU v0.12 admission adapter using the real `WLUWorkDemand` surface;
- WLU reservation identity bound into the placement lease;
- placement release which releases the associated admission reservation;
- queue-neutral dispatch envelope preserving owner node, execution node and placement lease;
- unchanged API Client v0.2 boundary: general placement precedes, but does not own, API egress-session reservation.

## Placement sequence

`Job requirements -> hard eligibility -> eligible candidates -> fitness ranking -> authoritative admission/WLU reservation -> placement lease -> Queue Fabric delivery`

For API work:

`general placement -> execution node -> API Client route/session reservation -> fetch -> completion to owner`

The two reservations are intentionally distinct.

## Authority adapters

`JobNodeHardConstraintAssessor` is the fail-closed integration seam for external
Security, Permissions and Legal Effect decisions. An assessor contributes reason
codes to eligibility. It has no scoring surface.

`JobNodeAdmissionAuthority` is the post-ranking reservation seam. Admission is
attempted in deterministic score order; denial causes the allocator to try the
next already-eligible node.

`JobNodeWLUAdmission` adapts WLU v0.12 `reserveDemand` / `release` and records the
returned reservation ID in `JobNodePlacementLease.reservationRef`.

## Dependencies used for qualification

- ooRexx 5.3.0 r13196
- ooRexx Crypto v0.8.3
- Work Load Units v0.12
- Alchemy Objects (dependency of WLU)
- API Client v0.2

Queue Fabric remains the transport/delivery authority. `JobNodeDispatchEnvelope`
is deliberately queue-neutral so a Queue Fabric adapter can transport it without
moving placement policy into Queue Fabric.

## v0.3

v0.3 is rebased/qualified against `oorexxapis(20260901-105155).zip` and adds direct adapters for the existing authority decision objects:

- Security Effect v0.10 `SecurityAssessment` (`ALLOW`/`CAUTION` executable; review/hold/reject fail closed for automatic placement),
- Legal Effect v0.14 `LegalEffectAssessment` (automatic placement requires `ADMISSIBLE`),
- Access Permissions v0.1 `AccessControlDecision` and `PermissionDecision` (`allowed` must be true),
- Queue Fabric v0.9-dev4 dispatch through `ObjectQueueManager~put` while preserving placement identity in correlation/header metadata.

These decisions remain hard eligibility inputs and are never converted into placement scores. Queue Fabric remains transport authority; the allocator remains placement authority. API Client v0.2 continues to own outbound API egress-session allocation after general execution-node placement.
