#!/usr/bin/env bash
set -euo pipefail
log=${FAKE_COLAB_LOG:?}
printf '%q ' "$@" >> "$log"; printf '\n' >> "$log"
cmd=""
for a in "$@"; do case "$a" in new|upload|download|install|exec|log|rm|stop|status) cmd=$a; break;; esac; done
if [[ "${FAKE_COLAB_FAIL_CMD:-}" == "$cmd" ]]; then echo "forced failure: $cmd" >&2; exit 7; fi
case "$cmd" in
  download)
    local="${@: -1}"; mkdir -p "$(dirname "$local")"; printf 'artifact\n' > "$local";;
  log)
    local="${@: -1}"; mkdir -p "$(dirname "$local")"; printf '{"event":"fake"}\n' > "$local";;
  *) :;;
esac
exit 0
