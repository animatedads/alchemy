say .JobNodeRequirement
j=.JobNodeRequirement~new
say j
::requires '../../job_node_allocator_v0.3/job_node_allocator_v0.3/src/JobNodeAllocator.cls'
