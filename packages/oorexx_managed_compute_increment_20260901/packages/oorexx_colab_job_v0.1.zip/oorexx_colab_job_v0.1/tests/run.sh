#!/usr/bin/env bash
set -euo pipefail
REXX_BIN=${REXX_BIN:-rexx}
cd "$(dirname "$0")"
"$REXX_BIN" test_core.rex
"$REXX_BIN" test_allocator.rex
