/* Contract-only example: does not run unless paths and credentials are real. */
req=.ColabJobRequirement~new("GPU","T4",.false,16384,30720,.true,.true)
inputs=.array~of(.ColabInputFile~new("corpus_bundle.zip","corpus_bundle.zip"))
outputs=.array~of(.ColabOutputFile~new("outputs/training-report.json","./training-report.json"), -
                  .ColabOutputFile~new("outputs/model.tar.gz","./model.tar.gz"))
env=.directory~new
env["HF_HOME"]="/content/oorexx-job-gemma-oorexx-recovery/hf-cache"
deps=.array~of("torch","transformers","datasets","accelerate")
spec=.ColabJobSpec~new("gemma-oorexx-recovery",req,"train_gemma_oorexx.py", -
  .array~of("--input","corpus_bundle.zip","--base","google/gemma-2-2b-it","--vocab-target","65536","--recovery-steps","100","--output","outputs"), -
  env,deps,inputs,outputs,7200,.false)
say "job="spec~jobId
say "requirements="req~canonical
say "Default behavior is teardown. Invoke .ColabJobRunner~run(spec) only with authenticated Colab CLI state."
::requires "../src/ColabJob.cls"
