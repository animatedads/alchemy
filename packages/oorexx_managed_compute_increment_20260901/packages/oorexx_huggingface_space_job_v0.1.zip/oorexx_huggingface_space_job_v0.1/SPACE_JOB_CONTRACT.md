# Managed Space Job Contract v0.1

This is the server-side contract expected by `HFSpaceJobRunner`. It is intentionally narrow enough to avoid turning a public Space into a generic remote shell.

## Endpoint tiers

A compatible Gradio Space should expose named endpoints equivalent to:

- `job_cpu` — ordinary CPU function, no `@spaces.GPU` decoration;
- `job_large` — ZeroGPU `large` function (48 GiB tier, 1x quota);
- `job_xlarge` — ZeroGPU `xlarge` function (96 GiB tier, 2x quota).

The exact names are configurable in `HFSpaceTarget`.

## Control envelope

The runner supplies `_job` by default:

```json
{
  "job_id": "gemma-recovery-acceptance",
  "operation_id": "GEMMA_OOREXX_RECOVERY_V1",
  "cleanup_remote": true,
  "tier": "ZEROGPU_LARGE",
  "expected_gpu_seconds": 100,
  "checkpointable": true
}
```

The Space must validate `operation_id` against an allowlist. Unknown operations fail closed. The client is never allowed to supply a shell command that the Space executes verbatim.

## Inputs

Files are uploaded first through `/gradio_api/upload`; the endpoint receives normal Gradio `FileData` values. The Space should copy them into a job-specific temporary directory, never trust the client filename as a path, and apply its own size/type validation.

## Cleanup

The operation owns a job-specific temporary workspace. Cleanup belongs in a server-side `finally` path. A successful response should only report:

```json
"cleanup": "DONE"
```

after the temporary execution workspace has actually been removed or reduced to explicitly retained artifacts/checkpoints.

## Result

The terminal result is a JSON object (or a one-element array containing it):

```json
{
  "status": "COMPLETED",
  "cleanup": "DONE",
  "artifacts": [
    {"name": "training-report.json", "url": "https://<same-space-host>/..."}
  ]
}
```

Within each artifact entry the runner accepts `name`/`url`, or `orig_name`/`path` for a Gradio FileData-style path. Downloads are restricted to the exact resolved Space host.

## Gemma acceptance operation

`GEMMA_OOREXX_RECOVERY_V1` is a suitable first allowlisted operation: fixed training implementation, input corpus bundle, base-model/vocabulary/recovery-step parameters, bounded output set, and no arbitrary command execution. The Space layer should call the installed training implementation; the ooRexx HF runner remains ignorant of Gemma internals.
