# ooRexx Hugging Face Space Job v0.1

Generic managed execution of an authorised workload endpoint hosted by a Hugging Face Gradio Space.

This package is a sibling of the Colab Job class, not a replacement for it:

- **Colab** is naturally ephemeral compute: allocate -> stage -> execute -> retrieve -> release.
- **Hugging Face Space** is a persistent application target: inspect/discover -> upload bounded inputs -> invoke an authorised endpoint -> consume finite SSE result -> retrieve bounded artifacts -> require cleanup evidence.

The workload remains provider-neutral. Gemma/ooRexx training is only an example operation; no Gemma, tokenizer, QLoRA or training implementation is embedded in this package.

## Transport boundary

Every HTTP operation goes through ooRexx API Client v0.3. There is no `curl` subprocess and no `gradio_client` dependency.

The Gradio path implemented here is the current documented direct HTTP contract:

1. optional Space discovery through `GET https://huggingface.co/api/spaces/<namespace>/<repo>`;
2. file upload through `POST /gradio_api/upload` multipart form data;
3. named v2 submission through `POST /gradio_api/call/v2/<endpoint>` (v1 `data` mode is also supported);
4. finite result stream through `GET /gradio_api/call/<endpoint>/<event_id>`;
5. SSE terminal `event: complete` parsing;
6. same-Space artifact retrieval.

`apiInfo`, `openApi` and `agentsMarkdown` provide introspection seams for the Space's current API description.

## Credential handling

`HFTokenCredential` takes a token-file path. It:

- rejects a missing file;
- uses `SysFileTree` to require Unix mode `0600` (`-rw-------`);
- reads the token only when constructing an authenticated request;
- never copies the token into the Gradio payload;
- never places the token in evidence;
- has no Git, repository-write, Space-settings or hardware-mutation method.

A token that happens to have write scope therefore does **not** turn a compute job into deployment authority.

## ZeroGPU policy

ZeroGPU is modelled as a quota-limited execution capability, not as a dedicated VM assigned by this runner.

`HFSpaceJobRequirement` maps hard VRAM requirements to:

- CPU: no GPU quota;
- `ZEROGPU_LARGE`: up to 48 GiB VRAM, quota factor 1;
- `ZEROGPU_XLARGE`: above 48 GiB and up to 96 GiB, quota factor 2;
- above 96 GiB: ineligible.

`HFZeroGpuQuotaBudget` defaults to **zero**, deliberately. The caller must configure the account's observed/allowed quota. For a PRO account configured with the documented 40-minute included allowance, an example is:

```rexx
budget=.HFZeroGpuQuotaBudget~new(2400,2400,.false,"HF_PRO_INCLUDED_NOMINAL")
```

2400 seconds represents the documented 40-minute PRO included daily allowance. Paid-credit spillover requires **both** site policy (`paidCreditsEnabled`) and the individual job (`allowPaidCredits`) to opt in. The budget never resets itself based on a guessed wall-clock boundary; `resetFromAuthority` exists for an authoritative/observed refresh.

Quota is assessed before input upload, then reserved immediately before submission. This avoids spending a local reservation when staging fails while still re-checking against concurrent reservations before a GPU operation is launched.

## Managed remote-operation authority

`HFSpaceJobRunner` requires an explicit `operationId`. The runner sends this in the `_job` control envelope together with job id, tier, expected GPU seconds, checkpointability and `cleanup_remote=true`.

**Do not deploy a public arbitrary-shell endpoint.** The Space side must allowlist operation IDs and dispatch only installed workload implementations. See `SPACE_JOB_CONTRACT.md`.

## File citizenship

v0.1 validates all local input paths before quota/network use, bounds each in-memory Gradio upload (default 256 MiB), sanitizes local artifact filenames, only downloads from the exact Space host, and requires `cleanup="DONE"` evidence by default.

Large model/corpus transfer is intentionally not misrepresented as solved by this first increment. Multi-GB artifacts should use a later streaming file-sink/source transport or an authorised Hub model/dataset/bucket publication path rather than materialising the entire file in an ooRexx string.

## Allocator seam

`HuggingFaceAllocatorAdapter.cls` maps the requirement into Job-to-Node Allocator v0.3 hard eligibility:

- CPU work gets `CPU_ONLY_OK` and never requests `GPU`;
- GPU work requires `GPU` plus `HF_ZEROGPU_LARGE` or `HF_ZEROGPU_XLARGE` tags;
- scoring cannot turn a CPU job into a GPU job or overcome an ineligible VRAM tier.

The API Client's `ApiRouteRequirement` remains separate and authoritative for egress selection.

## Qualified dependencies

- ooRexx 5.3.0 r13196 Internal Test Version
- ooRexx API Client v0.3
- Foreign Runtime v0.22.5
- Job-to-Node Allocator v0.3 (optional adapter)
- Crypto v0.8.3 (allocator dependency)

No live Space or ZeroGPU time was consumed during v0.1 qualification. The end-to-end test uses a local TLS fixture that implements the Hub/Gradio upload -> v2 submit -> chunked SSE -> artifact contract.
