# Architecture

```
Generic compute workload
        |
        | hard resource requirements
        v
Job-to-Node Allocator
        |
        +---- eligible HF Space target
                   |
                   | API egress requirement
                   v
ooRexx API Client v0.3
        |
        +---- HTTPS / multipart upload
        +---- Gradio v2 submit
        +---- finite SSE result
        +---- artifact GET
                   |
                   v
        authorised Space operation
```

The allocator and API Client remain independent authorities. The allocator says whether the execution target is capable/permitted. API Client says how outbound traffic is routed and admitted. `HFSpaceJobRunner` composes them; it does not duplicate either.

## ZeroGPU

The Space itself is configured for ZeroGPU. `job_large` and `job_xlarge` are separate endpoint contracts so their Python implementations can carry the appropriate `@spaces.GPU(size=...)` decoration. CPU work uses a non-GPU endpoint. The ooRexx caller never upgrades Space hardware merely because a GPU might be faster.

## Failure ordering

1. local file validation;
2. endpoint eligibility;
3. quota preflight;
4. input upload;
5. quota reservation;
6. authenticated submit;
7. SSE completion;
8. remote cleanup evidence;
9. artifact download.

This ordering avoids VM/GPU work for malformed local requests and prevents silent paid-quota escalation.

## Security boundary

The API token authenticates the HTTP caller. It is not a bearer capability for arbitrary remote code execution. The remote Space service must independently map `operation_id` to an installed, allowed workload implementation and must not accept an arbitrary shell command, script path, environment injection or repository mutation from the client.

Deployment/push authority is a different plane and deliberately absent from this package.
