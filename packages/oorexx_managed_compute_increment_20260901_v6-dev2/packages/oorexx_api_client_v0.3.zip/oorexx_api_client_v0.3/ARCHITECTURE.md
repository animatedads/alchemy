# Architecture

The v0.2 authority model remains intact: `ApiRequest` never selects a host or VPN itself. Mandatory network/legal properties remain in `ApiRouteRequirement`; `ApiEgressRegistry` advertises capability; `ApiSessionManager` creates a bounded egress session; WLU admission happens only after routing.

v0.3 adds a native transport implementation without collapsing those layers.

```
provider adapter
  -> ApiClient~execute / submit
  -> route/session eligibility
  -> WLU admission
  -> ApiHttpsTransport
       -> RxSock TCP
       -> Foreign Runtime
       -> OpenSSL memory BIO TLS
       -> HTTP/1.1 framing
  -> ApiResponse
  -> rate observation / completion authority
```

`ApiClient~execute(request)` exists for protocol adapters (for example a Gradio/Hugging Face adapter) that already own a single synchronous operation. It uses exactly the same route, admission, accounting and completion machinery as queued work; it does not bypass egress policy.

## TLS boundary

Private keys are not involved: this is a client transport. Peer validation is on by default. Hostname verification is configured in OpenSSL before the handshake and SNI is sent independently. Disabling verification is a configuration capability, not the default, and was not used for qualified endpoint tests.

## Streaming boundary

The HTTP transport can receive chunked SSE and `ApiSseParser` preserves event/data/id/retry fields. v0.3 collects the finite HTTP body before parsing it. Provider adapters must therefore use this only for streams with a terminal response/close contract. Indefinitely-open event feeds require a later incremental streaming callback API.
