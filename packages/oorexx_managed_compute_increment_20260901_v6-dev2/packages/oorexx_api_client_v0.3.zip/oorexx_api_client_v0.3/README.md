# ooRexx API Client v0.3

Provider-neutral outbound API execution with managed egress sessions and a native HTTPS transport.

v0.3 preserves the v0.2 separation between API work, route authority, WLU admission and completion routing, and adds an executable HTTPS/HTTP/1.1 transport implemented in ooRexx over RxSock and Foreign Runtime/OpenSSL. It does **not** shell out to curl.

## Execution path

`ApiRequest -> ApiClient -> ApiRouteRequirement -> ApiSessionManager -> admission -> ApiTransport -> endpoint -> ApiResponse`

`ApiClient~execute(request)` is the synchronous one-request seam for protocol/provider adapters. `submit` / `executeNext` / `drain` remain the scheduler path.

## Native HTTPS transport

`ApiHttpsTransport` provides:

- HTTPS only, with DNS/IPv4 host URLs;
- RxSock TCP ownership;
- OpenSSL TLS through Foreign Runtime memory BIOs;
- TLS 1.2 minimum, SNI, certificate-chain verification and hostname verification;
- bounded response headers and bodies;
- HTTP/1.1 `Content-Length`, chunked transfer decoding and connection-close bodies;
- binary request/response strings;
- SSE parsing through `ApiSseParser`;
- explicit timeouts and fail-closed transport errors.

The v0.3 transport deliberately uses `Connection: close`. Connection pooling, HTTP/2, proxy CONNECT, IPv6 URL literals, redirects and incremental callback delivery of indefinitely-open SSE streams are later transport increments. Finite SSE jobs whose server closes the stream after completion are qualified.

## Dependencies

- ooRexx 5.3.0 r13196 or compatible
- RxSock (`socket.cls` / `librxsock`)
- Foreign Runtime v0.22.5
- OpenSSL 3.x runtime libraries

The three bridge declarations under `bridge/` are part of this package. They are ABI declarations; Foreign Runtime remains the native FFI authority.
