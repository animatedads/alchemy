# Family
Regenerated fixture resource.
