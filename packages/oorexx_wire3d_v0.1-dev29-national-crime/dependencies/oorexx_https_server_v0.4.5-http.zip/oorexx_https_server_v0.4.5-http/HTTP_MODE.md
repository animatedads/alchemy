ooRexx HTTPS Server v0.4.5-http
Adds transportMode=HTTP while retaining HTTPS as the default.
HTTP mode uses RxSock directly and does not construct a TLS context.
